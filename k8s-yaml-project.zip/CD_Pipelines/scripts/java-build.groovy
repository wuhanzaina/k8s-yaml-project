#!/usr/bin/env groovy

String branch = "cloud-deployments/master"
boolean deploy = "${deploy}"
String env = "prod"

// 基础的git地址
String gitFolder = "ServiceSrc"
String projectName = "sdw-reqs-manage"
String moduleName = "sdw-reqs-manage"
String end = "backend"


node{

    sh "echo 'this branch is ${branch}'"

    sh "cp -f /data/ansible/vars/env.yml /data/tmp/${moduleName}-${env}.yml"
    sh "sed -i 's#profile: .*#profile: ${env}#g' /data/tmp/${moduleName}-${env}.yml"
    sh "sed -i 's#end: .*#end: ${end}#g' /data/tmp/${moduleName}-${env}.yml"
    sh "sed -i 's#branch: .*#branch: ${branch}#g' /data/tmp/${moduleName}-${env}.yml"
    sh "sed -i 's#gitFolder: .*#gitFolder: ${gitFolder}#g' /data/tmp/${moduleName}-${env}.yml"
    sh "sed -i 's#projectName: .*#projectName: ${projectName}#g' /data/tmp/${moduleName}-${env}.yml"
    sh "sed -i 's#filePrefix: .*#filePrefix: ${moduleName}#g' /data/tmp/${moduleName}-${env}.yml"

    stage("代理编译打包和上传镜像"){
        sh "ansible-playbook -i /data/ansible/inventory.ini /data/ansible/jenkins-python.yml -e '@/data/tmp/${moduleName}-${env}.yml'"
    }

    if(deploy) {
        stage("部署") {
            sh "ansible-playbook -i /data/ansible/inventory.ini /data/ansible/proxy.yml -e '@/data/tmp/${moduleName}-${env}.yml'"
        }
    }

}
