# 提供基于容器平台Kubesphere的部署脚本

### 完整实施步骤:

## 1.外网访问环境192.168.52.66上使用docker安装nginx, vsftpd  
#### > 安装vsftpd  
docker run -d -v /home/mnt/vsftp/ftpfile/sdwftp:/home/vsftpd -p 20:20 -p 21:21 -p 21100-21110:21100-21110 -e FTP_USER=myuser -e FTP_PASS=mypass -e PASV_ADDRESS=127.0.0.1 -e PASV_MIN_PORT=21100 -e PASV_MAX_PORT=21110 --name vsftpd --restart=always fauria/vsftpd  

#### > 安装nginx

// 测试环境容器名为nginx
docker run --name nginx -d -p 80:80 -p 81:81 -p 82:82 -p 83:83 -v /root/nginx/templates/default.conf:/etc/nginx/conf.d/default.conf  -v /root/nginx/templates/nginx.conf:/etc/nginx/nginx.conf  -v /home/mnt/vsftp/ftpfile/sdwftp/:/home/mnt/vsftp/ftpfile/sdwftp nginx:1.17.9-alpine  
(请参见CD_Pipelines/docker/nginx/配置)

// 生产环境容器名为gateway, 原因是nginx已被harbor占用
docker run --name gateway -d -p 80:80 -p 81:81 -p 82:82 -p 83:83 -v /root/nginx/templates/default.conf:/etc/nginx/conf.d/default.conf  -v /root/nginx/templates/nginx.conf:/etc/nginx/nginx.conf  -v /home/mnt/vsftp/ftpfile/sdwftp/:/home/mnt/vsftp/ftpfile/sdwftp nginx:1.17.9-alpine