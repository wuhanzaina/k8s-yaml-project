> 1. nginx部署在172.16.0.80这个机器上, 以容器部署
> 2. 172.16.0.80能访问PVE中的虚拟机如K8S集群(172.16.0.80~84)
> 3. 迁移后的前后端服务均部署在K8S集群(80~84)环境
> 4. 前后端代码均存放在DMZ区, CI/CD工具jenkins为172.16.0.80:30000服务
> 5. 前端代码和Python工程由于需要下载依赖包, 无法在41上的jenkins中进行构建, 故这里是透过41的jenkins发送构建任务到192.168.52.165机器上进行前端和Python项目的编辑打包, 最后将镜像回传至41机器
> 6. docker启动vsftpd:  
     docker run -d -v /data/vsftpd:/home/vsftpd -p 30088:20 -p 30089:21 -p 31100-31200:31100-31200 -e FTP_USER=sdwftp -e FTP_PASS=kotei@2022 -e PASV_MIN_PORT=31100 -e PASV_MAX_PORT=31200 -e PASV_ADDRESS=192.168.146.12 -e FILE_OPEN_MODE=0777 -e LOCAL_UMASK=022 --privileged --name vsftpd --restart=always fauria/vsftpd
> 7. docker启动nginx:  
     Server-80: docker run --name gateway -d -p 80:80 -p 443:443 -p 32123:32123 -p 32124:32124 -p 32742-32750:32742-32750 -v /root/nginx/templates/default.conf:/etc/nginx/conf.d/default.conf  -v /root/nginx/templates/nginx.conf:/etc/nginx/nginx.conf  -v /data/vsftpd/sdwftp/:/data/vsftpd/sdwftp -v /root/nginx/certs:/certs --restart=always nginx
     Server-16: docker run --name gateway -d -p 80:80 -p 443:443 -p 30920:30920 -p 32745:32745 -p 32746:32746 -p 32747:32747 -p 32759:32759 -v /root/nginx/templates/default.conf:/etc/nginx/conf.d/default.conf  -v /root/nginx/templates/nginx.conf:/etc/nginx/nginx.conf  -v /data/vsftpd/sdwftp/:/data/vsftpd/sdwftp -v /root/nginx/certs:/certs --restart=always nginx
     == Deprecated>> docker run --name gateway -d -p 80:80 -v /root/nginx/templates/default.conf:/etc/nginx/conf.d/default.conf  -v /root/nginx/templates/nginx.conf:/etc/nginx/nginx.conf  -v /data/vsftpd/sdwftp/:/data/vsftpd/sdwftp --restart=always nginx
         *  (其中要记得把ftp的文件路径在nginx容器中挂载出来)
         * 新增https协议访问后, 去掉80端口, 增加443端口暴露, 增加证书路径/root/nginx/certs挂载至容器内/certs
> 8. 
