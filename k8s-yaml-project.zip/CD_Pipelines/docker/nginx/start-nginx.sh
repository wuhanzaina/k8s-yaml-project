#!/bin/sh
# This script is baked into the appsmith-editor Dockerfile and is used to boot Nginx when the Docker container starts
# Refer: /app/client/Dockerfile
set -ue
cat /nginx.conf.template > /etc/nginx/conf.d/default.conf
cat /nginx-root.conf.template > /etc/nginx/nginx.conf
exec nginx -g 'daemon off;'
