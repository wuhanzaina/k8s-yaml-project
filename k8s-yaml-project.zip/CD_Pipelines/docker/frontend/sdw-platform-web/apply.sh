#!/bin/sh
# sdw-platform-web

name=`kubectl get deploy -nsmart-develop-prod | grep sdw-platform-web |awk '{print $1}'`
echo ${name}
if [[ ${name} = 'sdw-platform-web' ]];then
          echo `kubectl delete -f /home/jenkins/agent/workspace/devops/sdw-platform/sdw-platform-web/k8s/frontend/sdw-platform-web/sdw-platform-web-prod.yaml`
          echo `kubectl apply -f /home/jenkins/agent/workspace/devops/sdw-platform/sdw-platform-web/k8s/frontend/sdw-platform-web/sdw-platform-web-prod.yaml`
else
          echo `kubectl apply -f /home/jenkins/agent/workspace/devops/sdw-platform/sdw-platform-web/k8s/frontend/sdw-platform-web/sdw-platform-web-prod.yaml`
fi
