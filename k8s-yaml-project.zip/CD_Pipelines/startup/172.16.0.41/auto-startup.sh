#!/bin/bash

vsftpd=`docker ps|grep vsftpd|grep -v 'grep'|awk '{print $1}'|wc -l`
gateway=`docker ps|grep gateway|grep -v 'grep'|awk '{print $1}'|wc -l`
harbor=`docker ps|grep harbor|grep -v 'grep'|awk '{print $1}'|wc -l`
if [ "$1" = "start" ];then

  if [[ $vsftpd -lt 1 ]];then
    docker run -d -v /home/mnt/vsftp/ftpfile:/home/vsftpd -p 30088:20 -p 30089:21 -p 31100-31110:31100-31110 -e FTP_USER=sdwftp -e FTP_PASS=kotei@2022 -e PASV_MIN_PORT=31100 -e PASV_MAX_PORT=31110 -e PASV_ADDRESS=172.16.0.41 -e FILE_OPEN_MODE=0777 -e LOCAL_UMASK=022 --privileged --name vsftpd --restart=always fauria/vsftpd
    echo 'vsftpd is running...'
    else
      echo 'vsftpd 【ON】'
  fi

  if [[ $gateway -lt 1 ]];then
    docker run --name gateway -d -p 80:80 -p 30011:30011 -p 30012:30012 -p 30013:30013 -p 30300:30300 -p 30880:30880 -v /root/nginx/templates/default.conf:/etc/nginx/conf.d/default.conf  -v /root/nginx/templates/nginx.conf:/etc/nginx/nginx.conf  -v /home/mnt/vsftp/ftpfile/sdwftp/:/home/mnt/vsftp/ftpfile/sdwftp --restart=always nginx
    echo 'gateway is running...'
    else
      echo 'gateway 【ON】'
  fi

  if [[ $harbor -lt 9 ]];then
    cd /root/harbor && docker-compose up -d
    echo 'harbor is running...'
    else
      echo 'harbor 【ON】'
  fi
  echo '### Services started ###'
elif [ "$1" = "stop" ];then

  if [[ $vsftpd -gt 0 ]];then
    docker rm --force vsftpd
    echo 'vsftpd is stopped...'
    else
      echo 'vsftpd 【OFF】'
  fi

  if [[ $gateway -gt 0 ]];then
    docker rm --force gateway
    echo 'gateway is stopped...'
    else 
      echo 'gateway 【OFF】'
  fi

  if [[ $harbor -gt 0 ]];then
    cd /root/harbor && docker-compose down
    echo 'harbor is stopped...'
    else
      echo 'harbor 【OFF】'
  fi
  echo '### Services stopped ###'
else
  echo 'Please input like this:"./auto-startup.sh start" or "./auto-startup.sh stop"'
fi
