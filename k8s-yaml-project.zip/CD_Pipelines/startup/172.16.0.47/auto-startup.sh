#!/bin/bash

keycloak=`docker ps|grep keycloak|grep -v 'grep'|awk '{print $1}'|wc -l`
if [ "$1" = "start" ];then
  if [[ $keycloak -lt 2 ]];then
    cd /root/compose-keycloak && docker-compose up -d
    echo 'Keycloak is running...'
    else
      echo 'keycloak 【ON】'
  fi
  echo '### Services started ###'
elif [ "$1" = "stop" ];then
  if [[ $keycloak -gt 0 ]];then
    cd /root/compose-keycloak && docker-compose down
    echo 'Keycloak is stopped...'
    else
      echo 'keycloak 【OFF】'
  fi
  echo '### Services stopped ###'
else
  echo 'Please input like this:"./auto-startup.sh start" or "./auto-startup.sh stop"'
fi
