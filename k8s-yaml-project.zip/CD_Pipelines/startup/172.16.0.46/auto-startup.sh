#!/bin/bash

hasura=`docker ps|grep hasura |grep -v 'grep'|awk '{print $1}'|wc -l`
if [ "$1" = "start" ];then
  if [[ $hasura -lt 3 ]];then
    cd /root/hasura-compose && docker-compose up -d
    echo 'Hasura is running...'
    else
      echo 'Hasura 【ON】'
  fi

  echo '### Services started ###'
elif [ "$1" = "stop" ];then
  if [[ $hasura -gt 0 ]];then
    cd /root/hasura-compose && docker-compose down
    echo 'Hasura is stopped...'
    else
      echo 'Hasura 【OFF】'
  fi

  echo '### Services stopped ###'
else
  echo 'Please input like this:"./auto-startup.sh start" or "./auto-startup.sh stop"'
fi
