#!/bin/bash

appsmith=`docker ps|grep appsmith |grep -v 'grep'|awk '{print $1}'|wc -l`
if [ "$1" = "start" ];then
  if [[ $appsmith -lt 6 ]];then
    cd /root/appsmith-compose && docker-compose up -d
    echo 'Appsmith is running...'
    else
      echo 'Appsmith 【ON】'
  fi

  echo '### Services started ###'
elif [ "$1" = "stop" ];then
  if [[ $appsmith -gt 0 ]];then
    cd /root/appsmith-compose && docker-compose down
    echo 'Appsmith is stopped...'
    else
      echo 'Appsmith 【OFF】'
  fi

  echo '### Services stopped ###'
else
  echo 'Please input like this:"./auto-startup.sh start" or "./auto-startup.sh stop"'
fi
