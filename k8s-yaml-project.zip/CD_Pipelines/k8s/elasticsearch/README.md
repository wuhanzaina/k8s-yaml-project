```
ES安装版本使用的是官方8.4.1 docker镜像

1. 在k8s中部署单节点v8.4.1 ES, 注意如下3个配置
   - discovery.type = single-node // 指定单节点模式
   - xpack.security.enabled = false // ES 8+版本默认使用SSL认证进行数据加密传输
   - plugins挂载路径/elasticsearch/plugins

2. 安装分词器ik
   请将ik.tar.gz上传至k8s节点上, 解压并放置在es的plugins挂载路径上, elasticsearch.yaml中plugins对应宿主机挂载路径为/elasticsearch/plugins
   (注意: /elasticsearch/plugins/目录下只能存放解压后的ik分词器文件夹, 原压缩文件ik.tar.gz不能在该目录下存放, 否则会出现安装失败的错误)
