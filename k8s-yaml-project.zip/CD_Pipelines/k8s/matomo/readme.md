
修改config/config.ini.php文件，在[General]下增加
trusted_hosts[] = "192.168.146.16:30990"
enable_trusted_host_check = 0
login_url = "http://192.168.146.16/webanalytics"