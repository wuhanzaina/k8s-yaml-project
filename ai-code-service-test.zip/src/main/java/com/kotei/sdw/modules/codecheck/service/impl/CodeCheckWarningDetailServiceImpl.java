/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:CodeCheckWarningDetailServiceImpl.java
 * 创建日期:2024-03-28
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.codecheck.entity.CodeCheckWarningDetail;
import com.kotei.sdw.modules.codecheck.mapper.CodeCheckWarningDetailMapper;
import com.kotei.sdw.modules.codecheck.service.CodeCheckWarningDetailService;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 *
 * 代码静态扫描警告明细表 ServiceImpl
 *
 *
 * @author tiger
 * @since 2024-03-28
 */
@Service
public class CodeCheckWarningDetailServiceImpl extends BaseServiceImpl<CodeCheckWarningDetail> implements CodeCheckWarningDetailService {
    @Autowired
    private CodeCheckWarningDetailMapper codeCheckWarningDetailMapper;

    @Override
    protected BaseMapper<CodeCheckWarningDetail> getMapper() {
        return codeCheckWarningDetailMapper;
    }

    /**
     * @brief Get a CodeCheckWarningDetail object by its id.
     *
     * @param id The id of the CodeCheckWarningDetail object to retrieve.
     * @return The CodeCheckWarningDetail object with the specified id, or nullptr if not found.
     */
    @Override
    public CodeCheckWarningDetail get(Long id) {
        return codeCheckWarningDetailMapper.selectById(id);
    }

    @Override
    /**
     * Retrieves a list of CodeCheckWarningDetails based on the provided PageVO.
     *
     * @param page The PageVO containing the paging and filtering information.
     * @return An IPage object containing the list of CodeCheckWarningDetails.
     */
    public IPage<CodeCheckWarningDetail> getList(PageVO<CodeCheckWarningDetail> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<CodeCheckWarningDetail> lambdaQueryWrapper = Wrappers.lambdaQuery(CodeCheckWarningDetail.class)
                .eq(params.containsKey("taskId"), CodeCheckWarningDetail::getTaskId, params.get("taskId"))
                .eq(params.containsKey("taskDetailId"), CodeCheckWarningDetail::getTaskDetailId, params.get("taskDetailId"))
                .eq(params.containsKey("filePath"), CodeCheckWarningDetail::getFilePath, params.get("filePath"))
                .eq(params.containsKey("lineNumber"), CodeCheckWarningDetail::getLineNumber, params.get("lineNumber"))
                .eq(params.containsKey("columnNumber"), CodeCheckWarningDetail::getColumnNumber, params.get("columnNumber"))
                .eq(params.containsKey("warningType"), CodeCheckWarningDetail::getWarningType, params.get("warningType"))
                .eq(params.containsKey("warningMessage"), CodeCheckWarningDetail::getWarningMessage, params.get("warningMessage"))
                .eq(params.containsKey("status"), CodeCheckWarningDetail::getStatus, params.get("status"))
                .eq(params.containsKey("createTime"), CodeCheckWarningDetail::getCreateTime, params.get("createTime"));
        return codeCheckWarningDetailMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    /**
     * @brief 在数据库中插入一个CodeCheckWarningDetail实体
     *
     * @param entity 待插入的CodeCheckWarningDetail实体
     * @return 插入成功后生成的主键值
     */
    @Override
    public Long insert(CodeCheckWarningDetail entity) {
        entity.setId(KeyGenerate.generateId());
        codeCheckWarningDetailMapper.insert(entity);
        return entity.getId();
    }

    /**
     * @brief Delete a record by its ID.
     *
     * This function deletes a record with the specified ID from the database.
     *
     * @param id The ID of the record to be deleted.
     */
    @Override
    public void delete(Long id) {
        codeCheckWarningDetailMapper.deleteById(id);
    }

    /**
     * @brief Update the CodeCheckWarningDetail entity.
     *
     * This function updates the CodeCheckWarningDetail entity with the provided entity.
     *
     * @param entity The CodeCheckWarningDetail entity to be updated.
     */
    @Override
    public void update(CodeCheckWarningDetail entity) {
        codeCheckWarningDetailMapper.updateById(entity);
    }
}
