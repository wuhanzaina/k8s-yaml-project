package com.kotei.sdw.modules.codecheck.constant;

/**
 * @author tiger
 * @date 2024/4/1 11:46
 */
public class Consts {
    public static final String ADMIN = "admin";
    public static final String TOTAL = "Total";
    public static final String WARNING = "warning";
    public static final String ERROR = "error";
    public static final String AI_CODE_SERVICE = "AI_CODE_SERVICE";
}
