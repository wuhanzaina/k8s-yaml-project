/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddUserActivityVO.java
* 创建日期:2024-03-04
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
*
* 用户活跃度统计表
*
*
* @author tiger
* @since 2024-03-04
*/
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "UserActivityStatisticVo", description = "新增用户活跃度统计表")
public class UserActivityStatisticVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
    * 日期
    */
    @ApiModelProperty(value = "日期(10)", required = true, position = 3)
    private String activityDate;
    /**
    * 数量
    */
    @ApiModelProperty(value = "数量", required = true, position = 4)
    private Integer count = 0;

}
