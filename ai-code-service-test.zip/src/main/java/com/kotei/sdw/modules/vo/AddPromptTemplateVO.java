/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code
* 文件名称:AddPromptTemplateVO.java
* 创建日期:2024-02-27
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
*
* prompt模板
*
*
* @author hk
* @since 2024-02-27
*/
@Data
@NoArgsConstructor
@ApiModel(value = "AddPromptTemplateVO", description = "新增prompt模板")
public class AddPromptTemplateVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
    * 模板名称
    */
    @ApiModelProperty(value = "模板名称(100)", position = 3)
    @Length(max = 100, message = "模板名称不能超过100个字符")
    private String name;
    /**
    * 扮演角色
    */
    @ApiModelProperty(value = "扮演角色(100)", position = 5)
    @Length(max = 100, message = "扮演角色不能超过100个字符")
    private String playRole;

    @ApiModelProperty(value = "开发语言", position = 6)
    private String language;
    /**
     * 提示词介绍
     */
    @ApiModelProperty(value = "提示词介绍", position = 6)
    private String intro;
    /**
    * 内容
    */
    @ApiModelProperty(value = "内容", required = true, position = 6)
    @NotNull(message="内容不能为空")
    private String context;
}
