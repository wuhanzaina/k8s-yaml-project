/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code
 * 文件名称:ConversationsAcceptServiceImpl.java
 * 创建日期:2024-02-27
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.statistic.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.api.Result;
import com.kotei.sdw.constant.GlobalConstant;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.constant.CommonConst;
import com.kotei.sdw.modules.feign.ChatbotFeign;
import com.kotei.sdw.modules.feign.vo.ConversationVO;
import com.kotei.sdw.modules.statistic.entity.ConversationsAccept;
import com.kotei.sdw.modules.statistic.mapper.ConversationsAcceptMapper;
import com.kotei.sdw.modules.statistic.service.ConversationsAcceptService;
import com.kotei.sdw.modules.statistic.service.FunctionUsageService;
import com.kotei.sdw.modules.statistic.vo.AddConversationsAcceptVO;
import com.kotei.sdw.modules.statistic.vo.AddFunctionUsageVO;
import com.kotei.sdw.modules.statistic.vo.EditConversationsAcceptVO;
import com.kotei.sdw.modules.statistic.vo.UserLikeVo;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.security.utils.SecurityUtils;
import com.kotei.sdw.system.api.model.LoginUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

import static cn.hutool.json.JSONUtil.toJsonStr;
import static com.kotei.sdw.constant.GlobalConstant.NO;
import static com.kotei.sdw.util.CompareUtils.greaterThanZero;

/**
 * 会话采纳信息 ServiceImpl
 *
 * @author hk
 * @since 2024-02-27
 */
@Service
@Slf4j
public class ConversationsAcceptServiceImpl extends BaseServiceImpl<ConversationsAccept> implements ConversationsAcceptService {
    @Autowired
    private ConversationsAcceptMapper conversationsAcceptMapper;
    @Autowired
    private ChatbotFeign chatbotFeign;
    @Autowired
    private FunctionUsageService functionUsageService;

    @Override
    protected BaseMapper<ConversationsAccept> getMapper() {
        return conversationsAcceptMapper;
    }

    @Override
    public ConversationsAccept get(Long id) {
        return conversationsAcceptMapper.selectById(id);
    }

    @Override
    public IPage<ConversationsAccept> getList(PageVO<ConversationsAccept> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<ConversationsAccept> lambdaQueryWrapper = Wrappers.lambdaQuery(ConversationsAccept.class)
                .eq(params.containsKey("conversationsId"), ConversationsAccept::getConversationsId, params.get("conversationsId"))
                .eq(params.containsKey("status"), ConversationsAccept::getStatus, params.get("status"))
                .eq(params.containsKey("type"), ConversationsAccept::getType, params.get("type"))
                .eq(params.containsKey("createrId"), ConversationsAccept::getCreaterId, params.get("createrId"))
                .eq(params.containsKey("createrName"), ConversationsAccept::getCreaterName, params.get("createrName"))
                .eq(params.containsKey("createTime"), ConversationsAccept::getCreateTime, params.get("createTime"));
        return conversationsAcceptMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    public Long insert(ConversationsAccept entity) {
        entity.setId(KeyGenerate.generateId());
        conversationsAcceptMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        conversationsAcceptMapper.deleteById(id);
    }

    @Override
    public void update(ConversationsAccept entity) {
        conversationsAcceptMapper.updateById(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void insert(AddConversationsAcceptVO add) {
        this.save(add);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(EditConversationsAcceptVO edit) {
        this.save(edit);
    }

    @Override
    public ConversationsAccept getByConversationsId(Long conversationsId) {
        LambdaQueryWrapper<ConversationsAccept> lambdaQueryWrapper = Wrappers.lambdaQuery(ConversationsAccept.class)
                .eq(ConversationsAccept::getConversationsId, conversationsId);
        return conversationsAcceptMapper.selectOne(lambdaQueryWrapper);
    }

    /**
     * 点赞功能。
     *
     * @param vo
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void likes(UserLikeVo vo) {
        ConversationsAccept ca = this.getByConversationsId(vo.getConversationsId());
        log.info("点赞功能 req: {}, conversationsAcceptId: {}", toJsonStr(vo), ca != null ? ca.getId() : "null");
        if (ca != null) {
            ConversationsAccept caEntity = new ConversationsAccept();
            caEntity.setId(ca.getId());
            caEntity.setLikes(vo.getLikes());
            this.update(caEntity);

            LoginUser loginUser = SecurityUtils.getLoginUser();
            //点赞数据同步到functionUsage表中
            saveOrUpdateFunctionUsage(ca.getType(), loginUser.getUserid());
        }
    }

    @Override
    public List<UserLikeVo> getLikesInfo(List<Long> conversationsList) {
        if (CollUtil.isEmpty(conversationsList)) {
            return Collections.emptyList();
        }
        LambdaQueryWrapper<ConversationsAccept> lambdaQueryWrapper = Wrappers.lambdaQuery(ConversationsAccept.class)
                .in(ConversationsAccept::getConversationsId, conversationsList);
        List<ConversationsAccept> conversationsAccepts = conversationsAcceptMapper.selectList(lambdaQueryWrapper);
        return conversationsAccepts.stream()
                .map(it -> UserLikeVo.builder().likes(it.getLikes()).conversationsId(it.getConversationsId()).build())
                .collect(Collectors.toList());
    }

    private Integer getCodeLine(String output) {
        String outputSub = StrUtil.subBetween(output, "```", "```");
        if (StrUtil.isNotBlank(outputSub)) {
            String[] split = StrUtil.split(outputSub, "\n");
            //去除空行
            if (split != null && split.length > 0) {
                return (int) Arrays.stream(split).map(String::trim).map(StringUtils::isNotBlank).count();
            }
        }
        return NO;

    }

    private void save(AddConversationsAcceptVO add) {
        ConversationsAccept conversationsAccept = this.getByConversationsId(add.getConversationsId());

        Integer useInsert; // 插入使用数量
        Integer useCopy; // 复制使用数量
        Integer useCreate; // 创建使用数量
        int status = NO; // 状态，默认为NO

        Boolean update = Boolean.TRUE; // 是否更新，默认为true
        boolean adoption = false; // 是否采纳，默认为false
        if (ObjectUtil.isNull(conversationsAccept)) { // 如果对话接受对象为空
            useInsert = NO; // 插入使用数量为NO
            useCopy = NO; // 复制使用数量为NO
            useCreate = NO; // 创建使用数量为NO
            conversationsAccept = new ConversationsAccept(); // 创建新的对话接受对象实例
            conversationsAccept.setUseCopy(useCopy); // 设置复制使用数量
            conversationsAccept.setUseCreate(useCreate); // 设置创建使用数量
            conversationsAccept.setUseInsert(useInsert); // 设置插入使用数量
            conversationsAccept.setId(KeyGenerate.generateId()); // 生成ID
            conversationsAccept.setType(add.getType()); // 设置类型
            conversationsAccept.setCost(NO); // 设置费用为NO
            conversationsAccept.setInputToken(NO); // 设置输入令牌为NO
            conversationsAccept.setLikes(NO); // 设置喜欢为NO
            conversationsAccept.setOutputToken(NO); // 设置输出令牌为NO
            conversationsAccept.setCodeLine(NO); // 设置代码行数为NO
            conversationsAccept.setAdoptionLineTotal(NO); // 设置采纳行数总和为NO
            update = false; // 设置更新为false
        } else {
            // 如果对话接受对象不为空
            useInsert = conversationsAccept.getUseInsert(); // 获取插入使用数量
            useCopy = conversationsAccept.getUseCopy(); // 获取复制使用数量
            useCreate = conversationsAccept.getUseCreate(); // 获取创建使用数量
        }


        if (greaterThanZero(add.getUseInsert())) {
            // 如果新增的插入使用数量不为空且大于0
            useInsert = add.getUseInsert() + useInsert; // 更新插入使用数量
            adoption = true; // 设置采纳为true
        }
        if (greaterThanZero(add.getUseCopy())) {
            // 如果新增的复制使用数量不为空且大于0
            useCopy = add.getUseCopy() + useCopy; // 更新复制使用数量
            adoption = true; // 设置采纳为true
        }
        if (greaterThanZero(add.getUseCreate())) {
            // 如果新增的创建使用数量不为空且大于0
            useCreate = add.getUseCreate() + useCreate; // 更新创建使用数量
            adoption = true; // 设置采纳为true
        }
        log.info("新增插件使用记录： adoption {} update {} req {} ", adoption, update, toJsonStr(add));
        if (!update) {
            //首次插入回话数据， 则需要调用接口获取回话数据
            getConversations(add, conversationsAccept);
        }
        if (adoption) {
            status = GlobalConstant.YES;
            Integer codeLine = conversationsAccept.getCodeLine();
            Integer adoptionLineTotal = conversationsAccept.getAdoptionLineTotal();
            adoptionLineTotal = ObjectUtil.isNotNull(adoptionLineTotal) ? adoptionLineTotal : NO;
            conversationsAccept.setAdoptionLineTotal(codeLine + adoptionLineTotal);
        }

        conversationsAccept.setStatus(status);
        conversationsAccept.setUseCopy(useCopy);
        conversationsAccept.setUseCreate(useCreate);
        conversationsAccept.setUseInsert(useInsert);
        LoginUser loginUser = SecurityUtils.getLoginUser();
        conversationsAccept.setCreaterId(loginUser.getUserid());
        conversationsAccept.setCreaterName(loginUser.getUsername());

        conversationsAccept.setConversationsId(add.getConversationsId());
        if (update) {
            this.update(conversationsAccept);
        } else {
            conversationsAccept.setCreateTime(new Date());
            this.insert(conversationsAccept);
        }

        this.saveOrUpdateFunctionUsage(conversationsAccept.getType(), loginUser.getUserid());
    }

    /**
     * 新增插件使用记录-获取回话数据
     * @param add
     * @param conversationsAccept
     */
    private void getConversations(AddConversationsAcceptVO add, ConversationsAccept conversationsAccept) {
        Result<ConversationVO> conversation = chatbotFeign.getConversationById(add.getConversationsId());
        log.info("新增插件使用记录-获取回话数据： conversationsId {} conversation {} ", add.getConversationsId(), toJsonStr(conversation));
        if (NO == conversation.getCode() && ObjectUtil.isNotNull(conversation.getData())) {
            ConversationVO conversationVO = conversation.getData();

            //费用情况
            conversationsAccept.setCost((int) Math.round(conversationVO.getCost() * CommonConst.NUM_10_000));
            conversationsAccept.setInputToken(conversationVO.getInputToken());
            conversationsAccept.setOutputToken(conversationVO.getOutputToken());

            //AI生成的代码行数
            Integer codeLine = getCodeLine(conversationVO.getOutput());
            conversationsAccept.setCodeLine(codeLine);
        }
    }

    /**
     * @param type   函数使用情况类型
     * @param userId 用户ID
     * @brief 保存或更新函数使用情况
     * <p>
     * 根据给定的类型和用户ID，从接受的数据中分析使用情况，并将结果存储或更新到数据库中。
     */
    private void saveOrUpdateFunctionUsage(int type, long userId) {
        AddFunctionUsageVO addFunctionUsageVO = this.conversationsAcceptMapper.analyseUsageDataFromAccept(userId, type);
        if (addFunctionUsageVO == null) {
            addFunctionUsageVO = new AddFunctionUsageVO();
        }
        addFunctionUsageVO.setType(type);
        functionUsageService.insertOrUpdate(addFunctionUsageVO);
    }


}
