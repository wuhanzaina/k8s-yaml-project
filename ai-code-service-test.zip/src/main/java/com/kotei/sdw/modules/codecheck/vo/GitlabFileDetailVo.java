package com.kotei.sdw.modules.codecheck.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class GitlabFileDetailVo {
    @JsonProperty("file_name")
    private String fileName;

    @JsonProperty("file_path")
    private String filePath;

    private int size;
    private String encoding;

    private String ref;

    @JsonProperty("commit_id")
    private String commitId;

    @JsonProperty("last_commit_id")
    private String lastCommitId;

}
