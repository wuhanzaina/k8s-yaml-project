package com.kotei.sdw.modules.feign.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author tiger
 * @date 2024/3/6 9:22
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserReq {
    private Long userId;
    //工号
    private String userName;
    private Long deptId;
}
