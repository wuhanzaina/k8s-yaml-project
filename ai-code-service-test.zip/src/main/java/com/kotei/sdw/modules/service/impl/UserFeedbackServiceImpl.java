/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:UserFeedbackServiceImpl.java
 * 创建日期:2024-03-11
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.service.impl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.api.Result;
import com.kotei.sdw.constant.GlobalConstant;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.constant.enums.AcceptTypeEnum;
import com.kotei.sdw.modules.entity.UserFeedback;
import com.kotei.sdw.modules.feign.ChatbotFeign;
import com.kotei.sdw.modules.feign.vo.ConversationVO;
import com.kotei.sdw.modules.mapper.UserFeedbackMapper;
import com.kotei.sdw.modules.service.UserFeedbackService;
import com.kotei.sdw.modules.vo.AddUserFeedbackVO.FeedbackFile;
import com.kotei.sdw.modules.vo.UserFeedbackViewVo;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Map;
import java.util.stream.Collectors;

import static cn.hutool.json.JSONUtil.parseArray;
import static org.apache.commons.lang3.StringUtils.defaultIfBlank;

/**
 *
 * 用户反馈表 ServiceImpl
 *
 *
 * @author tiger
 * @since 2024-03-11
 */
@Service
public class UserFeedbackServiceImpl extends BaseServiceImpl<UserFeedback> implements UserFeedbackService {
    @Autowired
    private UserFeedbackMapper userFeedbackMapper;
    @Autowired
    private ChatbotFeign chatbotFeign;

    @Override
    protected BaseMapper<UserFeedback> getMapper() {
        return userFeedbackMapper;
    }

    @Override
    public UserFeedback get(Long id) {
        return userFeedbackMapper.selectById(id);
    }

    @Override
    public UserFeedbackViewVo getById(Long id) {
        UserFeedback userFeedback = this.get(id);
        UserFeedbackViewVo vo = new UserFeedbackViewVo();
        BeanUtils.copyProperties(userFeedback, vo, "feedbackFiles", "acceptTypes");

        vo.setFeedbackFiles(JSONUtil.toList(parseArray(defaultIfBlank(userFeedback.getFeedbackFiles(), "[]")), FeedbackFile.class));
        vo.setAcceptTypes(JSONUtil.toList(parseArray(defaultIfBlank(userFeedback.getAcceptTypes(), "[]")), String.class)
                .stream()
                .map(it -> AcceptTypeEnum.getByCode(it).getName())
                .collect(Collectors.toList())
        );
        if (userFeedback.getAcceptId() != null && userFeedback.getAcceptId() > 0) {
            Result<ConversationVO> conversation = chatbotFeign.getConversationById(userFeedback.getAcceptId());
            if (GlobalConstant.NO == conversation.getCode() && ObjectUtil.isNotNull(conversation.getData())) {
                vo.setInput(conversation.getData().getInput());
                vo.setOutput(conversation.getData().getOutput());
            }
        }
        return vo;
    }

    @Override
    public IPage<UserFeedback> getList(PageVO<UserFeedback> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<UserFeedback> lambdaQueryWrapper = Wrappers.lambdaQuery(UserFeedback.class)
                .eq(params.containsKey("userId"), UserFeedback::getUserId, params.get("userId"))
                .eq(params.containsKey("userName"), UserFeedback::getUserName, params.get("userName"))
                .eq(params.containsKey("userNo"), UserFeedback::getUserName, params.get("userNo"))
                .eq(params.containsKey("title"), UserFeedback::getTitle, params.get("title"))
                .eq(params.containsKey("departmentId"), UserFeedback::getDepartmentId, params.get("departmentId"))
                .eq(params.containsKey("departmentName"), UserFeedback::getDepartmentName, params.get("departmentName"))
                .eq(params.containsKey("rootDepartmentId"), UserFeedback::getRootDepartmentId, params.get("rootDepartmentId"))
                .eq(params.containsKey("rootDepartmentName"), UserFeedback::getRootDepartmentName, params.get("rootDepartmentName"))
                .eq(params.containsKey("feedbackDate"), UserFeedback::getFeedbackDate, params.get("feedbackDate"))
                .eq(params.containsKey("feedbackType"), UserFeedback::getFeedbackType, params.get("feedbackType"))
                .eq(params.containsKey("feedbackSubType"), UserFeedback::getFeedbackSubType, params.get("feedbackSubType"))
                .eq(params.containsKey("feedbackContent"), UserFeedback::getFeedbackContent, params.get("feedbackContent"))
                .eq(params.containsKey("acceptId"), UserFeedback::getAcceptId, params.get("acceptId"))
                .eq(params.containsKey("name"), UserFeedback::getName, params.get("name"))
                .eq(params.containsKey("version"), UserFeedback::getVersion, params.get("version"))
                .eq(params.containsKey("osType"), UserFeedback::getOsType, params.get("osType"))
                .eq(params.containsKey("osVersion"), UserFeedback::getOsVersion, params.get("osVersion"))
                .eq(params.containsKey("ideaType"), UserFeedback::getIdeaType, params.get("ideaType"))
                .eq(params.containsKey("ideaVersion"), UserFeedback::getIdeaVersion, params.get("ideaVersion"))
                .eq(params.containsKey("ipAddr"), UserFeedback::getIpAddr, params.get("ipAddr"))
                .eq(params.containsKey("browser"), UserFeedback::getBrowser, params.get("browser"))
                .eq(params.containsKey("createTime"), UserFeedback::getCreateTime, params.get("createTime"))
                .between(params.containsKey("startFeedbackDate") && params.containsKey("endFeedbackDate"), UserFeedback::getFeedbackDate, params.get("startFeedbackDate"), params.get("endFeedbackDate"));
        return userFeedbackMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    public Long insert(UserFeedback entity) {
        entity.setId(KeyGenerate.generateId());
        if (entity.getCreateTime() == null) {
            entity.setCreateTime(new Date());
        }
        userFeedbackMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        userFeedbackMapper.deleteById(id);
    }

    @Override
    public void update(UserFeedback entity) {
        userFeedbackMapper.updateById(entity);
    }

}
