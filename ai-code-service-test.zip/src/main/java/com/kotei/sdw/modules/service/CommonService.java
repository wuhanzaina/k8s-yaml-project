package com.kotei.sdw.modules.service;

import com.kotei.sdw.modules.feign.vo.DeptRes.DeptVo;
import com.kotei.sdw.modules.feign.vo.UserReq;
import com.kotei.sdw.modules.feign.vo.UserRes;
import com.kotei.sdw.modules.feign.vo.UserRes.UserVo;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @author tiger
 * @date 2024/3/5 18:03
 */
public interface CommonService {
    /**
     * 获取所有的组织架构信息
     *
     * @return
     */
    List<DeptVo> getAllDepartment();

    /**
     * 获取所有的根节点部门对象（组织架构的第二层）
     *
     * @return
     */
    List<DeptVo> getAllRootDepartment();

    /**
     * 根据任意depteId获取对应的根节点部门对象
     *
     * @param departmentId
     * @return
     */
    DeptVo getRootDepartment(Long departmentId);

    DeptVo getDepartmentById(Long departmentId);

    /**
     * 根据当前节点ID获取自身和后代节点列表
     *
     * @param departmentId
     * @return
     */
    List<DeptVo> getDescendantDeptList(Long departmentId);

    /**
     * @param userId 用户ID
     * @return UserVo 用户信息
     * @brief 获取指定用户的信息
     */
    UserVo getUserById(Long userId);

    /**
     * @param userNo 用户编号
     * @return UserVo 用户信息
     * @brief 根据用户编号获取用户信息
     */
    UserVo getUserByNo(String userNo);

    /**
     * @param req 用户请求
     * @return 用户响应
     * @brief 获取用户列表
     */
    UserRes getUserList(UserReq req);

    /**
     * @param multipartFile 要上传的文件
     * @return 上传成功后返回文件路径
     * @brief 上传文件
     */
    String upload(MultipartFile multipartFile);

    /**
     * 从git用户名中获取工号
     *
     * @param gitUserName
     * @return
     */
    String getUserNoByGitUserName(String gitUserName);
}
