/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:EditUserFeedbackVO.java
* 创建日期:2024-03-11
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

/**
*
* 用户反馈表
*
*
* @author tiger
* @since 2024-03-11
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@ApiModel(value = "EditUserFeedbackVO", description = "编辑用户反馈表")
public class EditUserFeedbackVO extends AddUserFeedbackVO {

    private static final long serialVersionUID = 1L;
    /**
    * ID
    */
    @ApiModelProperty(value = "ID",required = true, position = 1)
    @NotNull(message = "id不能为空")
    private Long id;

}
