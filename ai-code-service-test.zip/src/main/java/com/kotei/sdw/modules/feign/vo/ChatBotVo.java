package com.kotei.sdw.modules.feign.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author tiger
 * @date 2024/4/3 13:30
 */
public class ChatBotVo {

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ChatRequest {
        private String model;
        private List<Message> messages;
        private int n = 1;
        private double temperature = 0.0d;
        private String appId;

        // 最大输出字符数
        private Integer max_tokens = 2000;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class ChatResponse {
        /**
         * 会话ID
         */
        private Long conversationId;
        private List<Choice> choices;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Choice {
        private int index;
        private Message message;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Message {
        private String role;
        private String content;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Usage {
        /**
         *   {
         *     "prompt_tokens": 5,
         *     "completion_tokens": 7,
         *     "total_tokens": 12
         *   }
         *
         */
        @JsonProperty("prompt_tokens")
        private Integer promptTokens;
        @JsonProperty("completion_tokens")
        private Integer completionTokens;
        @JsonProperty("total_tokens")
        private Integer totalTokens;
    }
}
