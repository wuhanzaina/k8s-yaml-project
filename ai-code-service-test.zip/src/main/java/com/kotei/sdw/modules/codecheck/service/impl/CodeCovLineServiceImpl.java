/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:CodeCovLineServiceImpl.java
* 创建日期:2024-04-22
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.modules.codecheck.entity.CodeCovLine;
import com.kotei.sdw.modules.codecheck.mapper.CodeCovLineMapper;
import com.kotei.sdw.modules.codecheck.service.CodeCovLineService;

/**
*
* 代码覆盖率行记录表 ServiceImpl
*
*
* @author tiger
* @since 2024-04-22
*/
@Service
public class CodeCovLineServiceImpl extends BaseServiceImpl<CodeCovLine> implements CodeCovLineService {
    @Autowired
    private CodeCovLineMapper codeCovLineMapper;

    @Override
    protected BaseMapper<CodeCovLine> getMapper() {
    return codeCovLineMapper;
    }

    @Override
    public CodeCovLine get(Long id) {
    return codeCovLineMapper.selectById(id);
    }

    @Override
    public IPage<CodeCovLine> getList(PageVO<CodeCovLine> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<CodeCovLine> lambdaQueryWrapper =Wrappers.lambdaQuery(CodeCovLine.class)
        .eq(params.containsKey("covTaskId"), CodeCovLine::getCovTaskId, params.get("covTaskId"))
        .eq(params.containsKey("covFunId"), CodeCovLine::getCovFunId, params.get("covFunId"))
        .eq(params.containsKey("lineNumber"), CodeCovLine::getLineNumber, params.get("lineNumber"))
        .eq(params.containsKey("count"), CodeCovLine::getCount, params.get("count"))
                ;
        return codeCovLineMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    public List<CodeCovLine> getListByFunId(Long covFunId) {
        LambdaQueryWrapper<CodeCovLine> lambdaQueryWrapper =Wrappers.lambdaQuery(CodeCovLine.class)
        .eq(CodeCovLine::getCovFunId, covFunId);
        return codeCovLineMapper.selectList(lambdaQueryWrapper);
    }

    @Override
    public Long insert(CodeCovLine entity) {
        entity.setId(KeyGenerate.generateId());
        codeCovLineMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        codeCovLineMapper.deleteById(id);
    }

    @Override
    public void update(CodeCovLine entity) {
        codeCovLineMapper.updateById(entity);
    }
}
