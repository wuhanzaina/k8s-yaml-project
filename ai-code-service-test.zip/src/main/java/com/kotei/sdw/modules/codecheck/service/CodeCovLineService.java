/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:CodeCovLineService.java
* 创建日期:2024-04-22
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.service;

import com.kotei.sdw.modules.codecheck.entity.CodeCovLine;
import com.kotei.sdw.mvc.service.BaseService;

import java.util.List;

/**
*
* 代码覆盖率行记录表 Service
*
*
* @author tiger
* @since 2024-04-22
*/
public interface CodeCovLineService extends BaseService<CodeCovLine> {

    List<CodeCovLine> getListByFunId(Long covFunId);
}
