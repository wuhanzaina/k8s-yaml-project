package com.kotei.sdw.modules.feign;

import com.kotei.sdw.modules.feign.vo.DeptRes;
import com.kotei.sdw.modules.feign.vo.DescendantDeptRes;
import com.kotei.sdw.modules.feign.vo.UserReq;
import com.kotei.sdw.modules.feign.vo.UserRes;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @Author hk
 * @Date 2024/3/5
 * @Description: 请求ai平台
 * @Version 1.0
 */
@FeignClient(value = "sdw-system")
public interface SdwSystemFeign {

    /**
     * 查询用户信息
     *
     * @param req
     * @return
     */
    @GetMapping("internal/list")
    UserRes getUserList(@SpringQueryMap UserReq req);

    /**
     * 查询全部部门信息
     *
     * @return
     */
    @GetMapping("internal/deptTree")
    DeptRes getAllDeptTree();


    /**
     * 根据当前节点ID获取自身和后代节点列表
     */
    @GetMapping("internal/descendant-nodes/{deptId}")
    DescendantDeptRes getDescendantNodes(@PathVariable("deptId") Long deptId);
}
