/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddGitCommitVO.java
* 创建日期:2024-03-06
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.controller;

import cn.hutool.core.bean.BeanUtil;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSort;
import com.kotei.sdw.api.Result;
import com.kotei.sdw.modules.statistic.entity.GitCommit;
import com.kotei.sdw.modules.statistic.service.FunctionUsageService;
import com.kotei.sdw.modules.statistic.service.GitCommitService;
import com.kotei.sdw.modules.statistic.vo.AddGitCommitVO;
import com.kotei.sdw.modules.statistic.vo.LineVO;
import com.kotei.sdw.mvc.controller.BaseController;
import com.kotei.sdw.mvc.vo.IdVO;
import com.kotei.sdw.security.annotation.RequiresPermissions;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.util.List;
/**
 *
 * git提交统计 Controller
 *
 *
 * @author hk
 * @since 2024-03-06
 */
@RestController
@RequestMapping(value="/statistic/commits", produces = MediaType.APPLICATION_JSON_VALUE)
@Validated
@Api(tags = "git提交统计")
@ApiSort(1)
public class GitCommitController extends BaseController {
	@Autowired
	private GitCommitService gitCommitService;
    @Autowired
	private FunctionUsageService functionUsageService;

	/**
     * 新增
     * @param addGitCommitVO
     * @return
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "新增", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperationSupport(order = 1)
    @RequiresPermissions("statistic:commit:create")
    public Result<IdVO> create(@RequestBody @Validated AddGitCommitVO addGitCommitVO) {
		GitCommit gitCommit = new GitCommit();
    	BeanUtil.copyProperties(addGitCommitVO, gitCommit);
    	Long id=gitCommitService.insert(gitCommit);
    	return Result.success(new IdVO(id));
    }

    /**
     * 列表查询
     * @return
     */
    @GetMapping("/adoptionList")
    @ApiOperationSupport(order = 7)
    @ApiOperation(value = "开发人员提交代码周趋势分析-采纳大模型代码行数")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "beginWeekBeginDate", value = "开始周对应的开始时间", required = true, paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "endWeekBeginDate", value = "结束周对应的开始时间", required = true, paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "userId", value = "用户ID", paramType = "query", dataType = "String")
    })
    public Result<List<LineVO>> adoptionList(@NotBlank(message="开始时间") String beginWeekBeginDate, @NotBlank(message="开始时间") String endWeekBeginDate,  Long userId) {
        List<LineVO> list = functionUsageService.adoptionList(beginWeekBeginDate,endWeekBeginDate,userId);
        return Result.success(list);
    }

    /**
     * 列表查询
     * @return
     */
    @GetMapping("/commitList")
    @ApiOperationSupport(order = 7)
    @ApiOperation(value = "开发人员提交代码周趋势分析-每周提交git仓库的代码行数")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "beginWeekBeginDate", value = "开始周对应的开始时间", required = true, paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "endWeekBeginDate", value = "结束周对应的开始时间", required = true, paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "userId", value = "用户ID", paramType = "query", dataType = "String")
    })
    public Result<List<LineVO>> commitList(@NotBlank(message="开始时间") String beginWeekBeginDate, @NotBlank(message="开始时间") String endWeekBeginDate, Long userId) {
        List<LineVO> list = gitCommitService.commitList(beginWeekBeginDate,endWeekBeginDate,userId);
        return Result.success(list);
    }

}
