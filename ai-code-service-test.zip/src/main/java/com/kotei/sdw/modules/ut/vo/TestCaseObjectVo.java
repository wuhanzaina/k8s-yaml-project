package com.kotei.sdw.modules.ut.vo;

/**
 * @author tiger
 * @date 2024/3/27 13:47
 */

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TestCaseObjectVo {
    /**
     * 生成UT测试用例ID
     */
    private Long id;
    /**
     * 测试目标函数名称
     */
    private String targetFunName;

    /**
     * 测试目标函数返回类型
     */
    private String targetFunResultType;
    /**
     * 命名空间列表
     */
    private List<String> namespaces;

    /**
     * 测试用例结构化JSON列表
     */
    private List<TestCaseInfoVo> taseCaseInfoList;

    /**
     * 测试用例代码列表
     */
    private List<String> taseCases;


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class TestCaseInfoVo {
        /**
         * 描述信息
         */
        private String description;

        private String testCaseCode;

        /**
         * 参数列表，包含一个NetworkHandleType类型的参数
         */
        private List<ParamInfo> functionParameters;

        /**
         * 静态变量列表，包含一个LinSM_ConfigPtr和一个LinSM_StateInfo的wakeupRetryCounter
         */
        private List<ParamInfo> staticVariables;

        /**
         * 存根函数列表，包含一个fun_name和一个mock_result
         */
        private List<StubbedFunction> stubbedFunctions;
        /**
         * public修饰的成员变量的赋值代码
         */
        private List<String> publicMemberVariables;

        /**
         * 预期结果，为E_OK
         */
        private String expectedResult;

    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class ParamInfo {
        /**
         * 参数名称
         */
        private String type;
        /**
         * 参数名称
         */
        private String name;

        /**
         * 参数值
         */
        private String value;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class StubbedFunction {
        /**
         * 存根函数名称
         */
        private String funName;

        /**
         * 存根函数的返回值
         */
        private String mockResult;

        /**
         * 存根函数的参数列表
         */
        private List<ParamInfo> params;
    }

}


