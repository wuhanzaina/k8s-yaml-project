/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:AddCodeCheckTaskVO.java
 * 创建日期:2024-03-26
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 通过项目编号获取统计内容
 *
 * @author tiger
 * @since 2024-03-26
 */
@Data
@NoArgsConstructor
@ApiModel(value = "RealTimeCodeCheckRes", description = "通过项目编号获取统计内容")
public class RealTimeCodeCheckRes implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 检查代码内容
     */
    @ApiModelProperty(value = "检查代码内容", position = 11)
    private String content;
    /**
     * 起始行号
     */
    @ApiModelProperty(value = "起始行号", position = 11)
    private Integer startLine;
    /**
     * 警告内容
     */
    @ApiModelProperty(value = "警告内容", position = 11)
    List<ExecTaskInfoVo.WarningInfo> warningList;
}
