package com.kotei.sdw.modules.codecheck.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.kotei.sdw.modules.codecheck.entity.ProjectCheck;

/**
* @author zhengyaow
* @description 针对表【project_check】的数据库操作Service
* @createDate 2024-12-24 15:22:17
*/
public interface ProjectCheckService extends IService<ProjectCheck> {

}
