package com.kotei.sdw.modules.codecheck.vo;

import com.kotei.sdw.modules.codecheck.entity.CodeCovFun;
import com.kotei.sdw.modules.codecheck.entity.CodeCovLine;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 代码覆盖率检查保存数据中转使用
 *
 * @author tiger
 * @date 2024/3/28 14:34
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CodeCovFunDetailToDbVo {
    private CodeCovFun fun;

    private List<CodeCovLine> codeCovLines;

}
