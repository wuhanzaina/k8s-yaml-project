package com.kotei.sdw.modules.codecheck.schedule;

import com.kotei.sdw.modules.codecheck.service.CodeCheckTaskService;
import com.kotei.sdw.modules.config.AppConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @author Deng.Weiping
 * @since 2023/11/9 10:19
 */
@Component
@Slf4j
public class RunTaskScheduled {
    @Autowired
    private AppConfig appConfig;
    @Autowired
    private CodeCheckTaskService codeCheckTaskService;

    /**
     * 定时触发生成代码静态扫描任务
     * 每个星期一的凌晨1点触发
     */
    @Scheduled(cron = "0 0 1 * * MON")
    public void triggerCodeStaticScan() {
        // 打印日志，记录触发静态代码扫描的配置信息和项目列表
        log.info("【Scheduled】 triggerCodeStaticScan : {} ", appConfig.getTriggerCodeStaticScan());

        // 判断是否需要触发静态代码扫描，如果需要，则遍历项目列表，触发静态代码扫描任务
        if (appConfig.getTriggerCodeStaticScan() != 1) {
            return;
        }
        codeCheckTaskService.triggerCodeStaticScan(null);
    }


    /**
     * 定时扫描启动待执行的任务
     * 每个星期一每过30秒触发一次
     */
////    @Scheduled(cron = "0/30 * * * * MON")
//    @Scheduled(cron = "0/20 * * * * ?")
//    public void scanAndExecuteTask() {
//        log.info("【Scheduled】 scanAndExecuteTask : {}", appConfig.getScanAndExecuteTask());
//        // 判断是否需要触发静态代码扫描，如果需要，则遍历项目列表，触发静态代码扫描任务
//        if (appConfig.getScanAndExecuteTask() != 1) {
//            return;
//        }
//        codeCheckTaskService.scanAndExecuteTask();
//    }

}
