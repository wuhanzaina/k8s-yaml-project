package com.kotei.sdw.modules.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author tiger
 * @date 2024/3/26 19:54
 */
@Slf4j
public class YamlUtils {
    private static final ObjectMapper yamlMapper = new ObjectMapper(new YAMLFactory());

    private static final ObjectMapper jsonMapper = new ObjectMapper();

    static {
        //在反序列化 JSON 时，Jackson 将忽略未知字段，不会抛出异常
        jsonMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    /**
     * yaml格式的内容先转换为json
     * 再把json对象转换为map对象
     *
     * @param yamlContent
     * @param clazz
     * @param <T>
     * @return
     * @throws JsonProcessingException
     */
    public static <T> Map<String, T> getMapFromYamlToClass(String yamlContent, Class<T> clazz) throws JsonProcessingException {
        if (StringUtils.isBlank(yamlContent)) {
            return Collections.emptyMap();
        }
        JsonNode json = YamlUtils.getJsonByYaml(yamlContent);
        if (json == null) {
            return Collections.emptyMap();
        }
        String jsonStr = json.toString();
        Map<String, Object> map = jsonMapper.readValue(jsonStr, new TypeReference<Map<String, Object>>() {
        });
        return map.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, entry -> jsonMapper.convertValue(entry.getValue(), clazz)));
    }

    /**
     * yaml格式的内容先转换为json
     * 再把json对象转换为list对象
     *
     * @param yamlContent
     * @param clazz
     * @param <T>
     * @return
     * @throws JsonProcessingException
     */
    public static <T> List<T> getListFromYamlToClass(String yamlContent, Class<T> clazz) throws JsonProcessingException {
        if (StringUtils.isBlank(yamlContent)) {
            return Collections.emptyList();
        }
        JsonNode json = YamlUtils.getJsonByYaml(yamlContent);
        if (json == null) {
            return Collections.emptyList();
        }
        String jsonStr = json.toString();
        return jsonMapper.readValue(jsonStr, jsonMapper.getTypeFactory().constructCollectionType(List.class, clazz));
    }

    /**
     * yaml格式的内容先转换为json
     *
     * @param yamlContent
     * @return
     */
    public static JsonNode getJsonByYaml(String yamlContent) {
        try {
            return yamlMapper.readValue(yamlContent, JsonNode.class);
        } catch (JsonProcessingException e) {
            log.warn("yaml to json error", e);
            return null;
        }
    }
}
