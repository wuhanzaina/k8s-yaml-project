/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddGitCommitVO.java
* 创建日期:2024-03-06
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
*
* git提交统计
*
*
* @author hk
* @since 2024-03-06
*/
@Data
@NoArgsConstructor
@ApiModel(value = "AddGitCommitVO", description = "新增git提交统计")
public class AddGitCommitVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
    * 用户ID
    */
    @ApiModelProperty(value = "用户ID", required = true, position = 2)
    @NotNull(message="用户ID不能为空")
    private Long userId;
    /**
    * 用户名称
    */
    @ApiModelProperty(value = "用户名称(50)", required = true, position = 3)
    @NotBlank(message = "用户名称不能为空")
    @Length(max = 50, message = "用户名称不能超过50个字符")
    private String userName;
    /**
    * 部门ID
    */
    @ApiModelProperty(value = "部门ID", required = true, position = 4)
    @NotNull(message="部门ID不能为空")
    private Long deptId;
    /**
    * 部门名称
    */
    @ApiModelProperty(value = "部门名称(100)", required = true, position = 5)
    @NotBlank(message = "部门名称不能为空")
    @Length(max = 100, message = "部门名称不能超过100个字符")
    private String deptName;
    /**
    * 一级部门ID
    */
    @ApiModelProperty(value = "一级部门ID", required = true, position = 6)
    @NotNull(message="一级部门ID不能为空")
    private Long rootDeptId;
    /**
    * 一级部门名称
    */
    @ApiModelProperty(value = "一级部门名称(100)", required = true, position = 7)
    @NotBlank(message = "一级部门名称不能为空")
    @Length(max = 100, message = "一级部门名称不能超过100个字符")
    private String rootDeptName;
    /**
    * 提交日期
    */
    @ApiModelProperty(value = "提交日期(10)", required = true, position = 8)
    @NotBlank(message = "提交日期不能为空")
    @Length(max = 10, message = "提交日期不能超过10个字符")
    private String commitDate;
    /**
    * 提交代码行数
    */
    @ApiModelProperty(value = "提交代码行数", required = true, position = 9)
    @NotNull(message = "提交代码行数不能为空")
    @Min(value = 0, message = "提交代码行数不能小于0")
    @Max(value = 9999, message = "")
    private Integer commitLineTotal;
    /**
    * 创建人id
    */
    @ApiModelProperty(value = "创建人id", required = true, position = 10)
    @NotNull(message="创建人id不能为空")
    private Long createrId;
    /**
    * 创建人
    */
    @ApiModelProperty(value = "创建人(60)", required = true, position = 11)
    @NotBlank(message = "创建人不能为空")
    @Length(max = 60, message = "创建人不能超过60个字符")
    private String createrName;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", required = true, position = 12)
    @NotNull(message="创建时间不能为空")
    private Date createTime;

}
