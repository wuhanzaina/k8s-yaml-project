/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code
* 文件名称:AddPromptTemplateVO.java
* 创建日期:2024-02-27
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.controller;

import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSort;
import com.kotei.sdw.api.Result;
import com.kotei.sdw.modules.entity.PromptFunction;
import com.kotei.sdw.modules.service.PromptFunctionService;
import com.kotei.sdw.modules.vo.AddPromptTemplateVO;
import com.kotei.sdw.mvc.controller.BaseController;
import com.kotei.sdw.mvc.vo.IdVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 *
 * prompt模板 Controller
 *
 *
 * @author hk
 * @since 2024-02-27
 */
@RestController
@RequestMapping(value="/prompt/function", produces = MediaType.APPLICATION_JSON_VALUE)
@Validated
@Api(tags = "功能提示词模板")
@ApiSort(1)
public class PromptFunctionController extends BaseController {
	@Autowired
	PromptFunctionService promptFunctionService;

	/**
     * 新增
     * @param addPromptTemplateVO
     * @return
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "新增/修改", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperationSupport(order = 1)
    public Result<IdVO> saveOrUpdate(@RequestBody @Validated AddPromptTemplateVO addPromptTemplateVO) {
    	Long id = promptFunctionService.saveOrUpdate(addPromptTemplateVO);
    	return Result.success(new IdVO(id));
    }

    /**
    * 查询当前用户所有的功能提示词模板
    */
    @GetMapping("/getPromptFunctionsByUser")
    @ApiOperation(value = "删除")
    @ApiOperationSupport(order = 2)
    public Result<List<PromptFunction>> getPromptFunctionsByUser() {
    	return Result.success(promptFunctionService.getPromptFunctionsByUser());
    }

}
