/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code
* 文件名称:PromptTemplate.java
* 创建日期:2024-02-27
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.entity;

import java.util.Date;
import com.kotei.sdw.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
*
* prompt模板
*
*
* @author hk
* @since 2024-02-27
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("prompt_template")
@ApiModel(value = "PromptTemplate", description = "prompt模板")
public class PromptTemplate extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 模板编码
    */
    @ApiModelProperty(value = "模板编码", position = 2)
    private String code;
    /**
    * 模板名称
    */
    @ApiModelProperty(value = "模板名称", position = 3)
    private String name;
    /**
     * 模板状态.0:不可用  1：可用
     */
    @ApiModelProperty(value = "模板状态.0:不可用  1：可用", position = 4)
    private Integer status;
    /**
     * 扮演角色
     */
    @ApiModelProperty(value = "扮演角色", position = 5)
    private String playRole;
    /**
     * 分享状态 0:未分享  1：已分享
     */
    @ApiModelProperty(value = "分享状态 0:未分享  1：已分享", position = 4)
    private Integer share;
    /**
    * 应用市场ID
    */
    @ApiModelProperty(value = "应用市场ID", position = 3)
    private Long marketId;
    /**
    * 开发语言
    */
    @ApiModelProperty(value = "开发语言", position = 6)
    private String language;
    /**
    * 提示词介绍
    */
    @ApiModelProperty(value = "提示词介绍", position = 6)
    private String intro;
    /**
    * 提示词内容
    */
    @ApiModelProperty(value = "提示词内容", position = 6)
    private String context;
    /**
    * 创建人id
    */
    @ApiModelProperty(value = "创建人id", position = 7)
    private Long createrId;
    /**
    * 创建人
    */
    @ApiModelProperty(value = "创建人", position = 8)
    private String createrName;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", position = 9)
    private Date createTime;
    /**
    * 修改人id
    */
    @ApiModelProperty(value = "修改人id", position = 10)
    private Long modifierId;
    /**
    * 修改人名称
    */
    @ApiModelProperty(value = "修改人名称", position = 11)
    private String modifierName;
    /**
    * 修改时间
    */
    @ApiModelProperty(value = "修改时间", position = 12)
    private Date modifyTime;


}
