package com.kotei.sdw.modules.utils;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.write.handler.CellWriteHandler;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.metadata.holder.WriteTableHolder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;

import java.util.List;

/**
 * @author pengh6366
 * @date 2023-05-18
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CellStyleHandler implements CellWriteHandler {
    private Integer[] columns;

    /**
     * @param writeSheetHolder 写入的工作表持有对象
     * @param writeTableHolder 写入的表格持有对象
     * @param cellDataList     存储单元格数据的列表
     * @param cell             被销毁的单元格对象
     * @param head             表头对象
     * @param relativeRowIndex 相对行索引
     * @param isHead           是否为表头
     * @brief 在单元格被销毁后触发的回调函数
     */
    @Override
    public void afterCellDispose(WriteSheetHolder writeSheetHolder, WriteTableHolder writeTableHolder, List<WriteCellData<?>> cellDataList, Cell cell, Head head, Integer relativeRowIndex, Boolean isHead) {
        // 检查columns是否为空
        if (ObjectUtil.isNotEmpty(columns)) {
            // 遍历columns列表
            for (Integer integer : columns) {
                // 检查当前cell的列索引是否与columns列表中的值相等
                if (cell.getColumnIndex() == integer) {
                    // 调用setStyle方法设置样式
                    setStyle(cell);
                }
            }
        } else {
            // 检查当前cell的列索引是否为0
            if (cell.getColumnIndex() == 0) {
                // 调用setStyle方法设置样式
                setStyle(cell);
            }
        }
    }


    /**
     * @param cell 单元格对象
     * @brief 设置单元格的样式
     */
    private void setStyle(Cell cell) {
        // 创建一个单元格样式
        CellStyle cellStyle = cell.getSheet().getWorkbook().createCellStyle();

        // 设置单元格是否锁定
        cellStyle.setLocked(StringUtils.isNotBlank(cell.getStringCellValue()));

        // 将样式应用到单元格
        cell.setCellStyle(cellStyle);

        // 如果单元格被锁定，设置字体颜色为灰色
        if (cell.getCellStyle().getLocked()) {
            // 创建一个字体
            Font font = cell.getSheet().getWorkbook().createFont();

            // 设置字体颜色为40%灰色
            font.setColor(IndexedColors.GREY_40_PERCENT.index);

            // 将字体应用到单元格样式
            cellStyle.setFont(font);
        }
    }
}
