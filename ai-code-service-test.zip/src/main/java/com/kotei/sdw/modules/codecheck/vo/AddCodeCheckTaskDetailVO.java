/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddCodeCheckTaskDetailVO.java
* 创建日期:2024-03-26
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
*
* 代码检查明细表
*
*
* @author tiger
* @since 2024-03-26
*/
@Data
@NoArgsConstructor
@ApiModel(value = "AddCodeCheckTaskDetailVO", description = "新增代码检查明细表")
public class AddCodeCheckTaskDetailVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
    * 任务ID
    */
    @ApiModelProperty(value = "任务ID", required = true, position = 2)
    private Long taskId;
    /**
    * 类型：CIRCLE:圈复杂度; COMMENT:代码注释率; WARNING:静态扫描警告
    */
    @ApiModelProperty(value = "类型：CIRCLE:圈复杂度; COMMENT:代码注释率; WARNING:静态扫描警告(32)", required = true, position = 3)
    private String type;
    /**
    * 文件地址
    */
    @ApiModelProperty(value = "文件地址(128)", required = true, position = 4)
    private String filePath;
    /**
    * 函数名称
    */
    @ApiModelProperty(value = "函数名称(128)", required = true, position = 5)
    private String funName;
    /**
    * 行号
    */
    @ApiModelProperty(value = "行号(11)", required = true, position = 6)
    private String lineNumber;
    /**
    * 列号
    */
    @ApiModelProperty(value = "列号", required = true, position = 7)
    private Integer columnNumber;
    /**
    * 警告类型
    */
    @ApiModelProperty(value = "警告类型(128)", required = true, position = 8)
    private String warningType;
    /**
    * 警告信息
    */
    @ApiModelProperty(value = "警告信息(1024)", required = true, position = 9)
    private String warningMessage;
    /**
    * 圈复杂度
    */
    @ApiModelProperty(value = "圈复杂度", required = true, position = 10)
    private Integer circleComplexity;
    /**
    * 代码总行数
    */
    @ApiModelProperty(value = "代码总行数", required = true, position = 11)
    private Integer codes;
    /**
    * 空白代码行数
    */
    @ApiModelProperty(value = "空白代码行数", required = true, position = 12)
    private Integer blanks;
    /**
    * 代码注释行数
    */
    @ApiModelProperty(value = "代码注释行数", required = true, position = 13)
    private Integer comments;
    /**
    * 状态
    */
    @ApiModelProperty(value = "状态", required = true, position = 14)
    private Integer status;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", required = true, position = 15)
    private Date createTime;

}
