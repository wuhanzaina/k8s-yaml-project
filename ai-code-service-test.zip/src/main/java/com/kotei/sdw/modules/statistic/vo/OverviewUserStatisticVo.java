/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddUserActivityVO.java
* 创建日期:2024-03-04
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
*
* 整体概览
 * 今日、本月活跃用户数，累计活跃用户数
 * 今日、本月活跃用户数，累计使用次数
*
*
* @author tiger
* @since 2024-03-04
*/
@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
@ApiModel(value = "OverviewUserStatisticVo", description = "整体概览-活跃度和使用次数统计")
public class OverviewUserStatisticVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
    * 今日活跃用户数
    */
    @ApiModelProperty(value = "今日活跃用户数", required = true, position = 1)
    private Integer todayActiveUserCount;
    /**
    * 本月活跃用户数
    */
    @ApiModelProperty(value = "本月活跃用户数", required = true, position = 2)
    private Integer monthActiveUserCount;
    /**
    * 累计活跃用户数
    */
    @ApiModelProperty(value = "累计活跃用户数", required = true, position = 3)
    private Integer totalActiveUserCount;

    /**
    * 今日使用次数
    */
    @ApiModelProperty(value = "今日使用次数", required = true, position = 4)
    private Integer todayUsageCount;
    /**
    * 本月使用次数
    */
    @ApiModelProperty(value = "本月使用次数", required = true, position = 5)
    private Integer monthUsageCount;
    /**
    * 累计使用次数
    */
    @ApiModelProperty(value = "累计使用次数", required = true, position = 6)
    private Integer totalUsageCount;



    /**
     * 今日使用token
     */
    @ApiModelProperty(value = "今日使用token", required = true, position = 4)
    private Integer todayTokenCount;
    /**
     * 本月使用token
     */
    @ApiModelProperty(value = "本月使用token", required = true, position = 5)
    private Integer monthTokenCount;
    /**
     * 累计使用token
     */
    @ApiModelProperty(value = "累计使用token", required = true, position = 6)
    private Integer totalTokenCount;

    /**
     * 今日使用费用
     */
    @ApiModelProperty(value = "今日使用费用", required = true, position = 4)
    private Double todayCostCount;
    /**
     * 本月使用费用
     */
    @ApiModelProperty(value = "本月使用费用", required = true, position = 5)
    private Double monthCostCount;
    /**
     * 累计使用费用
     */
    @ApiModelProperty(value = "累计使用费用", required = true, position = 6)
    private Double totalCostCount;

}
