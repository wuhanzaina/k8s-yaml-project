/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:UserActivityServiceImpl.java
 * 创建日期:2024-03-04
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.statistic.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcelFactory;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.exception.BaseException;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.constant.CommonConst;
import com.kotei.sdw.modules.feign.vo.DeptRes.DeptVo;
import com.kotei.sdw.modules.service.CommonService;
import com.kotei.sdw.modules.statistic.entity.UserActivity;
import com.kotei.sdw.modules.statistic.mapper.FunctionUsageMapper;
import com.kotei.sdw.modules.statistic.mapper.UserActivityMapper;
import com.kotei.sdw.modules.statistic.service.UserActivityService;
import com.kotei.sdw.modules.statistic.vo.*;
import com.kotei.sdw.modules.utils.CellStyleHandler;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.security.utils.SecurityUtils;
import com.kotei.sdw.system.api.model.LoginUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static java.util.Optional.ofNullable;

/**
 * 用户活跃度统计表 ServiceImpl
 *
 * @author tiger
 * @since 2024-03-04
 */
@Service
@Slf4j
public class UserActivityServiceImpl extends BaseServiceImpl<UserActivity> implements UserActivityService {
    @Autowired
    private UserActivityMapper userActivityMapper;
    @Autowired
    private FunctionUsageMapper functionUsageMapper;
    @Autowired
    private CommonService commonService;

    @Override
    protected BaseMapper<UserActivity> getMapper() {
        return userActivityMapper;
    }

    @Override
    public UserActivity get(Long id) {
        return userActivityMapper.selectById(id);
    }

    @Override
    public IPage<UserActivity> getList(PageVO<UserActivity> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<UserActivity> lambdaQueryWrapper = Wrappers.lambdaQuery(UserActivity.class)
                .eq(params.containsKey("userId"), UserActivity::getUserId, params.get("userId"))
                .eq(params.containsKey("activityDate"), UserActivity::getActivityDate, params.get("activityDate"))
                .eq(params.containsKey("rootDepartmentId"), UserActivity::getRootDepartmentId, params.get("rootDepartmentId"))
                .eq(params.containsKey("departmentId"), UserActivity::getDepartmentId, params.get("departmentId"));
        return userActivityMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long insert(UserActivity entity) {
        if (entity.getId() == null) {
            entity.setId(KeyGenerate.generateId());
        }
        if (entity.getCreateTime() == null) {
            entity.setCreateTime(new Date());
        }
        int count = userActivityMapper.insertBatch(Collections.singletonList(entity));
        return count > 0 ? entity.getId() : 0;
    }

    @Override
    public void delete(Long id) {
        userActivityMapper.deleteById(id);
    }

    @Override
    public void update(UserActivity entity) {
        userActivityMapper.updateById(entity);
    }

    /**
     * 统计某个日期范围内的每天、周、月活跃用户数量
     *
     * @param req
     * @return
     */
    @Override
    public List<UserActivityStatisticVo> findUserActivityStatistic(UserActivityStatisticReq req) {
        if (req.getType() == null) {
            throw new BaseException("请选择统计类型");
        }
        // 定义日期范围
        LocalDate startDate = LocalDate.parse(req.getStartDate());
        LocalDate endDate = LocalDate.parse(req.getEndDate());
        switch (req.getType()) {
            case DAY:
                // 构造日期列表
                return getUserActivityStatisticVos(req, startDate, endDate);
            case WEEK:
                // 构造日期列表
                return getUserActivityStatisticVos(req, endDate);
            case MONTH:
                // 构造日期列表
                return getActivityStatisticVos(req, startDate, endDate);
        }
        return Collections.emptyList();
    }

    /**
     * 获取用户活动统计信息
     *
     * @param req       用户活动统计请求对象
     * @param startDate 统计开始日期
     * @param endDate   统计结束日期
     * @return 活动统计信息列表
     */
    private List<UserActivityStatisticVo> getActivityStatisticVos(UserActivityStatisticReq req, LocalDate startDate, LocalDate endDate) {
        List<UserActivityStatisticVo> resultMonth = new ArrayList<>();
        LocalDate dateMonth = startDate;
        while (!dateMonth.isAfter(endDate)) {
            String activityDate = dateMonth.getYear() + "-" + String.format("%02d", dateMonth.getMonthValue());
            resultMonth.add(UserActivityStatisticVo.builder().activityDate(activityDate).build());
            dateMonth = dateMonth.plusMonths(1);
        }
        //数据库中查询得到的数据结果
        List<UserActivityStatisticVo> dataListMonth = functionUsageMapper.findActivityCountByMonthInRange(req);
        Map<String, Integer> mapFromDbMonth = dataListMonth.stream()
                .collect(Collectors.toMap(UserActivityStatisticVo::getActivityDate, UserActivityStatisticVo::getCount));
        // 数据库中取出的数据放入结果集
        for (UserActivityStatisticVo item : resultMonth) {
            Integer count = mapFromDbMonth.get(item.getActivityDate());
            item.setCount(count == null ? 0 : count);
        }
        return resultMonth;
    }

    /**
     * Retrieves a list of UserActivityStatisticVo objects based on the given UserActivityStatisticReq and endDate.
     *
     * @param req     The UserActivityStatisticReq object containing the request parameters.
     * @param endDate The end date for the statistics.
     * @return The list of UserActivityStatisticVo objects.
     */
    private List<UserActivityStatisticVo> getUserActivityStatisticVos(UserActivityStatisticReq req, LocalDate endDate) {
        List<UserActivityStatisticVo> resultWeek = new ArrayList<>();
        LocalDate dateWeek = LocalDate.parse(req.getStartDate());
        while (!dateWeek.isAfter(endDate)) {
            LocalDate endDateWeek = dateWeek.plusDays(6);
            //数据库中查询得到的数据结果
            int activityCountInRange = functionUsageMapper.findActivityCountInRange(
                    UserActivityStatisticReq.builder()
                            .startDate(dateWeek.toString())
                            .endDate(endDateWeek.toString()).build()
            );
            resultWeek.add(UserActivityStatisticVo.builder().activityDate(dateWeek + "/" + endDateWeek).count(activityCountInRange).build());
            dateWeek = dateWeek.plusWeeks(1);
        }
        return resultWeek;
    }

    /**
     * @param req       用户活动统计请求对象
     * @param startDate 统计开始日期
     * @param endDate   统计结束日期
     * @return 活动统计信息列表
     * @brief 获取用户活动统计信息
     */
    private List<UserActivityStatisticVo> getUserActivityStatisticVos(UserActivityStatisticReq req, LocalDate startDate, LocalDate endDate) {
        List<UserActivityStatisticVo> result = new ArrayList<>();
        LocalDate date = startDate;
        while (!date.isAfter(endDate)) {
            result.add(UserActivityStatisticVo.builder().activityDate(date.toString()).build());
            date = date.plusDays(1);
        }
        //数据库中查询得到的数据结果
        List<UserActivityStatisticVo> dataList = functionUsageMapper.findActivityCountByDayInRange(req);
        Map<String, Integer> mapFromDb = dataList.stream()
                .collect(Collectors.toMap(UserActivityStatisticVo::getActivityDate, UserActivityStatisticVo::getCount));
        // 数据库中取出的数据放入结果集
        for (UserActivityStatisticVo item : result) {
            Integer count = mapFromDb.get(item.getActivityDate());
            item.setCount(count == null ? 0 : count);
        }
        return result;
    }

    /**
     * 部门使用插件情况统计
     *
     * @param req
     * @return
     */
    @Override
    public List<DepartmentUsedStatisticVo> findDepartmentUsedStatistic(RangeStatisticReq req) {
        //以部门为单位统计用户活跃度
        List<DepartmentUsedStatisticVo> statisticVoList = functionUsageMapper.findActivityCountByDeptInRange(req);
        //获取部门的人数，人员使用率
        Map<Long, Integer> deptStaffCountMap = commonService.getAllRootDepartment().stream()
                .collect(Collectors.toMap(DeptVo::getId, v -> ofNullable(v.getStaffCount()).orElse(0), Integer::sum));
        //通过部门id统计部门使用插件的次数
        Map<Long, DepartmentUsedStatisticVo> usageTotalCountMap = functionUsageMapper.findUsedCountByDeptId(req).stream()
                .collect(Collectors.toMap(DepartmentUsedStatisticVo::getDepartmentId, Function.identity()));
        //使用次数最多的功能
        Map<Long, String> maxUsageFeatureByDeptMap = functionUsageMapper.findUsedCountByDeptAndType(req)
                .stream()
                .collect(Collectors.groupingBy(DepartmentUsedStatisticVo::getDepartmentId,
                                Collectors.collectingAndThen(
                                        Collectors.maxBy(Comparator.comparingInt(DepartmentUsedStatisticVo::getUsageTotalCount)),
                                        maxVo -> maxVo.map(DepartmentUsedStatisticVo::getUsageMostFeature).orElse(""))
                        )
                );

        for (DepartmentUsedStatisticVo item : statisticVoList) {
            Long departmentId = item.getDepartmentId();
            Integer staffCount = deptStaffCountMap.get(departmentId);
            item.setStaffCount(staffCount);
            item.setUsageRate(staffCount == null || staffCount == 0 ? 0 : Math.round(item.getUserActivityCount() * 100F / staffCount));

            DepartmentUsedStatisticVo departmentUsedStatisticVo = usageTotalCountMap.get(departmentId);
            if (departmentUsedStatisticVo != null) {
                item.setUsageTotalCount(departmentUsedStatisticVo.getUsageTotalCount());
                item.setTokenCount(departmentUsedStatisticVo.getTokenCount());
                item.setModelsCost(departmentUsedStatisticVo.getModelsCost() / CommonConst.NUM_10_000);
            }
            item.setUsageMostFeature(maxUsageFeatureByDeptMap.get(departmentId));
        }

        return statisticVoList;
    }

    /**
     * 记录当前登录用户的活跃度
     *
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public long save() {
        LoginUser loginUser = SecurityUtils.getLoginUser();
        log.info("用户活跃度新增记录 loginUser: {}", JSONUtil.toJsonStr(loginUser));
        UserActivity userActivity = new UserActivity();
        userActivity.setUserId(loginUser.getUserid());
        if (userActivity.getActivityDate() == null) {
            userActivity.setActivityDate(LocalDate.now().toString());
        }
        userActivity.setDepartmentId(loginUser.getSysUser().getDeptId());
        userActivity.setDepartmentName(loginUser.getSysUser().getDept().getDeptName());
        userActivity.setUserName(loginUser.getSysUser().getNickName());
        userActivity.setUserNo(loginUser.getSysUser().getUserName());

        //置换出根节点部门对象
        DeptVo rootDepartment = commonService.getRootDepartment(userActivity.getDepartmentId());
        userActivity.setRootDepartmentId(rootDepartment.getId());
        userActivity.setRootDepartmentName(rootDepartment.getLabel());
        return this.insert(userActivity);
    }

    /**
     * 用户活跃度导出
     *
     * @param req      请求参数
     * @param response 响应对象
     */
    @Override
    public void userActivityExport(RangeStatisticReq req, HttpServletResponse response) {
        // 从数据库查询数据
        List<UserActivityExportVo> list = this.functionUsageMapper.findUseCountByDeptInRange(req);
        if (CollUtil.isEmpty(list)) {
            return;
        }

        try {
            // 设置响应头部信息
            response.setContentType("application/vnd.ms-excel");
            response.setCharacterEncoding("utf-8");
            String fileName = URLEncoder.encode(String.format("用户活跃度列表_%s.xlsx", LocalDate.now()), "UTF-8");
            response.setHeader("Content-Disposition", "attachment;filename=" + fileName);

            // 获取输出流
            OutputStream outputStream = response.getOutputStream();
            BufferedOutputStream bos = new BufferedOutputStream(outputStream);

            // 添加标题行
            list.add(0, UserActivityExportVo
                    .builder()
                    .userNo("用户工号").activityDate("日期").userName("用户名称").departmentName("部门").rootDepartmentName("一级部门")
                    .genCode("生成代码次数").explainCode("代码解释").noteCodeFun("添加注释-函数").noteCodeLine("添加注释-逐行").qa("智能代码问答").count("使用总数")
                    .build());
            // 创建ExcelWriter对象
            ExcelWriter writer = EasyExcelFactory.write(bos).excelType(ExcelTypeEnum.XLSX).build();
            // 创建WriteSheet对象
            WriteSheet writeSheet = EasyExcelFactory.writerSheet(0).registerWriteHandler(new CellStyleHandler(new Integer[]{})).build();
            // 写入空行，用于设置样式
            writer.write(new ArrayList<>(), writeSheet);
            writer.write(new ArrayList<>(), writeSheet);
            // 写入数据
            writer.write(list, writeSheet);
            // 完成写入
            writer.finish();
            // 刷新缓冲区
            bos.flush();
        } catch (Exception e) {
            log.error("userActivityExport error", e);
        }
    }


}

