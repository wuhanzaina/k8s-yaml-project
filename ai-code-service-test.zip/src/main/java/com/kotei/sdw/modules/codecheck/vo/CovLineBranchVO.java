/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:AddCodeCovLineVO.java
 * 创建日期:2024-04-22
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 代码覆盖率分支信息
 *
 * @author tiger
 * @since 2024-04-22
 */
@Data
@NoArgsConstructor
@ApiModel(value = "CovLineBranchVO", description = "代码覆盖率分支信息")
public class CovLineBranchVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 行号
     */
    @ApiModelProperty(value = "行号", required = true, position = 1)
    private Integer lineNumber;

    @ApiModelProperty(value = "分支列表", required = true, position = 2)
    private List<BranchInfo> branches;

    @Data
    @NoArgsConstructor
    public static class BranchInfo {
        /**
         * 代码块编号
         */
        @ApiModelProperty(value = "代码块编号", required = true, position = 2)
        private Integer blockno;
        /**
         * 执行次数
         */
        @ApiModelProperty(value = "执行次数", required = true, position = 3)
        private Integer count;
        /**
         * 落地分支
         */
        @ApiModelProperty(value = "落地分支", required = true, position = 4)
        private String fallthrough;
    }
}
