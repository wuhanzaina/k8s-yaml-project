/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:DictDataServiceImpl.java
* 创建日期:2024-03-05
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.dict.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.modules.dict.entity.DictData;
import com.kotei.sdw.modules.dict.mapper.DictDataMapper;
import com.kotei.sdw.modules.dict.service.DictDataService;

/**
*
* 数据字典 ServiceImpl
*
*
* @author hk
* @since 2024-03-05
*/
@Service
public class DictDataServiceImpl extends BaseServiceImpl<DictData> implements DictDataService {
    @Autowired
    private DictDataMapper dictDataMapper;

    @Override
    protected BaseMapper<DictData> getMapper() {
    return dictDataMapper;
    }

    /**
     * 通过ID获取对象
     * @param id
     * @return
     */
    @Override
    public DictData get(Long id) {
    return dictDataMapper.selectById(id);
    }

    /**
     * 查询列表数据
     * @param page
     * @return
     */
    @Override
    public IPage<DictData> getList(PageVO<DictData> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<DictData> lambdaQueryWrapper =Wrappers.lambdaQuery(DictData.class)
        .eq(params.containsKey("dictCode"), DictData::getDictCode, params.get("dictCode"))
        .eq(params.containsKey("dictSort"), DictData::getDictSort, params.get("dictSort"))
        .eq(params.containsKey("dictLabel"), DictData::getDictLabel, params.get("dictLabel"))
        .eq(params.containsKey("dictValue"), DictData::getDictValue, params.get("dictValue"))
        .eq(params.containsKey("status"), DictData::getStatus, params.get("status"))
        .eq(params.containsKey("dictType"), DictData::getDictType, params.get("dictType"))
        .eq(params.containsKey("dictDefault"), DictData::getDictDefault, params.get("dictDefault"));
        return dictDataMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    /**
     * 插入数据
     * @param entity
     * @return
     */
    @Override
    public Long insert(DictData entity) {
        entity.setId(KeyGenerate.generateId());
        dictDataMapper.insert(entity);
        return entity.getId();
    }

    /**
     * 通过ID删除数据
     * @param id
     */
    @Override
    public void delete(Long id) {
        dictDataMapper.deleteById(id);
    }

    /**
     * 通过ID更新对象
     * @param entity
     */
    @Override
    public void update(DictData entity) {
        dictDataMapper.updateById(entity);
    }

    /**
     * 通过Type和type获取对象
     * @param type
     * @param value
     * @return
     */
    @Override
    public DictData getByTypeAndValue(String type, String value) {
        LambdaQueryWrapper<DictData> lambdaQueryWrapper =Wrappers.lambdaQuery(DictData.class)
                .eq( DictData::getDictType, type)
                .eq(DictData::getDictValue, value);
        return  dictDataMapper.selectOne(lambdaQueryWrapper);
    }

    @Override
    public List<DictData> getListByType(String type) {
        LambdaQueryWrapper<DictData> lambdaQueryWrapper =Wrappers.lambdaQuery(DictData.class)
                .eq( DictData::getDictType, type);
        return dictDataMapper.selectList(lambdaQueryWrapper);
    }
}
