/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddDictDataVO.java
* 创建日期:2024-03-05
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.dict.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
*
* 数据字典
*
*
* @author hk
* @since 2024-03-05
*/
@Data
@NoArgsConstructor
@ApiModel(value = "AddDictDataVO", description = "新增数据字典")
public class AddDictDataVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
    * 字典编码
    */
    @ApiModelProperty(value = "字典编码(200)", required = true, position = 2)
    @NotBlank(message = "字典编码不能为空")
    @Length(max = 200, message = "字典编码不能超过200个字符")
    private String dictCode;
    /**
    * 字典排序
    */
    @ApiModelProperty(value = "字典排序", required = true, position = 3)
    @NotNull(message = "字典排序不能为空")
    @Min(value = 0, message = "字典排序不能小于0")
    @Max(value = 50, message = "")
    private Integer dictSort;
    /**
    * 字典标签
    */
    @ApiModelProperty(value = "字典标签(200)", required = true, position = 4)
    @NotBlank(message = "字典标签不能为空")
    @Length(max = 200, message = "字典标签不能超过200个字符")
    private String dictLabel;
    /**
    * 字典键值
    */
    @ApiModelProperty(value = "字典键值(200)", required = true, position = 5)
    @NotBlank(message = "字典键值不能为空")
    @Length(max = 200, message = "字典键值不能超过200个字符")
    private String dictValue;
    /**
    * 状态 0.不可用  1.可用
    */
    @ApiModelProperty(value = "状态 0.不可用  1.可用", required = true, position = 6)
    @NotNull(message = "状态 0.不可用  1.可用不能为空")
    @Min(value = 0, message = "状态 0.不可用  1.可用不能小于0")
    @Max(value = 2, message = "")
    private Integer status;
    /**
    * 字典类型
    */
    @ApiModelProperty(value = "字典类型(200)", required = true, position = 7)
    @NotBlank(message = "字典类型不能为空")
    @Length(max = 200, message = "字典类型不能超过200个字符")
    private String dictType;
    /**
    * 是否默认 0.不是默认 1.是默认
    */
    @ApiModelProperty(value = "是否默认 0.不是默认 1.是默认", required = true, position = 8)
    @NotNull(message = "是否默认 0.不是默认 1.是默认不能为空")
    @Min(value = 0, message = "是否默认 0.不是默认 1.是默认不能小于0")
    @Max(value = 2, message = "")
    private Integer dictDefault;

}
