/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:AddBatchCodeUtTestCaseVO.java
 * 创建日期:2024-05-22
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.ut.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.List;

/**
 * 批量生成UT测试用例任务
 *
 * @author tiger
 * @since 2024-05-22
 */
@Data
@NoArgsConstructor
@ApiModel(value = "AddBatchCodeUtTestCaseVO", description = "新增批量生成UT测试用例任务")
public class AddBatchCodeUtTestCaseVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 项目工程标识
     */
    @ApiModelProperty(value = "项目工程标识(512)", required = true, position = 9)
    @NotBlank(message = "项目工程标识不能为空")
    private String projectCode;
    /**
     * 分支
     */
    @ApiModelProperty(value = "分支(128)", required = true, position = 10)
    @NotBlank(message = "分支不能为空")
    private String branch;

    /**
     * 函数列表
     */
    @ApiModelProperty(value = "函数列表", required = true, position = 10)
    private List<FunInfo> funList;

    @Data
    @NoArgsConstructor
    @ApiModel(value = "AddBatchCodeUtTestCaseVO_FunInfo", description = "新增批量生成UT测试用例任务函数内容")
    public static class FunInfo {

        /**
         * 文件路径
         */
        @ApiModelProperty(value = "文件路径", required = true, position = 9)
        @NotBlank(message = "文件路径不能为空")
        private String filePath;
        /**
         * 函数名称不能为空
         */
        @ApiModelProperty(value = "函数名称不能为空", required = true, position = 10)
        @NotBlank(message = "函数名称不能为空")
        private String funName;
    }


}
