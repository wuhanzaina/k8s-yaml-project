/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddUserActivityVO.java
* 创建日期:2024-03-04
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
*
* top10数据模型
*
*
* @author tiger
* @since 2024-03-04
*/
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "UsedTop10Vo", description = "top10数据模型")
public class UsedTop10Vo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
    * id
    */
    @ApiModelProperty(value = "id", required = true, position = 2)
    private String userId;

    /**
    * 工号
    */
    @ApiModelProperty(value = "工号", required = true, position = 2)
    private String userNo;

    @ApiModelProperty(value = "名称", required = true, position = 3)
    private String userName;
    /**
    * 数量
    */
    @ApiModelProperty(value = "数量", required = true, position = 4)
    private Integer count = 0;

}
