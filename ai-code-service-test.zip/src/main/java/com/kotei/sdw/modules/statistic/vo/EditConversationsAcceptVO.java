/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code
* 文件名称:EditConversationsAcceptVO.java
* 创建日期:2024-02-27
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.vo;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
*
* 会话采纳信息
*
*
* @author hk
* @since 2024-02-27
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@ApiModel(value = "EditConversationsAcceptVO", description = "编辑会话采纳信息")
public class EditConversationsAcceptVO extends AddConversationsAcceptVO {

    private static final long serialVersionUID = 1L;


}
