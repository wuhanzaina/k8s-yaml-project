package com.kotei.sdw.modules.ut.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author tiger
 * @date 2024/4/9 17:11
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FunAstInfoVo {

    /**
     * 测试目标函数名称
     */
    private String funName;

    /**
     * 测试目标函数返回类型
     */
    private String resultType;

    /**
     * 参数列表，包含一个NetworkHandleType类型的参数
     */
    private List<ParamInfoVo> params;

    /**
     * 变量列表
     */
    private List<ParamInfoVo> vars;

    /**
     * 全局静态变量列表
     */
    private List<ParamInfoVo> staticVars;

    /**
     * 宏定义列表
     */
    private List<ParamInfoVo> macroVars;

    /**
     * 枚举定义列表
     */
    private List<ParamInfoVo> enumVars;
    /**
     * 类型定义列表
     */
    private List<ParamInfoVo> classVars;

    /**
     * 存根函数列表，包含一个fun_name和一个mock_result
     */
    private List<Function> funs;
    /**
     * 命名空间列表
     */
    private List<String> namespaces;


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class ParamInfoVo {
        /**
         * 参数名称
         */
        private String name;
        /**
         * 参数类型
         */
        private String type;
        /**
         * 参数类型定义
         */
        private String content;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Function {
        /**
         * 存根函数名称
         */
        private String funName;

        /**
         * 存根函数的返回类型
         */
        private String resultType;
        /**
         * 存根函数的返回类型定义
         */
        private String resultTypeContent;

        /**
         * 存根函数的参数列表
         */
        private List<ParamInfoVo> params;
    }
}
