/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddCodeCovLineVO.java
* 创建日期:2024-04-22
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
*
* 代码覆盖率行记录表
*
*
* @author tiger
* @since 2024-04-22
*/
@Data
@NoArgsConstructor
@ApiModel(value = "AddCodeCovLineVO", description = "新增代码覆盖率行记录表")
public class AddCodeCovLineVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
    * 任务ID
    */
    @ApiModelProperty(value = "任务ID", required = true, position = 2)
    @NotNull(message="任务ID不能为空")
    private Long covTaskId;
    /**
    * 任务函数ID
    */
    @ApiModelProperty(value = "任务函数ID", required = true, position = 3)
    @NotNull(message="任务函数ID不能为空")
    private Long covLineId;
    /**
    * 行号
    */
    @ApiModelProperty(value = "行号", required = true, position = 4)
    @NotNull(message = "行号不能为空")
    @Min(value = 0, message = "行号不能小于0")
    private Integer lineNumber;

}
