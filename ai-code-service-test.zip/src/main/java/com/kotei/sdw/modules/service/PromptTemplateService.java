/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code
* 文件名称:PromptTemplateService.java
* 创建日期:2024-02-27
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.service;

import com.kotei.sdw.modules.entity.PromptTemplate;
import com.kotei.sdw.modules.vo.AddPromptTemplateVO;
import com.kotei.sdw.modules.vo.EditPromptTemplateVO;
import com.kotei.sdw.mvc.service.BaseService;

/**
*
* prompt模板 Service
*
*
* @author hk
* @since 2024-02-27
*/
public interface PromptTemplateService extends BaseService<PromptTemplate> {
    /**
     * 新增
     * @param add
     */
    Long insert(AddPromptTemplateVO add);

    /**
     * 修改
     * @param edit
     */
    void update(EditPromptTemplateVO edit);

    PromptTemplate getByMarketIdAndUserId(Long marketId, Long userId);

    /**
     * 分享到市场
     * @param ptId
     * @return 提示词市场ID
     */
    void share(Long ptId, Integer share);
}
