package com.kotei.sdw.modules.codecheck.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * {
 *   "object_kind": "push",
 *   "event_name": "push",
 *   "before": "c64683ab400b353ac0ddc020e4517ac009010943",
 *   "after": "76f76205ba6703bc92c71eb596615d9353a597a1",
 *   "ref": "refs/heads/main",
 *   "ref_protected": true,
 *   "checkout_sha": "76f76205ba6703bc92c71eb596615d9353a597a1",
 *   "message": null,
 *   "user_id": 1,
 *   "user_name": "Administrator",
 *   "user_username": "root",
 *   "user_email": null,
 *   "user_avatar": "https://www.gravatar.com/avatar/258d8dc916db8cea2cafb6c3cd0cb0246efe061421dbd83ec3a350428cabda4f?s=80&d=identicon",
 *   "project_id": 1,
 *   "project": {
 *     "id": 1,
 *     "name": "test_project",
 *     "description": null,
 *     "web_url": "http://192.168.52.66:9980/dcs_code_project/test_project",
 *     "avatar_url": null,
 *     "git_ssh_url": "ssh://git@192.168.52.66:9922/dcs_code_project/test_project.git",
 *     "git_http_url": "http://192.168.52.66:9980/dcs_code_project/test_project.git",
 *     "namespace": "dcs_code_project",
 *     "visibility_level": 0,
 *     "path_with_namespace": "dcs_code_project/test_project",
 *     "default_branch": "main",
 *     "ci_config_path": null,
 *     "homepage": "http://192.168.52.66:9980/dcs_code_project/test_project",
 *     "url": "ssh://git@192.168.52.66:9922/dcs_code_project/test_project.git",
 *     "ssh_url": "ssh://git@192.168.52.66:9922/dcs_code_project/test_project.git",
 *     "http_url": "http://192.168.52.66:9980/dcs_code_project/test_project.git"
 *   },
 *   "commits": [
 *     {
 *       "id": "76f76205ba6703bc92c71eb596615d9353a597a1",
 *       "message": "Update README.md3",
 *       "title": "Update README.md3",
 *       "timestamp": "2024-04-03T07:11:47+00:00",
 *       "url": "http://192.168.52.66:9980/dcs_code_project/test_project/-/commit/76f76205ba6703bc92c71eb596615d9353a597a1",
 *       "author": {
 *         "name": "Administrator",
 *         "email": "[REDACTED]"
 *       },
 *       "added": [
 *
 *       ],
 *       "modified": [
 *         "README.md"
 *       ],
 *       "removed": [
 *
 *       ]
 *     },
 *     {
 *       "id": "060150da9f57ce3509bc4e4fe4f2466c16cce216",
 *       "message": "推送工程\n",
 *       "title": "推送工程",
 *       "timestamp": "2024-03-26T12:06:05+08:00",
 *       "url": "http://192.168.52.66:9980/dcs_code_project/test_project/-/commit/060150da9f57ce3509bc4e4fe4f2466c16cce216",
 *       "author": {
 *         "name": "wangzhengyao",
 *         "email": "[REDACTED]"
 *       },
 *       "added": [
 *
 *       ],
 *       "modified": [
 *         "README.md"
 *       ],
 *       "removed": [
 *
 *       ]
 *     },
 *     {
 *       "id": "c64683ab400b353ac0ddc020e4517ac009010943",
 *       "message": "推送工程\n",
 *       "title": "推送工程",
 *       "timestamp": "2024-03-26T11:19:57+08:00",
 *       "url": "http://192.168.52.66:9980/dcs_code_project/test_project/-/commit/c64683ab400b353ac0ddc020e4517ac009010943",
 *       "author": {
 *         "name": "wangzhengyao",
 *         "email": "[REDACTED]"
 *       },
 *       "added": [
 *         "HelloJava.java"
 *       ],
 *       "modified": [
 *         "README.md"
 *       ],
 *       "removed": [
 *
 *       ]
 *     }
 *   ],
 *   "total_commits_count": 3,
 *   "push_options": {
 *   },
 *   "repository": {
 *     "name": "test_project",
 *     "url": "ssh://git@192.168.52.66:9922/dcs_code_project/test_project.git",
 *     "description": null,
 *     "homepage": "http://192.168.52.66:9980/dcs_code_project/test_project",
 *     "git_http_url": "http://192.168.52.66:9980/dcs_code_project/test_project.git",
 *     "git_ssh_url": "ssh://git@192.168.52.66:9922/dcs_code_project/test_project.git",
 *     "visibility_level": 0
 *   }
 * }
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class GitlabPushEventVo {
    // 事件类型
    @JsonProperty("object_kind")
    private String objectKind;
    // 事件名称
    @JsonProperty("event_name")
    private String eventName;
    // push前的commit id
    private String before;
    // push后的commit id
    private String after;
    // 分支名称
    private String ref;
    // checkout的commit id
    @JsonProperty("checkout_sha")
    private String checkoutSha;
    // 提交信息
    private String message;
    // 用户id
    @JsonProperty("user_id")
    private int userId;
    // 用户名
    @JsonProperty("user_name")
    private String userName;
    // 用户账号
    @JsonProperty("user_username")
    private String userUsername;
    // 用户邮箱
    @JsonProperty("user_email")
    private String userEmail;
    // 用户头像
    @JsonProperty("user_avatar")
    private String userAvatar;
    // 项目id
    @JsonProperty("project_id")
    private int projectId;
    // 项目信息
    private Project project;
    // 提交信息列表
    private List<Commit> commits;
    // 提交数量
    @JsonProperty("total_commits_count")
    private int totalCommitsCount;
    // 仓库信息
    private Repository repository;


    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class Project {
        // 项目id
        private int id;
        // 项目名称
        private String name;
        // 项目描述
        private String description;
        // 项目web地址
        @JsonProperty("web_url")
        private String webUrl;
        // 项目头像地址
        @JsonProperty("avatar_url")
        private String avatarUrl;
        // 项目git ssh地址
        @JsonProperty("git_ssh_url")
        private String gitSshUrl;
        // 项目git http地址
        @JsonProperty("git_http_url")
        private String gitHttpUrl;
        // 项目命名空间
        private String namespace;
        // 可见性等级
        @JsonProperty("visibility_level")
        private int visibilityLevel;
        // 命名空间路径
        @JsonProperty("path_with_namespace")
        private String pathWithNamespace;
        // 默认分支
        @JsonProperty("default_branch")
        private String defaultBranch;
        // ci配置路径
        @JsonProperty("ci_config_path")
        private String ciConfigPath;
        // 项目主页
        private String homepage;
        // 项目地址
        private String url;
        // 项目ssh地址
        @JsonProperty("ssh_url")
        private String sshUrl;
        // 项目http地址
        @JsonProperty("http_url")
        private String httpUrl;
    }

    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class Commit {
        // 提交id
        private String id;
        // 提交信息
        private String message;
        // 提交时间戳
        private String timestamp;
        // 提交地址
        private String url;
        // 提交作者信息
        private Author author;
        // 新增文件列表
        private List<String> added;
        // 修改文件列表
        private List<String> modified;
        // 删除文件列表
        private List<String> removed;
    }

    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class Author {
        // 作者名称
        private String name;
        // 作者邮箱
        private String email;
    }

    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class Repository {
        // 仓库名称
        private String name;
        // 仓库地址
        private String url;
        // 仓库描述
        private String description;
        // 仓库主页
        private String homepage;
        // 仓库git http地址
        @JsonProperty("git_http_url")
        private String gitHttpUrl;
        // 仓库git ssh地址
        @JsonProperty("git_ssh_url")
        private String gitSshUrl;
        // 可见性等级
        @JsonProperty("visibility_level")
        private int visibilityLevel;
    }
}