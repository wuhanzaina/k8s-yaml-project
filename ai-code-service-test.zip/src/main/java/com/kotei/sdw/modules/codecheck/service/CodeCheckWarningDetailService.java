/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:CodeCheckWarningDetailService.java
* 创建日期:2024-03-28
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.service;

import com.kotei.sdw.modules.codecheck.entity.CodeCheckWarningDetail;
import com.kotei.sdw.mvc.service.BaseService;

/**
*
* 代码静态扫描警告明细表 Service
*
*
* @author tiger
* @since 2024-03-28
*/
public interface CodeCheckWarningDetailService extends BaseService<CodeCheckWarningDetail> {

}
