/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:CodeCheckTask.java
* 创建日期:2024-03-26
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.kotei.sdw.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
*
* 代码检查任务表
*
*
* @author tiger
* @since 2024-03-26
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("code_check_task")
@ApiModel(value = "CodeCheckTask", description = "代码检查任务表")
public class CodeCheckTask extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 类型：ALL:全量扫描; INCREMENT:增量扫描
    */
    @ApiModelProperty(value = "类型：ALL:全量扫描; INCREMENT:增量扫描", position = 2)
    private String type;
    /**
    * 执行任务ID
    */
    @ApiModelProperty(value = "执行任务ID", position = 3)
    private String execTaskId;
    /**
    * hookId
    */
    @ApiModelProperty(value = "hookId", position = 3)
    private Long hookId;
    /**
    * 用户ID
    */
    @ApiModelProperty(value = "用户ID", position = 4)
    private Long userId;
    /**
    * 用户名称
    */
    @ApiModelProperty(value = "用户名称", position = 5)
    private String userName;
    /**
    * 工号
    */
    @ApiModelProperty(value = "工号", position = 6)
    private String userNo;
    /**
    * 当前部门ID
    */
    @ApiModelProperty(value = "当前部门ID", position = 7)
    private Long departmentId;
    /**
    * 当前部门
    */
    @ApiModelProperty(value = "当前部门", position = 8)
    private String departmentName;
    /**
    * 一级部门ID
    */
    @ApiModelProperty(value = "一级部门ID", position = 9)
    private Long rootDepartmentId;
    /**
    * 一级部门
    */
    @ApiModelProperty(value = "一级部门", position = 10)
    private String rootDepartmentName;
    /**
    * 项目标识
    */
    @ApiModelProperty(value = "项目标识", position = 11)
    private String projectCode;
    /**
    * 分支
    */
    @ApiModelProperty(value = "分支", position = 12)
    private String branch;
    /**
    * 最大圈复杂度
    */
    @ApiModelProperty(value = "最大圈复杂度", position = 13)
    private Integer maxCircleComplexity;
    /**
    * 平均圈复杂度
    */
    @ApiModelProperty(value = "平均圈复杂度", position = 13)
    private Integer circleComplexity;
    /**
    * 代码总行数
    */
    @ApiModelProperty(value = "代码总行数", position = 14)
    private Integer codes;
    /**
    * 空白代码行数
    */
    @ApiModelProperty(value = "空白代码行数", position = 15)
    private Integer blanks;
    /**
    * 代码注释行数
    */
    @ApiModelProperty(value = "代码注释行数", position = 16)
    private Integer comments;
    /**
    * warning总数
    */
    @ApiModelProperty(value = "warning总数", position = 17)
    private Integer warning;
    /**
    * error总数
    */
    @ApiModelProperty(value = "error总数", position = 18)
    private Integer error;
    /**
    * 注释率不达标数量
    */
    @ApiModelProperty(value = "注释率不达标数量", position = 17)
    private Integer offGradeComments;
    /**
    * 圈复杂度不达标数量
    */
    @ApiModelProperty(value = "圈复杂度不达标数量", position = 18)
    private Integer offGradeCircleComplexity;
    /**
    * 状态 0：初始化；1：执行中；2：执行完成；3：执行失败
    */
    @ApiModelProperty(value = "状态 0：初始化；1：执行中；2：执行完成；3：执行失败", position = 19)
    private Integer status;

    @ApiModelProperty(value = "执行失败原因", position = 19)
    private String message;

    /**
     * 扫描语言
     */
    @ApiModelProperty(value = "扫描语言", required = true, position = 12)
    private String language;

    @ApiModelProperty(value = "技术债等级", required = true, position = 12)
    private String sqaleDebtRatio;
    /**
     * 邮箱地址
     */
    @ApiModelProperty(value = "邮箱地址", required = true, position = 12)
    private String email;

    /**
     * pm名字
     */
    @ApiModelProperty(value = "pm名字", required = true, position = 12)
    private String pm;

    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", position = 20)
    private Date createTime;
    /**
    * 任务完成时间
    */
    @ApiModelProperty(value = "任务完成时间", position = 20)
    private Date finishTime;


}
