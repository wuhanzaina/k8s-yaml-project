/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddCodeCheckTaskVO.java
* 创建日期:2024-03-26
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
*
* 代码检查任务表
*
*
* @author tiger
* @since 2024-03-26
*/
@Data
@NoArgsConstructor
@ApiModel(value = "AddCodeCheckTaskVO", description = "新增代码检查任务表")
public class AddCodeCheckTaskVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
    * 项目标识
    */
    @ApiModelProperty(value = "项目标识(512)", required = true, position = 11)
    @NotNull(message = "项目标识不能为空")
    private String projectCode;
    /**
    * 分支
    */
    @ApiModelProperty(value = "分支(128)", required = true, position = 12)
    @NotNull(message = "分支不能为空")
    private String branch;
    /**
    * 扫描语言
    */
    @ApiModelProperty(value = "扫描语言", required = true, position = 12)
    private String language;

    /**
     * 邮箱地址
     */
    @ApiModelProperty(value = "发送邮箱地址", required = true, position = 12)
    private String email;

    /**
     * pm名字
     */
    @ApiModelProperty(value = "pm名称", required = true, position = 12)
    private String pm;

}
