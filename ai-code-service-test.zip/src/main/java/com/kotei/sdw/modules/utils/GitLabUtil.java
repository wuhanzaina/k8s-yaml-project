package com.kotei.sdw.modules.utils;

import lombok.extern.slf4j.Slf4j;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.ResetCommand;
import org.eclipse.jgit.api.Status;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.diff.DiffEntry;
import org.eclipse.jgit.diff.DiffFormatter;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.eclipse.jgit.util.FileUtils;
import org.eclipse.jgit.util.io.DisabledOutputStream;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.File;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.kotei.sdw.util.StreamUtil.toStream;
import static java.util.stream.Collectors.toList;

@Slf4j
public class GitLabUtil {
    public static final String GIT_POSTFIX = ".git";

    /**
     * 克隆代码仓库
     *
     * @param repositoryUrl 仓库的URL地址
     * @param branch        分支名称
     * @param username      用户名
     * @param password      密码
     * @param localProjectPath   项目本地路径
     * @throws GitAPIException 如果Git操作失败
     * @throws IOException     如果IO操作失败
     */
    public static void cloneRepository(String repositoryUrl, String branch, String username, String password, String localProjectPath) throws GitAPIException, IOException {
        // 创建SSL上下文，绕过证书验证
        ignoreSSLVerifier();

        File localDir = new File(localProjectPath);
        boolean existsRepository = existsGitRepository(localDir);
        log.info("existsRepository repositoryUrl: {} localDir: {} existsRepository: {}", repositoryUrl, localDir, existsRepository);
        if (existsRepository) {
            // 如果本地已经存在.git目录，则执行pull操作
            try (Git git = Git.open(localDir)) {
                Status status = git.status().call();
                if (!status.isClean()) {
                    //本地仓库不干净，放弃本地更改
                    git.reset().setMode(ResetCommand.ResetType.HARD).call();
                }
                //拉取远程最新的代码
                git.pull()
                        .setCredentialsProvider(getCredentialsProvider(username, password))
                        .setRemote("origin")
                        .setRemoteBranchName(branch)
                        .call();
            }
        } else {
            // 删除本地目录（如果存在）
            FileUtils.delete(localDir, FileUtils.SKIP_MISSING);
            // 执行clone操作
            Git.cloneRepository()
                    .setBranch(branch)
                    .setURI(repositoryUrl)
                    .setCredentialsProvider(getCredentialsProvider(username, password))
                    .setDirectory(localDir)
                    .call();
        }
    }

//    public static void main(String[] args) throws GitAPIException, IOException {
//        String url = "https://172.16.0.120/astri/RI-KCAROS-BSWCP/KT_CP/KT_CP_test.git";
//        String branch = "master";
//        String username = "dcs.codechecker";
//        String password = "ocsa@2024!";
//        String localProjectPath = "D:/work/test";
//        cloneRepository(url, branch, username, password, localProjectPath);
//    }

    public static boolean existsGitRepository(File localDir) {
        return localDir.exists() && localDir.isDirectory() && new File(localDir, GIT_POSTFIX).exists();
    }

    /**
     * @param username 用户名
     * @param password 密码
     * @return 用户名和密码凭据提供程序
     * @brief 获取用户名和密码提供程序
     * <p>
     * 通过给定的用户名和密码创建一个用户名密码凭据提供程序.
     */
    private static UsernamePasswordCredentialsProvider getCredentialsProvider(String username, String password) {
        return new UsernamePasswordCredentialsProvider(username, password);
    }

    /**
     * 创建SSL上下文，绕过证书验证
     */
    private static void ignoreSSLVerifier() {
        try {
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[]{new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] x509Certificates, String s) {
                }

                public void checkServerTrusted(X509Certificate[] x509Certificates, String s) {
                }

                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
            }}, null);

            // 设置全局SSL上下文
            HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
        } catch (NoSuchAlgorithmException | KeyManagementException e) {
            log.error("ignoreSSLVerifier error", e);
        }
    }

    /**
     * @param repositoryUrl The URL of the repository.
     * @return The project name extracted from the repository URL, or null if the project name cannot be extracted.
     * @brief Extracts the project name from a repository URL.
     */
    public static String extractProjectName(String repositoryUrl) {
        /* Define the regular expression pattern to match the project name in the repository URL. */
        String pattern = ".*/(.*)" + GIT_POSTFIX;
        /* Create a regex pattern object using the defined pattern. */
        Pattern regex = Pattern.compile(pattern);
        /* Create a matcher object to match the pattern against the repository URL. */
        Matcher matcher = regex.matcher(repositoryUrl);
        /* Check if the pattern matches the repository URL. */
        if (matcher.find()) {
            /* Return the project name extracted from the repository URL. */
            return matcher.group(1);
        }
        /* Return null if the project name cannot be extracted from the repository URL. */
        return null;
    }

    /**
     * 判断远程分支和本地分支是否存在差异
     * @param projectPath
     * @param branch
     * @param excludedFolders
     * @return
     */
    public static boolean diffFromGitLab(String projectPath, String branch, List<String> excludedFolders) {
        try (Repository repository = Git.open(new File(projectPath)).getRepository()) {
            ObjectId localBranchId = repository.resolve("refs/heads/" + branch);
            ObjectId remoteBranchId = repository.resolve("refs/remotes/origin/" + branch);

            try (RevWalk revWalk = new RevWalk(repository)) {
                RevCommit localCommit = revWalk.parseCommit(localBranchId);
                RevCommit remoteCommit = revWalk.parseCommit(remoteBranchId);

                DiffFormatter diffFormatter = new DiffFormatter(DisabledOutputStream.INSTANCE);
                diffFormatter.setRepository(repository);
                List<DiffEntry> diffs = diffFormatter.scan(localCommit.getTree(), remoteCommit.getTree());

                // 排除文件夹路径
                // 过滤差异文件列表
                List<DiffEntry> filteredDiffs = toStream(diffs)
                        .filter(diff -> toStream(excludedFolders)
                                .noneMatch(folder -> diff.getNewPath().toUpperCase().contains(folder.toUpperCase()) || diff.getOldPath().toUpperCase().contains(folder.toUpperCase())))
                        .collect(toList());

                if (filteredDiffs.isEmpty()) {
                    log.info("本地分支和远程分支没有差异 projectPath: {}", projectPath);
                    return false;
                } else {
                    log.info("本地分支和远程分支有差异 projectPath: {}", projectPath);
                    return true;
                }
            }
        } catch (Exception e) {
            log.error("diffFromGitLab", e);
        }
        return false;
    }

}
