package com.kotei.sdw.modules.statistic.constant.enums;

/**
 * @author tiger
 * @date 2024/4/3 11:39
 */
public enum CodeUtTestCaseStatusEnum {
    DEFAULT(-1, ""),
    INIT(0, "用户提交请求"),
    AST(1, "AST结构生成"),
    AI_STRUCTURE(2, "AI结构化数据生成"),
    USER_STRUCTURE(3, "用户提交结构化数据"),
    SUCCESS(4, "测试用例生成完成"),
    FAILED(5, "测试用例生成失败"),
    ;

    private final Integer code;
    private final String name;

    CodeUtTestCaseStatusEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    /**
     * 通过code获取
     *
     * @param code
     * @return
     */
    public static CodeUtTestCaseStatusEnum getByCode(Integer code) {
        if (code == null) {
            return DEFAULT;
        }
        for (CodeUtTestCaseStatusEnum type : CodeUtTestCaseStatusEnum.values()) {
            if (type.getCode().equals(code)) {
                return type;
            }
        }
        return DEFAULT;
    }
}
