/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code
* 文件名称:PromptTemplateService.java
* 创建日期:2024-02-27
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.service;

import com.kotei.sdw.modules.entity.PromptFunction;
import com.kotei.sdw.modules.vo.AddPromptTemplateVO;
import com.kotei.sdw.mvc.service.BaseService;

import java.util.List;

/**
 * 系统功能提示词模板服务
 * 如: 代码生成、代码解释、代码注释、代码纠错等...
 * @author mahuang
 * @since 2024-03-19
 */
public interface PromptFunctionService extends BaseService<PromptFunction> {

    /**
     * 查询用户当前所有功能提示词模板
     */
    List<PromptFunction> getPromptFunctionsByUser();

    /**
     * 新增或修改
     * @param add
     */
    Long saveOrUpdate(AddPromptTemplateVO add);
}
