/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:AddPromptMarketVO.java
 * 创建日期:2024-05-14
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * 提示词市场
 *
 *
 * @author tiger
 * @since 2024-05-14
 */
@Data
@NoArgsConstructor
@ApiModel(value = "AddPromptMarketVO", description = "新增提示词市场")
public class AddPromptMarketVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 模板名称
     */
    @ApiModelProperty(value = "模板名称(100)", required = true, position = 2)
    @NotBlank(message = "模板名称不能为空")
    @Length(max = 100, message = "模板名称不能超过100个字符")
    private String name;
    /**
     * 模板状态.0:不可用  1：可用
     */
    @ApiModelProperty(value = "模板状态.0:不可用  1：可用", required = true, position = 3)
    @NotNull(message = "模板状态.0:不可用  1：可用不能为空")
    @Min(value = 0, message = "模板状态.0:不可用  1：可用不能小于0")
    private Integer status;
    /**
     * 分享状态 0:未分享  1：已分享
     */
    @ApiModelProperty(value = "分享状态 0:未分享  1：已分享", required = true, position = 4)
    @NotNull(message = "分享状态 0:未分享  1：已分享不能为空")
    @Min(value = 0, message = "分享状态 0:未分享  1：已分享不能小于0")
    private Integer share;
    /**
     * 被分享次数
     */
    @ApiModelProperty(value = "被分享次数", required = true, position = 5)
    @NotNull(message = "被分享次数不能为空")
    @Min(value = 0, message = "被分享次数不能小于0")
    private Integer shareCount;
    /**
     * 开发语言
     */
    @ApiModelProperty(value = "开发语言(64)", required = true, position = 6)
    @NotBlank(message = "开发语言不能为空")
    @Length(max = 64, message = "开发语言不能超过64个字符")
    private String language;
    /**
     * 提示词介绍
     */
    @ApiModelProperty(value = "提示词介绍(1024)", required = true, position = 7)
    @NotBlank(message = "提示词介绍不能为空")
    @Length(max = 1024, message = "提示词介绍不能超过1024个字符")
    private String intro;
    /**
     * 提示词内容
     */
    @ApiModelProperty(value = "提示词内容", required = true, position = 8)
    @NotNull(message = "提示词内容不能为空")
    private String context;
    /**
     * 创建人id
     */
    @ApiModelProperty(value = "创建人id", required = true, position = 9)
    @NotNull(message = "创建人id不能为空")
    private Long createrId;
    /**
     * 创建人
     */
    @ApiModelProperty(value = "创建人(60)", required = true, position = 10)
    @NotBlank(message = "创建人不能为空")
    @Length(max = 60, message = "创建人不能超过60个字符")
    private String createrName;
    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间", required = true, position = 11)
    @NotNull(message = "创建时间不能为空")
    private Date createTime;
    /**
     * 修改人id
     */
    @ApiModelProperty(value = "修改人id", required = true, position = 12)
    @NotNull(message = "修改人id不能为空")
    private Long modifierId;
    /**
     * 修改人名称
     */
    @ApiModelProperty(value = "修改人名称(60)", required = true, position = 13)
    @NotBlank(message = "修改人名称不能为空")
    @Length(max = 60, message = "修改人名称不能超过60个字符")
    private String modifierName;
    /**
     * 修改时间
     */
    @ApiModelProperty(value = "修改时间", required = true, position = 14)
    @NotNull(message = "修改时间不能为空")
    private Date modifyTime;

}
