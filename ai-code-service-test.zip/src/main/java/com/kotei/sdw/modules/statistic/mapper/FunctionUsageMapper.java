/**
* All rights Reserved, Designed By www.kote.net
* 项目名称:ai-code-service
* 文件名称:FunctionUsageMapper.java
* 创建日期:2024-03-05
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.mapper;

import com.kotei.sdw.modules.statistic.entity.FunctionUsage;
import com.kotei.sdw.modules.statistic.vo.*;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
*
* 功能使用情况 Mapper
*
*
* @author hk
* @since 2024-03-05
*/
@Mapper
public interface FunctionUsageMapper extends BaseMapper<FunctionUsage> {

    /**
     * 用户插件使用次数top10
     * @param req
     * @return
     */
    List<UsedTop10Vo> usedTop10(RangeStatisticReq req);

    /**
     * 采纳率top10
     * @param req
     * @return
     */
    List<UsedTop10Vo> adoptionTop10(RangeStatisticReq req);

    /**
     * 统计部门使用插件的次数
     * @param req
     * @return
     */
    List<DepartmentUsedStatisticVo> findUsedCountByDeptId(RangeStatisticReq req);


    /**
     * 统计部门+功能类型使用插件的次数
     * @param req
     * @return
     */
    List<DepartmentUsedStatisticVo> findUsedCountByDeptAndType(RangeStatisticReq req);

    OverviewUserStatisticVo findTodayUsageCount();
    OverviewUserStatisticVo findMonthUsageCount();
    OverviewUserStatisticVo findTotalUsageCount();


    int findTodayActiveUserCount();
    int findMonthActiveUserCount();
    int findTotalActiveUserCount();


    List<UserActivityStatisticVo> findActivityCountByDayInRange(UserActivityStatisticReq req);

    int findActivityCountInRange(UserActivityStatisticReq req);

    List<UserActivityStatisticVo> findActivityCountByMonthInRange(UserActivityStatisticReq req);

    List<DepartmentUsedStatisticVo> findActivityCountByDeptInRange(RangeStatisticReq req);

    List<UserActivityExportVo> findUseCountByDeptInRange(RangeStatisticReq req);
}
