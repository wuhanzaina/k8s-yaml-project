/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:GitlabHookServiceImpl.java
 * 创建日期:2024-03-26
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.service.impl;

import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kotei.sdw.api.ResultEnum;
import com.kotei.sdw.exception.BaseException;
import com.kotei.sdw.json.util.JsonUtil;
import com.kotei.sdw.modules.codecheck.service.GitUrlVerifyService;
import com.kotei.sdw.modules.config.AccessKeyConfig;
import com.kotei.sdw.modules.config.GitLabConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;


/**
 * gitlab hook记录表 ServiceImpl
 *
 * @author hk
 * @since 2024-12-09
 */
@Service
@Slf4j
public class GitUrlVerifyServiceImpl implements GitUrlVerifyService {

    @Autowired
    private GitLabConfig gitLabConfig;

    @Override
    public Boolean verify(String url) {
        String accessKey;
        boolean validGitLabUrl= Boolean.FALSE;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(url);
            JsonNode commitsNode = jsonNode.get("url");
            url = commitsNode.textValue();
            // 使用 split 方法分割 URL
            String[] parts = url.split("/");

            // 获取主机部分（即第一个元素）
            String host = parts[2];
            String config = gitLabConfig.getAccessKey().get(host);
            AccessKeyConfig accessKeyConfig = JsonUtil.toObject(config, AccessKeyConfig.class);
            url = this.replaceIpInUrl(url, accessKeyConfig.getReplace());
            accessKey = accessKeyConfig.getAccessKey();
        }catch (Exception e){
            e.printStackTrace();
            throw new BaseException(ResultEnum.NOT_FOUND.getCode(), ResultEnum.NOT_FOUND.getMsg());
        }
        // 4. 判断文件扩展名
        if(!url.endsWith(".xls") && !url.endsWith(".xlsx")){
            throw new BaseException(ResultEnum.PARAM_VERIFICATION_FAILED.getCode(), "文件校验不通过");
        }
        if(StrUtil.isNotBlank(accessKey)){
            this.disableSslVerification();
            validGitLabUrl = this.isValidGitLabUrl(url, accessKey);
        }else {
            throw new BaseException(ResultEnum.UNAUTHORIZED.getCode(), "未授权访问");
        }

        return validGitLabUrl;
    }

    // 校验 GitLab URL 是否有效，并且是否指向一个有效文件
    private  boolean isValidGitLabUrl(String url, String accessKey) {
        int responseCode;
        HttpURLConnection connection;
        try {
            // 1. 校验 URL 格式是否正确
            URL parsedUrl = new URL(url);

            // 2. 使用 GitLab API 验证 URL 是否存在
            connection = (HttpURLConnection) parsedUrl.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("PRIVATE-TOKEN", accessKey); // 设置 access key

            responseCode = connection.getResponseCode();
        } catch (Exception e) {
            throw new BaseException(ResultEnum.UNAUTHORIZED.getCode(), "未授权访问");
        }
        // 3. 判断是否是有效文件
        if (responseCode == HttpURLConnection.HTTP_OK) {
            // 获取文件信息
            String contentType = connection.getHeaderField("Content-Type");
            return contentType != null && contentType.startsWith("text/html"); // 文件信息通常是 JSON 格式
        } else {
            throw new BaseException(ResultEnum.NOT_FOUND.getCode(), ResultEnum.NOT_FOUND.getMsg());
        }

    }


    // 忽略 SSL 证书验证
    private void disableSslVerification() {
        try {
            // 创建一个不验证证书的 TrustManager
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        public void checkClientTrusted(X509Certificate[] certs, String authType) {
                        }

                        public void checkServerTrusted(X509Certificate[] certs, String authType) {
                        }
                    }
            };

            // 安装 TrustManager
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // 忽略主机名验证
            HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
        } catch (NoSuchAlgorithmException | KeyManagementException e) {
            e.printStackTrace();
        }
    }

    /**
     * 替换 URL 中的 IP 地址
     *
     * @param originalUrl 原始 URL
     * @param newIp       新的 IP 地址
     * @return 替换后的 URL
     */
    private String replaceIpInUrl(String originalUrl, String newIp) {
        // 使用正则表达式匹配 IP 地址
        String regex = "(https?://)(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})(?::\\d{1,5})?";

        // 替换 IP 地址
        String newUrl = originalUrl.replaceAll(regex, "$1" + newIp);

        return newUrl;
    }
}
