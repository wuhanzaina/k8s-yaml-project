/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:GitCommitServiceImpl.java
 * 创建日期:2024-03-06
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.statistic.service.impl;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.constant.GlobalConstant;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.statistic.entity.GitCommit;
import com.kotei.sdw.modules.statistic.mapper.GitCommitMapper;
import com.kotei.sdw.modules.statistic.service.GitCommitService;
import com.kotei.sdw.modules.statistic.vo.LineVO;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import org.apache.commons.compress.utils.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/**
 * git提交统计 ServiceImpl
 *
 * @author hk
 * @since 2024-03-06
 */
@Service
public class GitCommitServiceImpl extends BaseServiceImpl<GitCommit> implements GitCommitService {
    @Autowired
    private GitCommitMapper gitCommitMapper;

    @Override
    protected BaseMapper<GitCommit> getMapper() {
        return gitCommitMapper;
    }

    @Override
    public GitCommit get(Long id) {
        return gitCommitMapper.selectById(id);
    }

    @Override
    public IPage<GitCommit> getList(PageVO<GitCommit> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<GitCommit> lambdaQueryWrapper = Wrappers.lambdaQuery(GitCommit.class)
                .eq(params.containsKey("userId"), GitCommit::getUserId, params.get("userId"))
                .eq(params.containsKey("userName"), GitCommit::getUserName, params.get("userName"))
                .eq(params.containsKey("deptId"), GitCommit::getDeptId, params.get("deptId"))
                .eq(params.containsKey("deptName"), GitCommit::getDeptName, params.get("deptName"))
                .eq(params.containsKey("rootDeptId"), GitCommit::getRootDeptId, params.get("rootDeptId"))
                .eq(params.containsKey("rootDeptName"), GitCommit::getRootDeptName, params.get("rootDeptName"))
                .eq(params.containsKey("commitDate"), GitCommit::getCommitDate, params.get("commitDate"))
                .eq(params.containsKey("commitLineTotal"), GitCommit::getCommitLineTotal, params.get("commitLineTotal"))
                .eq(params.containsKey("createrId"), GitCommit::getCreaterId, params.get("createrId"))
                .eq(params.containsKey("createrName"), GitCommit::getCreaterName, params.get("createrName"))
                .eq(params.containsKey("createTime"), GitCommit::getCreateTime, params.get("createTime"));
        return gitCommitMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    public Long insert(GitCommit entity) {
        entity.setId(KeyGenerate.generateId());
        gitCommitMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        gitCommitMapper.deleteById(id);
    }

    @Override
    public void update(GitCommit entity) {
        gitCommitMapper.updateById(entity);
    }

    /**
     * @param beginWeekBeginDateStr 开始周的开始日期字符串
     * @param endWeekBeginDateStr   结束周的开始日期字符串
     * @param userId                用户ID
     * @return 包含commit列表的LineVO对象列表
     * @brief 从开始周的开始日期到结束周的开始日期之间的commit列表
     */
    @Override
    public List<LineVO> commitList(String beginWeekBeginDateStr, String endWeekBeginDateStr, Long userId) {
        // 创建结果列表
        List<LineVO> results = Lists.newArrayList();
        // 将字符串类型的日期转换为DateTime类型
        DateTime beginWeekBeginDate = DateUtil.parse(beginWeekBeginDateStr, DatePattern.NORM_DATE_FORMAT);
        DateTime endWeekBeginDate = DateUtil.parse(endWeekBeginDateStr, DatePattern.NORM_DATE_FORMAT);
        // 计算两个日期之间的周数
        Long l = DateUtil.betweenWeek(beginWeekBeginDate, endWeekBeginDate, Boolean.FALSE);
        // 循环遍历每一周
        for (int i = 0; i <= l; i++) {
            // 根据偏移量获取当前周的日期
            DateTime dateTime = DateUtil.offsetWeek(beginWeekBeginDate, i);
            // 获取当前周的开始日期和结束日期
            String beginOfWeek = DateUtil.beginOfWeek(dateTime).toDateStr();
            String endOfWeek = DateUtil.endOfWeek(dateTime).toDateStr();

            // 创建LambdaQueryWrapper对象，并设置查询条件
            LambdaQueryWrapper<GitCommit> lambdaQueryWrapper = Wrappers.lambdaQuery(GitCommit.class)
                    .between(GitCommit::getCommitDate, beginOfWeek, endOfWeek);
            // 如果userId不为空，则添加userId的查询条件
            if (ObjectUtil.isNotNull(userId)) {
                lambdaQueryWrapper.eq(GitCommit::getUserId, userId);
            }
            // 执行数据库查询，返回满足条件的GitCommit列表
            List<GitCommit> list = gitCommitMapper.selectList(lambdaQueryWrapper);
            // 创建原子引用变量，用于计算总行数
            AtomicReference<Integer> commitLineTotal = new AtomicReference<>(GlobalConstant.NO);
            // 遍历GitCommit列表，计算总行数
            list.forEach(vo -> commitLineTotal.set(commitLineTotal.get() + vo.getCommitLineTotal()));

            // 创建LineVO对象，并设置开始日期、结束日期和总行数
            LineVO lineVO = new LineVO();
            lineVO.setBeginOfWeek(beginOfWeek);
            lineVO.setEndOfWeek(endOfWeek);
            lineVO.setLineTotal(commitLineTotal.get());
            // 将LineVO对象添加到结果列表中
            results.add(lineVO);
        }
        // 返回结果列表
        return results;
    }

}
