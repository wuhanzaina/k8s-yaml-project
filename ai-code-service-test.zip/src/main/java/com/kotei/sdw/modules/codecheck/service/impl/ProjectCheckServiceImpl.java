package com.kotei.sdw.modules.codecheck.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.kotei.sdw.modules.codecheck.entity.ProjectCheck;
import com.kotei.sdw.modules.codecheck.mapper.ProjectCheckMapper;
import com.kotei.sdw.modules.codecheck.service.ProjectCheckService;
import org.springframework.stereotype.Service;

/**
* @author zhengyaow
* @description 针对表【project_check】的数据库操作Service实现
* @createDate 2024-12-24 15:22:17
*/
@Service
public class ProjectCheckServiceImpl extends ServiceImpl<ProjectCheckMapper, ProjectCheck>  implements ProjectCheckService {

}




