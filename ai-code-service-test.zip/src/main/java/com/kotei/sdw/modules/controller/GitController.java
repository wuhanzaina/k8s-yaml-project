package com.kotei.sdw.modules.controller;

import com.github.xiaoymin.knife4j.annotations.ApiSort;
import com.kotei.sdw.api.Result;
import com.kotei.sdw.modules.codecheck.service.GitUrlVerifyService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author hk
 * @date 2024/12/09 15:11
 */
@RestController
@RequestMapping(value = "/base/common", produces = MediaType.APPLICATION_JSON_VALUE)
@Validated
@Api(tags = "git url  校验")
@ApiSort(1)
@Slf4j
public class GitController {

    @Autowired
    private GitUrlVerifyService gitUrlVerifyService;

    /**
     * gitlab web hook
     *
     * @return
     */
    @PostMapping(value = "/gitlab/verify")
    @ApiOperation(value = "gitlab校验url")
    public Result<Boolean> verifyUrl(@RequestBody String url) {
        return Result.success(gitUrlVerifyService.verify(url));
    }


}
