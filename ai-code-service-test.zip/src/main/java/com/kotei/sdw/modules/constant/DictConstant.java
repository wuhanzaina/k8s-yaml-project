/**
 * All rights Reserved, Designed By  www.kotei-info.com
 * 项目名称:sdw-platform
 * 文件名称:BuildRelEnum
 * 创建日期:2023/3/20
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 **/
package com.kotei.sdw.modules.constant;

/**
 * 数据字典
 *
 * @author hk
 * @date 2024/3/5
 **/
public interface DictConstant {
    /**
     * 状态
     */
    interface Type {
        /**
         * 功能使用情况
         */
        String FUNCTION_USAGE = "function_usage";

        /**
         * 功能使用情况
         */
        String FUNCTION_USAGE_X = "function_usage_x";
    }

}
