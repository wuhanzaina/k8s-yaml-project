/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:AddCodeCovFunVO.java
 * 创建日期:2024-04-22
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.controller;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSort;
import com.kotei.sdw.api.Result;
import com.kotei.sdw.modules.codecheck.entity.CodeCovFun;
import com.kotei.sdw.modules.codecheck.service.CodeCovFunService;
import com.kotei.sdw.modules.codecheck.vo.AddCodeCovFunVO;
import com.kotei.sdw.modules.codecheck.vo.CodeCovFunQueryVO;
import com.kotei.sdw.modules.codecheck.vo.EditCodeCovFunVO;
import com.kotei.sdw.mvc.controller.BaseController;
import com.kotei.sdw.mvc.vo.IdVO;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.security.annotation.RequiresPermissions;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 *
 * 代码覆盖率函数表 Controller
 *
 *
 * @author tiger
 * @since 2024-04-22
 */
@RestController
@RequestMapping(value = "/codecheck/cov-funs", produces = MediaType.APPLICATION_JSON_VALUE)
@Validated
@Api(tags = "代码覆盖率函数表")
@ApiSort(1)
public class CodeCovFunController extends BaseController {
    @Autowired
    private CodeCovFunService codeCovFunService;

    /**
     * 新增
     * @param addCodeCovFunVO
     * @return
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "新增", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperationSupport(order = 1)
    @RequiresPermissions("codecheck:cov-fun:create")
    public Result<IdVO> create(@RequestBody @Validated AddCodeCovFunVO addCodeCovFunVO) {
        CodeCovFun codeCovFun = new CodeCovFun();
        BeanUtil.copyProperties(addCodeCovFunVO, codeCovFun);
        Long id = codeCovFunService.insert(codeCovFun);
        return Result.success(new IdVO(id));
    }

    /**
     * 删除
     * @param id
     */
    @DeleteMapping("/{id}")
    @ApiOperation(value = "删除")
    @ApiImplicitParam(name = "id", value = "id", required = true, paramType = "path", dataType = "Long")
    @ApiOperationSupport(order = 2)
    @RequiresPermissions("codecheck:cov-fun:delete")
    public Result<Void> delete(@NotNull(message = "ID不能为空") @PathVariable("id") Long id) {
        codeCovFunService.delete(id);
        return Result.success();
    }

    /**
     * 编辑
     * @param editCodeCovFunVO
     */
    @PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "编辑", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperationSupport(order = 3)
    @RequiresPermissions("codecheck:cov-fun:edit")
    public Result<Void> edit(@RequestBody @Validated EditCodeCovFunVO editCodeCovFunVO) {
        CodeCovFun codeCovFun = new CodeCovFun();
        BeanUtil.copyProperties(editCodeCovFunVO, codeCovFun);
        codeCovFunService.update(codeCovFun);
        return Result.success();
    }

    /**
     * 查询
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    @ApiOperation(value = "查询")
    @ApiImplicitParam(name = "id", value = "id", required = true, paramType = "path", dataType = "Long")
    @ApiOperationSupport(order = 4)
//    @RequiresPermissions("codecheck:cov-fun:get")
    public Result<CodeCovFunQueryVO> get(@NotNull(message = "id不能为空") @PathVariable("id") Long id) {
        CodeCovFunQueryVO vo =  codeCovFunService.getDetail(id);
        return Result.success(vo);
    }

    /**
     * 分页查询
     * @param page 分页查询参数
     * @return
     */
    @PostMapping("/page")
    @ApiOperation(value = "分页查询")
    @ApiOperationSupport(order = 5)
//    @RequiresPermissions("codecheck:cov-fun:page")
    public Result<IPage<CodeCovFun>> page(@Validated @RequestBody PageVO<CodeCovFun> page) {
        IPage<CodeCovFun> pageInfo = codeCovFunService.getList(page);
        return Result.success(pageInfo);
    }

    /**
     * 批量删除
     * @param ids id集合
     */
    @DeleteMapping(value = "/batch/{ids}")
    @ApiOperation(value = "批量删除")
    @ApiImplicitParam(name = "ids", value = "多个ID之间用英文','号分隔", required = true, paramType = "path", dataType = "String")
    @ApiOperationSupport(order = 6)
    @RequiresPermissions("codecheck:cov-fun:batchDelete")
    public Result<Void> batchDelete(@NotBlank(message = "IDS不能为空") @PathVariable("ids") String ids) {
        codeCovFunService.delete(Convert.toList(Long.class, StrUtil.splitTrim(ids, StrUtil.COMMA)));
        return Result.success();
    }

    /**
     * 列表查询
     * @return
     */
    @GetMapping("/list")
    @ApiOperation(value = "列表查询")
    @ApiOperationSupport(order = 7)
    @RequiresPermissions("codecheck:cov-fun:list")
    public Result<List<CodeCovFun>> list() {
        List<CodeCovFun> list = codeCovFunService.getList();
        return Result.success(list);
    }

}
