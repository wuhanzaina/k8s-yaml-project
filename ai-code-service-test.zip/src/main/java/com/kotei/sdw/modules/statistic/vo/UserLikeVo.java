/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code
* 文件名称:AddConversationsAcceptVO.java
* 创建日期:2024-02-27
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
*
* 顶一下，踩一下
*
*
* @author hk
* @since 2024-02-27
*/
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "UserLikeVo", description = "顶一下，踩一下")
public class UserLikeVo implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
    * 会话ID
    */
    @ApiModelProperty(value = "会话ID", required = true, position = 2)
    @NotNull(message="会话ID不能为空")
    private Long conversationsId;
    /**
    * 顶一下，踩一下.1：赞  2：踩
    */
    @ApiModelProperty(value = "0：未操作 1：赞  2：踩", position = 3)
    private Integer likes;

}
