/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:GitlabCommit.java
 * 创建日期:2024-04-09
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.kotei.sdw.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 *
 * commit记录表
 *
 *
 * @author tiger
 * @since 2024-04-09
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("gitlab_commit_file")
@ApiModel(value = "GitlabCommit", description = "commit文件记录")
public class GitlabCommitFile extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
     * commitId
     */
    @ApiModelProperty(value = "commitId", position = 2)
    private Long commitId;
    /**
     * 类型：ADDED:新增; MODIFIED:修改；REMOVED：删除
     */
    @ApiModelProperty(value = "类型：ADDED:新增; MODIFIED:修改；REMOVED：删除", position = 3)
    private String type;
    /**
     * 项目工程标识
     */
    @ApiModelProperty(value = "项目工程标识", position = 6)
    private String projectCode;
    /**
     * 分支
     */
    @ApiModelProperty(value = "分支", position = 7)
    private String branch;
    /**
     * 文件地址
     */
    @ApiModelProperty(value = "文件地址", position = 4)
    private String filePath;
    /**
     * 状态
     */
    @ApiModelProperty(value = "状态", position = 9)
    private Integer status;
    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间", position = 10)
    private Date createTime;


}
