/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:ConversationsAccept.java
* 创建日期:2024-03-11
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.kotei.sdw.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
*
* 会话采纳信息
*
*
* @author tiger
* @since 2024-03-11
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("conversations_accept")
@ApiModel(value = "ConversationsAccept", description = "会话采纳信息")
public class ConversationsAccept extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 会话ID
    */
    @ApiModelProperty(value = "会话ID", position = 2)
    private Long conversationsId;
    /**
    * 是否采纳.0：未采纳  1：采纳
    */
    @ApiModelProperty(value = "是否采纳.0：未采纳  1：采纳", position = 3)
    private Integer status;
    /**
    * 类型.	0：代码生成；	1：代码解释；	2：添加注释 - 函数；	3：添加注释 - 逐行；	4：智能代码问答
    */
    @ApiModelProperty(value = "类型.	0：代码生成；	1：代码解释；	2：添加注释 - 函数；	3：添加注释 - 逐行；	4：智能代码问答", position = 4)
    private Integer type;
    /**
    * 采纳代码行数
    */
    @ApiModelProperty(value = "采纳代码行数", position = 5)
    private Integer adoptionLineTotal;
    /**
    * 用于复制次数
    */
    @ApiModelProperty(value = "用于复制次数", position = 6)
    private Integer useCopy;
    /**
    * 用于插入次数
    */
    @ApiModelProperty(value = "用于插入次数", position = 7)
    private Integer useInsert;
    /**
    * 用于新建次数
    */
    @ApiModelProperty(value = "用于新建次数", position = 8)
    private Integer useCreate;
    /**
    * 1:点赞；0：未点赞
    */
    @ApiModelProperty(value = "1:点赞；0：未点赞", position = 9)
    private Integer likes;
    /**
    * 输入koken数量费用（单位分）
    */
    @ApiModelProperty(value = "输入koken数量费用（单位分）", position = 10)
    private Integer inputToken;
    /**
    * 输出token数量
    */
    @ApiModelProperty(value = "输出token数量", position = 11)
    private Integer outputToken;
    /**
    * AI输出的代码行数
    */
    @ApiModelProperty(value = "AI输出的代码行数", position = 11)
    private Integer codeLine;
    /**
    * 费用（单位分）
    */
    @ApiModelProperty(value = "费用（单位分）", position = 12)
    private Integer cost;
    /**
    * 创建人id
    */
    @ApiModelProperty(value = "创建人id", position = 13)
    private Long createrId;
    /**
    * 创建人
    */
    @ApiModelProperty(value = "创建人", position = 14)
    private String createrName;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", position = 15)
    private Date createTime;


}
