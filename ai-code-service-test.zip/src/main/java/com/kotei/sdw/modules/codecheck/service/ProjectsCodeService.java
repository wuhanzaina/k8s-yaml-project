package com.kotei.sdw.modules.codecheck.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.kotei.sdw.modules.codecheck.entity.Project;
import com.kotei.sdw.modules.codecheck.entity.ProjectsCode;
import com.kotei.sdw.mvc.service.BaseService;

import java.util.List;

/**
* @author zhengyaow
* @description 针对表【projects_code】的数据库操作Service
* @createDate 2024-11-25 15:54:19
*/
public interface ProjectsCodeService extends BaseService<ProjectsCode> {

     List<ProjectsCode> getProjectsCodeList();

}
