/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:FunctionUsage.java
* 创建日期:2024-03-05
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.entity;

import java.util.Date;
import com.kotei.sdw.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
*
* 功能使用情况
*
*
* @author hk
* @since 2024-03-05
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("function_usage")
@ApiModel(value = "FunctionUsage", description = "功能使用情况")
public class FunctionUsage extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 功能名称
    */
    @ApiModelProperty(value = "功能名称", position = 2)
    private String name;
    /**
    * 功能类型;0.根据注释生成代码 1.代码补齐（单行、多行、代码块补齐）2.根据自定义prompt模板生成代码3.代码纠错4.代码解释5.代码注释6.代码评审7.单元测试用例生成8.智能代码问答
    */
    @ApiModelProperty(value = "功能类型;0.根据注释生成代码 1.代码补齐（单行、多行、代码块补齐）2.根据自定义prompt模板生成代码3.代码纠错4.代码解释5.代码注释6.代码评审7.单元测试用例生成8.智能代码问答", position = 3)
    private Integer type;
    /**
    * 使用次数
    */
    @ApiModelProperty(value = "使用次数", position = 4)
    private Integer useTotal;
    /**
    * 功能采纳率
    */
    @ApiModelProperty(value = "功能采纳率", position = 5)
    private String adoptionRate;
    /**
    * 功能点赞次数
    */
    @ApiModelProperty(value = "功能点赞次数", position = 6)
    private Integer upvoteTotal;
    /**
    * 采纳代码行数
    */
    @ApiModelProperty(value = "采纳代码行数", position = 7)
    private Integer adoptionLineTotal;
    /**
    * 用户ID
    */
    @ApiModelProperty(value = "用户ID", position = 8)
    private Long userId;
    /**
    * 用户名称
    */
    @ApiModelProperty(value = "用户名称", position = 9)
    private String userName;
    /**
    * 用户工号
    */
    @ApiModelProperty(value = "用户工号", position = 9)
    private String userNo;
    /**
    * 部门ID
    */
    @ApiModelProperty(value = "部门ID", position = 10)
    private Long deptId;
    /**
    * 部门名称
    */
    @ApiModelProperty(value = "部门名称", position = 11)
    private String deptName;
    /**
     * 一级部门ID
     */
    @ApiModelProperty(value = "一级部门ID", position = 10)
    private Long rootDeptId;
    /**
     * 一级部门名称
     */
    @ApiModelProperty(value = "一级部门名称", position = 11)
    private String rootDeptName;
    /**
    * 使用日期
    */
    @ApiModelProperty(value = "使用日期", position = 12)
    private String useDate;
    /**
     * 输入token
     */
    @ApiModelProperty(value = "输入token数量", position = 10)
    private Integer inputToken;
    /**
     * 输出token数量
     */
    @ApiModelProperty(value = "输出token数量", position = 11)
    private Integer outputToken;
    /**
     * 费用（单位毫）
     */
    @ApiModelProperty(value = "费用（单位毫）", position = 12)
    private Integer cost;
    /**
    * 创建人id
    */
    @ApiModelProperty(value = "创建人id", position = 13)
    private Long createrId;
    /**
    * 创建人
    */
    @ApiModelProperty(value = "创建人", position = 14)
    private String createrName;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", position = 15)
    private Date createTime;
    /**
    * 修改人id
    */
    @ApiModelProperty(value = "修改人id", position = 16)
    private Long modifierId;
    /**
    * 修改人名称
    */
    @ApiModelProperty(value = "修改人名称", position = 17)
    private String modifierName;
    /**
    * 修改时间
    */
    @ApiModelProperty(value = "修改时间", position = 18)
    private Date modifyTime;


}
