package com.kotei.sdw.modules.service.transaction;


/**
 * 构建事务springBean对象
 *
 * @author tiger
 */
public interface TransactionalService {
    /**
     * @param action 要执行的Action对象
     * @return void
     * @brief 事务处理函数
     * <p>
     * 该函数用于处理事务，接受一个Action对象作为参数，然后调用其apply方法来执行具体的业务逻辑。
     */
    void transaction(Action action);

    /**
     * @param action 交易动作
     * @brief 创建一个新的交易
     */

    void newTransaction(Action action);

    /**
     * @param action 一个函数对象，表示要执行的操作
     * @return void
     * @brief 不使用事务的函数
     * @details 这个函数用于执行不需要事务支持的操作。函数接受一个函数对象作为参数，然后执行该函数对象表示的操作。
     * 函数本身不开启事务，因此在函数中的操作无法回滚。
     * 该函数使用`@Override`注解表示是对父类的方法进行重写。
     * 函数使用`@Transactional(propagation = NOT_SUPPORTED)`注解表示不需要事务支持。
     */
    void notTransaction(Action action);
}
