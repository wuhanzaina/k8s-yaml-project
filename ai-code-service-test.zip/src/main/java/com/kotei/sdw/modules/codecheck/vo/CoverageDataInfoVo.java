package com.kotei.sdw.modules.codecheck.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kotei.sdw.modules.codecheck.constant.enums.ExecTaskStatusEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Api(tags = "代码覆盖率任务回调")
public class CoverageDataInfoVo {

    // 本地任务ID
    @ApiModelProperty(value = "本地任务ID")
    private Long taskId;

    // jenkins执行任务ID
    @ApiModelProperty(value = "jenkins执行任务ID")
    private Long piplineTaskId;

    //任务状态 执行中：ONGOING, 成功：SUCCESS, 失败：FAILED
    @ApiModelProperty(value = "回调类型 执行中：ONGOING, 成功：SUCCESS, 失败：FAILED")
    private ExecTaskStatusEnum status;

    @ApiModelProperty(value = "失败原因")
    private String message;

    // 汇总信息 json 字符串
    private String summary;

    // 细节信息 json 字符串
    private String details;

    // 汇总信息类
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class Summary {
        // 分支覆盖数
        @JsonProperty("branch_covered")
        private int branchCovered;

        // 分支覆盖百分比
        @JsonProperty("branch_percent")
        private BigDecimal branchPercent;

        // 分支总数
        @JsonProperty("branch_total")
        private int branchTotal;

        // 文件汇总信息列表
        @JsonProperty("files")
        private List<FileSummary> files;

        // 函数覆盖数
        @JsonProperty("function_covered")
        private int functionCovered;

        // 函数覆盖百分比
        @JsonProperty("function_percent")
        private BigDecimal functionPercent;

        // 函数总数
        @JsonProperty("function_total")
        private int functionTotal;

        // 行覆盖数
        @JsonProperty("line_covered")
        private int lineCovered;

        // 行覆盖百分比
        @JsonProperty("line_percent")
        private BigDecimal linePercent;

        // 总行数
        @JsonProperty("line_total")
        private int lineTotal;

    }

    // 细节信息类
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class Details {
        // 文件细节信息列表
        @JsonProperty("files")
        private List<FileDetail> files;
    }

    // 文件汇总信息类
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class FileSummary {
        // 分支覆盖数
        @JsonProperty("branch_covered")
        private int branchCovered;

        // 分支覆盖百分比
        @JsonProperty("branch_percent")
        private BigDecimal branchPercent;

        // 分支总数
        @JsonProperty("branch_total")
        private int branchTotal;

        // 文件名
        @JsonProperty("filename")
        private String filename;

        // 函数覆盖数
        @JsonProperty("function_covered")
        private int functionCovered;

        // 函数覆盖百分比
        @JsonProperty("function_percent")
        private BigDecimal functionPercent;

        // 函数总数
        @JsonProperty("function_total")
        private int functionTotal;

        // 行覆盖数
        @JsonProperty("line_covered")
        private int lineCovered;

        // 行覆盖百分比
        @JsonProperty("line_percent")
        private BigDecimal linePercent;

        // 总行数
        @JsonProperty("line_total")
        private int lineTotal;
    }

    // 文件细节信息类
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class FileDetail {
        // 文件名
        @JsonProperty("file")
        private String file;

        // 函数信息列表
        @JsonProperty("functions")
        private List<Function> functions;

        // 行信息列表
        @JsonProperty("lines")
        private List<Line> lines;
    }

    // 函数信息类
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class Function {
        // 块覆盖百分比
        @JsonProperty("blocks_percent")
        private int blocksPercent;

        // 执行次数
        @JsonProperty("execution_count")
        private int executionCount;

        // 行号
        @JsonProperty("lineno")
        private int lineno;

        // 函数名
        @JsonProperty("name")
        private String name;

        // 函数
        @JsonProperty("fun")
        private String fun;

        // 返回次数
        @JsonProperty("returned_count")
        private int returnedCount;
    }

    // 行信息类
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class Line {
        // 分支信息列表
        @JsonProperty("branches")
        private List<Branch> branches;

        // 行执行次数
        @JsonProperty("count")
        private int count;

        // 行号
        @JsonProperty("line_number")
        private int lineNumber;
    }

    // 分支信息类
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class Branch {
        // 块编号
        @JsonProperty("blockno")
        private int blockno;

        // 分支执行次数
        @JsonProperty("count")
        private int count;

        //是否 落地分支
        //某个分支后没有break或return等语句，直接“落下”到下一个分支，那么当前分支就是落地分支
        @JsonProperty("fallthrough")
        private boolean fallthrough;

        // 是否抛出异常
        @JsonProperty("throw")
        private boolean throwBranch;
    }
}