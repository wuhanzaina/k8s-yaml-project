/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:AddCodeCheckTaskVO.java
 * 创建日期:2024-03-26
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 通过项目编号获取统计内容
 *
 * @author tiger
 * @since 2024-03-26
 */
@Data
@NoArgsConstructor
@ApiModel(value = "CodeCheckStatisticsVo", description = "通过项目编号获取统计内容")
public class CodeCheckStatisticsVo implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 负债评级
     */
    @ApiModelProperty(value = "负债评级(512)", position = 11)
    private String sqaleDebtRatio;
    /**
     * 项目状态
     */
    @ApiModelProperty(value = "项目状态(512)", position = 11)
    private String projectStatus;

    /**
     * 项目标识
     */
    @ApiModelProperty(value = "项目标识(512)", position = 11)
    private String projectParent;
    /**
     * 项目git仓库
     */
    @ApiModelProperty(value = "仓库地址(512)", position = 11)
    private String projectCode;

    /**
     * 项目git仓库分支
     */
    @ApiModelProperty(value = "仓库分支(512)", position = 11)
    private String branch;
    /**
     * 代码注释行数
     */
    @ApiModelProperty(value = "代码注释行数", position = 12)
    private Integer comments = 0;
    /**
     * 代码总行数
     */
    @ApiModelProperty(value = "代码总行数", position = 12)
    private Integer codes = 0;
    /**
     * 代码空行数
     */
    @ApiModelProperty(value = "代码空行数", position = 12)
    private Integer blanks = 0;
    /**
     * 注释率不达标数量
     */
    @ApiModelProperty(value = "注释率不达标数量", position = 12)
    private Integer offGradeComments = 0;
    /**
     * 圈复杂度不达标数量
     */
    @ApiModelProperty(value = "圈复杂度不达标数量", position = 12)
    private Integer offGradeCircleComplexity = 0;
    /**
     * 圈复杂度显示最大值
     */
    @ApiModelProperty(value = "圈复杂度显示最大值", position = 12)
    private Integer maxCircleComplexity = 0;
    /**
     * 警告数量
     */
    @ApiModelProperty(value = "警告数量", position = 12)
    private Integer warning = 0;
    /**
     * 错误数量
     */
    @ApiModelProperty(value = "错误数量", position = 12)
    private Integer error = 0;
    /**
     * 扫描语言
     */
    @ApiModelProperty(value = "扫描语言", required = true, position = 12)
    private String language;
    /**
     * 注释率
     */
    @ApiModelProperty(value = "代码类型对应的最小注释率", required = true, position = 12)
    private String minCommentsRate;

    /**
     * 最大复杂度
     */
    @ApiModelProperty(value = "最大复杂度", required = true, position = 12)
    private Map maxComplex;
    /**
     * 对应自行木详细信息
     */
    @ApiModelProperty(value = "git仓库详细信息", required = true, position = 12)
    private List<CodeCheckStatisticsVo> codeCheckStatisticsVoList;

}
