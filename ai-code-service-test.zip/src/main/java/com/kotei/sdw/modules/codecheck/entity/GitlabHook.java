/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:GitlabHook.java
* 创建日期:2024-03-26
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.entity;

import java.util.Date;
import com.kotei.sdw.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
*
* gitlab hook记录表
*
*
* @author tiger
* @since 2024-03-26
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("gitlab_hook")
@ApiModel(value = "GitlabHook", description = "gitlab hook记录表")
public class GitlabHook extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 内容
    */
    @ApiModelProperty(value = "内容", position = 2)
    private String content;
    /**
    * 状态
    */
    @ApiModelProperty(value = "状态", position = 3)
    private Integer status;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", position = 4)
    private Date createTime;


}
