package com.kotei.sdw.modules.constant.enums;

/**
 * 单次反馈类型，  含义：[1:内容不全；2:格式不对；3:答非所问；4: 没有帮助]
 *
 * @author tiger
 * @date 2024/3/13 10:22
 */
public enum AcceptTypeEnum {
    DEFAULT("", ""),
    PARTIAL("1", "内容不全"),
    WRONG("2", "格式不对"),
    NOT_APPROPRIATE("3", "答非所问"),
    NO_HELP("4", "没有帮助"),
    ;

    private final String code;
    private final String name;

    AcceptTypeEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    /**
     * 通过code获取
     *
     * @param code
     * @return
     */
    public static AcceptTypeEnum getByCode(String code) {
        if (code == null) {
            return DEFAULT;
        }
        for (AcceptTypeEnum type : AcceptTypeEnum.values()) {
            if (type.getCode().equals(code)) {
                return type;
            }
        }
        return DEFAULT;
    }
}
