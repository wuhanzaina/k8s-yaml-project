/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:CodeCheckTaskDetail.java
* 创建日期:2024-03-26
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.entity;

import java.util.Date;
import com.kotei.sdw.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
*
* 代码检查明细表
*
*
* @author tiger
* @since 2024-03-26
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("code_check_task_detail")
@ApiModel(value = "CodeCheckTaskDetail", description = "代码检查明细表")
public class CodeCheckTaskDetail extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 任务ID
    */
    @ApiModelProperty(value = "任务ID", position = 2)
    private Long taskId;
    /**
    * 类型：CIRCLE:圈复杂度; COMMENT:代码注释率; WARNING:静态扫描警告
    */
    @ApiModelProperty(value = "类型：CIRCLE:圈复杂度; COMMENT:代码注释率; WARNING:静态扫描警告", position = 3)
    private String type;
    /**
    * 代码语言格式
    */
    @ApiModelProperty(value = "代码语言格式", position = 4)
    private String fileType = "";
    /**
    * 文件地址
    */
    @ApiModelProperty(value = "文件地址", position = 4)
    private String filePath = "";
    /**
    * 函数名称
    */
    @ApiModelProperty(value = "函数名称", position = 5)
    private String funName = "";
    /**
    * warning数量
    */
    @ApiModelProperty(value = "warning数量", position = 6)
    private Integer warning = 0;
    /**
    * error数量
    */
    @ApiModelProperty(value = "error数量", position = 7)
    private Integer error = 0;
    /**
    * 圈复杂度
    */
    @ApiModelProperty(value = "圈复杂度", position = 10)
    private Integer circleComplexity = 0;
    /**
    * 代码总行数
    */
    @ApiModelProperty(value = "代码总行数", position = 11)
    private Integer codes = 0;
    /**
    * 空白代码行数
    */
    @ApiModelProperty(value = "空白代码行数", position = 12)
    private Integer blanks = 0;
    /**
    * 代码注释行数
    */
    @ApiModelProperty(value = "代码注释行数", position = 13)
    private Integer comments = 0;
    /**
    * 状态
    */
    @ApiModelProperty(value = "状态", position = 14)
    private Integer status = 0;
    /**
    * 是否达标 0：达标；1：不达标
    */
    @ApiModelProperty(value = "是否达标 0：达标；1：不达标", position = 15)
    private Integer offGrade = 0;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", position = 16)
    private Date createTime;


}
