/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:CodeCovTask.java
* 创建日期:2024-04-22
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.kotei.sdw.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
*
* 代码覆盖率任务表
*
*
* @author tiger
* @since 2024-04-22
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("code_cov_task")
@ApiModel(value = "CodeCovTask", description = "代码覆盖率任务表")
public class CodeCovTask extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 执行任务ID
    */
    @ApiModelProperty(value = "执行任务ID", position = 2)
    private String execTaskId;
    /**
    * 用户ID
    */
    @ApiModelProperty(value = "用户ID", position = 3)
    private Long userId;
    /**
    * 用户名称
    */
    @ApiModelProperty(value = "用户名称", position = 4)
    private String userName;
    /**
    * 工号
    */
    @ApiModelProperty(value = "工号", position = 5)
    private String userNo;
    /**
    * 当前部门ID
    */
    @ApiModelProperty(value = "当前部门ID", position = 6)
    private Long departmentId;
    /**
    * 当前部门
    */
    @ApiModelProperty(value = "当前部门", position = 7)
    private String departmentName;
    /**
    * 一级部门ID
    */
    @ApiModelProperty(value = "一级部门ID", position = 8)
    private Long rootDepartmentId;
    /**
    * 一级部门
    */
    @ApiModelProperty(value = "一级部门", position = 9)
    private String rootDepartmentName;
    /**
    * 项目工程标识
    */
    @ApiModelProperty(value = "项目工程标识", position = 10)
    private String projectCode;
    /**
    * 分支
    */
    @ApiModelProperty(value = "分支", position = 11)
    private String branch;
    /**
    * 覆盖分支数
    */
    @ApiModelProperty(value = "覆盖分支数", position = 12)
    private Integer branchCovered;
    /**
    * 分支数
    */
    @ApiModelProperty(value = "分支数", position = 13)
    private Integer branchTotal;
    /**
    * 分支覆盖率
    */
    @ApiModelProperty(value = "分支覆盖率", position = 14)
    private BigDecimal branchPercent;
    /**
    * 函数覆盖数
    */
    @ApiModelProperty(value = "函数覆盖数", position = 15)
    private Integer functionCovered;
    /**
    * 函数覆盖率
    */
    @ApiModelProperty(value = "函数覆盖率", position = 16)
    private BigDecimal functionPercent;
    /**
    * 函数总数
    */
    @ApiModelProperty(value = "函数总数", position = 17)
    private Integer functionTotal;
    /**
    * 行覆盖数
    */
    @ApiModelProperty(value = "行覆盖数", position = 18)
    private Integer lineCovered;
    /**
    * 行覆盖率
    */
    @ApiModelProperty(value = "行覆盖率", position = 19)
    private BigDecimal linePercent;
    /**
    * 行总数
    */
    @ApiModelProperty(value = "行总数", position = 20)
    private Integer lineTotal;

    @ApiModelProperty(value = "覆盖率未达标函数个数", position = 20)
    private Integer offCovFun;
    @ApiModelProperty(value = "状态 0：初始化；1：执行中；2：执行完成；3：执行失败", position = 23)
    private Integer status;
    /**
    * 执行失败原因
    */
    @ApiModelProperty(value = "执行失败原因", position = 24)
    private String message;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", position = 25)
    private Date createTime;
    /**
    * 执行完毕时间
    */
    @ApiModelProperty(value = "执行完毕时间", position = 26)
    private Date finishTime;


}
