package com.kotei.sdw.modules.feign.vo;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author tiger
 * @date 2024/3/6 9:22
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "User", description = "用户")
public class UserRes {

    /** 总记录数 */
    private long total;

    /** 列表数据 */
    private List<UserVo> rows;

    /** 消息状态码 */
    private int code;

    /** 消息内容 */
    private String msg;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UserVo {
        private Long userId;
        private String userName;
        private String nickName;

        private Long deptId;
        private Integer status;
        private Integer type;
        private UserDept dept;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UserDept {
        private Long deptId;
        private Long parentId;
        private String deptName;
    }
}
