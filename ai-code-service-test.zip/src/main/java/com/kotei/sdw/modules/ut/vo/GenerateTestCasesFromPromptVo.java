package com.kotei.sdw.modules.ut.vo;

/**
 * @author tiger
 * @date 2024/3/27 13:47
 */

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiModel(value = "GenerateTestCasesFromPromptVo", description = "提示词对象")
public class GenerateTestCasesFromPromptVo {
    /**
     * 提示词
     */
    @ApiModelProperty(value = "提示词", required = true, position = 2)
    @NotNull(message = "提示词内容不能为空")
    private String prompt;

}


