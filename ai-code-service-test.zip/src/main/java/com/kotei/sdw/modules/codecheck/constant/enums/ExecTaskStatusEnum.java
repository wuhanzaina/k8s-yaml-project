package com.kotei.sdw.modules.codecheck.constant.enums;

/**
 * 状态 0：初始化；1：执行中；2：执行完成；3：执行失败
 * 执行中：ONGOING, 成功：SUCCESS, 失败：FAILED
 *
 * @author tiger
 * @date 2024/3/13 10:22
 */
public enum ExecTaskStatusEnum {
    DEFAULT(-1, ""),
    INIT(0, "初始化"),
    ONGOING(1, "执行中"),
    SUCCESS(2, "执行完成"),
    FAILED(3, "执行失败"),
    ;

    private final Integer code;
    private final String name;

    ExecTaskStatusEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    /**
     * 通过code获取
     *
     * @param code
     * @return
     */
    public static ExecTaskStatusEnum getByCode(Integer code) {
        if (code == null) {
            return DEFAULT;
        }
        for (ExecTaskStatusEnum type : ExecTaskStatusEnum.values()) {
            if (type.getCode().equals(code)) {
                return type;
            }
        }
        return DEFAULT;
    }
}
