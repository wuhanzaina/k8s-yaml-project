/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:GitlabCommitServiceImpl.java
* 创建日期:2024-04-09
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.modules.codecheck.entity.GitlabCommit;
import com.kotei.sdw.modules.codecheck.mapper.GitlabCommitMapper;
import com.kotei.sdw.modules.codecheck.service.GitlabCommitService;

/**
*
* commit记录表 ServiceImpl
*
*
* @author tiger
* @since 2024-04-09
*/
@Service
public class GitlabCommitServiceImpl extends BaseServiceImpl<GitlabCommit> implements GitlabCommitService {
    @Autowired
    private GitlabCommitMapper gitlabCommitMapper;

    @Override
    protected BaseMapper<GitlabCommit> getMapper() {
    return gitlabCommitMapper;
    }

    @Override
    public GitlabCommit get(Long id) {
    return gitlabCommitMapper.selectById(id);
    }

    @Override
    public IPage<GitlabCommit> getList(PageVO<GitlabCommit> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<GitlabCommit> lambdaQueryWrapper =Wrappers.lambdaQuery(GitlabCommit.class)
        .eq(params.containsKey("commitId"), GitlabCommit::getCommitId, params.get("commitId"))
        .eq(params.containsKey("url"), GitlabCommit::getUrl, params.get("url"))
        .eq(params.containsKey("authorName"), GitlabCommit::getAuthorName, params.get("authorName"))
        .eq(params.containsKey("authorEmail"), GitlabCommit::getAuthorEmail, params.get("authorEmail"))
        .eq(params.containsKey("projectCode"), GitlabCommit::getProjectCode, params.get("projectCode"))
        .eq(params.containsKey("branch"), GitlabCommit::getBranch, params.get("branch"))
        .eq(params.containsKey("content"), GitlabCommit::getContent, params.get("content"))
        .eq(params.containsKey("status"), GitlabCommit::getStatus, params.get("status"))
        .eq(params.containsKey("createTime"), GitlabCommit::getCreateTime, params.get("createTime"));
        return gitlabCommitMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    public Long insert(GitlabCommit entity) {
        entity.setId(KeyGenerate.generateId());
        gitlabCommitMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        gitlabCommitMapper.deleteById(id);
    }

    @Override
    public void update(GitlabCommit entity) {
        gitlabCommitMapper.updateById(entity);
    }
}
