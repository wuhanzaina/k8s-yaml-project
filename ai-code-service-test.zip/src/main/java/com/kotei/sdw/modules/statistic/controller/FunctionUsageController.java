/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddFunctionUsageVO.java
* 创建日期:2024-03-05
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.controller;

import java.util.Collection;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.kotei.sdw.modules.statistic.vo.*;
import com.kotei.sdw.security.annotation.RequiresPermissions;
import io.swagger.annotations.ApiImplicitParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSort;
import com.kotei.sdw.mvc.controller.BaseController;
import com.kotei.sdw.mvc.vo.IdVO;
import com.kotei.sdw.api.Result;

import com.kotei.sdw.modules.statistic.entity.FunctionUsage;
import com.kotei.sdw.modules.statistic.service.FunctionUsageService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
/**
 *
 * 功能使用情况 Controller
 *
 *
 * @author hk
 * @since 2024-03-05
 */
@RestController
@RequestMapping(value="/statistic/usages", produces = MediaType.APPLICATION_JSON_VALUE)
@Validated
@Api(tags = "功能使用情况")
@ApiSort(1)
public class FunctionUsageController extends BaseController {
	@Autowired
	private FunctionUsageService functionUsageService;

	/**
     * 新增
     * @param addFunctionUsageVO
     * @return
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "新增", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperationSupport(order = 1)
    public Result<IdVO> create(@RequestBody @Validated AddFunctionUsageVO addFunctionUsageVO) {
    	Long id=functionUsageService.insertOrUpdate(addFunctionUsageVO);
    	return Result.success(new IdVO(id));
    }



    /**
    * 查询
    * @param id
    * @return
    */
    @GetMapping("/{id}")
    @ApiOperation(value = "查询")
    @ApiImplicitParam(name = "id", value = "id", required = true, paramType = "path", dataType = "Long")
    @ApiOperationSupport(order = 4)
    @RequiresPermissions("statistic:usage:get")
    public Result<FunctionUsage> get(@NotNull(message = "id不能为空") @PathVariable("id") Long id) {
		FunctionUsage functionUsage = functionUsageService.get(id);
    	return Result.success(functionUsage);
    }


    /**
    * 列表查询
    * @return
    */
    @GetMapping("/list")
    @ApiOperationSupport(order = 7)
    @ApiOperation(value = "查询功能使用情况")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "startDate", value = "开始时间", required = true, paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "endDate", value = "结束时间时间", required = true, paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "deptId", value = "部门ID", required = true, paramType = "query", dataType = "String")
    })
    public Result<Collection<FunctionUsageVO>> list(@NotBlank(message="开始时间") String startDate, @NotBlank(message="开始时间") String endDate, @NotNull(message = "部门ID不能为空") Long deptId) {
        Collection<FunctionUsageVO> list = functionUsageService.list(deptId,startDate,endDate);
    	return Result.success(list);
    }

    /**
     * 根据部门分组列表查询
     * @return
     */
    @GetMapping("/groupList")
    @ApiOperationSupport(order = 7)
    @ApiOperation(value = "根据部门分组列表查询")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "startDate", value = "开始时间", required = true, paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "endDate", value = "结束时间时间", required = true, paramType = "query", dataType = "String")
    })
    public Result<List<GroupFunctionUsageVO>> groupList(@NotBlank(message="开始时间") String startDate,@NotBlank(message="开始时间") String endDate) {
        List<GroupFunctionUsageVO> list = functionUsageService.groupList(startDate,endDate);
        return Result.success(list);
    }


    /**
     * 使用次数 top10
     * @return
     */
    @PostMapping("/used-top10")
    @ApiOperation(value = "用户使用插件top10")
    @ApiOperationSupport(order = 8)
    public Result<List<UsedTop10Vo>> usedTop10(@RequestBody RangeStatisticReq req) {
        List<UsedTop10Vo> list = functionUsageService.usedTop10(req);
        return Result.success(list);
    }

    /**
     * 采纳率 top10
     * @return
     */
    @PostMapping("/adoption-top10")
    @ApiOperation(value = "采纳率 top10")
    @ApiOperationSupport(order = 9)
    public Result<List<UsedTop10Vo>> adoptionTop10(@RequestBody RangeStatisticReq req) {
        List<UsedTop10Vo> list = functionUsageService.adoptionTop10(req);
        return Result.success(list);
    }


    /**
     * 使用插件情况分析-整体概览
     * @return
     */
    @PostMapping("/overview")
    @ApiOperation(value = "使用插件情况分析-整体概览")
    @ApiOperationSupport(order = 10)
    public Result<OverviewUserStatisticVo> findOverviewUserStatistic() {
        OverviewUserStatisticVo vo = functionUsageService.findOverviewUserStatistic();
        return Result.success(vo);
    }

}
