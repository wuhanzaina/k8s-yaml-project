/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code
* 文件名称:PromptTemplate.java
* 创建日期:2024-02-27
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.kotei.sdw.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 系统功能提示词模板服务
 * 如: 代码生成、代码解释、代码注释、代码纠错等...
 * @author mahuang
 * @since 2024-03-19
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("prompt_function")
@ApiModel(value = "PromptFunction", description = "prompt模板")
public class PromptFunction extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 模板编码
    */
    @ApiModelProperty(value = "模板编码", position = 2)
    private String code;
    /**
    * 模板名称
    */
    @ApiModelProperty(value = "模板名称", position = 3)
    private String name;
    /**
    * 模板状态.0:不可用  1：可用
    */
    @ApiModelProperty(value = "模板状态.0:不可用  1：可用", position = 4)
    private Integer status;
    /**
    * 扮演角色
    */
    @ApiModelProperty(value = "扮演角色", position = 5)
    private String playRole;
    /**
    * 内容
    */
    @ApiModelProperty(value = "内容", position = 6)
    private String context;
    /**
    * 创建人id
    */
    @ApiModelProperty(value = "创建人id", position = 7)
    private Long createrId;
    /**
    * 创建人
    */
    @ApiModelProperty(value = "创建人", position = 8)
    private String createrName;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", position = 9)
    private Date createTime;
    /**
    * 修改人id
    */
    @ApiModelProperty(value = "修改人id", position = 10)
    private Long modifierId;
    /**
    * 修改人名称
    */
    @ApiModelProperty(value = "修改人名称", position = 11)
    private String modifierName;
    /**
    * 修改时间
    */
    @ApiModelProperty(value = "修改时间", position = 12)
    private Date modifyTime;


}
