package com.kotei.sdw.modules.codecheck.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kotei.sdw.modules.codecheck.constant.enums.ExecTaskStatusEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * @author tiger
 * @date 2024/3/26 15:10
 */

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Api(tags = "执行任务回调")
public class ExecTaskInfoVo {
    // 本地任务ID
    @ApiModelProperty(value = "本地任务ID")
    private Long taskId;

    @ApiModelProperty(value = "本地项目编号")
    private String projectName;

    // jenkins执行任务ID
    @ApiModelProperty(value = "jenkins执行任务ID")
    private Long piplineTaskId;

    //任务状态 执行中：ONGOING, 成功：SUCCESS, 失败：FAILED
    @ApiModelProperty(value = "回调类型 执行中：ONGOING, 成功：SUCCESS, 失败：FAILED")
    private ExecTaskStatusEnum status;

    @ApiModelProperty(value = "失败原因")
    private String message;

    //圈复杂度文本数据
    @ApiModelProperty(value = "圈复杂度文本数据")
    private String circleText;

    //静态扫描警告文本数据
    @ApiModelProperty(value = "静态扫描警告文本数据")
    private String warningText;

    //代码注释率文本数据
    @ApiModelProperty(value = "代码注释率文本数据")
    private String commentsText;

    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @Api(tags = "静态扫描警告")
    public static class WarningInfo {
        @JsonProperty("file_path")
        private String filePath;

        @JsonProperty("line_number")
        private int lineNumber;

        @JsonProperty("column_number")
        private int columnNumber;

        @JsonProperty("warning_type")
        private String warningType;

        @JsonProperty("warning_message")
        private String warningMessage;
    }

    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @Api(tags = "代码注释率")
    public static class CommentInfo {
        private int blanks; //空白行的数量
        private int code; //代码行的数量
        private int comments; //注释行的数量  注释行/(代码行-空白行)
        //每个文件的详细信息
        private Map<String, List<Report>> children;

        @Builder
        @AllArgsConstructor
        @NoArgsConstructor
        @Data
        public static class Report {
            private Stats stats;
            //文件名称
            private String name;
        }

        /**
         * 每个文件的代码注释情况
         */
        @Builder
        @AllArgsConstructor
        @NoArgsConstructor
        @Data
        public static class Stats {
            private int blanks;
            private int code;
            private int comments;
        }
    }


    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @Api(tags = "圈复杂度")
    public static class CircleComplexityInfo {
        private Integer circleComplexity;
        private String filePath;
        private String funName;
    }
}