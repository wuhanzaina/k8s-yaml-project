/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code
 * 文件名称:PromptTemplateServiceImpl.java
 * 创建日期:2024-02-27
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.constant.GlobalConstant;
import com.kotei.sdw.exception.BaseException;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.entity.PromptMarket;
import com.kotei.sdw.modules.entity.PromptTemplate;
import com.kotei.sdw.modules.feign.vo.DeptRes;
import com.kotei.sdw.modules.mapper.PromptTemplateMapper;
import com.kotei.sdw.modules.service.CommonService;
import com.kotei.sdw.modules.service.PromptMarketService;
import com.kotei.sdw.modules.service.PromptTemplateService;
import com.kotei.sdw.modules.vo.AddPromptTemplateVO;
import com.kotei.sdw.modules.vo.EditPromptTemplateVO;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.security.utils.SecurityUtils;
import com.kotei.sdw.system.api.model.LoginUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Map;

/**
 *
 * prompt模板 ServiceImpl
 *
 *
 * @author hk
 * @since 2024-02-27
 */
@Service
public class PromptTemplateServiceImpl extends BaseServiceImpl<PromptTemplate> implements PromptTemplateService {
    @Autowired
    private PromptTemplateMapper promptTemplateMapper;
    @Autowired
    private PromptMarketService promptMarketService;
    @Autowired
    private CommonService commonService;

    @Override
    protected BaseMapper<PromptTemplate> getMapper() {
        return promptTemplateMapper;
    }

    @Override
    public PromptTemplate get(Long id) {
        return promptTemplateMapper.selectById(id);
    }

    @Override
    public IPage<PromptTemplate> getList(PageVO<PromptTemplate> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<PromptTemplate> lambdaQueryWrapper = Wrappers.lambdaQuery(PromptTemplate.class)
                .eq(params.containsKey("code"), PromptTemplate::getCode, params.get("code"))
                .eq(params.containsKey("name"), PromptTemplate::getName, params.get("name"))
                .eq(params.containsKey("status"), PromptTemplate::getStatus, params.get("status"))
                .eq(params.containsKey("playRole"), PromptTemplate::getPlayRole, params.get("playRole"))
                .eq(params.containsKey("context"), PromptTemplate::getContext, params.get("context"))
                .eq(params.containsKey("createrId"), PromptTemplate::getCreaterId, params.get("createrId"))
                .eq(params.containsKey("createrName"), PromptTemplate::getCreaterName, params.get("createrName"))
                .eq(params.containsKey("createTime"), PromptTemplate::getCreateTime, params.get("createTime"))
                .eq(params.containsKey("modifierId"), PromptTemplate::getModifierId, params.get("modifierId"))
                .eq(params.containsKey("modifierName"), PromptTemplate::getModifierName, params.get("modifierName"))
                .eq(params.containsKey("modifyTime"), PromptTemplate::getModifyTime, params.get("modifyTime"));
        return promptTemplateMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    public Long insert(PromptTemplate entity) {
        entity.setId(KeyGenerate.generateId());
        LoginUser loginUser = SecurityUtils.getLoginUser();
        entity.setCreaterId(loginUser.getUserid());
        entity.setCreaterName(loginUser.getSysUser().getNickName());
        promptTemplateMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        promptTemplateMapper.deleteById(id);
    }

    @Override
    public void update(PromptTemplate entity) {
        LoginUser loginUser = SecurityUtils.getLoginUser();
        entity.setModifierId(loginUser.getUserid());
        entity.setModifierName(loginUser.getSysUser().getNickName());
        promptTemplateMapper.updateById(entity);
    }

    @Override
    @Transactional
    public Long insert(AddPromptTemplateVO add) {
        PromptTemplate promptTemplate = new PromptTemplate();
        BeanUtil.copyProperties(add, promptTemplate);
        promptTemplate.setCode("");
        promptTemplate.setStatus(GlobalConstant.YES);
        promptTemplate.setCreateTime(new Date());
        promptTemplate.setModifyTime(new Date());
        promptTemplate.setId(KeyGenerate.generateId());
        return this.insert(promptTemplate);
    }

    @Override
    @Transactional
    public void update(EditPromptTemplateVO edit) {
        PromptTemplate promptTemplate = this.get(edit.getId());
        promptTemplate.setModifyTime(new Date());
        BeanUtil.copyProperties(edit, promptTemplate);
        this.update(promptTemplate);
    }


    @Override
    public PromptTemplate getByMarketIdAndUserId(Long marketId, Long userId) {
        LambdaQueryWrapper<PromptTemplate> lambdaQueryWrapper = Wrappers.lambdaQuery(PromptTemplate.class)
                .eq(PromptTemplate::getMarketId, marketId)
                .eq(PromptTemplate::getCreaterId, userId)
                ;
        lambdaQueryWrapper.last(" limit 1");
        return this.promptTemplateMapper.selectOne(lambdaQueryWrapper);
    }


    /**
     * 分享/取消分享到提示词市场
     *
     * @param ptId
     * @return 提示词市场ID
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void share(Long ptId, Integer share) {
        PromptTemplate pt = this.get(ptId);
        PromptMarket pmDb = promptMarketService.getByPtId(ptId);
        PromptMarket pm = new PromptMarket();
        if (share == 1) {
            //当前的模板未被分享，那么分享
            saveOrUpdatePm(pmDb, pt);
        } else {
            //当前的模板已被分享，那么取消分享 更新PM
            if (pmDb != null) {
                pm.setId(pmDb.getId());
                pm.setStatus(0);
                promptMarketService.update(pm);
            }
        }
        //更新PT
        PromptTemplate updatePt = new PromptTemplate();
        updatePt.setId(pt.getId());
        updatePt.setShare(share);
        this.update(updatePt);
    }

    private void saveOrUpdatePm(PromptMarket pmDb, PromptTemplate pt) {
        PromptMarket pm = new PromptMarket();
        String name = pt.getName();
        if (pmDb == null) {
            //检查名称是否重复
            PromptMarket promptMarket = this.promptMarketService.getByName(name);
            if (promptMarket != null) {
                throw new BaseException("提示词市场中已存在[" + name + "]");
            }
            //新增一个PM
            LoginUser user = SecurityUtils.getLoginUser();
            if (user != null) {
                pm.setDepartmentId(user.getSysUser().getDeptId());
                pm.setDepartmentName(user.getSysUser().getDept().getDeptName());
                pm.setUserName(user.getSysUser().getNickName());
                pm.setUserNo(user.getUsername());
                //置换出根节点部门对象
                DeptRes.DeptVo rootDepartment = commonService.getRootDepartment(pm.getDepartmentId());
                pm.setRootDepartmentId(rootDepartment.getId());
                pm.setRootDepartmentName(rootDepartment.getLabel());
            }
            pm.setName(name);
            pm.setStatus(1);
            pm.setPtId(pt.getId());
            pm.setShareCount(0);
            pm.setLanguage(pt.getLanguage());
            pm.setIntro(pt.getIntro());
            pm.setContext(pt.getContext());
            pm.setCreaterId(pt.getCreaterId());
            pm.setCreaterName(pt.getCreaterName());
            pm.setModifyTime(new Date());
            promptMarketService.insert(pm);
        } else {
            //更新PM
            pm.setId(pmDb.getId());
            pm.setIntro(pt.getIntro());
            pm.setContext(pt.getContext());
            pm.setName(name);
            pm.setStatus(1);
            promptMarketService.update(pm);
        }
    }
}
