package com.kotei.sdw.modules.ut.vo;

/**
 * @author tiger
 * @date 2024/3/27 13:47
 */

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CheckCodeSuggestAIVo {
    /**
     * 修改建议
     */
    private String suggest;

    /**
     * 修改后的代码
     */
    private String suggestCode;

}


