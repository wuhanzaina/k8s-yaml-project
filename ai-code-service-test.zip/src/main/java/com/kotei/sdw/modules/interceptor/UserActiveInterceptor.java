package com.kotei.sdw.modules.interceptor;

import com.kotei.sdw.exception.BaseException;
import com.kotei.sdw.modules.config.AppConfig;
import com.kotei.sdw.security.utils.SecurityUtils;
import com.kotei.sdw.system.api.domain.SysUser;
import com.kotei.sdw.system.api.model.LoginUser;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.Optional;

/**
 * @author tiger
 * @date 2024/3/13 16:23
 */
@Slf4j
@Component
public class UserActiveInterceptor implements HandlerInterceptor {

    @Autowired
    private AppConfig appConfig;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String clientCode = request.getHeader("X-CLIENT-CODE");
        if ("DCSCode".equals(clientCode)) {
            //判断版本是否要强制升级
            String clientVersion = request.getHeader("X-DCSCODE-VERSION");
            String serverVersion = appConfig.getDsCodeVersion();
            int[] v1 = getPluginVersion(clientVersion);
            int[] v2 = getPluginVersion(serverVersion);
            boolean upgrade = v1[0] < v2[0] || (v1[0] == v2[0] && v1[1] < v2[1]) || (v1[0] == v2[0] && v1[1] == v2[1] && v1[2] < v2[2]);
            log.info("clientVersion: {}, serverVersion: {}, upgrade: {}", clientVersion, serverVersion, upgrade);
            if (upgrade) {
                LoginUser loginUser = SecurityUtils.getLoginUser();
                String userNo = Optional.ofNullable(loginUser).map(LoginUser::getSysUser).map(SysUser::getUserName).orElse("0");
                throw new BaseException("userNo:" + userNo + " 请将插件版本更新至 " + serverVersion);
            }
//
//            // 记录用户活跃度
//            LoginUser loginUser = SecurityUtils.getLoginUser();
//            try {
//                log.info("UserActiveInterceptor 拦截器记录用户活跃度 loginUserNo :{} ", loginUser == null ? "null" : loginUser.getUsername());
//                userActivityService.save();
//            } catch (Exception e) {
//                log.info("UserActiveInterceptor 拦截器记录用户活跃度异常 loginUserNo :{} ", loginUser == null ? "null" : loginUser.getUsername());
//            }
        }
        return true;
    }

    private int[] getPluginVersion(String version) {
        if (StringUtils.isBlank(version)) {
            return new int[]{0, 0, 0};
        }
        return Arrays.stream(version.replace("v", "").split("\\.")).mapToInt(Integer::parseInt).toArray();
    }
}
