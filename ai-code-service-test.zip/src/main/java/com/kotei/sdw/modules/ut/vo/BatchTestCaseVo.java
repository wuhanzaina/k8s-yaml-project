package com.kotei.sdw.modules.ut.vo;

/**
 * @author tiger
 * @date 2024/3/27 13:47
 */

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiModel(value = "BatchTestCaseVo", description = "批量生成UT测试用例")
public class BatchTestCaseVo {
    /**
     * 文件地址
     */
    @ApiModelProperty(value = "文件地址", required = true, position = 9)
    private String filePath;
    /**
     * 测试用例
     */
    @ApiModelProperty(value = "测试用例", required = true, position = 9)
    private List<String> testCaseList;

}


