/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:AddCodeCovFunVO.java
 * 创建日期:2024-04-22
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 *
 * 代码覆盖率函数表
 *
 *
 * @author tiger
 * @since 2024-04-22
 */
@Data
@NoArgsConstructor
@ApiModel(value = "CodeCovFunQueryVO", description = "代码覆盖率函数表")
public class CodeCovFunQueryVO implements Serializable {

    private static final long serialVersionUID = 1L;
    @ApiModelProperty(value = "ID", required = true, position = 2)
    private Long id;
    /**
     * 任务ID
     */
    @ApiModelProperty(value = "任务ID", required = true, position = 2)
    private Long covTaskId;
    /**
     * 文件路径
     */
    @ApiModelProperty(value = "文件路径(512)", required = true, position = 3)
    private String filePath;
    /**
     * 函数内容
     */
    @ApiModelProperty(value = "函数内容(32)", required = true, position = 4)
    private String funName;
    /**
     * 函数内容
     */
    @ApiModelProperty(value = "函数内容(8900)", required = true, position = 5)
    private String fun;
    /**
     * 代码覆盖率
     */
    @ApiModelProperty(value = "代码覆盖率(3,2)", required = true, position = 6)
    private BigDecimal blocksPercent;
    /**
     * 执行次数
     */
    @ApiModelProperty(value = "执行次数", required = true, position = 7)
    private Integer executionCount;
    /**
     * 函数起始行号
     */
    @ApiModelProperty(value = "函数起始行号", required = true, position = 8)
    private Integer lineNo;
    /**
     * 函数占用行数
     */
    @ApiModelProperty(value = "函数占用行数", required = true, position = 9)
    private Integer lineNum;
    /**
     * 返回执行次数
     */
    @ApiModelProperty(value = "返回执行次数", required = true, position = 10)
    private Integer returnedCount;

    /**
     * 未覆盖行号
     */
    @ApiModelProperty(value = "未覆盖行号", required = true, position = 10)
    private List<Integer> offLines;

    @ApiModelProperty(value = "分支详细内容JSON数据[{\"blockno\":0,\"count\":0,\"fallthrough\":false,\"throw\":false}]", position = 4)
    private List<CovLineBranchVO> branches;

}
