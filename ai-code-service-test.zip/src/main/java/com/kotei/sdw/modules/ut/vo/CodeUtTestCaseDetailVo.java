/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:CodeUtTestCase.java
 * 创建日期:2024-04-03
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.ut.vo;

import com.kotei.sdw.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 *
 * 代码生成UT测试用例
 *
 *
 * @author tiger
 * @since 2024-04-03
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@ApiModel(value = "CodeUtTestCase", description = "代码生成UT测试用例")
public class CodeUtTestCaseDetailVo extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
     * 用户ID
     */
    @ApiModelProperty(value = "用户ID", position = 2)
    private Long userId;
    /**
     * 用户名称
     */
    @ApiModelProperty(value = "用户名称", position = 3)
    private String userName;
    /**
     * 工号
     */
    @ApiModelProperty(value = "工号", position = 4)
    private String userNo;
    /**
     * 当前部门ID
     */
    @ApiModelProperty(value = "当前部门ID", position = 5)
    private Long departmentId;
    /**
     * 当前部门
     */
    @ApiModelProperty(value = "当前部门", position = 6)
    private String departmentName;
    /**
     * 一级部门ID
     */
    @ApiModelProperty(value = "一级部门ID", position = 7)
    private Long rootDepartmentId;
    /**
     * 一级部门
     */
    @ApiModelProperty(value = "一级部门", position = 8)
    private String rootDepartmentName;
    /**
     * 项目工程标识
     */
    @ApiModelProperty(value = "项目工程标识", position = 9)
    private String projectCode;
    /**
     * 分支
     */
    @ApiModelProperty(value = "分支", position = 10)
    private String branch;
    /**
     * 文件地址
     */
    @ApiModelProperty(value = "文件地址", position = 11)
    private String filePath;
    /**
     * 函数
     */
    @ApiModelProperty(value = "函数", position = 12)
    private String fun;
    /**
     * 函数名称
     */
    @ApiModelProperty(value = "函数名称", position = 12)
    private String funName;
    /**
     * 函数返回类型
     */
    @ApiModelProperty(value = "函数返回类型", position = 12)
    private String resultType;
    /**
     * 函数AST结构
     */
    @ApiModelProperty(value = "函数AST结构", position = 13)
    private String astContent;
    /**
     * AI返回的结构化数据
     */
    @ApiModelProperty(value = "AI返回的结构化数据", position = 14)
    private String aiUtStructure;
    /**
     * 用户最终提交的结构化数据
     */
    @ApiModelProperty(value = "用户最终提交的结构化数据", position = 15)
    private String userUtStructure;
    /**
     * 测试用例
     */
    @ApiModelProperty(value = "测试用例", position = 16)
    private String testCases;
    /**
     * 生成测试用例个数
     */
    @ApiModelProperty(value = "生成测试用例个数", position = 16)
    private Integer testCaseCount;
    /**
     * 状态 0：用户提交请求；1：AST结构生成；2：AI结构化数据生成；3：用户提交结构化数据；4：测试用例生成 5：测试用例生成完成失败
     */
    @ApiModelProperty(value = "状态 0：用户提交请求；1：AST结构生成；2：AI结构化数据生成；3：用户提交结构化数据；4：测试用例生成完成；5：测试用例生成完成失败", position = 17)
    private Integer status;
    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间", position = 18)
    private Date createTime;
    /**
     * 执行完毕时间
     */
    @ApiModelProperty(value = "执行完毕时间", position = 19)
    private Date finishTime;


}
