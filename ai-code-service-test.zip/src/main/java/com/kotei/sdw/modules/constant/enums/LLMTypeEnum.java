package com.kotei.sdw.modules.constant.enums;

/**
 * 单次反馈类型，  含义：[1:内容不全；2:格式不对；3:答非所问；4: 没有帮助]
 *
 * @author tiger
 * @date 2024/3/13 10:22
 */
public enum LLMTypeEnum {
    DEFAULT("", ""),
    OPENAI("OPENAI", "openai"),
    DEEP_SEEK("DEEP_SEEK", "DeepSeek"),
    ;

    private final String code;
    private final String name;

    LLMTypeEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    /**
     * 通过code获取
     *
     * @param code
     * @return
     */
    public static LLMTypeEnum getByCode(String code) {
        if (code == null) {
            return DEFAULT;
        }
        for (LLMTypeEnum type : LLMTypeEnum.values()) {
            if (type.getCode().equals(code)) {
                return type;
            }
        }
        return DEFAULT;
    }
}
