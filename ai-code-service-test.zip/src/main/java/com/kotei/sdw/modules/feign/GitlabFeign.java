package com.kotei.sdw.modules.feign;

import com.kotei.sdw.modules.codecheck.vo.GitlabCommitDetailVo;
import com.kotei.sdw.modules.codecheck.vo.GitlabFileDetailVo;
import feign.Headers;
import feign.Param;
import feign.RequestLine;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "gitlab", url = "https://172.16.0.120/api/v4")
public interface GitlabFeign {

    @RequestLine("GET /projects/{id}/repository/files/{file_path}")
    @Headers("PRIVATE-TOKEN: {access_token}")
    GitlabFileDetailVo getFileDetail(@Param("id") String projectId, @Param("file_path") String filePath, @Param("access_token") String accessToken);

    @RequestLine("GET /projects/{id}/repository/commits/{commit_id}")
    @Headers("PRIVATE-TOKEN: {access_token}")
    GitlabCommitDetailVo getCommitDetail(@Param("id") String projectId, @Param("commit_id") String commitId, @Param("access_token") String accessToken);
}
