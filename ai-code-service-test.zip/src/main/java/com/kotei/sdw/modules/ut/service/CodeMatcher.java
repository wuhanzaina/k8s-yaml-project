package com.kotei.sdw.modules.ut.service;

/**
 * @author tiger
 * @date 2024/5/22 18:40
 */
@FunctionalInterface
public interface CodeMatcher {
    boolean match(String line);
}
