package com.kotei.sdw.modules.feign.vo;

import com.kotei.sdw.system.api.domain.SysDept;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author tiger
 * @date 2024/3/5 17:18
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "DeptVo", description = "用户部门数据")
public class DescendantDeptRes implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 列表数据 */
    private List<SysDept> data;

    /** 消息状态码 */
    private int code;

    /** 消息内容 */
    private String msg;

}
