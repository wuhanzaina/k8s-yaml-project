/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:BatchCodeUtTestCaseServiceImpl.java
 * 创建日期:2024-05-22
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.ut.service.impl;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.config.AppConfig;
import com.kotei.sdw.modules.feign.vo.DeptRes;
import com.kotei.sdw.modules.service.CommonService;
import com.kotei.sdw.modules.service.transaction.TransactionalService;
import com.kotei.sdw.modules.statistic.constant.enums.CodeUtTestCaseStatusEnum;
import com.kotei.sdw.modules.ut.entity.BatchCodeUtTestCase;
import com.kotei.sdw.modules.ut.entity.CodeUtTestCase;
import com.kotei.sdw.modules.ut.mapper.BatchCodeUtTestCaseMapper;
import com.kotei.sdw.modules.ut.service.BatchCodeUtTestCaseService;
import com.kotei.sdw.modules.ut.service.CodeUtTestCaseService;
import com.kotei.sdw.modules.ut.service.GenerateTestCaseService;
import com.kotei.sdw.modules.ut.vo.AddBatchCodeUtTestCaseVO;
import com.kotei.sdw.modules.ut.vo.BatchTestCaseVo;
import com.kotei.sdw.modules.ut.vo.GenerateTestCasesFromFunVo;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.security.utils.SecurityUtils;
import com.kotei.sdw.system.api.model.LoginUser;
import com.kotei.sdw.util.CompareUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.kotei.sdw.modules.codecheck.constant.Consts.ADMIN;
import static com.kotei.sdw.modules.utils.ComonUtil.getCodeBlackFromSourceFile;
import static com.kotei.sdw.modules.utils.GitLabUtil.GIT_POSTFIX;
import static com.kotei.sdw.util.StreamUtil.toStream;
import static java.util.concurrent.CompletableFuture.runAsync;

/**
 * 批量生成UT测试用例任务 ServiceImpl
 *
 * @author tiger
 * @since 2024-05-22
 */
@Service
@Slf4j
public class BatchCodeUtTestCaseServiceImpl extends BaseServiceImpl<BatchCodeUtTestCase> implements BatchCodeUtTestCaseService {
    @Autowired
    private BatchCodeUtTestCaseMapper batchCodeUtTestCaseMapper;
    @Autowired
    private CommonService commonService;
    @Autowired
    private GenerateTestCaseService generateTestCaseService;
    @Autowired
    private CodeUtTestCaseService codeUtTestCaseService;
    @Autowired
    private AppConfig appConfig;
    @Autowired
    private TransactionalService transactionalService;

    @Override
    protected BaseMapper<BatchCodeUtTestCase> getMapper() {
        return batchCodeUtTestCaseMapper;
    }

    @Override
    public BatchCodeUtTestCase get(Long id) {
        return batchCodeUtTestCaseMapper.selectById(id);
    }

    @Override
    public IPage<BatchCodeUtTestCase> getList(PageVO<BatchCodeUtTestCase> page) {
        Map<String, Object> params = page.getParams();
        String startCreateDate = "startCreateDate", endCreateDate = "endCreateDate";
        LambdaQueryWrapper<BatchCodeUtTestCase> lambdaQueryWrapper = Wrappers.lambdaQuery(BatchCodeUtTestCase.class)
                .eq(params.containsKey("userId"), BatchCodeUtTestCase::getUserId, params.get("userId"))
                .eq(params.containsKey("userName"), BatchCodeUtTestCase::getUserName, params.get("userName"))
                .eq(params.containsKey("userNo"), BatchCodeUtTestCase::getUserNo, params.get("userNo"))
                .eq(params.containsKey("departmentId"), BatchCodeUtTestCase::getDepartmentId, params.get("departmentId"))
                .eq(params.containsKey("departmentName"), BatchCodeUtTestCase::getDepartmentName, params.get("departmentName"))
                .eq(params.containsKey("rootDepartmentId"), BatchCodeUtTestCase::getRootDepartmentId, params.get("rootDepartmentId"))
                .eq(params.containsKey("rootDepartmentName"), BatchCodeUtTestCase::getRootDepartmentName, params.get("rootDepartmentName"))
                .eq(params.containsKey("projectCode"), BatchCodeUtTestCase::getProjectCode, params.get("projectCode"))
                .eq(params.containsKey("branch"), BatchCodeUtTestCase::getBranch, params.get("branch"))
                .eq(params.containsKey("count"), BatchCodeUtTestCase::getCount, params.get("count"))
                .eq(params.containsKey("status") && params.get("status") != null, BatchCodeUtTestCase::getStatus, params.get("status"))
                .eq(params.containsKey("message"), BatchCodeUtTestCase::getMessage, params.get("message"))
                .eq(params.containsKey("createTime"), BatchCodeUtTestCase::getCreateTime, params.get("createTime"))
                .eq(params.containsKey("finishTime"), BatchCodeUtTestCase::getFinishTime, params.get("finishTime"))
                .between(params.containsKey(startCreateDate) && params.get(startCreateDate) != null && params.containsKey(endCreateDate) && params.get(endCreateDate) != null, BatchCodeUtTestCase::getCreateTime, params.get(startCreateDate), params.get(endCreateDate));
        lambdaQueryWrapper.orderByDesc(BatchCodeUtTestCase::getId);
        return batchCodeUtTestCaseMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    public Long insert(BatchCodeUtTestCase entity) {
        if (entity.getId() == null) {
            entity.setId(KeyGenerate.generateId());
        }
        if (entity.getCreateTime() == null) {
            entity.setCreateTime(new Date());
        }
        batchCodeUtTestCaseMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        batchCodeUtTestCaseMapper.deleteById(id);
    }

    @Override
    public void update(BatchCodeUtTestCase entity) {
        batchCodeUtTestCaseMapper.updateById(entity);
    }

    @Override
    public Long save(AddBatchCodeUtTestCaseVO req) {
        BatchCodeUtTestCase task = new BatchCodeUtTestCase();
        String branch = req.getBranch();
        //过滤掉.h 的数据内容
        List<AddBatchCodeUtTestCaseVO.FunInfo> funList = toStream(req.getFunList()).filter(it -> !it.getFilePath().endsWith(".h")).collect(Collectors.toList());
        String projectCode = req.getProjectCode().endsWith(GIT_POSTFIX) ? req.getProjectCode() : req.getProjectCode() + GIT_POSTFIX;
        task.setBranch(branch);
        task.setProjectCode(projectCode);
        task.setCount(0);
        task.setFunCount(funList.size());
        //执行中
        task.setStatus(1);
        LoginUser user = SecurityUtils.getLoginUser();
        if (user != null) {
            task.setUserId(user.getUserid());
            task.setDepartmentId(user.getSysUser().getDeptId());
            task.setDepartmentName(user.getSysUser().getDept().getDeptName());
            task.setUserName(user.getSysUser().getNickName());
            task.setUserNo(user.getUsername());
            //置换出根节点部门对象
            DeptRes.DeptVo rootDepartment = commonService.getRootDepartment(task.getDepartmentId());
            task.setRootDepartmentId(rootDepartment.getId());
            task.setRootDepartmentName(rootDepartment.getLabel());
        } else {
            //设置为系统管理员
            //1	admin	admin	103	研发部门	101	武汉
            task.setUserId(1L);
            task.setUserName(ADMIN);
            task.setUserNo(ADMIN);
            task.setDepartmentId(103L);
            task.setDepartmentName("研发部门");
            task.setRootDepartmentId(101L);
            task.setRootDepartmentName("武汉");
        }
        Long id = KeyGenerate.generateId();
        task.setId(id);
        transactionalService.newTransaction(() -> insert(task));

        //项目本地目录地址
        String projectPath = generateTestCaseService.getProjectGitPath(projectCode, branch);

        log.info("AddBatchCodeUtTestCase req: {}", JSONUtil.toJsonStr(req));
        runAsync(() -> {
            //通过文件地址+函数名称得到函数内容
            GenerateTestCasesFromFunVo vo = new GenerateTestCasesFromFunVo();
            for (AddBatchCodeUtTestCaseVO.FunInfo funInfo : funList) {
                String funName = funInfo.getFunName();
                //window 路径转化为Linux 路径
                String filePath = funInfo.getFilePath().replace("\\", "/");
                List<String> funCodeList = getCodeBlackFromSourceFile(
                        projectPath + File.separator + filePath,
                        1,
                        (String line) -> line.contains(funName)
                );
                vo.setFun(toStream(funCodeList).findFirst().orElse(""));
                vo.setProjectCode(projectCode);
                vo.setBranch(branch);
                vo.setFilePath(filePath);
                vo.setBatchId(id);
                log.info("AddBatchCodeUtTestCase  generateTestCasesFromFun req: {}", JSONUtil.toJsonStr(vo));
                generateTestCaseService.generateTestCasesFromFun(vo);
            }
        });
        return id;
    }

    /**
     * 通过子任务修改批量任务的状态
     *
     * @param id
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStatus(Long id) {
        if (CompareUtils.greaterThanZero(id)) {
            BatchCodeUtTestCase batchCodeUtTestCase = this.get(id);
            List<CodeUtTestCase> utTestCases = codeUtTestCaseService.getListByBatchId(id);
            //所有的测试用例都执行完成，那么修改批量任务的状态
            long count = toStream(utTestCases)
                    .filter(it -> it.getStatus().equals(CodeUtTestCaseStatusEnum.SUCCESS.getCode()) || it.getStatus().equals(CodeUtTestCaseStatusEnum.FAILED.getCode()))
                    .count();
            log.info("通过子任务修改批量任务的状态 batchCodeUtTestCase.funCount: {}, count: {} utTestCases.count: {}", batchCodeUtTestCase.getFunCount(), count, toStream(utTestCases).count());
            BatchCodeUtTestCase updateEntity = new BatchCodeUtTestCase();
            updateEntity.setId(id);
            if (batchCodeUtTestCase.getFunCount() <= count) {
                //子任务已经执行完成
                updateEntity.setStatus(2);
                updateEntity.setFinishTime(new Date());
                this.update(updateEntity);
            }
        }
    }

    /**
     * 获取批量生成的UT用例列表
     *
     * @param id
     * @return
     */
    @Override
    public List<BatchTestCaseVo> getTestCaseCodeListById(Long id) {
        List<CodeUtTestCase> utTestCases = codeUtTestCaseService.getListByBatchId(id);
        return toStream(utTestCases)
                .filter(testCase -> testCase.getStatus().equals(CodeUtTestCaseStatusEnum.SUCCESS.getCode()))
                .collect(Collectors.groupingBy(CodeUtTestCase::getFilePath))
                .entrySet().stream()
                .map(entry -> BatchTestCaseVo.builder()
                        .filePath(generateTestCaseService.getTestCasePathFromSourceFile(entry.getKey()))
                        .testCaseList(entry.getValue().stream()
                                .flatMap(testCase -> JSONUtil.toList(JSONUtil.parseArray(testCase.getTestCases()), String.class).stream())
                                .collect(Collectors.toList()))
                        .build())
                .collect(Collectors.toList());
    }
}
