package com.kotei.sdw.modules.constant.enums;

/**
 * ONE:针对单个会话的反馈；GLOBAL:全局反馈
 * @author tiger
 * @date 2024/3/13 10:22
 */
public enum FeedbackTypeEnum {
    DEFAULT("", ""),
    ONE("ONE", "单个会话反馈"),
    GLOBAL("GLOBAL", "全局反馈"),
    ;

    private final String code;
    private final String name;

    FeedbackTypeEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    /**
     * 通过code获取FeedbackType
     * @param code
     * @return
     */
    public static FeedbackTypeEnum getByCode(String code) {
        if (code == null) {
            return DEFAULT;
        }
        for (FeedbackTypeEnum type : FeedbackTypeEnum.values()) {
            if (type.getCode().equals(code)) {
                return type;
            }
        }
        return DEFAULT;
    }
}
