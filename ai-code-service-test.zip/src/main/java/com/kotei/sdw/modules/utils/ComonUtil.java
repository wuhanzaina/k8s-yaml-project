package com.kotei.sdw.modules.utils;

import cn.hutool.core.io.FileUtil;
import cn.hutool.json.JSONUtil;
import com.kotei.sdw.modules.ut.service.CodeMatcher;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.lang3.StringUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author tiger
 * @date 2024/5/8 13:58
 */
@Slf4j
public class ComonUtil {

    /**
     * @param workPath   工作路径
     * @param scriptPath 脚本路径
     * @brief 执行shell脚本
     */
    public static int processShell(String workPath, String scriptPath) {
        try {
            log.info("genTestCasesFromFun processShell start {}", scriptPath);
            if (!FileUtil.exist(scriptPath)) {
                String msg = "编译脚本不存在," + scriptPath;
                log.error(msg);
                return -1;
            }
            // 构建CommandLine对象，并设置要执行的命令
            CommandLine commandLine = CommandLine.parse("sh " + scriptPath);
            // 创建DefaultExecutor对象，并执行命令
            DefaultExecutor executor = DefaultExecutor.builder().get();
            if (StringUtils.isNotBlank(workPath)) {
                // 设置工作目录（可选）
                executor.setWorkingDirectory(new File(workPath));
            }
            int exitCode = executor.execute(commandLine);
            log.info("genTestCasesFromFun processShell end {} 退出码：{}", scriptPath, exitCode);
            return exitCode;
        } catch (IOException e) {
            log.error("genTestCasesFromFun processShell error ", e);
            return -1;
        }
    }

    /**
     * 过滤AI返回的结构化数据
     *
     * @param content
     * @return
     */
    public static String extractCodeBlockForJson(String content) {
        //判断返回的内容是json字符串，直接返回
        if (JSONUtil.isJson(content)) {
            return content;
        }
        List<String> codeBlocks = new ArrayList<>();
        //返回MD格式的代码块
        Pattern pattern = Pattern.compile("```json([\\s\\S]+?)```");
        Matcher matcher = pattern.matcher(content);
        while (matcher.find()) {
            String result = matcher.group(1);
            codeBlocks.add(result.trim());
        }
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < codeBlocks.size(); i++) {
            String item = codeBlocks.get(i).trim();
            // 把前后的\n去掉
            if (item.startsWith("\\n[")) {
                item = item.replace("\\n[", "[");
            }
            if (item.endsWith("]\\n")) {
                item = item.replace("]\\n", "]");
            }
            if (JSONUtil.isJsonArray(item)) {
                item = item.replaceFirst("\\[", "");
                int lastBracketIndex = item.lastIndexOf("]");
                if (lastBracketIndex != -1) {
                    item = item.substring(0, lastBracketIndex) + item.substring(lastBracketIndex + 1);
                }
            }
            if (i < codeBlocks.size() - 1) {
                item += ",";
            }
            sb.append(item);
        }
        sb.append("]");
        return sb.toString();
    }

    /**
     * 过滤AI返回的结构化数据
     *
     * @param content
     * @return
     */
    public static String extractFirstCodeBlockForJson(String content) {
        //判断返回的内容是json字符串，直接返回
        if (JSONUtil.isJson(content)) {
            return content;
        }
        //返回MD格式的代码块
        Pattern pattern = Pattern.compile("[\\s\\S]*```json([\\s\\S]+?)```[\\s\\S]*");
        Matcher matcher = pattern.matcher(content);
        if (matcher.matches()) {
            return matcher.group(1);
        }
        return "";
    }

    /**
     * 从代码文件中找出符号条件的代码块
     *
     * @param filePath
     * @param num      获取代码数量  -1 表示全部内容
     * @return
     */
    public static List<String> getCodeBlackFromSourceFile(String filePath, int num, CodeMatcher matcher) {
        List<String> content = new ArrayList<>();
        if (!FileUtil.exist(filePath)) {
            log.info("getCodeBlackFromSourceFile filePath: {} not exists ", filePath);
            return content;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean start = false;
            int braceCount = 0;
            int firstBracket = 0;
            StringBuilder item = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                if (matcher.match(line)) {
                    //找到匹配的内容开始提取用例的内容
                    start = true;
                }
                if (start) {
                    item.append(line).append("\n");
                } else {
                    continue;
                }
                braceCount += countOccurrences(line, '{');
                if (braceCount > 0) {
                    firstBracket = 1;
                }
                braceCount -= countOccurrences(line, '}');
                if (firstBracket == 1 && braceCount == 0) {
                    start = false;
                    firstBracket = 0;
                    content.add(item.toString());
                    item.setLength(0);
                    if (num >= 0 && content.size() >= num) {
                        break;
                    }
                }
            }
        } catch (IOException e) {
            log.error("getTestCaseFromSourceFile error ", e);
        }
        log.info("getCodeBlackFromSourceFile filePath: {} content: {}", filePath, JSONUtil.toJsonStr(content));
        return content;
    }

    private static int countOccurrences(String line, char character) {
        int count = 0;
        for (int i = 0; i < line.length(); i++) {
            if (line.charAt(i) == character) {
                count++;
            }
        }
        return count;
    }

}
