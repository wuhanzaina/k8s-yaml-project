/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:PromptMarketService.java
* 创建日期:2024-05-14
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.service;

import com.kotei.sdw.modules.entity.PromptMarket;
import com.kotei.sdw.mvc.service.BaseService;

/**
*
* 提示词市场 Service
*
*
* @author tiger
* @since 2024-05-14
*/
public interface PromptMarketService extends BaseService<PromptMarket> {

    PromptMarket getByPtId(Long ptId);

    PromptMarket getByName(String name);

    /**
     * 市场中的提示词应用到我的提示词列表
     */
    void used(Long id);
}
