package com.kotei.sdw.modules.constant.enums;

/**
 * 反馈类型：[BUG:Bug报告、PROPOSAL:优化建议、NEW:新增功能、PERFORMANCE:性能问题、OTHER:其他]
 *
 * @author tiger
 * @date 2024/3/13 10:22
 */
public enum FeedbackSubTypeEnum {
    DEFAULT("", ""),
    BUG("BUG", "Bug报告"),
    PROPOSAL("PROPOSAL", "优化建议"),
    NEW("NEW", "新增功能"),
    PERFORMANCE("PERFORMANCE", "性能问题"),
    OTHER("OTHER", "其他");

    private final String code;
    private final String name;

    FeedbackSubTypeEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    /**
     * 通过code获取FeedbackType
     *
     * @param code
     * @return
     */
    public static FeedbackSubTypeEnum getByCode(String code) {
        if (code == null) {
            return DEFAULT;
        }
        for (FeedbackSubTypeEnum type : FeedbackSubTypeEnum.values()) {
            if (type.getCode().equals(code)) {
                return type;
            }
        }
        return DEFAULT;
    }
}
