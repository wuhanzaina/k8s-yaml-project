package com.kotei.sdw.modules.service.transaction;

/**
 * @author tiger
 */
@FunctionalInterface
public interface Action {
    void apply();
}
