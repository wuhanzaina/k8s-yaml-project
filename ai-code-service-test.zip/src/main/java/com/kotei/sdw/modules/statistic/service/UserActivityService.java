/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:UserActivityService.java
 * 创建日期:2024-03-04
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.statistic.service;

import com.kotei.sdw.modules.statistic.entity.UserActivity;
import com.kotei.sdw.modules.statistic.vo.DepartmentUsedStatisticVo;
import com.kotei.sdw.modules.statistic.vo.RangeStatisticReq;
import com.kotei.sdw.modules.statistic.vo.UserActivityStatisticReq;
import com.kotei.sdw.modules.statistic.vo.UserActivityStatisticVo;
import com.kotei.sdw.mvc.service.BaseService;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 *
 * 用户活跃度统计表 Service
 *
 *
 * @author tiger
 * @since 2024-03-04
 */
public interface UserActivityService extends BaseService<UserActivity> {

    /**
     * 统计某个日期范围内的每天、周、月活跃用户数量
     *
     * @param req
     * @return
     */
    List<UserActivityStatisticVo> findUserActivityStatistic(UserActivityStatisticReq req);

    /**
     * 部门使用插件情况统计
     *
     * @param req
     * @return
     */
    List<DepartmentUsedStatisticVo> findDepartmentUsedStatistic(RangeStatisticReq req);

    @Transactional(rollbackFor = Exception.class)
    long save();

    void userActivityExport(RangeStatisticReq req, HttpServletResponse response);
}