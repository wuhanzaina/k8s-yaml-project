/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:UserFeedback.java
* 创建日期:2024-03-11
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.kotei.sdw.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
*
* 用户反馈表
*
*
* @author tiger
* @since 2024-03-11
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("user_feedback")
@ApiModel(value = "UserFeedback", description = "用户反馈表")
public class UserFeedback extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 标题
    */
    @ApiModelProperty(value = "标题", position = 2)
    private String title;
    /**
    * 用户ID
    */
    @ApiModelProperty(value = "用户ID", position = 3)
    private Long userId;
    /**
    * 用户名称
    */
    @ApiModelProperty(value = "用户名称", position = 4)
    private String userName;
    /**
    * 工号
    */
    @ApiModelProperty(value = "工号", position = 4)
    private String userNo;
    /**
    * 当前部门ID
    */
    @ApiModelProperty(value = "当前部门ID", position = 5)
    private Long departmentId;
    /**
    * 当前部门
    */
    @ApiModelProperty(value = "当前部门", position = 6)
    private String departmentName;
    /**
    * 一级部门ID
    */
    @ApiModelProperty(value = "一级部门ID", position = 7)
    private Long rootDepartmentId;
    /**
    * 一级部门
    */
    @ApiModelProperty(value = "一级部门", position = 8)
    private String rootDepartmentName;
    /**
    * 反馈时间
    */
    @ApiModelProperty(value = "反馈时间", position = 9)
    private String feedbackDate;
    /**
    * 反馈类型：[ONE:针对单个会话的反馈；GLOBAL:全局反馈]
    */
    @ApiModelProperty(value = "反馈类型：[ONE:针对单个会话的反馈；GLOBAL:全局反馈]", position = 10)
    private String feedbackType;
    /**
    * 反馈类型：[BUG:Bug报告、PROPOSAL:优化建议、NEW:新增功能、PERFORMANCE:性能问题、OTHER:其他]
    */
    @ApiModelProperty(value = "反馈类型：[BUG:Bug报告、PROPOSAL:优化建议、NEW:新增功能、PERFORMANCE:性能问题、OTHER:其他]", position = 11)
    private String feedbackSubType = "";
    /**
    * 反馈内容
    */
    @ApiModelProperty(value = "反馈内容", position = 12)
    private String feedbackContent;
    /**
    * 反馈上传的附件，json数组
    */
    @ApiModelProperty(value = "反馈上传的附件，json数组", position = 13)
    private String feedbackFiles;
    /**
    * 会话ID
    */
    @ApiModelProperty(value = "会话ID", position = 14)
    private Long acceptId;
    /**
    * 单次反馈类型，json数组
    */
    @ApiModelProperty(value = "单次反馈类型，json数组", position = 15)
    private String acceptTypes;
    /**
    * 插件名称
    */
    @ApiModelProperty(value = "插件名称", position = 16)
    private String name;
    /**
    * 插件版本
    */
    @ApiModelProperty(value = "插件版本", position = 17)
    private String version;
    /**
    * 操作系统类型
    */
    @ApiModelProperty(value = "操作系统类型", position = 18)
    private String osType;
    /**
    * 操作系统版本
    */
    @ApiModelProperty(value = "操作系统版本", position = 19)
    private String osVersion;
    /**
    * 开发工具类型 vscode, idea
    */
    @ApiModelProperty(value = "开发工具类型 vscode, idea", position = 20)
    private String ideaType;
    /**
    * 开发工具版本
    */
    @ApiModelProperty(value = "开发工具版本", position = 21)
    private String ideaVersion;
    /**
    * IP地址
    */
    @ApiModelProperty(value = "IP地址", position = 22)
    private String ipAddr;
    /**
    * 客户端浏览器类型
    */
    @ApiModelProperty(value = "客户端浏览器类型", position = 23)
    private String browser;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", position = 24)
    private Date createTime;


}
