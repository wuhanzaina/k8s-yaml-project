package com.kotei.sdw.modules.statistic.enums;

/**
 * @author tiger
 * @date 2024/3/4 16:33
 */
public enum FunctionUsageEnums {

    DAY("DAY","按天统计"),
    WEEK("WEEK","按照周统计"),
    MONTH("MONTH","按照月统计"),
    ;

    private String code;

    private String name;


    FunctionUsageEnums(String code, String name){
        this.code = code;
        this.name = name;
    }
}
