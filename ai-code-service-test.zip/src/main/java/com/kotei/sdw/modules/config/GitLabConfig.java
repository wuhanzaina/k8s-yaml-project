package com.kotei.sdw.modules.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;

@Data
@Component
@ConfigurationProperties(prefix = "gitlab")
public class GitLabConfig {
    /**
     * 获取git相关配置系统
     */
    private Map<String, String> accessKey;

}

