/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:ai-code
 * 文件名称:AddConversationsAcceptVO.java
 * 创建日期:2024-02-27
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.statistic.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * 会话采纳信息
 *
 *
 * @author hk
 * @since 2024-02-27
 */
@Data
@NoArgsConstructor
@ApiModel(value = "AddConversationsAcceptVO", description = "新增会话采纳信息")
public class AddConversationsAcceptVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 会话ID
     */
    @ApiModelProperty(value = "会话ID", required = true, position = 2)
    @NotNull(message = "会话ID不能为空")
    private Long conversationsId;
    /**
     * 类型.0:代码生成 1:代码纠错 2:代码解释 3:代码注释
     */
    @ApiModelProperty(value = "类型. 0：代码生成；1：代码解释；2：添加注释 - 函数；3：添加注释 - 逐行；4：智能代码问答", position = 4)
    @Min(value = 0, message = "类型不能小于0")
    @Max(value = 9, message = "类型不能大于9")
    private Integer type;

    /**
     * 是否用于复制 0：否  1：是
     */
    @ApiModelProperty(value = "是否用于复制 0：否  1：是", position = 3)
    private Integer useCopy;
    /**
     * 是否用于插入  0：否  1：是
     */
    @ApiModelProperty(value = "是否用于插入  0：否  1：是", position = 3)
    private Integer useInsert;
    /**
     * 是否用于新建  0：否  1：是
     */
    @ApiModelProperty(value = "是否用于新建  0：否  1：是", position = 3)
    private Integer useCreate;

}
