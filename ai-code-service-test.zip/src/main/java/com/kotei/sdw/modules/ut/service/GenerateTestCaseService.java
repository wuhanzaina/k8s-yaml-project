package com.kotei.sdw.modules.ut.service;

import com.kotei.sdw.modules.ut.vo.CompletionTestCasesFromFunVo;
import com.kotei.sdw.modules.ut.vo.GenerateTestCasesFromFunVo;
import com.kotei.sdw.modules.ut.vo.TestCaseObjectVo;

import java.util.List;

/**
 * @author tiger
 * @date 2024/3/27 13:42
 */
public interface GenerateTestCaseService {

    /**
     * 通过结构化的数据自动生成单元测试用用例
     *
     * @param testCaseObjectVo <p>
     *                         {
     *                         "description": "Initial wakeupRetryCounter less than retryMax",
     *                         "params": [
     *                         "NetworkHandleType network = 0"
     *                         ],
     *                         "static_variables": [
     *                         "LinSM_ConfigPtr = NULL_PTR",
     *                         "LinSM_StateInfo[0].wakeupRetryCounter = 0"
     *                         ],
     *                         "stubbed_functions": [
     *                         {
     *                         "fun_name":"LINSM_CALL_EXT_CANIF_WAKEUP",
     *                         "mock_result": "E_OK"
     *                         }
     *                         ],
     *                         "expected_result": "E_OK"
     *                         }
     *                         </p>
     * @return 测试用用例
     *
     * <p>
     * TEST_CASE("Com_TestCase_3", "[LinSm_Stm2_WaitConfirm_WakeupConfirm]")
     * {
     * printf("\nTestCase_3: fun: [LinSm_Stm2_WaitConfirm_WakeupConfirm]\n");
     * <p>
     * Std_ReturnType rslt = E_OK;
     * NetworkHandleType networknum = 0u;
     * <p>
     * Mock(Stub_DoStm3Matrix).willActLike(
     * [&] (NetworkHandleType network, uint8 evt){
     * return E_NOT_OK;
     * }
     * );
     * <p>
     * <p>
     * rslt = LinSm_Stm2_WaitConfirm_WakeupConfirm(networknum);
     * <p>
     * <p>
     * printf("rslt = %d\n", rslt);
     * CHECK(E_NOT_OK == rslt);
     * }
     * </p>
     */
    List<String> generateTestCasesFromJson(TestCaseObjectVo testCaseObjectVo);

    TestCaseObjectVo generateTestCasesFromPrompt(Long id, String prompt);

    TestCaseObjectVo generateTestCasesFromFun(GenerateTestCasesFromFunVo vo);

    void buildAstInfo(String projectCode, String branch);

    TestCaseObjectVo generateTestCasesFromId(Long id);

    /**
     * 通过代码覆盖率函数ID获取测试用例
     * @param codeCovFunId
     * @return
     */
    List<String> getTestCaseByCodeCovFunId(Long codeCovFunId);

    /**
     * 由大模型补全测试用例
     * @param vo
     * @return
     */
    TestCaseObjectVo completionTestCasesFromFun(CompletionTestCasesFromFunVo vo);

    /**
     * 通过源码文件路径推算出UT文件路径
     * @param sourcePath
     * @return
     */
    String getTestCasePathFromSourceFile(String sourcePath);

    String getProjectGitPath(String projectCode, String branch);

    String getProjectRootPath(String projectCode, String branch);

    String getScriptPath(String projectPath, String projectCode);
}
