package com.kotei.sdw.modules.ut.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import com.google.common.collect.Maps;
import com.kotei.sdw.exception.BaseException;
import com.kotei.sdw.modules.codecheck.entity.CodeCovFun;
import com.kotei.sdw.modules.codecheck.entity.CodeCovLine;
import com.kotei.sdw.modules.codecheck.entity.CodeCovTask;
import com.kotei.sdw.modules.codecheck.entity.Project;
import com.kotei.sdw.modules.codecheck.service.CodeCovFunService;
import com.kotei.sdw.modules.codecheck.service.CodeCovLineService;
import com.kotei.sdw.modules.codecheck.service.CodeCovTaskService;
import com.kotei.sdw.modules.codecheck.service.ProjectService;
import com.kotei.sdw.modules.config.AppConfig;
import com.kotei.sdw.modules.feign.ChatbotFeign;
import com.kotei.sdw.modules.feign.vo.ChatBotVo;
import com.kotei.sdw.modules.feign.vo.ChatBotVo.ChatRequest;
import com.kotei.sdw.modules.feign.vo.ChatBotVo.ChatResponse;
import com.kotei.sdw.modules.feign.vo.DeptRes;
import com.kotei.sdw.modules.service.CommonService;
import com.kotei.sdw.modules.statistic.constant.enums.CodeUtTestCaseStatusEnum;
import com.kotei.sdw.modules.ut.entity.CodeUtTestCase;
import com.kotei.sdw.modules.ut.mapper.CodeUtTestCaseMapper;
import com.kotei.sdw.modules.ut.service.BatchCodeUtTestCaseService;
import com.kotei.sdw.modules.ut.service.CodeUtTestCaseService;
import com.kotei.sdw.modules.ut.service.GenerateTestCaseService;
import com.kotei.sdw.modules.ut.vo.CompletionTestCasesFromFunVo;
import com.kotei.sdw.modules.ut.vo.FunAstInfoVo;
import com.kotei.sdw.modules.ut.vo.FunAstInfoVo.ParamInfoVo;
import com.kotei.sdw.modules.ut.vo.GenerateTestCasesFromFunVo;
import com.kotei.sdw.modules.ut.vo.TestCaseObjectVo;
import com.kotei.sdw.modules.ut.vo.TestCaseObjectVo.ParamInfo;
import com.kotei.sdw.modules.ut.vo.TestCaseObjectVo.StubbedFunction;
import com.kotei.sdw.modules.ut.vo.TestCaseObjectVo.TestCaseInfoVo;
import com.kotei.sdw.modules.utils.GitLabUtil;
import com.kotei.sdw.security.utils.SecurityUtils;
import com.kotei.sdw.system.api.model.LoginUser;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static cn.hutool.core.collection.CollUtil.isNotEmpty;
import static cn.hutool.json.JSONUtil.parseArray;
import static cn.hutool.json.JSONUtil.toJsonStr;
import static com.google.common.collect.ImmutableList.of;
import static com.kotei.sdw.modules.codecheck.constant.Consts.ADMIN;
import static com.kotei.sdw.modules.codecheck.constant.Consts.AI_CODE_SERVICE;
import static com.kotei.sdw.modules.constant.CommonConst.*;
import static com.kotei.sdw.modules.utils.ComonUtil.*;
import static com.kotei.sdw.modules.utils.GitLabUtil.GIT_POSTFIX;
import static com.kotei.sdw.modules.utils.GitLabUtil.extractProjectName;
import static com.kotei.sdw.util.CompareUtils.greaterThanZero;
import static com.kotei.sdw.util.StreamUtil.toStream;
import static java.util.Arrays.asList;
import static java.util.Optional.ofNullable;
import static java.util.concurrent.CompletableFuture.runAsync;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;
import static org.apache.commons.lang3.StringUtils.*;

/**
 * @author tiger
 * @date 2024/3/27 13:42
 */
@Slf4j
@Service
public class GenerateTestCaseServiceImpl implements GenerateTestCaseService {
    @Autowired
    private AppConfig appConfig;
    @Autowired
    private CommonService commonService;
    @Autowired
    private CodeUtTestCaseService codeUtTestCaseService;
    @Autowired
    private ChatbotFeign chatbotFeign;
    @Autowired
    private ProjectService projectService;
    @Autowired
    private CodeCovFunService codeCovFunService;
    @Autowired
    private CodeCovLineService codeCovLineService;
    @Autowired
    private CodeCovTaskService codeCovTaskService;
    @Autowired
    private CodeUtTestCaseMapper codeUtTestCaseMapper;
    @Autowired
    private BatchCodeUtTestCaseService batchCodeUtTestCaseService;

    /**
     * 通过结构化的数据自动生成单元测试用用例
     *
     * @param testCaseObjectVo <p>
     *                         {
     *                         "description": "Initial wakeupRetryCounter less than retryMax",
     *                         "params": [
     *                         "NetworkHandleType network = 0"
     *                         ],
     *                         "static_variables": [
     *                         "LinSM_ConfigPtr = NULL_PTR",
     *                         "LinSM_StateInfo[0].wakeupRetryCounter = 0"
     *                         ],
     *                         "stubbed_functions": [
     *                         {
     *                         "fun_name":"LINSM_CALL_EXT_CANIF_WAKEUP",
     *                         "mock_result": "E_OK"
     *                         }
     *                         ],
     *                         "expected_result": "E_OK"
     *                         }
     *                         </p>
     * @return 测试用用例
     *
     * <p>
     * TEST_CASE("Com_TestCase_3", "[LinSm_Stm2_WaitConfirm_WakeupConfirm]")
     * {
     * printf("\nTestCase_3: fun: [LinSm_Stm2_WaitConfirm_WakeupConfirm]\n");
     * <p>
     * Std_ReturnType rslt = E_OK;
     * NetworkHandleType networknum = 0u;
     * <p>
     * Mock(Stub_DoStm3Matrix).willActLike(
     * [&] (NetworkHandleType network, uint8 evt){
     * return E_NOT_OK;
     * }
     * );
     * <p>
     * <p>
     * rslt = LinSm_Stm2_WaitConfirm_WakeupConfirm(networknum);
     * <p>
     * <p>
     * printf("rslt = %d\n", rslt);
     * CHECK(E_NOT_OK == rslt);
     * }
     * </p>
     */
    @Override
    public List<String> generateTestCasesFromJson(TestCaseObjectVo testCaseObjectVo) {
        if (testCaseObjectVo == null || CollUtil.isEmpty(testCaseObjectVo.getTaseCaseInfoList())) {
            // 如果testCaseObjectVo为空或者testCaseObjectVo中的taseCaseInfoList为空，则返回一个空的列表
            return Collections.emptyList();
        }
        log.info("generateTestCasesFromJson start id: {} testCaseObjectVo: {}", testCaseObjectVo.getId(), toJsonStr(testCaseObjectVo));
        if (greaterThanZero(testCaseObjectVo.getId())) {
            CodeUtTestCase updateUtTestCase = new CodeUtTestCase();
            updateUtTestCase.setId(testCaseObjectVo.getId());
            updateUtTestCase.setUserUtStructure(toJsonStr(testCaseObjectVo.getTaseCaseInfoList()));
            updateUtTestCase.setStatus(CodeUtTestCaseStatusEnum.USER_STRUCTURE.getCode());
            codeUtTestCaseService.update(updateUtTestCase);
        }

        // 获取taseCaseInfoList列表
        List<TestCaseInfoVo> taseCaseInfoList = testCaseObjectVo.getTaseCaseInfoList();
        // 获取目标函数名
        String originFunName = testCaseObjectVo.getTargetFunName();
        String targetFunName = originFunName;
        //判断方法名称是否带有类型
        boolean c__function = targetFunName.contains("::");
        String[] targetFunNameList = originFunName.split("::");
        log.info("generateTestCasesFromJson 判断C++函数 id: {} targetFunName: {} isC++: {}", testCaseObjectVo.getId(), targetFunName, c__function);
        // 创建一个空的字符串列表res
        List<String> res = new ArrayList<>(taseCaseInfoList.size());
        // 遍历taseCaseInfoList列表
        for (int i = 0; i < taseCaseInfoList.size(); i++) {
            // 获取当前索引的TestCaseInfoVo对象
            TestCaseInfoVo testCaseInfo = taseCaseInfoList.get(i);
            // 创建一个StringBuilder对象来存储代码片段
            StringBuilder sb = new StringBuilder();
            // 根据目标函数名和索引生成一个唯一的id
            String id = "UT_" + originFunName.replace("::", "_") + "_" + (i + 1);
            // 添加注释和测试用例名称到字符串构建器中
            sb.append("//").append(testCaseInfo.getDescription()).append("\n");
            sb.append("TEST_CASE(\"").append(id).append("\", \"[").append(originFunName).append("]\")\n");
            sb.append("{\n");
            // 打印id和目标函数名到控制台
            sb.append("    printf(\" ").append(id).append(": fun: [").append(originFunName).append("]\\n\");\n");
            if (c__function) {
                sb.append("    using namespace std;\n");
                toStream(testCaseObjectVo.getNamespaces()).forEach(na -> sb.append("    using namespace ").append(na).append(";\n"));
                sb.append("    SET_TEST_FUNCTION_NAME(").append(targetFunNameList[0].trim()).append("_").append(targetFunNameList[1].trim()).append(");\n");
                sb.append("    ").append(targetFunNameList[0]).append(" targetClazz;\n");
                targetFunName = "targetClazz." + targetFunNameList[1];
                //处理public成员变量赋值
                sb.append(toStream(testCaseInfo.getPublicMemberVariables()).map(it -> "targetClazz." + it).collect(joining("\n")));
            }
            // 处理内部参数
            sb.append(actionParams(testCaseInfo.getFunctionParameters()));
            log.info("generateTestCasesFromJson actionParams id: {}", testCaseObjectVo.getId());
            // 处理静态变量
//            sb.append(actionStaticParams(testCaseInfo.getStaticVariables()));
            // 处理打桩函数
            sb.append(actionSubFun(testCaseInfo));
            log.info("generateTestCasesFromJson actionSubFun id: {}", testCaseObjectVo.getId());
            // 调用目标函数并将结果赋值给res变量
            sb.append("    ");
            boolean funResulVoid = "void".equalsIgnoreCase(testCaseObjectVo.getTargetFunResultType().trim());
            if (!funResulVoid) {
                sb.append(testCaseObjectVo.getTargetFunResultType()).append(" res = ");
            }
            sb.append(targetFunName).append("(").append(toStream(testCaseInfo.getFunctionParameters()).map(ParamInfo::getName).collect(joining(", "))).append(");\n");

            if (!funResulVoid) {
                // 打印res变量的值到控制台
                sb.append("    printf(\"res = %d\\n\", res);\n");
                // 检查目标函数的返回值是否与预期结果相等
                sb.append("    CHECK(").append(testCaseInfo.getExpectedResult()).append(" == res);\n");
            }
            sb.append("}\n");

            // 将生成的测试用例添加到res列表中
            res.add(sb.toString());
        }

        log.info("generateTestCasesFromJson SUCCESS id: {} originFunName: {} , targetFunName: {} ", testCaseObjectVo.getId(), originFunName, targetFunName);
        if (greaterThanZero(testCaseObjectVo.getId())) {
            CodeUtTestCase updateUtTestCase = new CodeUtTestCase();
            updateUtTestCase.setId(testCaseObjectVo.getId());
            updateUtTestCase.setTestCases(toJsonStr(res));
            updateUtTestCase.setStatus(CodeUtTestCaseStatusEnum.SUCCESS.getCode());
            updateUtTestCase.setTestCaseCount(taseCaseInfoList.size());
            updateUtTestCase.setFinishTime(new Date());
            codeUtTestCaseService.update(updateUtTestCase);
        }
        // 返回生成的测试用例列表
        return res;
    }

    /**
     * 生成结构化的UT单元测试用例
     *
     * @param prompt
     * @return
     */
    @Override
    public TestCaseObjectVo generateTestCasesFromPrompt(Long id, String prompt) {
        CodeUtTestCase codeUtTestCase = this.codeUtTestCaseService.get(id);
        ChatRequest request = new ChatRequest();
        request.setModel(appConfig.getAiModel());
        request.setAppId(AI_CODE_SERVICE);
        request.setMax_tokens(4096);
        request.setMessages(of(ChatBotVo.Message.builder().role("user").content(prompt).build()));
        ChatResponse chatResponse = callLLm(request);
        log.info("genTestCasesFromPrompt chatCompletions id: {} req: {}, res: {}", id, request, chatResponse);
        TestCaseObjectVo vo = new TestCaseObjectVo();
        String codeBlock = "";
        if (isNotEmpty(chatResponse.getChoices())) {
            codeBlock = extractCodeBlockForJson(chatResponse.getChoices().get(0).getMessage().getContent());
            try {
                List<TestCaseInfoVo> list = JSONUtil.toList(parseArray(defaultIfBlank(codeBlock, "[]")), TestCaseInfoVo.class);
                vo.setTaseCaseInfoList(list);
            } catch (Exception e) {
                codeBlock = "";
                log.error("genTestCasesFromPrompt JSON序列化异常", e);
            }
        }
        //更新入库
        CodeUtTestCase updateUtTestCase = new CodeUtTestCase();
        updateUtTestCase.setId(id);
        if (isNotBlank(codeBlock)) {
            if (codeUtTestCase.getType() == 0) {
                //生成测试用例任务
                updateUtTestCase.setAiUtStructure(codeBlock); //ai structure content
                updateUtTestCase.setStatus(CodeUtTestCaseStatusEnum.AI_STRUCTURE.getCode());
            } else {
                //补全测试用例任务
                updateUtTestCase.setAiUtStructure(codeBlock); //ai structure content
                updateUtTestCase.setAiUtStructure("[]"); //ai structure content
                updateUtTestCase.setTestCases(toJsonStr(
                        toStream(vo.getTaseCaseInfoList()).map(it -> "//" + it.getDescription() + "\n" + it.getTestCaseCode()).collect(toList())
                ));
                updateUtTestCase.setTestCaseCount(vo.getTaseCaseInfoList().size());
                updateUtTestCase.setFinishTime(new Date());
                updateUtTestCase.setStatus(CodeUtTestCaseStatusEnum.SUCCESS.getCode());
            }
        } else {
            updateUtTestCase.setAiUtStructure("[]");
            updateUtTestCase.setStatus(CodeUtTestCaseStatusEnum.FAILED.getCode());
            updateUtTestCase.setMessage("AI返回的数据异常");
        }
        codeUtTestCaseService.update(updateUtTestCase);
        return vo;
    }

    /**
     * 输入函数内容由大模型生成结构化UT
     *
     * @param vo
     * @return
     */
    @Override
    public TestCaseObjectVo generateTestCasesFromFun(GenerateTestCasesFromFunVo vo) {
        log.info("genTestCasesFromFun vo: {}", vo);
        preTestCaseReqVo(vo);
        String[] funArray = extractFunction(vo.getFun());
        CodeUtTestCase utTestCase = genCodeUtTestCase(vo, funArray);
        codeUtTestCaseService.insert(utTestCase);
        Long id = utTestCase.getId();

        //生成结构化的UT单元测试用例
        if (vo.getAsync() == 2 || (greaterThanZero(utTestCase.getBatchId()) && appConfig.getThreadNum() <= 1)) {
            //同步执行
            TestCaseObjectVo res = genTestCaseObjectVo(id);
            res.setId(id);
            res.setTargetFunResultType(funArray[0]);
            res.setTargetFunName(funArray[1]);
            return res;
        } else {
            //用户直接提交生成单个函数的UT测试用例，采用异步方案
            runAsync(() -> genTestCaseObjectVo(id));

            //组装返回值
            TestCaseObjectVo res = new TestCaseObjectVo();
            res.setId(id);
            res.setTargetFunResultType(funArray[0]);
            res.setTargetFunName(funArray[1]);
            return res;
        }
    }

    /**
     * 构建 CodeUtTestCase 对象
     *
     * @param vo
     * @param funArray
     * @return
     */
    private CodeUtTestCase genCodeUtTestCase(GenerateTestCasesFromFunVo vo, String[] funArray) {
        LoginUser user = SecurityUtils.getLoginUser();
        CodeUtTestCase utTestCase = new CodeUtTestCase();
        if (user != null) {
            utTestCase.setUserId(user.getUserid());
            utTestCase.setUserNo(user.getUsername());
            utTestCase.setUserName(user.getSysUser().getNickName());
            utTestCase.setDepartmentId(user.getSysUser().getDeptId());
            utTestCase.setDepartmentName(user.getSysUser().getDept().getDeptName());
            //置换出根节点部门对象
            DeptRes.DeptVo rootDepartment = commonService.getRootDepartment(utTestCase.getDepartmentId());
            utTestCase.setRootDepartmentId(rootDepartment.getId());
            utTestCase.setRootDepartmentName(rootDepartment.getLabel());
        } else {
            //设置为系统管理员
            //1	admin	admin	103	研发部门	101	武汉
            utTestCase.setUserId(1L);
            utTestCase.setUserName(ADMIN);
            utTestCase.setUserNo(ADMIN);
            utTestCase.setDepartmentId(103L);
            utTestCase.setDepartmentName("研发部门");
            utTestCase.setRootDepartmentId(101L);
            utTestCase.setRootDepartmentName("武汉");
        }
        utTestCase.setProjectCode(vo.getProjectCode());
        utTestCase.setFun(vo.getFun());
        utTestCase.setFilePath(vo.getFilePath().replace("\\", "/"));
        utTestCase.setBranch(vo.getBranch());
        utTestCase.setBatchId(vo.getBatchId());
        utTestCase.setStatus(CodeUtTestCaseStatusEnum.INIT.getCode());
        utTestCase.setAstContent("");
        utTestCase.setTestCases("");
        utTestCase.setAiUtStructure("");
        utTestCase.setUserUtStructure("");
        utTestCase.setTestCaseCount(0);
        utTestCase.setFunName(funArray[1]);
        utTestCase.setType(vo.getType());
        utTestCase.setCodeCovFunId(vo.getCodeCovFunId());
        return utTestCase;
    }

    /**
     * 预处理参数
     *
     * @param vo
     */
    private void preTestCaseReqVo(GenerateTestCasesFromFunVo vo) {
        //兼容不标准的project_code
        if (!vo.getProjectCode().endsWith(GIT_POSTFIX)) {
            vo.setProjectCode(vo.getProjectCode() + GIT_POSTFIX);
        }
        //处理掉 mock代码
        // if(!MOCK_IS_VALID(AliveSupervision_Init))
        //        return Mock(Stub_AliveSupervision_Init).call(name,param,nameSpace);
        vo.setFun(preFunction(vo.getFun()));
    }

    /**
     * 加工处理函数内容
     *
     * @param fun
     * @return
     */
    private String preFunction(String fun) {
        //处理掉 mock代码
        // if(!MOCK_IS_VALID(AliveSupervision_Init))
        // return Mock(Stub_AliveSupervision_Init).call(name,param,nameSpace);
        String[] funList = fun.split("\n");
        int count = 0;
        for (String item : funList) {
            if (item.contains("MOCK_IS_VALID(")) {
                fun = fun.replace(item, "");
                count++;
            }
            if (item.contains("Mock(Stub")) {
                fun = fun.replace(item, "");
                count++;
            }
            if (count >= 2) {
                break;
            }
        }
        return fun;
    }

    /**
     * 生成UT的核心逻辑
     *
     * <p>1.下载代码<p/>
     * <p>2.执行编译脚本，生成编译后的JSON库文件<p/>
     * <p>3.调用AST得到函数相关信息<p/>
     * <p>4.组装提示词<p/>
     * <p>6.调用大模型接口生成UT结果<p/>
     * <p>7.数据、状态入库<p/>
     * 组装提示词
     * 生成结构化的UT单元测试用例
     *
     * @param id
     * @param id
     * @return
     */
    private TestCaseObjectVo genTestCaseObjectVo(Long id) {
        CodeUtTestCase codeUtTestCase = this.codeUtTestCaseService.get(id);
        String projectCode = codeUtTestCase.getProjectCode();
        String branch = codeUtTestCase.getBranch();
        String gitCloneDir = appConfig.getGitCloneDir();
        //项目本地目录地址
        String projectPath = getProjectGitPath(projectCode, branch);
        log.info("genTestCasesFromFun start id: {} projectCode: {} gitCloneDir: {}", id, projectCode, gitCloneDir);

        StopWatch stopWatch = new StopWatch("使用AI生成UT测试用例 " + id);
        Project project = projectService.getByCode(projectCode, branch);
        //判断本地是否存在git仓库
        boolean existsGitRepository = GitLabUtil.existsGitRepository(new File(projectPath));
        boolean diffFromGitLab = false;
        //判断本地分支是否与远程分支有差异
        if (existsGitRepository) {
            diffFromGitLab = GitLabUtil.diffFromGitLab(projectPath, branch, asList("Test", "TestCase"));
        }
        log.info("genTestCasesFromFun diffFromGitLab done id: {} existsGitRepository: {} diffFromGitLab: {}", id, existsGitRepository, diffFromGitLab);
        //1. clone/pull仓库代码到本地
        try {
            stopWatch.start("clone代码");
            String gitUserName = ofNullable(project).map(Project::getGitUserName).orElse(GIT_USER_NAME);
            String gitUserPwd = ofNullable(project).map(Project::getGitUserPwd).orElse(GIT_USER_PWD);
            GitLabUtil.cloneRepository(projectCode, branch, gitUserName, gitUserPwd, projectPath);
            log.info("genTestCasesFromFun clone done id: {} projectCode: {}", id, projectCode);
        } catch (GitAPIException | IOException e) {
            log.error("genTestCasesFromFun clone ", e);
        }
        stopWatch.stop();

        stopWatch.start("编译生成json文件");
        //projectPath 修改为工程代码的根目录
        projectPath = getProjectRootPath(projectCode, branch);
        String scriptPath = getScriptPath(projectCode, branch);
        log.info("genTestCasesFromFun projectPath: {}, scriptPath: {}", projectPath, scriptPath);
        boolean exist = FileUtil.exist(scriptPath);
        if (!exist) {
            //编译脚本build_ut.sh不存在
            updateStatusToFailed(id, "编译脚本build_ut.sh不存在");
        }

        //2. 执行编译脚本
        int code = processShell(projectPath, scriptPath);
        if (exist && code != 0) {
            //编译脚本build_ut.sh不存在，或者执行返回码不为0
            updateStatusToFailed(id, "编译脚本build_ut.sh执行有误，退出码不为0");
        }
        stopWatch.stop();

        //3. 调用AST服务，返回函数相关的语法树
        stopWatch.start("调用AST服务");
        //函数文件相对地址
        String filePath = codeUtTestCase.getFilePath();
        FunAstInfoVo funAstInfo = null;
        if (code == 0) {
            funAstInfo = getAstFunInfo(id, projectPath, branch, codeUtTestCase.getFunName(), filePath, (!existsGitRepository) || diffFromGitLab);
            if (StringUtils.isBlank(ofNullable(funAstInfo).map(FunAstInfoVo::getFunName).orElse(null))) {
                //AST语法分析返回异常
                updateStatusToFailed(id, "AST语法分析返回异常");
            }
        }
        TestCaseObjectVo testCaseObjectVo = null;
        if (StringUtils.isNotBlank(ofNullable(funAstInfo).map(FunAstInfoVo::getFunName).orElse(null))) {
            CodeUtTestCase updateUtTestCase = new CodeUtTestCase();
            updateUtTestCase.setId(id);
            updateUtTestCase.setAstContent(toJsonStr(funAstInfo)); //ast content
            updateUtTestCase.setStatus(CodeUtTestCaseStatusEnum.AST.getCode());
            codeUtTestCaseService.update(updateUtTestCase);
            log.info("genTestCasesFromFun ast done id: {} projectPath: {} funName:{} filePath: {} res: {}", id, projectPath, funAstInfo, filePath, updateUtTestCase.getAstContent());
            stopWatch.stop();

            stopWatch.start("调用大模型生成UT");
            //4. 组装函数相关的提示词，调用大模型接口生成UT结果
            String promptAll = getAllPrompt(id, funAstInfo, codeUtTestCase, projectPath);
            //5. 调用大模型接口生成UT结果
            testCaseObjectVo = this.generateTestCasesFromPrompt(id, promptAll);
            log.info("genTestCasesFromFun call_ai id: {} type: {} TestCaseCount: {}", id, codeUtTestCase.getType(), toStream(testCaseObjectVo.getTaseCaseInfoList()).count());
            testCaseObjectVo.setId(id);
            testCaseObjectVo.setTargetFunName(codeUtTestCase.getFunName());
            //从ast语法树中补充namespace
            List<String> namespaces = funAstInfo.getNamespaces();
            testCaseObjectVo.setNamespaces(namespaces);
            stopWatch.stop();

            stopWatch.start("结构化UT用例生成测试用例代码");
            if (codeUtTestCase.getType() == 0) {
                //生成测试用例任务
                testCaseObjectVo.setId(id);
                if (StringUtils.isBlank(testCaseObjectVo.getTargetFunResultType())) {
                    testCaseObjectVo.setTargetFunResultType(funAstInfo.getResultType());
                }
                //6. 通过json数据结构生成UT测试用例
                List<String> res = generateTestCasesFromJson(testCaseObjectVo);
                testCaseObjectVo.setTaseCases(res);
                log.info("genTestCasesFromFun gen_ut_from_json id: {}  TestCaseCount: {}", id, toStream(res).count());
            } else {
                testCaseObjectVo.setTaseCases(toStream(testCaseObjectVo.getTaseCaseInfoList()).map(it -> "//" + it.getDescription() + "\n" + it.getTestCaseCode()).collect(toList()));
            }
        }
        //更新批量任务的的状态
        batchCodeUtTestCaseService.updateStatus(codeUtTestCase.getBatchId());
        stopWatch.stop();
        log.info(stopWatch.prettyPrint());

        return testCaseObjectVo;
    }

    /**
     * 通过AST服务构建出语法树
     *
     * @param projectCode
     * @param branch
     */
    @Override
    public void buildAstInfo(String projectCode, String branch) {
        log.info("buildAstInfo start project: {} branch: {}", projectCode, branch);
        String upperCaseBranch = branch.toUpperCase();
        if (!(upperCaseBranch.contains("UT") || upperCaseBranch.contains("MASTER") || upperCaseBranch.startsWith("DEVELOP_") || upperCaseBranch.startsWith("TEST"))) {
            return;
        }
        String projectPath = getProjectGitPath(projectCode, branch);
        try {
            GitLabUtil.cloneRepository(projectCode, branch, GIT_USER_NAME, GIT_USER_PWD, projectPath);
            log.info("buildAstInfo clone project: {}", projectCode);
        } catch (GitAPIException | IOException e) {
            log.error("buildAstInfo clone error", e);
        }
        String projectRootPath = getProjectRootPath(projectCode, branch);
        String scriptPath = getScriptPath(projectRootPath, branch);
        int code = processShell(projectRootPath, scriptPath);
        log.info("buildAstInfo processShell scriptPath: {} code: {}", scriptPath, code);
        if (code == 0) {
            Map<String, Object> map = Maps.newHashMap();
            map.put("projectPath", projectRootPath);
            map.put("branch", branch);
            // 通过AST服务构建出语法树并缓存
            String url = appConfig.getPythonBasePath() + "/api/code-tree/ast-refactoring-database";
            String reqStr = toJsonStr(map);
            log.info("buildAstInfo url: {} req: {}", url, reqStr);
            String resp = HttpUtil.post(url, reqStr, 100_000);
            log.info("buildAstInfo end url: {} project: {} resp: {}", url, projectCode, resp);
        }
    }

    /**
     * 获取完整的提示词
     *
     * @param id
     * @param funAstInfo
     * @param codeUtTestCase
     * @param projectPath
     * @return
     */
    private String getAllPrompt(Long id, FunAstInfoVo funAstInfo, CodeUtTestCase codeUtTestCase, String projectPath) {
        String funAstPrompt = getGeneratePrompt(funAstInfo, codeUtTestCase.getFun());
        log.info("genTestCasesFromFun funAstPrompt id: {} type：{} ", id, codeUtTestCase.getType());
        //核心引导AI的提示词
        String guidePrompt = guideTestCasePrompt(codeUtTestCase, projectPath);
        log.info("genTestCasesFromFun guidePrompt id: {} type：{} ", id, codeUtTestCase.getType());
        String promptAll;
        if (codeUtTestCase.getType() == 0) {
            //生成测试用例任务
            promptAll = "JSON格式模板：\n  " + GEN_UT_JSON_TEMP + "\n" + guidePrompt + "\n\n" + funAstPrompt;
        } else {
            //补全测试用例任务
            promptAll = guidePrompt + "\n\n" + funAstPrompt;
        }
        return promptAll;
    }

    /**
     * 异常情况的记录入库
     *
     * @param id
     * @param message
     */
    private void updateStatusToFailed(Long id, String message) {
        CodeUtTestCase updateUtTestCase = new CodeUtTestCase();
        updateUtTestCase.setId(id);
        updateUtTestCase.setStatus(CodeUtTestCaseStatusEnum.FAILED.getCode());
        updateUtTestCase.setMessage(message);
        codeUtTestCaseService.update(updateUtTestCase);
    }

    /**
     * 由大模型重新生成结构化UT
     *
     * @param id
     * @return
     */
    @Override
    public TestCaseObjectVo generateTestCasesFromId(Long id) {
        CodeUtTestCase codeUtTestCase = this.codeUtTestCaseService.get(id);
        if (codeUtTestCase == null) {
            throw new BaseException("对象信息为空, id: " + id);
        }
        //清空数据
        codeUtTestCase.setTestCases("");
        codeUtTestCase.setUserUtStructure("");
        codeUtTestCase.setAiUtStructure("");
        codeUtTestCase.setAstContent("");
        codeUtTestCase.setStatus(CodeUtTestCaseStatusEnum.INIT.getCode());
        codeUtTestCaseService.update(codeUtTestCase);

        //生成结构化的UT单元测试用例
        return genTestCaseObjectVo(codeUtTestCase.getId());
    }

    /**
     * 通过代码覆盖率函数ID获取测试用例
     *
     * @param codeCovFunId
     * @return
     */
    @Override
    public List<String> getTestCaseByCodeCovFunId(Long codeCovFunId) {
        CodeCovFun codeCovFun = codeCovFunService.get(codeCovFunId);
        if (codeCovFun == null) {
            return null;
        }
        CodeCovTask codeCovTask = codeCovTaskService.get(codeCovFun.getCovTaskId());
        String projectCode = codeCovTask.getProjectCode();
        String branch = codeCovTask.getBranch();
        String filePath = codeCovFun.getFilePath();
        String funName = codeCovFun.getFunName();
        List<String> testCases = codeUtTestCaseMapper.selectTestCaseByFunName(projectCode, branch, filePath, funName);
        return toStream(testCases)
                .filter(StringUtils::isNotBlank)
                .flatMap(it -> toStream(JSONUtil.toList(parseArray(it), String.class)))
                .filter(StringUtils::isNotBlank)
                .distinct()
                .collect(toList());
    }

    /**
     * 由大模型补全测试用例
     *
     * @param vo
     * @return
     */
    @Override
    public TestCaseObjectVo completionTestCasesFromFun(CompletionTestCasesFromFunVo vo) {
        CodeCovFun codeCovFun = codeCovFunService.get(vo.getCodeCovFunId());
        String filePath = codeCovFun.getFilePath();
        String fun = codeCovFun.getFun();
        CodeCovTask codeCovTask = codeCovTaskService.get(codeCovFun.getCovTaskId());
        String projectCode = codeCovTask.getProjectCode();
        String branch = codeCovTask.getBranch();

        GenerateTestCasesFromFunVo generateTestCasesFromFunVo = new GenerateTestCasesFromFunVo();
        generateTestCasesFromFunVo.setFun(fun);
        generateTestCasesFromFunVo.setBranch(branch);
        generateTestCasesFromFunVo.setFilePath(filePath);
        generateTestCasesFromFunVo.setProjectCode(projectCode);
        generateTestCasesFromFunVo.setType(1); //AI补全测试用例
        return generateTestCasesFromFun(generateTestCasesFromFunVo);
    }

    /**
     * 通过源码文件路径推算出UT文件路径
     *
     * @param sourcePath
     * @return
     */
    @Override
    public String getTestCasePathFromSourceFile(String sourcePath) {
        String mainName = FileUtil.mainName(sourcePath);
        return "TestCase/UT/src/" + mainName + File.separator + "ut_" + mainName + ".cpp";
    }

    /**
     * 获取工程Git下载路径
     *
     * @param projectCode
     * @param branch
     * @return
     */
    @Override
    public String getProjectGitPath(String projectCode, String branch) {
        String gitCloneDir = appConfig.getGitCloneDir();
        //项目本地目录地址
        return gitCloneDir + File.separator + extractProjectName(projectCode) + File.separator + branch;
    }

    /**
     * 获取代码工程的根路径
     *
     * @param projectCode
     * @param branch
     * @return
     */
    @Override
    public String getProjectRootPath(String projectCode, String branch) {
        String projectGitPath = getProjectGitPath(projectCode, branch);
        //628 演示项目的git仓库
        // https://172.16.0.120/astri/RI-SmartDevelopII/ClusterMiddleware_iFlytek/Project_Doc.git
        if (projectCode.contains("ClusterMiddleware_iFlytek/Project_Doc")) {
            return projectGitPath + "/05_SoftwareUnitVerification/0505_TestProject/A0QNX_SERVICE_T1EJ";
        }
        return projectGitPath;
    }

    /**
     * 获取代码工程build_ut.sh
     *
     * @param projectCode
     * @return
     */
    @Override
    public String getScriptPath(String projectCode, String branch) {
        String projectRootPath = getProjectRootPath(projectCode, branch);
        if (projectCode.contains("ClusterMiddleware_iFlytek/Project_Doc")) {
            return projectRootPath + "/script/build_ut.sh";
        }
        return projectRootPath + File.separator + "build_ut.sh";
    }

    /**
     * @param testCaseInfo 测试用例信息
     * @return 生成的动作子函数字符串
     * @brief 私有函数，用于生成动作子函数的字符串
     */
    private static StringBuilder actionSubFun(TestCaseInfoVo testCaseInfo) {
        StringBuilder sb = new StringBuilder();

        // 判断是否存在被打桩的函数
        if (isNotEmpty(testCaseInfo.getStubbedFunctions())) {
            for (StubbedFunction subFun : testCaseInfo.getStubbedFunctions()) {
                String funName = subFun.getFunName();
                if (funName.contains("->")) {
                    funName = funName.replaceAll("->", "_");
                }
                if (funName.contains("::")) {
                    funName = funName.replaceAll("::", "_");
                }
                if (funName.contains(".")) {
                    funName = funName.replaceAll("\\.", "_");
                }
                sb.append("    Mock(").append(funName.startsWith("Stub_") ? funName : "Stub_" + funName).append(").willActLike(\n");
                sb.append("         [&] (").append(subFun.getParams().stream().map(it -> it.getType() + " param_" + it.getName()).collect(joining(", "))).append(") {\n"); //被打桩的函数入参
                sb.append("         return ").append((subFun.getMockResult().equalsIgnoreCase("NULL")) || (subFun.getMockResult().equalsIgnoreCase("VOID")) ? "" : subFun.getMockResult()).append(";\n");
                sb.append("         }\n");
                sb.append("    );\n");
            }
        }
        return sb;
    }

    /**
     * @param testCaseInfo 参数信息列表
     * @return 拼接后的参数信息字符串
     * @brief 拼接参数信息
     */
    private static StringBuilder actionParams(List<ParamInfo> testCaseInfo) {
        StringBuilder sb = new StringBuilder();
        if (isNotEmpty(testCaseInfo)) {
            for (ParamInfo param : testCaseInfo) {
                String name = param.getName();
                sb.append("    ").append(param.getType()).append(" ").append(name).append(" = ").append(param.getValue()).append(";\n");
            }
        }
        return sb;
    }

    /**
     * @param testCaseInfo 参数信息列表
     * @return 拼接后的参数信息字符串
     * @brief 拼接参数信息
     */
    private StringBuilder actionStaticParams(List<ParamInfo> testCaseInfo) {
        StringBuilder sb = new StringBuilder();
        if (isNotEmpty(testCaseInfo)) {
            for (ParamInfo param : testCaseInfo) {
                sb.append("    ").append(param.getName()).append(" = ").append(param.getValue()).append(";\n");
            }
        }
        return sb;
    }

    /**
     * 提取返回类型的方法
     * 提取函数名的方法
     *
     * @param input
     * @return
     */
    private String[] extractFunction(String input) {
        String[] result = new String[2];
        Pattern pattern = Pattern.compile("FUNC\\((\\w+),\\s*\\w+\\)\\s+([\\w<>:]+)");
        Matcher matcher = pattern.matcher(input);
        if (matcher.find()) {
            String returnType = matcher.group(1);
            String functionName = matcher.group(2);
            result[0] = returnType;
            result[1] = functionName;
            return result;
        }
        pattern = Pattern.compile("([\\w<>:]+)\\s+(\\w+)::(\\w+)\\s*\\(.*\\)");
        matcher = pattern.matcher(input);
        if (matcher.find()) {
            String returnType = matcher.group(1);
            String className = matcher.group(2);
            String functionName = matcher.group(3);
            result[0] = returnType;
            result[1] = className + "::" + functionName;
            return result;
        }
        pattern = Pattern.compile("([\\w<>:]+)\\s+(\\w+)\\s*\\(.*\\)");
        matcher = pattern.matcher(input);
        if (matcher.find()) {
            String returnType = matcher.group(1);
            String functionName = matcher.group(2);
            result[0] = returnType;
            result[1] = functionName;
            return result;
        }
        return result;
    }

    /**
     * 调用ast服务，获取函数相关的信息
     *
     * @param id
     * @param projectPath
     * @param funName
     * @param filePath
     * @return
     */
    private FunAstInfoVo getAstFunInfo(Long id, String projectPath, String branch, String funName, String filePath, boolean reInit) {
        if (filePath.contains("A0QNX_SERVICE_T1EJ")) {
            filePath = filePath.substring(filePath.indexOf("A0QNX_SERVICE_T1EJ/")).replace("A0QNX_SERVICE_T1EJ/", "");
        }
        Map<String, Object> map = Maps.newHashMap();
        map.put("projectPath", projectPath);
        map.put("branch", branch);
        map.put("funName", funName);
        map.put("filePath", filePath);
        map.put("reInit", reInit);
        // 通过AST服务分析函数的相关信息，定义等内容
        String url = appConfig.getPythonBasePath() + "/api/code-tree/ast-fun-info";

        String reqStr = toJsonStr(map);
        log.info("getAstFunInfo start id: {} url: {} req: {}", id, url, reqStr);
        String str = HttpUtil.post(url, reqStr, 60_000);
        log.info("getAstFunInfo end id: {} res: {}", id, str);
        return JSONUtil.isJson(str) ? JSONUtil.toBean(str, FunAstInfoVo.class) : null;
    }

    /**
     * 分析AST语法组装函数上下文相关提示词
     *
     * @param funAstInfo AST信息
     * @param fun        被测函数内容
     * @return 提示信息
     */
    private String getGeneratePrompt(FunAstInfoVo funAstInfo, String fun) {
        //整理函数相关信息
        Map<String, String> varsMap = getVarsMap(funAstInfo);
        Set<String> funsSet = getFuns(funAstInfo);
        //兼容AST无法解析的数据和排除多余的数据
        if (CollUtil.isNotEmpty(appConfig.getVarSupplementMap())) {
            for (Map.Entry<String, String> item : appConfig.getVarSupplementMap().entrySet()) {
                if (fun.contains(item.getKey())) {
                    varsMap.put(item.getKey(), item.getValue());
                }
            }
        }
        if (fun.contains("E_NOT_OK")) {
            varsMap.put("E_OK", " #define E_OK            (Std_ReturnType)(0x00u)");
        }
        if (CollUtil.isNotEmpty(appConfig.getExcludeVarSupplement())) {
            for (String item : appConfig.getExcludeVarSupplement()) {
                if (fun.contains(item)) {
                    varsMap.remove(item);
                    List<ParamInfoVo> classVars = toStream(funAstInfo.getClassVars()).filter(it -> !it.getType().equals(item)).collect(toList());
                    funAstInfo.setClassVars(classVars);
                }
            }
        }

        List<ParamInfoVo> macroVars = funAstInfo.getMacroVars();
        List<ParamInfoVo> enumVars = funAstInfo.getEnumVars();
        List<ParamInfoVo> staticVars = funAstInfo.getStaticVars();
        List<ParamInfoVo> classVars = funAstInfo.getClassVars();
        StringBuilder prompt = new StringBuilder("被测函数：\n```json\n" + fun + "```\n");
        prompt.append("本函数中使用到的类型定义、枚举定义、宏定义如下：\n");
        if (CollUtil.isNotEmpty(varsMap)) {
            toStream(varsMap.values()).filter(StringUtils::isNotBlank).distinct().forEach(value -> prompt.append(value).append("\n"));
        }
        if (CollUtil.isNotEmpty(enumVars)) {
            toStream(enumVars).map(ParamInfoVo::getContent).filter(StringUtils::isNotBlank).distinct().forEach(value -> prompt.append(value).append("\n"));
        }
        if (CollUtil.isNotEmpty(macroVars)) {
            toStream(macroVars).map(ParamInfoVo::getContent).filter(StringUtils::isNotBlank).distinct().forEach(value -> prompt.append(value).append("\n"));
        }
        if (CollUtil.isNotEmpty(classVars)) {
            toStream(classVars).map(ParamInfoVo::getContent).filter(StringUtils::isNotBlank).distinct().forEach(value -> prompt.append(value).append("\n"));
        }
        prompt.append("全局静态变量定义：\n");
        String staticVarsPromptText = toStream(staticVars)
                .map(ParamInfoVo::getContent)
                .filter(StringUtils::isNotBlank)
                .distinct()
                .collect(joining("\n"));
        prompt.append(isEmpty(staticVarsPromptText) ? "无\n" : staticVarsPromptText + "\n");
        prompt.append("被调用函数列表：\n");
        String funsPromptText = toStream(funsSet)
                .filter(StringUtils::isNotBlank)
                .distinct()
                .collect(joining("\n"));
        prompt.append(isEmpty(funsPromptText) ? "无\n" : funsPromptText + "\n");
        prompt.append("\n");
        return prompt.toString();
    }

    /**
     * @param funAstInfo FunAstInfoVo对象
     * @return 返回函数集合
     * @brief 从FunAstInfoVo对象中获取函数集合
     */
    private Set<String> getFuns(FunAstInfoVo funAstInfo) {
        return funAstInfo.getFuns().stream()
                // 对funAstInfo对象的函数集合进行流式处理
                .filter(fun -> !fun.getResultType().equalsIgnoreCase("void"))
                // 过滤掉返回类型不是"void"的函数
                .map(FunAstInfoVo.Function::getFunName)
                // 提取函数的名称
                .collect(Collectors.toSet()); // 将结果收集到一个Set集合中并返回
    }

    /**
     * 获取变量映射表
     *
     * @param funAstInfo 函数AST信息
     * @return 变量映射表
     */
    private Map<String, String> getVarsMap(FunAstInfoVo funAstInfo) {
        Map<String, String> varsMap = new HashMap<>();

        // 将变量、参数和函数合并为一个流
        Stream.concat(Stream.concat(toStream(funAstInfo.getVars()), toStream(funAstInfo.getParams())), toStream(funAstInfo.getFuns()).filter(fun -> !fun.getResultType().equalsIgnoreCase("void")).map(fun -> new ParamInfoVo(fun.getFunName(), fun.getResultType(), fun.getResultTypeContent())))
                // 过滤掉已存在的变量
                .filter(var -> !varsMap.containsKey(var.getType()))
                // 将变量添加到映射表中
                .forEach(var -> varsMap.put(var.getType(), var.getContent()));

        return varsMap;
    }

    /**
     * 组装补充测试用例的提示词
     *
     * @param utTestCase
     * @return
     */
    private String guideTestCasePrompt(CodeUtTestCase utTestCase, String projectPath) {
        StringBuilder prompt = new StringBuilder();
        //先判断是否已经存在测试用例
        String funName = utTestCase.getFunName();
        String filePath = utTestCase.getFilePath();
        //判断已经存在测试用例
        String path = projectPath + File.separator + getTestCasePathFromSourceFile(filePath);
        List<String> existingTestCaseList = getCodeBlackFromSourceFile(
                path,
                appConfig.getNumTestCases(),
                (String line) -> line.contains("TEST_CASE(") && line.contains("[" + funName + "]")
        );
        Long id = utTestCase.getId();
        log.info("guideTestCasePrompt existingTestCase id: {}, path: {}, funName: {}, existingTestCaseList: {} ", id, path, funName, toJsonStr(existingTestCaseList));
        if (CollUtil.isEmpty(existingTestCaseList)) {
            //如果没有测试用例，则先生成json
            prompt.append(appConfig.getGenTestCaseJsonPrompt());
            utTestCase.setType(0);
        } else {
            //如果已有测试用例做参考，则直接生成测试用例代码
            prompt.append(appConfig.getGenTestCodeCasePrompt());
            prompt.append("\n\n下面是人工编写好的测试用例代码，可以作为参考进行生成：\n```json\n").append(toStream(existingTestCaseList).collect(joining("\n"))).append("```");
            utTestCase.setType(1);
        }
        //更新type字段
        CodeUtTestCase updateUtTestCase = new CodeUtTestCase();
        updateUtTestCase.setId(id);
        updateUtTestCase.setType(utTestCase.getType());
        this.codeUtTestCaseService.update(updateUtTestCase);

        //组装 已经做了覆盖率扫描的添加的提示词
        Long codeCovFunId = utTestCase.getCodeCovFunId();
        List<Integer> offLines = null;
        if (greaterThanZero(codeCovFunId)) {
            //传递了CodeCovFunId， 则直接使用 codeCovFunId 查询未覆盖的行
            CodeCovFun codeCovFun = codeCovFunService.get(codeCovFunId);
            log.info("guideTestCasePrompt covFun id: {} codeCovFunId: {}, funName: {}", id, codeCovFun.getId(), codeCovFun.getFunName());
            Integer lineNo = codeCovFun.getLineNo();
            List<CodeCovLine> list = codeCovLineService.getListByFunId(codeCovFunId);
            offLines = toStream(list).filter(it -> it.getCount() == 0).map(it -> it.getLineNumber() - lineNo).collect(toList());
        }
        if (StringUtils.isNotBlank(utTestCase.getFunName())) {
            //传递了CodeCovFunId， 则直接使用 codeCovFunId 查询未覆盖的行
            CodeCovTask lastFinish = codeCovTaskService.getLastFinish(utTestCase.getProjectCode(), utTestCase.getBranch());
            Long covTaskId = ofNullable(lastFinish).map(CodeCovTask::getId).orElse(0L);
            List<CodeCovFun> funList = covTaskId == 0L ? null : codeCovFunService.getListLikeFunName(covTaskId, utTestCase.getFunName());
            log.info("guideTestCasePrompt covFun id: {} covTaskId: {}, covFunList: {} {}, size: {}", id, covTaskId,
                    toJsonStr(toStream(funList).map(CodeCovFun::getId).collect(toList())),
                    toJsonStr(toStream(funList).map(CodeCovFun::getFunName).collect(toList())),
                    toStream(funList).count());
            if (funList != null && funList.size() == 1) {
                codeCovFunId = funList.get(0).getId();
                //查询获取只有一个函数的时候， 则获取其中覆盖的行号供AI进行参考
                Integer lineNo = funList.get(0).getLineNo();
                List<CodeCovLine> list = codeCovLineService.getListByFunId(codeCovFunId);
                offLines = toStream(list).filter(it -> it.getCount() == 0).map(it -> it.getLineNumber() - lineNo).collect(toList());
            }
        }
        if (CollUtil.isNotEmpty(offLines)) {
            prompt.append("\n\n").append(appConfig.getSupplementTestCasePrompt().replace("{unCovLines}", toJsonStr(offLines)));
        }
        return prompt.toString();
    }

    /**
     * 请求AI， 选择LLM
     * todo 后续会统一到AI助手服务中,当前的版本是为了测试这个大模型的能力
     *
     * @param request
     * @return
     */
    private ChatResponse callLLm(ChatRequest request) {
        return chatbotFeign.chatCompletions(request);
    }


}
