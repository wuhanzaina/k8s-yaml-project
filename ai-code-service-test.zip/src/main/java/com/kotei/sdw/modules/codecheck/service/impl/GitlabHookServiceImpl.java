/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:GitlabHookServiceImpl.java
 * 创建日期:2024-03-26
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.service.impl;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.codecheck.entity.GitlabCommit;
import com.kotei.sdw.modules.codecheck.entity.GitlabCommitFile;
import com.kotei.sdw.modules.codecheck.entity.GitlabHook;
import com.kotei.sdw.modules.codecheck.mapper.GitlabCommitFileMapper;
import com.kotei.sdw.modules.codecheck.mapper.GitlabHookMapper;
import com.kotei.sdw.modules.codecheck.service.GitlabCommitService;
import com.kotei.sdw.modules.codecheck.service.GitlabHookService;
import com.kotei.sdw.modules.codecheck.vo.GitlabPushEventVo;
import com.kotei.sdw.modules.codecheck.vo.GitlabPushEventVo.Commit;
import com.kotei.sdw.modules.service.transaction.TransactionalService;
import com.kotei.sdw.modules.ut.service.GenerateTestCaseService;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static cn.hutool.json.JSONUtil.parseArray;
import static com.kotei.sdw.util.StreamUtil.toStream;
import static org.apache.commons.collections4.ListUtils.partition;

/**
 * gitlab hook记录表 ServiceImpl
 *
 * @author tiger
 * @since 2024-03-26
 */
@Service
@Slf4j
public class GitlabHookServiceImpl extends BaseServiceImpl<GitlabHook> implements GitlabHookService {
    @Autowired
    private GitlabHookMapper gitlabHookMapper;
    @Autowired
    private TransactionalService transactionalService;
    @Autowired
    private GitlabCommitService gitlabCommitService;
    @Autowired
    private GitlabCommitFileMapper gitlabCommitFileMapper;

    @Autowired
    private GenerateTestCaseService generateTestCaseService;

    @Override
    protected BaseMapper<GitlabHook> getMapper() {
        return gitlabHookMapper;
    }

    @Override
    public GitlabHook get(Long id) {
        return gitlabHookMapper.selectById(id);
    }

    @Override
    public IPage<GitlabHook> getList(PageVO<GitlabHook> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<GitlabHook> lambdaQueryWrapper = Wrappers.lambdaQuery(GitlabHook.class)
                .eq(params.containsKey("content"), GitlabHook::getContent, params.get("content"))
                .eq(params.containsKey("status"), GitlabHook::getStatus, params.get("status"))
                .eq(params.containsKey("createTime"), GitlabHook::getCreateTime, params.get("createTime"));
        return gitlabHookMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long insert(GitlabHook entity) {
        if (entity.getId() == null || entity.getId() <= 0) {
            entity.setId(KeyGenerate.generateId());
        }
        entity.setCreateTime(new Date());
        gitlabHookMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        gitlabHookMapper.deleteById(id);
    }

    @Override
    public void update(GitlabHook entity) {
        gitlabHookMapper.updateById(entity);
    }

    /**
     * 接收到hook信息之后保存信息并调用jenkins接口执行任务
     *
     * @param pushEvent
     */
    @Override
    public void save(String pushEvent) {
        StopWatch stopWatch = new StopWatch("接收gitlabWebHook信息");
        stopWatch.start("解析gitlab web hook event 数据");
        Long hookId = KeyGenerate.generateId();
        GitlabHook hook = new GitlabHook();
        List<GitlabCommit> commitList = new ArrayList<>();
        List<GitlabCommitFile> commitFileList = new ArrayList<>();

        hook.setId(hookId);
        hook.setStatus(0);
        GitlabPushEventVo gitlabPushEventVo;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(pushEvent);
            // 读取"commits"字段
            JsonNode commitsNode = jsonNode.get("commits");
            // 移除字段
            ((ObjectNode) jsonNode).remove("commits");
            // 转换回json字符串
            String updatedJsonString = objectMapper.writeValueAsString(jsonNode);
            hook.setContent(updatedJsonString);
            stopWatch.stop();

            stopWatch.start("整理数据表对象集合");
            Date today = new Date();
            gitlabPushEventVo = JSONUtil.toBean(updatedJsonString, GitlabPushEventVo.class);
            List<Commit> commits = JSONUtil.toList(parseArray(commitsNode.toString()), Commit.class);
            toStream(commits).forEach(gitCommit -> {
                GitlabCommit commit = getGitlabCommit(gitCommit, hookId, gitlabPushEventVo, today);
                commitList.add(commit);
                //此次commit中新增的文件
                commitFileList.addAll(getCommitFileData(gitCommit.getAdded(), commit, "ADDED", today));
                //此次commit中修改的文件
                commitFileList.addAll(getCommitFileData(gitCommit.getModified(), commit, "MODIFIED", today));
                //此次commit中删除的文件
                commitFileList.addAll(getCommitFileData(gitCommit.getRemoved(), commit, "REMOVED", today));
            });
            stopWatch.stop();
        } catch (JsonProcessingException e) {
            log.error("pushEvent to json error ", e);
            return;
        }

        stopWatch.start("更新DB数据");
        transactionalService.newTransaction(() -> {
            //保存hook数据
            this.insert(hook);
            //保存 git commit
            gitlabCommitService.insertBatch(commitList, 1000);
            //保存 git  commit file
            toStream(partition(commitFileList, 1000)).forEach(it -> gitlabCommitFileMapper.insertOrUpdateBatch(it));
        });
        stopWatch.stop();
        log.info(stopWatch.prettyPrint());

        try {
            String projectCode = gitlabPushEventVo.getProject().getHttpUrl();
            String[] words = gitlabPushEventVo.getRef().split("/");
            generateTestCaseService.buildAstInfo(projectCode, words[words.length - 1]);
        } catch (Exception e) {
            log.error("pushEvent buildAstInfo error ", e);
        }

    }

    private GitlabCommit getGitlabCommit(Commit gitCommit, Long hookId, GitlabPushEventVo gitlabPushEventVo, Date today) {
        GitlabCommit commit = new GitlabCommit();
        commit.setHookId(hookId);
        commit.setCommitId(gitCommit.getId());
        commit.setUrl(gitCommit.getUrl());
        commit.setAuthorName(gitCommit.getAuthor().getName());
        commit.setAuthorEmail(gitCommit.getAuthor().getEmail());
        commit.setProjectCode(gitlabPushEventVo.getProject().getHttpUrl());
        String[] words = gitlabPushEventVo.getRef().split("/");
        commit.setBranch(words[words.length - 1]);
        commit.setStatus(0);
        commit.setCreateTime(today);
        commit.setId(KeyGenerate.generateId());
        return commit;
    }

    private List<GitlabCommitFile> getCommitFileData(List<String> gitCommit, GitlabCommit commit, String type, Date today) {
        return toStream(gitCommit).map(it -> {
            GitlabCommitFile gitlabCommitFile = new GitlabCommitFile();
            gitlabCommitFile.setProjectCode(commit.getProjectCode());
            gitlabCommitFile.setBranch(commit.getBranch());
            gitlabCommitFile.setCommitId(commit.getId());
            gitlabCommitFile.setStatus(0);
            gitlabCommitFile.setType(type);
            gitlabCommitFile.setFilePath(it);
            gitlabCommitFile.setCreateTime(today);
            gitlabCommitFile.setId(KeyGenerate.generateId());
            return gitlabCommitFile;
        }).collect(Collectors.toList());
    }

}
