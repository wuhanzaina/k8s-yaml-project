/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:DictDataService.java
* 创建日期:2024-03-05
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.dict.service;

import com.kotei.sdw.modules.dict.entity.DictData;
import com.kotei.sdw.mvc.service.BaseService;

import java.util.List;

/**
*
* 数据字典 Service
*
*
* @author hk
* @since 2024-03-05
*/
public interface DictDataService extends BaseService<DictData> {
    /**
     * 根据类型和值查询
     * @param type
     * @param value
     * @return
     */
    DictData getByTypeAndValue(String type,String value);

    /**
     * 根据类型查询列表
     * @param type
     * @return
     */
    List<DictData> getListByType(String type);
}
