package com.kotei.sdw.modules.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSort;
import com.kotei.sdw.api.Result;
import com.kotei.sdw.modules.codecheck.service.CodeCheckTaskService;
import com.kotei.sdw.modules.codecheck.service.CodeCovTaskService;
import com.kotei.sdw.modules.codecheck.service.GitlabHookService;
import com.kotei.sdw.modules.codecheck.vo.CoverageDataInfoVo;
import com.kotei.sdw.modules.codecheck.vo.ExecTaskInfoVo;
import com.kotei.sdw.modules.service.CommonService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author tiger
 * @date 2024/3/11 15:11
 */
@RestController
@RequestMapping(value = "/base/common", produces = MediaType.APPLICATION_JSON_VALUE)
@Validated
@Api(tags = "公共接口")
@ApiSort(1)
@Slf4j
public class CommonController {

    @Autowired
    private CommonService commonService;

    @Autowired
    private GitlabHookService gitlabHookService;

    @Autowired
    private CodeCheckTaskService codeCheckTaskService;

    @Autowired
    private CodeCovTaskService codeCovTaskService;


    /**
     * 上传文件
     *
     * @return
     */
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiOperation(value = "上传文件")
    @ApiOperationSupport(order = 7)
    public Result<String> importDefect(@RequestParam(value = "file", required = false) MultipartFile file) {
        String path = commonService.upload(file);
        return Result.success(path);
    }

    /**
     * gitlab web hook
     *
     * @return
     */
    @PostMapping(value = "/gitlab/hook")
    @ApiOperation(value = "gitlab hook回调接口")
    public Result<Void> gitlabPushEvent(@RequestBody String pushEvent) {
        log.info("pushEvent {}", pushEvent);
        if (pushEvent != null) {
            gitlabHookService.save(pushEvent);
        }
        return Result.success();
    }

    /**
     * 手动触发静态代码扫描任务
     *
     * @return
     */
    @PostMapping(value = "/auto/exec-task/{projectId}")
    @ApiOperation(value = "手动触发代码检查任务")
    public Result<Void> autoExecCodeCheckTask(@PathVariable("projectId") Long projectId) {
        log.info("定时任务自动触发【代码检查扫描】 projectId: {}", projectId);
        codeCheckTaskService.triggerCodeStaticScan(projectId);
        return Result.success();
    }

    /**
     * jenkins静态代码扫描任务回调接口
     *
     * @return
     */
    @PostMapping(value = "/exec-task/callback")
    @ApiOperation(value = "jenkins静态代码扫描任务回调接口")
    public Result<String> execTaskCallback(@RequestBody ExecTaskInfoVo execTaskInfo) throws JsonProcessingException {
        log.info("execTaskCallback execTaskInfo taskId:{} piplineTaskId:{} status:{}", execTaskInfo.getTaskId(), execTaskInfo.getPiplineTaskId(), execTaskInfo.getStatus());
        codeCheckTaskService.execTaskForJenkinsCallback(execTaskInfo);
        return Result.success("");
    }



    /**
     *  更新代码注释率接口
     *
     * @return
     */
    @PostMapping(value = "/exec-task/updateComments")
    @ApiOperation(value = "更新代码注释率")
    public Result<String> updateTaskComments(@RequestParam("taskId") Long taskId ) throws JsonProcessingException {
        log.info("execTaskCallback execTaskInfo taskId:{}", taskId);
        codeCheckTaskService.updateTaskComments(taskId);
        return Result.success("");
    }


    /**
     * jenkins代码覆盖率任务回调接口
     *
     * @return
     */
    @PostMapping(value = "/cov-task/callback")
    @ApiOperation(value = "jenkins代码覆盖率任务回调接口")
    public Result<String> covTaskCallback(@RequestBody CoverageDataInfoVo coverageDataInfo) {
        log.info("covTaskCallback coverageDataInfo taskId:{} piplineTaskId:{} status:{}", coverageDataInfo.getTaskId(), coverageDataInfo.getPiplineTaskId(), coverageDataInfo.getStatus());

        codeCovTaskService.covTaskForJenkinsCallback(coverageDataInfo);
        return Result.success("");
    }

}
