/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:AddUserFeedbackVO.java
 * 创建日期:2024-03-11
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 *
 * 用户反馈表
 *
 *
 * @author tiger
 * @since 2024-03-11
 */
@Data
@NoArgsConstructor
@ApiModel(value = "AddUserFeedbackVO", description = "新增用户反馈表")
public class AddUserFeedbackVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 用户ID
     */
    @ApiModelProperty(value = "用户ID", required = true, position = 2)
    private Long userId;
    /**
     * 反馈标题
     */
    @ApiModelProperty(value = "反馈标题", required = true, position = 3)
    private String title;
    /**
     *  反馈类型：[ONE:针对单个会话的反馈；GLOBAL:全局反馈]
     */
    @ApiModelProperty(value = "反馈类型：[ONE:针对单个会话的反馈；GLOBAL:全局反馈]", required = true, position = 9)
    private String feedbackType;
    /**
     * 反馈类型：[BUG:Bug报告、PROPOSAL:优化建议、NEW:新增功能、PERFORMANCE:性能问题、OTHER:其他]
     */
    @ApiModelProperty(value = "反馈类型：[BUG:Bug报告、PROPOSAL:优化建议、NEW:新增功能、PERFORMANCE:性能问题、OTHER:其他]", required = true, position = 10)
    private String feedbackSubType = "";
    /**
     * 反馈内容
     */
    @ApiModelProperty(value = "反馈内容", required = true, position = 11)
    @NotNull(message = "反馈内容不能为空")
    private String feedbackContent;
    /**
     * 反馈文件列表
     */
    @ApiModelProperty(value = "反馈文件列表", required = true, position = 12)
    private List<FeedbackFile> feedbackFiles;
    /**
     * 会话ID
     */
    @ApiModelProperty(value = "会话ID,单次反馈", required = true, position = 13)
    private String acceptId;
    /**
     * 单次反馈类型
     */
    @ApiModelProperty(value = "单次反馈类型. 含义：[1:内容不全；2:格式不对；3:答非所问；4: 没有帮助]", required = true, position = 13)
    private List<String> acceptTypes;
    /**
     * 插件名称
     */
    @ApiModelProperty(value = "插件名称(128)", required = true, position = 14)
    private String name;
    /**
     * 插件版本
     */
    @ApiModelProperty(value = "插件版本(32)", required = true, position = 15)
    private String version;
    /**
     * 操作系统类型
     */
    @ApiModelProperty(value = "操作系统类型(32)", required = true, position = 16)
    private String osType;
    /**
     * 操作系统版本
     */
    @ApiModelProperty(value = "操作系统版本(32)", required = true, position = 17)
    private String osVersion;
    /**
     * 开发工具类型 vscode, idea
     */
    @ApiModelProperty(value = "开发工具类型 [VSCODE, IDEA]", required = true, position = 18)
    private String ideaType;
    /**
     * 开发工具版本
     */
    @ApiModelProperty(value = "开发工具版本(32)", required = true, position = 19)
    private String ideaVersion;

    @Data
    @AllArgsConstructor
    @Builder
    @NoArgsConstructor
    @ApiModel(value = "FeedbackFile", description = "反馈文件")
    public static class FeedbackFile implements Serializable {
        @ApiModelProperty(value = "文件名称")
        private String name;
        @ApiModelProperty(value = "文件地址")
        private String path;
    }
}
