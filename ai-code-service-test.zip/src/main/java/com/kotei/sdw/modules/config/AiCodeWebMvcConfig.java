package com.kotei.sdw.modules.config;

import com.kotei.sdw.modules.interceptor.UserActiveInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author tiger
 * @date 2024/3/13 16:34
 */
@Configuration
public class AiCodeWebMvcConfig implements WebMvcConfigurer {
    @Autowired
    private UserActiveInterceptor userActiveInterceptor;

    /**
     * @param registry The interceptor registry to which the interceptor will be added.
     * @return void
     * @brief This function adds an interceptor to the interceptor registry.
     * The interceptor is used to perform some actions before and after handling a request.
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(userActiveInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns("/statistic/activitys");
    }
}
