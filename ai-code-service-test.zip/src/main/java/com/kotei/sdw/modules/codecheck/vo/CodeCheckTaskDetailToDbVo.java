package com.kotei.sdw.modules.codecheck.vo;

import com.kotei.sdw.modules.codecheck.entity.CodeCheckTaskDetail;
import com.kotei.sdw.modules.codecheck.entity.CodeCheckWarningDetail;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 扫描代码的警告信息保存数据中转使用
 * @author tiger
 * @date 2024/3/28 14:34
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CodeCheckTaskDetailToDbVo {
    private CodeCheckTaskDetail detail;

    private List<CodeCheckWarningDetail> warningDetails;



}
