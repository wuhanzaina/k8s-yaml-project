package com.kotei.sdw.modules.feign;

import com.kotei.sdw.api.Result;
import com.kotei.sdw.modules.feign.vo.ChatBotVo.ChatRequest;
import com.kotei.sdw.modules.feign.vo.ChatBotVo.ChatResponse;
import com.kotei.sdw.modules.feign.vo.ConversationVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.constraints.NotNull;

/**
 * @Author hk
 * @Date 2024/3/5
 * @Description: 请求ai平台
 * @Version 1.0
 */
@FeignClient(value = "ai-code-chatbot", contextId = "AiCodeChatbot")
public interface ChatbotFeign {

    /**
     * 根据UmlId查询
     *
     * @param id
     * @return
     */
    @GetMapping("/conversation/v1/{id}")
    Result<ConversationVO> getConversationById(@NotNull(message = "id不能为空") @PathVariable("id") Long id);

    /**
     * 调用大模型聊天
     * @param req
     * @return
     */
    @PostMapping(path = "/sysai/v1/chat/completions", consumes = MediaType.APPLICATION_JSON_VALUE)
    ChatResponse chatCompletions(@RequestBody @Validated ChatRequest req);
}
