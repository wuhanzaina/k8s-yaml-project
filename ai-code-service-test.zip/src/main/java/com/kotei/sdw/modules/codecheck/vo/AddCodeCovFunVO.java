/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddCodeCovFunVO.java
* 创建日期:2024-04-22
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
*
* 代码覆盖率函数表
*
*
* @author tiger
* @since 2024-04-22
*/
@Data
@NoArgsConstructor
@ApiModel(value = "AddCodeCovFunVO", description = "新增代码覆盖率函数表")
public class AddCodeCovFunVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
    * 任务ID
    */
    @ApiModelProperty(value = "任务ID", required = true, position = 2)
    @NotNull(message="任务ID不能为空")
    private Long covTaskId;
    /**
    * 文件路径
    */
    @ApiModelProperty(value = "文件路径(512)", required = true, position = 3)
    @NotBlank(message = "文件路径不能为空")
    @Length(max = 512, message = "文件路径不能超过512个字符")
    private String filePath;
    /**
    * 函数内容
    */
    @ApiModelProperty(value = "函数内容(32)", required = true, position = 4)
    @NotBlank(message = "函数内容不能为空")
    @Length(max = 32, message = "函数内容不能超过32个字符")
    private String funName;
    /**
    * 函数内容
    */
    @ApiModelProperty(value = "函数内容(8900)", required = true, position = 5)
    @NotBlank(message = "函数内容不能为空")
    @Length(max = 8900, message = "函数内容不能超过8900个字符")
    private String fun;
    /**
    * 代码覆盖率
    */
    @ApiModelProperty(value = "代码覆盖率(3,2)", required = true, position = 6)
    @Digits(integer = 3, fraction = 2, message = "代码覆盖率只能包含5位整数,2位小数")
    @DecimalMin(value = "0.01", message = "代码覆盖率不能小于等于0")
    private BigDecimal blocksPercent;
    /**
    * 执行次数
    */
    @ApiModelProperty(value = "执行次数", required = true, position = 7)
    @NotNull(message = "执行次数不能为空")
    @Min(value = 0, message = "执行次数不能小于0")
    private Integer executionCount;
    /**
    * 函数起始行号
    */
    @ApiModelProperty(value = "函数起始行号", required = true, position = 8)
    @NotNull(message = "函数起始行号不能为空")
    @Min(value = 0, message = "函数起始行号不能小于0")
    private Integer lineNo;
    /**
    * 函数占用行数
    */
    @ApiModelProperty(value = "函数占用行数", required = true, position = 9)
    @NotNull(message = "函数占用行数不能为空")
    @Min(value = 0, message = "函数占用行数不能小于0")
    private Integer lineNum;
    /**
    * 返回执行次数
    */
    @ApiModelProperty(value = "返回执行次数", required = true, position = 10)
    @NotNull(message = "返回执行次数不能为空")
    @Min(value = 0, message = "返回执行次数不能小于0")
    private Integer returnedCount;

}
