/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:AddUserActivityVO.java
 * 创建日期:2024-03-04
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.statistic.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 *
 * 部门使用插件情况统计
 *
 *
 * @author tiger
 * @since 2024-03-04
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiModel(value = "DepartmentUsedStatisticVo", description = "部门使用插件情况统计")
public class DepartmentUsedStatisticVo implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 一级部门ID
     */
    @ApiModelProperty(value = "一级部门ID", required = true, position = 1)
    private Long departmentId;
    /**
     * 部门
     */
    @ApiModelProperty(value = "一级部门", required = true, position = 2)
    private String departmentName;
    /**
     * 活跃用户数
     */
    @ApiModelProperty(value = "活跃用户数", required = true, position = 2)
    private Integer userActivityCount = 0;
    /**
     * 员工数量
     */
    @ApiModelProperty(value = "员工数量", position = 5)
    private Integer staffCount = 0;
    /**
     * 人员使用率
     */
    @ApiModelProperty(value = "人员使用率", required = true, position = 2)
    private Integer usageRate;
    /**
     * 使用次数
     */
    @ApiModelProperty(value = "使用次数", required = true, position = 2)
    private Integer usageTotalCount = 0;
    /**
     * 使用次数最多的功能
     */
    @ApiModelProperty(value = "使用次数最多的功能", required = true, position = 2)
    private String usageMostFeature;
    /**
     * token数量
     */
    @ApiModelProperty(value = "token数量", required = true, position = 2)
    private Integer tokenCount = 0;
    /**
     * 使用大模型费用
     */
    @ApiModelProperty(value = "使用大模型费用", required = true, position = 2)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "0.00")
    private Double modelsCost = 0.0;

}
