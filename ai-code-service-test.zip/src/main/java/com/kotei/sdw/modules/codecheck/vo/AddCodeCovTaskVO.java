/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddCodeCovTaskVO.java
* 创建日期:2024-04-22
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
*
* 代码覆盖率任务表
*
*
* @author tiger
* @since 2024-04-22
*/
@Data
@NoArgsConstructor
@ApiModel(value = "AddCodeCovTaskVO", description = "新增代码覆盖率任务表")
public class AddCodeCovTaskVO implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 项目标识
     */
    @ApiModelProperty(value = "项目标识(512)", required = true, position = 11)
    @NotNull(message = "项目标识不能为空")
    private String projectCode;
    /**
     * 分支
     */
    @ApiModelProperty(value = "分支(128)", required = true, position = 12)
    @NotNull(message = "分支不能为空")
    private String branch;

}
