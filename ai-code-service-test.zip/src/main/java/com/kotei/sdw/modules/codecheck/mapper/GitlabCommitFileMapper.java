/**
 * All rights Reserved, Designed By www.kote.net
 * 项目名称:ai-code-service
 * 文件名称:GitlabCommitMapper.java
 * 创建日期:2024-04-09
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.mapper;

import com.kotei.sdw.modules.codecheck.entity.GitlabCommitFile;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * commit记录表 Mapper
 *
 * @author tiger
 * @since 2024-04-09
 */
@Mapper
public interface GitlabCommitFileMapper extends BaseMapper<GitlabCommitFile> {

    /**
     * 使用了INSERT INTO ... VALUES语句来进行批量插入操作。
     * 当遇到唯一索引冲突时，使用ON DUPLICATE KEY UPDATE语句来更新其他字段为传入的字段。通过VALUES()函数可以获取到插入时的值，从而实现更新操作。
     * @param entitys
     * @return
     */
    int insertOrUpdateBatch(List<GitlabCommitFile> entitys);
}
