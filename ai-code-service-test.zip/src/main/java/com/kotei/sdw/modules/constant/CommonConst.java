package com.kotei.sdw.modules.constant;

import com.kotei.sdw.modules.feign.vo.DeptRes;

import java.util.List;

/**
 * @author tiger
 * @date 2024/3/5 17:36
 */
public class CommonConst {

    /**
     * 部门缓存的时间
     */
    public static Long cacheDepartmentTime;
    public static final int NUM_10_000 = 10000;
    public static final String GIT_USER_NAME = "dcs.codechecker";
    public static final String GIT_USER_PWD = "ocsa@2024!";

    /**
     * 缓存的部门数据
     */
    public static List<DeptRes.DeptVo> allDepartmentList;

    /**
     * 使用AI生成UT用例的json提示词
     */
    public static final String GEN_UT_JSON_TEMP = "[{\"description\":\"场景说明，包括参数值、打桩函数Mock值等\",\"functionParameters\":[{\"type\":\"被测函数的入参类型\",\"name\":\"被测函数的入参名称\",\"value\":\"被测函数的入参取值\"}],\"expectedResult\":\"被测函数的期望结果值\",\"publicMemberVariables\":[\"public修饰的成员变量的赋值代码\"],\"staticVariables\":[{\"type\":\"静态变量参数类型\",\"name\":\"静态变量的参数名称\",\"value\":\"静态变量的参数取值\"}],\"stubbedFunctions\":[{\"funName\":\"打桩函数名称\",\"mockResult\":\"打桩函数Mock返回值\",\"params\":[{\"type\":\"打桩函数的参数类型\",\"name\":\"打桩函数的参数名称\",\"value\":\"打桩函数的参数取值\"}]}]}]\n";
}
