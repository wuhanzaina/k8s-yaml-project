/**
 * All rights Reserved, Designed By  www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:AdoptionLineVO
 * 创建日期:2024/3/6
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 **/
package com.kotei.sdw.modules.statistic.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 采纳
 * @author fox
 * @date 2024/3/6
 **/
@Data
@NoArgsConstructor
@ApiModel(value = "AdoptionLineVO", description = "开发人员提交代码周趋势分析")
public class LineVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 周开始时间
     */
    @ApiModelProperty(value = "周开始时间", position = 2)
    private String beginOfWeek;
    /**
     * 周结束时间
     */
    @ApiModelProperty(value = "周结束时间", position = 2)
    private String endOfWeek;
    /**
     * 代码行数
     */
    @ApiModelProperty(value = "代码行数", position = 7)
    private Integer lineTotal;
}
