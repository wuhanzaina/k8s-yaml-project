package com.kotei.sdw.modules.codecheck.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;

import com.kotei.sdw.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 
 * @TableName project_check
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("project_check")
@ApiModel(value = "ProjectCheck", description = "无法检查项目配置")
public class ProjectCheck extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 项目花名
     */
    @TableField(value = "project_name")
    @ApiModelProperty(value = "项目花名", position = 2)
    private String projectName;

    /**
     * 状态
     */
    @TableField(value = "status")
    @ApiModelProperty(value = "项目状态", position = 3)
    private String status;

    /**
     * 备注
     */
    @TableField(value = "notes")
    @ApiModelProperty(value = "项目说明", position = 4)
    private String notes;

}