package com.kotei.sdw.modules.feign.vo;

import com.baomidou.mybatisplus.annotation.TableName;
import com.kotei.sdw.entity.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 人机对话
 *
 * @author mahuang
 * @since 2023-05-22
 */
@Data
@NoArgsConstructor
@TableName("t_conversations")
public class ConversationVO extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * ID
     */
    @ApiModelProperty(value = "ID", position = 3)
    private Long id;
    /**
     * 用户ID
     */
    @ApiModelProperty(value = "用户ID", position = 3)
    private String userId;
    /**
     * 用户名称
     */
    @ApiModelProperty(value = "用户名称", position = 3)
    private String username;
    /**
     * 问题
     */
    @ApiModelProperty(value = "问题", position = 3)
    private String input;
    /**
     * 回答
     */
    @ApiModelProperty(value = "回答", position = 3)
    private String output;

    private Integer inputToken;

    private Integer outputToken;

    private Integer codeLine;

    private Integer totalToken;

    /**
     * 费用
     */
    private Double cost;


}
