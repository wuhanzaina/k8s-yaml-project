/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:CodeUtTestCaseServiceImpl.java
 * 创建日期:2024-04-03
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.ut.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.statistic.constant.enums.CodeUtTestCaseStatusEnum;
import com.kotei.sdw.modules.ut.entity.CodeUtTestCase;
import com.kotei.sdw.modules.ut.mapper.CodeUtTestCaseMapper;
import com.kotei.sdw.modules.ut.service.CodeUtTestCaseService;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 *
 * 代码生成UT测试用例 ServiceImpl
 *
 *
 * @author tiger
 * @since 2024-04-03
 */
@Service
public class CodeUtTestCaseServiceImpl extends BaseServiceImpl<CodeUtTestCase> implements CodeUtTestCaseService {
    @Autowired
    private CodeUtTestCaseMapper codeUtTestCaseMapper;

    @Override
    protected BaseMapper<CodeUtTestCase> getMapper() {
        return codeUtTestCaseMapper;
    }

    @Override
    public CodeUtTestCase get(Long id) {
        return codeUtTestCaseMapper.selectById(id);
    }

    @Override
    public IPage<CodeUtTestCase> getList(PageVO<CodeUtTestCase> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<CodeUtTestCase> lambdaQueryWrapper = Wrappers.lambdaQuery(CodeUtTestCase.class)
                .eq(params.containsKey("userId"), CodeUtTestCase::getUserId, params.get("userId"))
                .eq(params.containsKey("userName"), CodeUtTestCase::getUserName, params.get("userName"))
                .eq(params.containsKey("userNo"), CodeUtTestCase::getUserNo, params.get("userNo"))
                .eq(params.containsKey("batchId"), CodeUtTestCase::getBatchId, params.get("batchId"))
                .eq(params.containsKey("departmentId"), CodeUtTestCase::getDepartmentId, params.get("departmentId"))
                .eq(params.containsKey("departmentName"), CodeUtTestCase::getDepartmentName, params.get("departmentName"))
                .eq(params.containsKey("rootDepartmentId"), CodeUtTestCase::getRootDepartmentId, params.get("rootDepartmentId"))
                .eq(params.containsKey("rootDepartmentName"), CodeUtTestCase::getRootDepartmentName, params.get("rootDepartmentName"))
                .eq(params.containsKey("projectCode"), CodeUtTestCase::getProjectCode, params.get("projectCode"))
                .eq(params.containsKey("branch"), CodeUtTestCase::getBranch, params.get("branch"))
                .like(params.containsKey("filePath") && params.get("filePath") != null, CodeUtTestCase::getFilePath, params.get("filePath"))
                .eq(params.containsKey("funName") && params.get("funName") != null, CodeUtTestCase::getFilePath, params.get("funName"))
                .eq(params.containsKey("status"), CodeUtTestCase::getStatus, params.get("status"))
                .eq(params.containsKey("createTime"), CodeUtTestCase::getCreateTime, params.get("createTime"))
                .eq(params.containsKey("finishTime"), CodeUtTestCase::getFinishTime, params.get("finishTime"))
                .between(params.containsKey("startCreateTime") && params.containsKey("endCreateTime"), CodeUtTestCase::getCreateTime, params.get("startCreateTime"), params.get("endCreateTime"));
        ;
        //1，执行中；2：成功；3：失败
        if (params.get("queryStatus") != null) {
            Integer queryStatus = Integer.valueOf((String) params.get("queryStatus"));
            switch (queryStatus) {
                case 1:
                    lambdaQueryWrapper.le(CodeUtTestCase::getStatus, CodeUtTestCaseStatusEnum.SUCCESS.getCode());
                    break;
                case 2:
                    lambdaQueryWrapper.eq(CodeUtTestCase::getStatus, CodeUtTestCaseStatusEnum.SUCCESS.getCode());
                    break;
                case 3:
                    lambdaQueryWrapper.eq(CodeUtTestCase::getStatus, CodeUtTestCaseStatusEnum.FAILED.getCode());
                    break;
            }
        }
        lambdaQueryWrapper.orderByDesc(CodeUtTestCase::getId);
        return codeUtTestCaseMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long insert(CodeUtTestCase entity) {
        entity.setId(KeyGenerate.generateId());
        if (entity.getCreateTime() == null) {
            entity.setCreateTime(new Date());
        }
        codeUtTestCaseMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        codeUtTestCaseMapper.deleteById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(CodeUtTestCase entity) {
        codeUtTestCaseMapper.updateById(entity);
    }

    @Override
    public List<CodeUtTestCase> getListByBatchId(Long id) {
        LambdaQueryWrapper<CodeUtTestCase> lambdaQueryWrapper = Wrappers.lambdaQuery(CodeUtTestCase.class);
        lambdaQueryWrapper.eq(CodeUtTestCase::getBatchId, id);
        return codeUtTestCaseMapper.selectList(lambdaQueryWrapper);
    }

}
