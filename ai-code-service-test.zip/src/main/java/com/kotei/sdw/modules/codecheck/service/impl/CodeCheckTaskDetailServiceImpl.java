/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:CodeCheckTaskDetailServiceImpl.java
 * 创建日期:2024-03-26
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.codecheck.entity.CodeCheckTaskDetail;
import com.kotei.sdw.modules.codecheck.mapper.CodeCheckTaskDetailMapper;
import com.kotei.sdw.modules.codecheck.service.CodeCheckTaskDetailService;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 *
 * 代码检查明细表 ServiceImpl
 *
 *
 * @author tiger
 * @since 2024-03-26
 */
@Service
public class CodeCheckTaskDetailServiceImpl extends BaseServiceImpl<CodeCheckTaskDetail> implements CodeCheckTaskDetailService {
    @Autowired
    private CodeCheckTaskDetailMapper codeCheckTaskDetailMapper;

    @Override
    protected BaseMapper<CodeCheckTaskDetail> getMapper() {
        return codeCheckTaskDetailMapper;
    }

    @Override
    public CodeCheckTaskDetail get(Long id) {
        return codeCheckTaskDetailMapper.selectById(id);
    }

    /**
     * 获取CodeCheckTaskDetail列表
     * @param page 分页对象
     * @return CodeCheckTaskDetail分页列表
     */
    @Override
    public IPage<CodeCheckTaskDetail> getList(PageVO<CodeCheckTaskDetail> page) {
        Map<String, Object> params = page.getParams();
        String filePath = "filePath", offGrade = "offGrade";
        LambdaQueryWrapper<CodeCheckTaskDetail> lambdaQueryWrapper = Wrappers.lambdaQuery(CodeCheckTaskDetail.class)
                .eq(params.containsKey("taskId"), CodeCheckTaskDetail::getTaskId, params.get("taskId"))
                .eq(params.containsKey("type") && params.get("type") != null, CodeCheckTaskDetail::getType, params.get("type"))
                .like(params.containsKey(filePath) && params.get(filePath) != null, CodeCheckTaskDetail::getFilePath, "%" + params.get(filePath) + "%")
                .eq(params.containsKey("funName"), CodeCheckTaskDetail::getFunName, params.get("funName"))
                .eq(params.containsKey(offGrade) && params.get(offGrade) != null, CodeCheckTaskDetail::getOffGrade, params.get(offGrade))
                .eq(params.containsKey("circleComplexity"), CodeCheckTaskDetail::getCircleComplexity, params.get("circleComplexity"))
                .eq(params.containsKey("codes"), CodeCheckTaskDetail::getCodes, params.get("codes"))
                .eq(params.containsKey("blanks"), CodeCheckTaskDetail::getBlanks, params.get("blanks"))
                .eq(params.containsKey("comments"), CodeCheckTaskDetail::getComments, params.get("comments"))
                .eq(params.containsKey("status"), CodeCheckTaskDetail::getStatus, params.get("status"))
                .eq(params.containsKey("createTime"), CodeCheckTaskDetail::getCreateTime, params.get("createTime"));
        return codeCheckTaskDetailMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    /**
     * @brief 插入CodeCheckTaskDetail实体
     *
     * @param entity 待插入的CodeCheckTaskDetail实体
     * @return 插入操作影响的行数
     */
    @Override
    public Long insert(CodeCheckTaskDetail entity) {
        entity.setId(KeyGenerate.generateId());
        codeCheckTaskDetailMapper.insert(entity);
        return entity.getId();
    }

    /**
     * @brief Deletes the item with the specified ID.
     *
     * @param id The ID of the item to delete.
     */
    @Override
    public void delete(Long id) {
        codeCheckTaskDetailMapper.deleteById(id);
    }

    /**
     * @brief Update the CodeCheckTaskDetail entity.
     *
     * This function is used to update the CodeCheckTaskDetail entity.
     *
     * @param entity The CodeCheckTaskDetail entity to update.
     */

    @Override
    public void update(CodeCheckTaskDetail entity) {
        codeCheckTaskDetailMapper.updateById(entity);
    }
}
