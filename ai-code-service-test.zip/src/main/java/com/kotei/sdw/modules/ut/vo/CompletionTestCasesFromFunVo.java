package com.kotei.sdw.modules.ut.vo;

/**
 * @author tiger
 * @date 2024/3/27 13:47
 */

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiModel(value = "CompletionTestCasesFromFunVo", description = "由大模型补全测试用例")
public class CompletionTestCasesFromFunVo implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 代码覆盖率函数记录Id
     */
    @ApiModelProperty(value = "代码覆盖率函数记录Id", required = true, position = 1)
    @NotNull(message = "代码覆盖率函数记录Id不能为空")
    private Long codeCovFunId;

}


