/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:ProjectServiceImpl.java
* 创建日期:2024-04-02
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.modules.codecheck.entity.Project;
import com.kotei.sdw.modules.codecheck.mapper.ProjectMapper;
import com.kotei.sdw.modules.codecheck.service.ProjectService;

/**
*
* 项目列表 ServiceImpl
*
*
* @author tiger
* @since 2024-04-02
*/
@Service
public class ProjectServiceImpl extends BaseServiceImpl<Project> implements ProjectService {
    @Autowired
    private ProjectMapper projectMapper;
    @Override
    protected BaseMapper<Project> getMapper() {
    return projectMapper;
    }

    @Override
    public Project get(Long id) {
    return projectMapper.selectById(id);
    }

    @Override
    public IPage<Project> getList(PageVO<Project> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<Project> lambdaQueryWrapper =Wrappers.lambdaQuery(Project.class)
        .eq(params.containsKey("type"), Project::getType, params.get("type"))
        .eq(params.containsKey("projectParent"), Project::getProjectParent, params.get("projectParent"))
        .eq(params.containsKey("projectName"), Project::getProjectName, params.get("projectName"))
        .eq(params.containsKey("projectCode"), Project::getProjectCode, params.get("projectCode"))
        .eq(params.containsKey("branch"), Project::getBranch, params.get("branch"))
        .eq(params.containsKey("gitUserName"), Project::getGitUserName, params.get("gitUserName"))
        .eq(params.containsKey("userId"), Project::getUserId, params.get("userId"))
        .eq(params.containsKey("userName"), Project::getUserName, params.get("userName"))
        .eq(params.containsKey("gitUserPwd"), Project::getGitUserPwd, params.get("gitUserPwd"))
        .eq(params.containsKey("taskGitToken"), Project::getTaskGitToken, params.get("taskGitToken"))
        .eq(params.containsKey("userNo"), Project::getUserNo, params.get("userNo"))
        .eq(params.containsKey("pmUserId"), Project::getPmUserId, params.get("pmUserId"))
        .eq(params.containsKey("pmUserName"), Project::getPmUserName, params.get("pmUserName"))
        .eq(params.containsKey("pmUserNo"), Project::getPmUserNo, params.get("pmUserNo"))
        .eq(params.containsKey("scheduleStatus"), Project::getScheduleStatus, params.get("scheduleStatus"))
        .eq(params.containsKey("status"), Project::getStatus, params.get("status"))
        .eq(params.containsKey("createTime"), Project::getCreateTime, params.get("createTime"));
        return projectMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    public Long insert(Project entity) {
        entity.setId(KeyGenerate.generateId());
        projectMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        projectMapper.deleteById(id);
    }

    @Override
    public void update(Project entity) {
        projectMapper.updateById(entity);
    }

    /**
     * 通过projectCode获取项目对象
     * @param code
     * @return
     */
    @Override
    public Project getByCode(String code, String branch) {
        LambdaQueryWrapper<Project> lambdaQueryWrapper =Wrappers.lambdaQuery(Project.class)
                .eq(Project::getProjectCode, code)
                .eq(Project::getBranch, branch)
                .last(" limit 1 ");
        return projectMapper.selectOne(lambdaQueryWrapper);
    }
}
