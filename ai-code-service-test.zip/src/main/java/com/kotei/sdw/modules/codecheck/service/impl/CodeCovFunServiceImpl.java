/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:CodeCovFunServiceImpl.java
 * 创建日期:2024-04-22
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.codecheck.entity.CodeCovFun;
import com.kotei.sdw.modules.codecheck.entity.CodeCovLine;
import com.kotei.sdw.modules.codecheck.mapper.CodeCovFunMapper;
import com.kotei.sdw.modules.codecheck.service.CodeCovFunService;
import com.kotei.sdw.modules.codecheck.service.CodeCovLineService;
import com.kotei.sdw.modules.codecheck.vo.CodeCovFunQueryVO;
import com.kotei.sdw.modules.codecheck.vo.CovLineBranchVO;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.util.StreamUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * 代码覆盖率函数表 ServiceImpl
 *
 *
 * @author tiger
 * @since 2024-04-22
 */
@Service
public class CodeCovFunServiceImpl extends BaseServiceImpl<CodeCovFun> implements CodeCovFunService {
    @Autowired
    private CodeCovFunMapper codeCovFunMapper;
    @Autowired
    private CodeCovLineService codeCovLineService;

    @Override
    protected BaseMapper<CodeCovFun> getMapper() {
        return codeCovFunMapper;
    }

    @Override
    public CodeCovFun get(Long id) {
        return codeCovFunMapper.selectById(id);
    }

    @Override
    public IPage<CodeCovFun> getList(PageVO<CodeCovFun> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<CodeCovFun> lambdaQueryWrapper = Wrappers.lambdaQuery(CodeCovFun.class)
                .eq(params.containsKey("covTaskId"), CodeCovFun::getCovTaskId, params.get("covTaskId"))
                .eq(params.containsKey("filePath"), CodeCovFun::getFilePath, params.get("filePath"))
                .like(params.containsKey("funName") && StringUtils.isNotBlank((String) params.get("funName")), CodeCovFun::getFunName, params.get("funName") + "%")
                .eq(params.containsKey("fun"), CodeCovFun::getFun, params.get("fun"))
                .eq(params.containsKey("blocksPercent"), CodeCovFun::getBlocksPercent, params.get("blocksPercent"))
                .eq(params.containsKey("executionCount"), CodeCovFun::getExecutionCount, params.get("executionCount"))
                .eq(params.containsKey("lineNo"), CodeCovFun::getLineNo, params.get("lineNo"))
                .eq(params.containsKey("lineNum"), CodeCovFun::getLineNum, params.get("lineNum"))
                .eq(params.containsKey("returnedCount"), CodeCovFun::getReturnedCount, params.get("returnedCount"));
        return codeCovFunMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    public Long insert(CodeCovFun entity) {
        entity.setId(KeyGenerate.generateId());
        codeCovFunMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        codeCovFunMapper.deleteById(id);
    }

    @Override
    public void update(CodeCovFun entity) {
        codeCovFunMapper.updateById(entity);
    }

    @Override
    public CodeCovFunQueryVO getDetail(Long id) {
        CodeCovFun codeCovFun = this.get(id);
        CodeCovFunQueryVO vo = new CodeCovFunQueryVO();
        BeanUtil.copyProperties(codeCovFun, vo);
        List<CodeCovLine> list = codeCovLineService.getListByFunId(id);
        vo.setOffLines(StreamUtil.toStream(list).filter(it -> it.getCount() == 0).map(CodeCovLine::getLineNumber).collect(Collectors.toList()));
        List<CovLineBranchVO> branchVOS = new ArrayList<>();
        if (list != null && !list.isEmpty()) {
            for (CodeCovLine codeCovLine : list) {
                if (StringUtils.isNotBlank(codeCovLine.getBranches())) {
                    CovLineBranchVO branchVO = new CovLineBranchVO();
                    branchVO.setLineNumber(codeCovLine.getLineNumber());
                    branchVO.setBranches(
                            JSONUtil.toList(JSONUtil.parseArray(codeCovLine.getBranches()), CovLineBranchVO.BranchInfo.class)
                    );
                    branchVOS.add(branchVO);
                }
            }
        }
        vo.setBranches(branchVOS);
        return vo;
    }

    @Override
    public List<CodeCovFun> getListLikeFunName(Long covTaskId, String funName) {
        return this.codeCovFunMapper.getListLikeFunName(covTaskId, funName);
    }
}
