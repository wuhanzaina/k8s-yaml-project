/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:AddUserActivityVO.java
 * 创建日期:2024-03-04
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.statistic.vo;

import com.alibaba.excel.annotation.ExcelIgnoreUnannotated;
import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 用户活跃度统计表
 * 日期	一级部门	当前部门	用户工号	用户名称	"创建日期
 *
 * @author tiger
 * @since 2024-03-04
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ExcelIgnoreUnannotated
@ApiModel(value = "UserActivityStatisticVo", description = "新增用户活跃度统计表")
public class UserActivityExportVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 日期
     */
    @ExcelProperty(value = "日期", index = 0)
    private String activityDate;

    /**
     * 一级部门
     */
    @ExcelProperty(value = "一级部门", index = 1)
    private String rootDepartmentName;

    /**
     * 当前部门
     */
    @ExcelProperty(value = "当前部门", index = 2)
    private String departmentName;

    @ExcelProperty(value = "用户工号", index = 3)
    private String userNo;

    @ExcelProperty(value = "用户名称", index = 4)
    private String userName;

    @ExcelProperty(value = "代码生成", index = 5)
    private String genCode;

    @ExcelProperty(value = "代码解释", index = 6)
    private String explainCode;

    @ExcelProperty(value = "添加注释-函数", index = 7)
    private String noteCodeFun;

    @ExcelProperty(value = "添加注释-逐行", index = 8)
    private String noteCodeLine;

    @ExcelProperty(value = "智能代码问答", index = 9)
    private String qa;

    @ExcelProperty(value = "使用总数", index = 10)
    private String count;

}
