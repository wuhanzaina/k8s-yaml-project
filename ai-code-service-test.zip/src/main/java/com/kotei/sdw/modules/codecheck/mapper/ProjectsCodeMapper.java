package com.kotei.sdw.modules.codecheck.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kotei.sdw.modules.codecheck.entity.ProjectsCode;
import org.apache.ibatis.annotations.Mapper;


/**
* @author zhengyaow
* @description 针对表【projects_code】的数据库操作Mapper
* @createDate 2024-11-25 15:54:19
* @Entity com.entity.ProjectsCode
*/
@Mapper
public interface ProjectsCodeMapper extends BaseMapper<ProjectsCode> {

}




