/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:CodeCovTaskServiceImpl.java
 * 创建日期:2024-04-22
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.codecheck.constant.enums.ExecTaskStatusEnum;
import com.kotei.sdw.modules.codecheck.entity.CodeCovFun;
import com.kotei.sdw.modules.codecheck.entity.CodeCovLine;
import com.kotei.sdw.modules.codecheck.entity.CodeCovTask;
import com.kotei.sdw.modules.codecheck.entity.Project;
import com.kotei.sdw.modules.codecheck.mapper.CodeCovTaskMapper;
import com.kotei.sdw.modules.codecheck.service.CodeCovFunService;
import com.kotei.sdw.modules.codecheck.service.CodeCovLineService;
import com.kotei.sdw.modules.codecheck.service.CodeCovTaskService;
import com.kotei.sdw.modules.codecheck.service.ProjectService;
import com.kotei.sdw.modules.codecheck.vo.AddCodeCovTaskVO;
import com.kotei.sdw.modules.codecheck.vo.CodeCovFunDetailToDbVo;
import com.kotei.sdw.modules.codecheck.vo.CoverageDataInfoVo;
import com.kotei.sdw.modules.config.AppConfig;
import com.kotei.sdw.modules.feign.vo.DeptRes;
import com.kotei.sdw.modules.service.CommonService;
import com.kotei.sdw.modules.service.transaction.TransactionalService;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.security.utils.SecurityUtils;
import com.kotei.sdw.system.api.model.LoginUser;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static cn.hutool.json.JSONUtil.parseArray;
import static com.google.common.collect.ImmutableMap.of;
import static com.kotei.sdw.modules.codecheck.constant.Consts.ADMIN;
import static com.kotei.sdw.modules.utils.GitLabUtil.GIT_POSTFIX;
import static com.kotei.sdw.util.StreamUtil.toStream;
import static java.util.Optional.ofNullable;
import static java.util.concurrent.CompletableFuture.runAsync;

/**
 * 代码覆盖率任务表 ServiceImpl
 *
 * @author tiger
 * @since 2024-04-22
 */
@Service
@Slf4j
public class CodeCovTaskServiceImpl extends BaseServiceImpl<CodeCovTask> implements CodeCovTaskService {
    @Autowired
    private CodeCovTaskMapper codeCovTaskMapper;
    @Autowired
    private CommonService commonService;
    @Autowired
    private AppConfig appConfig;
    @Autowired
    private TransactionalService transactionalService;
    @Autowired
    private ProjectService projectService;

    @Autowired
    private CodeCovFunService codeCovFunService;

    @Autowired
    private CodeCovLineService codeCovLineService;

    @Override
    protected BaseMapper<CodeCovTask> getMapper() {
        return codeCovTaskMapper;
    }

    @Override
    public CodeCovTask get(Long id) {
        return codeCovTaskMapper.selectById(id);
    }

    @Override
    public IPage<CodeCovTask> getList(PageVO<CodeCovTask> page) {
        Map<String, Object> params = page.getParams();
        String userId = "userId", projectCode = "projectCode", startCreateDate = "startCreateDate", endCreateDate = "endCreateDate", branch = "branch", status = "status";
        LambdaQueryWrapper<CodeCovTask> lambdaQueryWrapper = Wrappers.lambdaQuery(CodeCovTask.class)
                .eq(params.containsKey("execTaskId"), CodeCovTask::getExecTaskId, params.get("execTaskId"))
                .eq(params.containsKey("userId"), CodeCovTask::getUserId, params.get("userId"))
                .eq(params.containsKey("userName"), CodeCovTask::getUserName, params.get("userName"))
                .eq(params.containsKey("userNo"), CodeCovTask::getUserNo, params.get("userNo"))
                .eq(params.containsKey("departmentId"), CodeCovTask::getDepartmentId, params.get("departmentId"))
                .eq(params.containsKey("departmentName"), CodeCovTask::getDepartmentName, params.get("departmentName"))
                .eq(params.containsKey("rootDepartmentId"), CodeCovTask::getRootDepartmentId, params.get("rootDepartmentId"))
                .eq(params.containsKey("rootDepartmentName"), CodeCovTask::getRootDepartmentName, params.get("rootDepartmentName"))
                .eq(params.containsKey("branchCovered"), CodeCovTask::getBranchCovered, params.get("branchCovered"))
                .eq(params.containsKey("branchTotal"), CodeCovTask::getBranchTotal, params.get("branchTotal"))
                .eq(params.containsKey("branchPercent"), CodeCovTask::getBranchPercent, params.get("branchPercent"))
                .eq(params.containsKey("functionCovered"), CodeCovTask::getFunctionCovered, params.get("functionCovered"))
                .eq(params.containsKey("functionPercent"), CodeCovTask::getFunctionPercent, params.get("functionPercent"))
                .eq(params.containsKey("functionTotal"), CodeCovTask::getFunctionTotal, params.get("functionTotal"))
                .eq(params.containsKey("lineCovered"), CodeCovTask::getLineCovered, params.get("lineCovered"))
                .eq(params.containsKey("linePercent"), CodeCovTask::getLinePercent, params.get("linePercent"))
                .eq(params.containsKey("lineTotal"), CodeCovTask::getLineTotal, params.get("lineTotal"))
                .eq(params.containsKey("message"), CodeCovTask::getMessage, params.get("message"))
                .eq(params.containsKey("createTime"), CodeCovTask::getCreateTime, params.get("createTime"))
                .eq(params.containsKey("finishTime"), CodeCovTask::getFinishTime, params.get("finishTime"))
                .like(params.containsKey(projectCode) && params.get(projectCode) != null, CodeCovTask::getProjectCode, "%" + params.get(projectCode) + "%")
                .eq(params.containsKey(branch) && params.get(branch) != null, CodeCovTask::getBranch, params.get(branch))
                .eq(params.containsKey(status) && params.get(status) != null, CodeCovTask::getStatus, params.get(status))
                .between(params.containsKey(startCreateDate) && params.get(startCreateDate) != null && params.containsKey(endCreateDate) && params.get(endCreateDate) != null, CodeCovTask::getCreateTime, params.get(startCreateDate), params.get(endCreateDate));
        ;
        lambdaQueryWrapper.orderByDesc(CodeCovTask::getId);
        return codeCovTaskMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    public Long insert(CodeCovTask entity) {
        entity.setId(KeyGenerate.generateId());
        if (entity.getCreateTime() == null) {
            entity.setCreateTime(new Date());
        }
        codeCovTaskMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        codeCovTaskMapper.deleteById(id);
    }

    @Override
    public void update(CodeCovTask entity) {
        codeCovTaskMapper.updateById(entity);
    }


    /**
     * 客户端点击【代码覆盖率检查】
     * 保存任务并执行
     *
     * @param vo
     * @return
     */
    @Override
    public Long save(AddCodeCovTaskVO vo) {
        log.info("用户代码覆盖率检查 req: {}", JSONUtil.toJsonStr(vo));
        CodeCovTask task = new CodeCovTask();
        //兼容不标准的project_code
        if (!vo.getProjectCode().endsWith(GIT_POSTFIX)) {
            vo.setProjectCode(vo.getProjectCode() + GIT_POSTFIX);
        }
        LoginUser user = SecurityUtils.getLoginUser();
        if (user != null) {
            task.setUserId(user.getUserid());
            task.setDepartmentId(user.getSysUser().getDeptId());
            task.setDepartmentName(user.getSysUser().getDept().getDeptName());
            task.setUserName(user.getSysUser().getNickName());
            task.setUserNo(user.getUsername());
            //置换出根节点部门对象
            DeptRes.DeptVo rootDepartment = commonService.getRootDepartment(task.getDepartmentId());
            task.setRootDepartmentId(rootDepartment.getId());
            task.setRootDepartmentName(rootDepartment.getLabel());
        } else {
            //设置为系统管理员
            //1	admin	admin	103	研发部门	101	武汉
            task.setUserId(1L);
            task.setUserName(ADMIN);
            task.setUserNo(ADMIN);
            task.setDepartmentId(103L);
            task.setDepartmentName("研发部门");
            task.setRootDepartmentId(101L);
            task.setRootDepartmentName("武汉");
        }

        task.setProjectCode(vo.getProjectCode());
        task.setBranch(vo.getBranch());

        return saveCodeCovTask2DB(task, true);
    }

    /**
     * 定时任务自动触发【代码覆盖率检查】
     * 保存任务并执行
     *
     * @param vo
     * @return
     */
    @Override
    public CodeCovTask saveByAdmin(AddCodeCovTaskVO vo) {
        if (vo == null) {
            return null;
        }
        CodeCovTask task = new CodeCovTask();

        //设置为系统管理员
        //1	admin	admin	103	研发部门	101	武汉
        task.setUserId(1L);
        task.setUserName(ADMIN);
        task.setUserNo(ADMIN);
        task.setDepartmentId(103L);
        task.setDepartmentName("研发部门");
        task.setRootDepartmentId(101L);
        task.setRootDepartmentName("武汉");

        task.setProjectCode(vo.getProjectCode());
        task.setBranch(vo.getBranch());
        task.setStatus(ExecTaskStatusEnum.INIT.getCode());

        saveCodeCovTask2DB(task, false);
        return task;
    }


    /**
     * 调用Jenkins接口执行任务
     *
     * @param task
     */
    @Override
    public void execCovTaskForJenkins(CodeCovTask task) {
        //使用线程异步执行jenkins 代码覆盖率检查任务
        runAsync(() -> {
            String execCovTaskUrl = appConfig.getExecCodeCheckUrl();
            log.info("execCovTaskForJenkinsInvoking start taskId: {} execCovTaskUrl: {}", task.getId(), execCovTaskUrl);
            String projectCode = task.getProjectCode();
            Project project = projectService.getByCode(projectCode, task.getBranch());
            String jenkinsRes = HttpUtil.get(
                    execCovTaskUrl,
                    of(
                            "taskId", task.getId(),
                            "excludeScanPaths", parseArray(ofNullable(project).map(Project::getExcludeScanPaths).orElse("[]")),
                            "gitHttpUrl", projectCode,
                            "branch", task.getBranch(),
                            "token", "codecover_trigger"),
                    30_000);
            log.info("execCovTaskForJenkinsInvoking end taskId: {} jenkinsRes: {}", task.getId(), jenkinsRes);
        });
    }


    /**
     * jenkins代码覆盖率任务回调接口
     *
     * @param coverageDataInfo
     */
    @Override
    public void covTaskForJenkinsCallback(CoverageDataInfoVo coverageDataInfo) {
        Long taskId = coverageDataInfo.getTaskId();
        CodeCovTask task = this.get(taskId);
        if (task == null) {
            log.warn("covTaskForJenkinsCallback task is null taskId: {}", taskId);
            return;
        }

        StopWatch stopWatch = new StopWatch("jenkins代码覆盖率任务回调接口");
        List<CodeCovFun> funs = new ArrayList<>();
        List<CodeCovLine> lines = new ArrayList<>();
        task.setExecTaskId(String.valueOf(coverageDataInfo.getPiplineTaskId()));
        task.setStatus(coverageDataInfo.getStatus().getCode());
        if (ExecTaskStatusEnum.SUCCESS.equals(coverageDataInfo.getStatus())) {
            stopWatch.start("SUCCESS解析参数");
            CoverageDataInfoVo.Summary summary = JSONUtil.toBean(coverageDataInfo.getSummary(), CoverageDataInfoVo.Summary.class);
            task.setBranchCovered(summary.getBranchCovered());
            task.setBranchTotal(summary.getBranchTotal());
            task.setBranchPercent(summary.getBranchPercent());
            task.setFunctionCovered(summary.getFunctionCovered());
            task.setFunctionTotal(summary.getFunctionTotal());
            task.setFunctionPercent(summary.getFunctionPercent());
            task.setLineCovered(summary.getLineCovered());
            task.setLineTotal(summary.getLineTotal());
            task.setLineCovered(summary.getLineCovered());
            task.setCreateTime(new Date());

            //组装执行代码覆盖率任务明细表
            CoverageDataInfoVo.Details details = JSONUtil.toBean(coverageDataInfo.getDetails(), CoverageDataInfoVo.Details.class);
            List<CodeCovFunDetailToDbVo> codeCovFunList = getCodeCovFunList(details, taskId);
            funs.addAll(toStream(codeCovFunList).map(CodeCovFunDetailToDbVo::getFun).collect(Collectors.toList()));
            List<CodeCovLine> codeCovLines = toStream(codeCovFunList)
                    .flatMap(detail -> toStream(detail.getCodeCovLines()))
                    .collect(Collectors.toList());
            lines.addAll(codeCovLines);

            //计算覆盖率不达标的函数个数
            task.setOffCovFun((int) toStream(funs).filter(it -> it.getBlocksPercent().compareTo(BigDecimal.valueOf(100)) < 0).count());
            stopWatch.stop();
        }
        if (ExecTaskStatusEnum.SUCCESS.equals(coverageDataInfo.getStatus()) || ExecTaskStatusEnum.FAILED.equals(coverageDataInfo.getStatus())) {
            task.setFinishTime(new Date());
            task.setMessage(StringUtils.defaultString(coverageDataInfo.getMessage(), ""));
        }

        transactionalService.newTransaction(() -> {
            stopWatch.start("更新DB");
            //更新task表的状态等信息
            this.update(task);

            // 清理掉所有的 code_cov_fun
            LambdaQueryWrapper<CodeCovFun> codeCovFunWrapper = Wrappers.lambdaQuery(CodeCovFun.class);
            codeCovFunWrapper.eq(CodeCovFun::getCovTaskId, taskId);
            codeCovFunService.delete(codeCovFunWrapper);
            // 清理掉所有的 code_cov_line
            LambdaQueryWrapper<CodeCovLine> codeCovLineWrapper = Wrappers.lambdaQuery(CodeCovLine.class);
            codeCovLineWrapper.eq(CodeCovLine::getCovTaskId, taskId);
            codeCovLineService.delete(codeCovLineWrapper);

            //批量插入任务详情
            if (CollUtil.isNotEmpty(funs)) {
                codeCovFunService.insertBatch(funs, 1000);
            }
            //批量插入静态扫描详情
            if (CollUtil.isNotEmpty(lines)) {
                // 通过对象的ID去重
                List<CodeCovLine> distinctLines = new ArrayList<>(lines.stream()
                        .collect(Collectors.toMap(CodeCovLine::getId, line -> line, (oldValue, newValue) -> oldValue))
                        .values());

                codeCovLineService.insertBatch(distinctLines, 1000);
            }
            stopWatch.stop();
        });
        log.info(stopWatch.prettyPrint());
    }

    /**
     * 处理 函数列表 和 行列表
     *
     * @param details
     * @param taskId
     * @return
     */
    private List<CodeCovFunDetailToDbVo> getCodeCovFunList(CoverageDataInfoVo.Details details, Long taskId) {
        List<CodeCovFunDetailToDbVo> list = new ArrayList<>();
        //处理当前文件的 行数据
        toStream(details.getFiles()).forEach(file -> {
            log.info("files foreach file : {}", JSONUtil.toJsonStr(file));
            List<CodeCovLine> lineList = toStream(file.getLines())
                    .map(it -> {
                        CodeCovLine line = new CodeCovLine();
                        line.setId(KeyGenerate.generateId());
                        line.setCovTaskId(taskId);
                        line.setLineNumber(it.getLineNumber());
                        line.setCount(it.getCount());
                        line.setBranchCount((int) toStream(it.getBranches()).count());
                        line.setOffBranchCount((int) toStream(it.getBranches()).filter(b -> b.getCount() <= 0).count());
                        if (it.getBranches() != null) {
                            line.setBranches(JSONUtil.toJsonStr(it.getBranches()));
                        } else {
                            line.setBranches("[]");
                        }
                        return line;
                    }).collect(Collectors.toList());

            List<CodeCovFunDetailToDbVo> dbVoList = toStream(file.getFunctions())
                    //过滤掉没有拿到方法体的函数，可能是构造函数或者析构函数
                    .filter(fun -> StringUtils.isNotBlank(fun.getFun()))
                    .map(it -> {
                        CodeCovFun fun = new CodeCovFun();
                        fun.setId(KeyGenerate.generateId());
                        fun.setCovTaskId(taskId);
                        fun.setFilePath(file.getFile());
                        fun.setFunName(it.getName());
                        fun.setFun(it.getFun());
                        //函数起始行号
                        fun.setLineNo(it.getLineno());
                        //函数占用总行数
                        fun.setLineNum(countNewLines(it.getFun()) + 1);
                        //代码块覆盖率
                        fun.setBlocksPercent(BigDecimal.valueOf(it.getBlocksPercent()));
                        fun.setReturnedCount(it.getReturnedCount());
                        fun.setExecutionCount(it.getExecutionCount());

                        int startLineNo = fun.getLineNo(), endLineNo = fun.getLineNo() + fun.getLineNum();
                        //处理函数对应的行数据
                        List<CodeCovLine> lines = toStream(lineList)
                                .filter(line -> line.getLineNumber() >= startLineNo && line.getLineNumber() < endLineNo)
                                .peek(line -> line.setCovFunId(fun.getId()))
                                .collect(Collectors.toList());

                        //行覆盖率
                        long offLineCount = toStream(lines).filter(line -> line.getCount() == 0).count();
                        long totalLineCount = toStream(lines).count();
                        if (totalLineCount <= 0 || (totalLineCount - offLineCount) < 0) {
                            fun.setLinePercent(BigDecimal.ZERO);
                        } else if (totalLineCount < (totalLineCount - offLineCount)) {
                            fun.setLinePercent(new BigDecimal(100));
                        } else {
                            fun.setLinePercent(BigDecimal.valueOf(100 * (totalLineCount - offLineCount)).divide(BigDecimal.valueOf(totalLineCount), 2, RoundingMode.HALF_UP));
                        }
                        log.info("getCodeCovFunList id: {} funName: {}, offLineCount: {}, totalLineCount: {}, linePercent: {}", fun.getId(), fun.getFunName(), offLineCount, totalLineCount, fun.getLinePercent().toPlainString());
                        //分支覆盖率
                        long branchCount = toStream(lines).mapToInt(CodeCovLine::getBranchCount).sum();
                        long offBranchCount = toStream(lines).mapToInt(CodeCovLine::getOffBranchCount).sum();
                        fun.setBranchPercent(branchCount == 0 ? BigDecimal.ZERO : BigDecimal.valueOf(100 * (branchCount - offBranchCount)).divide(BigDecimal.valueOf(branchCount), 2, RoundingMode.HALF_UP));
                        log.info("getCodeCovFunList id: {} funName: {}, offBranchCount: {}, branchCount: {}, branchPercent: {}", fun.getId(), fun.getFunName(), offBranchCount, branchCount, fun.getBranchPercent().toPlainString());

                        log.info("func foreach : {}", JSONUtil.toJsonStr(fun));
                        CodeCovFunDetailToDbVo vo = new CodeCovFunDetailToDbVo();
                        vo.setFun(fun);
                        vo.setCodeCovLines(lines);
                        return vo;
                    }).collect(Collectors.toList());
            list.addAll(dbVoList);
        });
        return list;
    }

    public static void main(String[] args) {

    }

    private static long getInvalidLineCount(String fun) {
        String[] lines = fun.split("\\r?\\n");
        int invalidLineCount = 0;
        for (String line : lines) {
            line = line.replaceAll(" ", "");
            if (line.isEmpty() || line.equals("{") || line.equals("}") || line.startsWith("//") || line.startsWith("/*") || line.startsWith("*") ||
                    ((line.startsWith("*") || line.startsWith("/*")) && line.endsWith("*/"))) {
                invalidLineCount++;
            }
        }
        //函数的最后一个} 剔除掉
        if (invalidLineCount > 0) {
            invalidLineCount--;
        }
        return invalidLineCount;
    }

    private Long saveCodeCovTask2DB(CodeCovTask task, boolean execTaskForJenkins) {
        //兼容不标准的project_code
        if (!task.getProjectCode().endsWith(GIT_POSTFIX)) {
            task.setProjectCode(task.getProjectCode() + GIT_POSTFIX);
        }
        task.setOffCovFun(0);
        transactionalService.newTransaction(() -> this.insert(task));

        //调用Jenkins接口执行任务
        if (execTaskForJenkins) {
            this.execCovTaskForJenkins(task);
        }
        return task.getId();
    }

    public static int countNewLines(String str) {
        if (StringUtils.isBlank(str)) {
            return 0;
        }
        String[] lines = str.split("\\r?\\n");
        return lines.length - 1;
    }

    @Override
    public CodeCovTask getLastFinish(String projectCode, String branch) {
        LambdaQueryWrapper<CodeCovTask> lambdaQueryWrapper = Wrappers.lambdaQuery(CodeCovTask.class);
        lambdaQueryWrapper.eq(CodeCovTask::getProjectCode, projectCode)
                .eq(CodeCovTask::getBranch, branch)
                .eq(CodeCovTask::getStatus, ExecTaskStatusEnum.SUCCESS.getCode());
        lambdaQueryWrapper.orderByDesc(CodeCovTask::getId);
        lambdaQueryWrapper.last(" limit 1");
        return this.codeCovTaskMapper.selectOne(lambdaQueryWrapper);
    }

}
