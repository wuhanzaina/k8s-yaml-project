/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:EditPromptMarketVO.java
* 创建日期:2024-05-14
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.vo;

import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
*
* 提示词市场
*
*
* @author tiger
* @since 2024-05-14
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@ApiModel(value = "EditPromptMarketVO", description = "编辑提示词市场")
public class EditPromptMarketVO extends AddPromptMarketVO {

    private static final long serialVersionUID = 1L;
    /**
    * ID
    */
    @ApiModelProperty(value = "ID",required = true, position = 1)
    @NotNull(message = "id不能为空")
    private Long id;

}
