/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:CodeCheckTaskService.java
* 创建日期:2024-03-26
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kotei.sdw.modules.codecheck.entity.CodeCheckTask;
import com.kotei.sdw.modules.codecheck.vo.*;
import com.kotei.sdw.modules.ut.vo.CheckCodeSuggestAIVo;
import com.kotei.sdw.mvc.service.BaseService;

import java.util.List;

/**
*
* 代码检查任务表 Service
*
*
* @author tiger
* @since 2024-03-26
*/
public interface CodeCheckTaskService extends BaseService<CodeCheckTask> {

    /**
     * 客户端主动点击【代码检查扫描】
     * @param addCodeCheckTaskVO
     * @return
     */
    Long save(AddCodeCheckTaskVO addCodeCheckTaskVO);

    CodeCheckTask saveByAdmin(AddCodeCheckTaskVO addCodeCheckTaskVO);

    /**
     * 调用Jenkins接口执行任务
     * @param task
     */
    void execTaskForJenkins(CodeCheckTask task);

    void execTaskForJenkinsCallback(ExecTaskInfoVo task) throws JsonProcessingException;

    /**
     * 根据 radon 工具更新注释代码行数
     * @param taskId
     */
    void updateTaskComments(Long taskId);

    void triggerCodeStaticScan(Long projectId);

    void scanAndExecuteTask();

    /**
     * 通过项目编号获取统计内容
     * @param projectParent
     * @return
     */
    CodeCheckStatisticsVo getListByProjectParent(String projectParent);

    /**
     * 实时静态代码检查
     * @param req
     * @return
     */
    RealTimeCodeCheckRes realTimeCheckCode(RealTimeCodeCheckReq req);
    /**
     * 大模型通过静态代码检查问题给出修改建议
     * @return
     */
    CheckCodeSuggestAIVo checkCodeSuggest(CodeCheckSuggestReq req);

    /**
     * 配置库代码静态检测
     * @return
     */
    List<Long> saveNormal();

    List<Long> saveProjectListTask(List<String> projectList);
}
