/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:UserActivity.java
* 创建日期:2024-03-04
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.entity;

import java.util.Date;
import com.kotei.sdw.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
*
* 用户活跃度统计表
*
*
* @author tiger
* @since 2024-03-04
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("user_activity")
@ApiModel(value = "UserActivity", description = "用户活跃度统计表")
public class UserActivity extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 用户ID
    */
    @ApiModelProperty(value = "用户ID", position = 2)
    private Long userId;
    /**
    * 用户
    */
    @ApiModelProperty(value = "用户", position = 2)
    private String userName;
    /**
     * 用户工号
     */
    @ApiModelProperty(value = "用户工号", position = 9)
    private String userNo;
    /**
    * 日期
    */
    @ApiModelProperty(value = "日期", position = 3)
    private String activityDate;
    /**
    * 部门ID
    */
    @ApiModelProperty(value = "部门ID", position = 4)
    private Long departmentId;
    /**
    * 部门
    */
    @ApiModelProperty(value = "部门", position = 4)
    private String departmentName;
    /**
    * 一级部门ID
    */
    @ApiModelProperty(value = "一级部门ID", position = 5)
    private Long rootDepartmentId;
    /**
    * 一级部门ID
    */
    @ApiModelProperty(value = "一级部门", position = 5)
    private String rootDepartmentName;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", position = 6)
    private Date createTime;


}
