/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:CodeCheckTaskServiceImpl.java
 * 创建日期:2024-03-26
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Maps;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.codecheck.constant.enums.ExecTaskStatusEnum;
import com.kotei.sdw.modules.codecheck.entity.*;
import com.kotei.sdw.modules.codecheck.mapper.CodeCheckTaskDetailMapper;
import com.kotei.sdw.modules.codecheck.mapper.CodeCheckTaskMapper;
import com.kotei.sdw.modules.codecheck.mapper.ProjectCheckMapper;
import com.kotei.sdw.modules.codecheck.mapper.ProjectsCodeMapper;
import com.kotei.sdw.modules.codecheck.service.CodeCheckTaskDetailService;
import com.kotei.sdw.modules.codecheck.service.CodeCheckTaskService;
import com.kotei.sdw.modules.codecheck.service.CodeCheckWarningDetailService;
import com.kotei.sdw.modules.codecheck.service.ProjectService;
import com.kotei.sdw.modules.codecheck.vo.*;
import com.kotei.sdw.modules.codecheck.vo.ExecTaskInfoVo.CircleComplexityInfo;
import com.kotei.sdw.modules.codecheck.vo.ExecTaskInfoVo.CommentInfo;
import com.kotei.sdw.modules.codecheck.vo.ExecTaskInfoVo.WarningInfo;
import com.kotei.sdw.modules.config.AppConfig;
import com.kotei.sdw.modules.feign.ChatbotFeign;
import com.kotei.sdw.modules.feign.vo.ChatBotVo;
import com.kotei.sdw.modules.feign.vo.DeptRes;
import com.kotei.sdw.modules.service.CommonService;
import com.kotei.sdw.modules.service.transaction.TransactionalService;
import com.kotei.sdw.modules.ut.vo.CheckCodeSuggestAIVo;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.security.utils.SecurityUtils;
import com.kotei.sdw.system.api.model.LoginUser;
import com.kotei.sdw.util.CompareUtils;
import com.kotei.sdw.util.StreamUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import java.io.File;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static cn.hutool.core.collection.CollUtil.isEmpty;
import static cn.hutool.core.collection.CollUtil.isNotEmpty;
import static cn.hutool.core.io.FileUtil.extName;
import static cn.hutool.json.JSONUtil.parseArray;
import static cn.hutool.json.JSONUtil.toList;
import static com.kotei.sdw.modules.codecheck.constant.CircleComplexityConst.CIRCLE_COMPLEXITY_MAP;
import static com.kotei.sdw.modules.codecheck.constant.Consts.*;
import static com.kotei.sdw.modules.utils.ComonUtil.extractFirstCodeBlockForJson;
import static com.kotei.sdw.modules.utils.GitLabUtil.GIT_POSTFIX;
import static com.kotei.sdw.modules.utils.YamlUtils.getListFromYamlToClass;
import static com.kotei.sdw.modules.utils.YamlUtils.getMapFromYamlToClass;
import static com.kotei.sdw.util.StreamUtil.toStream;
import static java.util.Optional.ofNullable;
import static java.util.concurrent.CompletableFuture.runAsync;
import static org.apache.commons.lang3.StringUtils.defaultIfBlank;

/**
 * 代码检查任务表 ServiceImpl
 *
 * @author tiger
 * @since 2024-03-26
 */
@Service
@Slf4j
public class CodeCheckTaskServiceImpl extends BaseServiceImpl<CodeCheckTask> implements CodeCheckTaskService {
    @Autowired
    private CodeCheckTaskMapper codeCheckTaskMapper;
    @Autowired
    private CommonService commonService;
    @Autowired
    private AppConfig appConfig;
    @Autowired
    private TransactionalService transactionalService;
    @Autowired
    private CodeCheckTaskDetailService codeCheckTaskDetailService;
    @Autowired
    private CodeCheckWarningDetailService codeCheckWarningDetailService;
    @Autowired
    private ProjectService projectService;
    @Autowired
    private ChatbotFeign chatbotFeign;
    @Autowired
    private CodeCheckTaskService codeCheckTaskService;
    @Autowired
    private ProjectsCodeMapper projectsCodeMapper;

    @Autowired
    private ProjectCheckMapper projectCheckMapper;

    @Override
    protected BaseMapper<CodeCheckTask> getMapper() {
        return codeCheckTaskMapper;
    }

    @Override
    public CodeCheckTask get(Long id) {
        return codeCheckTaskMapper.selectById(id);
    }


    @Override
    public IPage<CodeCheckTask> getList(PageVO<CodeCheckTask> page) {
        Map<String, Object> params = page.getParams();
        String userId = "userId", projectCode = "projectCode", startCreateDate = "startCreateDate", endCreateDate = "endCreateDate", branch = "branch", status = "status";
        LambdaQueryWrapper<CodeCheckTask> lambdaQueryWrapper = Wrappers.lambdaQuery(CodeCheckTask.class)
                .eq(params.containsKey("type"), CodeCheckTask::getType, params.get("type"))
                .eq(params.containsKey("hookId"), CodeCheckTask::getExecTaskId, params.get("hookId"))
                .eq(params.containsKey("execTaskId"), CodeCheckTask::getExecTaskId, params.get("execTaskId"))
                .eq(params.containsKey(userId) && params.get(userId) != null, CodeCheckTask::getUserId, params.get(userId))
                .eq(params.containsKey("userName"), CodeCheckTask::getUserName, params.get("userName"))
                .eq(params.containsKey("userNo"), CodeCheckTask::getUserNo, params.get("userNo"))
                .eq(params.containsKey("departmentId"), CodeCheckTask::getDepartmentId, params.get("departmentId"))
                .eq(params.containsKey("departmentName"), CodeCheckTask::getDepartmentName, params.get("departmentName"))
                .eq(params.containsKey("rootDepartmentId"), CodeCheckTask::getRootDepartmentId, params.get("rootDepartmentId"))
                .eq(params.containsKey("rootDepartmentName"), CodeCheckTask::getRootDepartmentName, params.get("rootDepartmentName"))
                .like(params.containsKey(projectCode) && params.get(projectCode) != null, CodeCheckTask::getProjectCode, "%" + params.get(projectCode) + "%")
                .eq(params.containsKey(branch) && params.get(branch) != null, CodeCheckTask::getBranch, params.get(branch))
                .eq(params.containsKey(status) && params.get(status) != null, CodeCheckTask::getStatus, params.get(status))
                .between(params.containsKey(startCreateDate) && params.get(startCreateDate) != null && params.containsKey(endCreateDate) && params.get(endCreateDate) != null, CodeCheckTask::getCreateTime, params.get(startCreateDate), params.get(endCreateDate));
        lambdaQueryWrapper.orderByDesc(CodeCheckTask::getId);
        return codeCheckTaskMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long insert(CodeCheckTask entity) {
        entity.setId(KeyGenerate.generateId());
        if (entity.getCreateTime() == null) {
            entity.setCreateTime(new Date());
        }
        if (entity.getHookId() == null) {
            entity.setHookId(0L);
        }
        codeCheckTaskMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        codeCheckTaskMapper.deleteById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(CodeCheckTask entity) {
        codeCheckTaskMapper.updateById(entity);
    }

    /**
     * 客户端点击【代码检查扫描】
     * 保存任务并执行
     *
     * @param addCodeCheckTaskVO
     * @return
     */
    @Override
    public Long save(AddCodeCheckTaskVO addCodeCheckTaskVO) {
        log.info("用户代码检查扫描 req: {}", JSONUtil.toJsonStr(addCodeCheckTaskVO));
        CodeCheckTask task = new CodeCheckTask();
        //兼容不标准的project_code
        if (!addCodeCheckTaskVO.getProjectCode().endsWith(GIT_POSTFIX)) {
            addCodeCheckTaskVO.setProjectCode(addCodeCheckTaskVO.getProjectCode() + GIT_POSTFIX);
        }
        //检查 项目是在数据库中配置
//        Project project = projectService.getByCode(addCodeCheckTaskVO.getProjectCode(), addCodeCheckTaskVO.getBranch());
//        if (project == null) {
//            throw new BaseException("当前项目和分支尚未配置，请咨询PM配置完成后再操作静态检查。");
//        }
        LoginUser user = SecurityUtils.getLoginUser();
        if (user != null) {
            task.setUserId(user.getUserid());
            task.setDepartmentId(user.getSysUser().getDeptId());
            task.setDepartmentName(user.getSysUser().getDept().getDeptName());
            task.setUserName(user.getSysUser().getNickName());
            task.setUserNo(user.getUsername());
            //置换出根节点部门对象
            DeptRes.DeptVo rootDepartment = commonService.getRootDepartment(task.getDepartmentId());
            task.setRootDepartmentId(rootDepartment.getId());
            task.setRootDepartmentName(rootDepartment.getLabel());
        } else {
            //设置为系统管理员
            //1	admin	admin	103	研发部门	101	武汉
            task.setUserId(1L);
            task.setUserName(ADMIN);
            task.setUserNo(ADMIN);
            task.setDepartmentId(103L);
            task.setDepartmentName("研发部门");
            task.setRootDepartmentId(101L);
            task.setRootDepartmentName("武汉");
            task.setStatus(ExecTaskStatusEnum.ONGOING.getCode());
        }

        task.setProjectCode(addCodeCheckTaskVO.getProjectCode());
        task.setBranch(addCodeCheckTaskVO.getBranch());
        task.setLanguage(addCodeCheckTaskVO.getLanguage());
        task.setEmail(addCodeCheckTaskVO.getEmail());
        task.setPm(addCodeCheckTaskVO.getPm());
        task.setType("ALL");
        //技术债评级
        String rating = null;

        Project project = projectService.getByCode(addCodeCheckTaskVO.getProjectCode(), addCodeCheckTaskVO.getBranch());
        String projectName = project.getProjectName();
        String url = "http://192.168.53.219:9000/api/measures/component?component=" + projectName + "&metricKeys=sqale_debt_ratio";
        String authorizationHeader = "Basic YWRtaW46MXFhekBXU1g=";
        //调用sonarqube接口获取 负债比率
        try {
            HttpResponse response = HttpRequest.get(url)
                    .header("Authorization", authorizationHeader)
                    .execute();
            System.out.println(response.body());
            JSONObject jsonObject = JSONUtil.parseObj(response.body());

            // 检查是否包含错误字段
            if (jsonObject.containsKey("errors")) {
                rating = "sonarqube中没有配置该项目";
            } else {
                // 解析正常响应
                JSONObject component = jsonObject.getJSONObject("component");
                JSONArray measures = component.getJSONArray("measures");
                if (measures != null && !measures.isEmpty()) {
                    JSONObject measure = measures.getJSONObject(0);
                    String value = measure.getStr("value");
                    rating = getRating(Double.parseDouble(value));
                } else {
                    System.out.println("No measures found.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        task.setSqaleDebtRatio(rating);


        return saveCodeCheckTask2DB(task, true);
    }


    /**
     * 根据技术债比率获取评级
     *
     * @param debtRatio
     * @return
     */
    public static String getRating(double debtRatio) {
        if (debtRatio >= 0 && debtRatio <= 5) {
            return "A";
        } else if (debtRatio > 5 && debtRatio <= 10) {
            return "B";
        } else if (debtRatio > 10 && debtRatio <= 20) {
            return "C";
        } else if (debtRatio > 20 && debtRatio <= 50) {
            return "D";
        } else if (debtRatio > 50 && debtRatio <= 100) {
            return "E";
        } else {
            return "无效的技术债务比率";
        }
    }

    /**
     * 定时任务自动触发【代码检查扫描】
     * 保存任务并执行
     *
     * @param addCodeCheckTaskVO
     * @return
     */
    @Override
    public CodeCheckTask saveByAdmin(AddCodeCheckTaskVO addCodeCheckTaskVO) {
        if (addCodeCheckTaskVO == null) {
            return null;
        }
        CodeCheckTask task = new CodeCheckTask();

        //设置为系统管理员
        //1	admin	admin	103	研发部门	101	武汉
        task.setUserId(1L);
        task.setUserName(ADMIN);
        task.setUserNo(ADMIN);
        task.setDepartmentId(103L);
        task.setDepartmentName("研发部门");
        task.setRootDepartmentId(101L);
        task.setRootDepartmentName("武汉");

        task.setProjectCode(addCodeCheckTaskVO.getProjectCode());
        task.setBranch(addCodeCheckTaskVO.getBranch());
        task.setStatus(ExecTaskStatusEnum.INIT.getCode());
        task.setType("ALL");

        saveCodeCheckTask2DB(task, false);
        return task;
    }


    /**
     * 调用Jenkins接口执行任务
     *
     * @param task
     */
    @Override
    public void execTaskForJenkins(CodeCheckTask task) {
        //使用线程异步执行jenkins任务
        runAsync(() -> {
            String execCodeCheckUrl = appConfig.getExecCodeCheckUrl();
            log.info("execTaskForJenkinsInvoking start hookId: {} taskId: {} execCodeCheckUrl: {}", task.getHookId(), task.getId(), execCodeCheckUrl);
            String projectCode = task.getProjectCode();
            Project project = projectService.getByCode(projectCode, task.getBranch());
            Map<String, Object> params = new HashMap<>();
            params.put("taskId", task.getId());
            params.put("excludeScanPaths", parseArray(ofNullable(project).map(Project::getExcludeScanPaths).orElse("[]")));
            params.put("gitHttpUrl", projectCode);
            params.put("branch", task.getBranch());
            params.put("language", task.getLanguage());
            params.put("email", task.getEmail());
            params.put("pm", task.getPm());
            params.put("projectName", Optional.ofNullable(project).map(Project::getProjectName).orElse("project is null"));
            params.put("token", "webhook_trigger");
            String jenkinsRes = HttpUtil.get(execCodeCheckUrl, params, 60_000);
            log.info("params : {}", params);
            log.info("execTaskForJenkinsInvoking end hookId: {} taskId: {} jenkinsRes: {}", task.getHookId(), task.getId(), jenkinsRes);
        });
    }

    /**
     * Jenkins执行代码检查任务回调接口
     *
     * @param execTaskInfo
     */
    @Override
    public void execTaskForJenkinsCallback(ExecTaskInfoVo execTaskInfo) throws JsonProcessingException {
        Long taskId = execTaskInfo.getTaskId();
        CodeCheckTask task = this.get(taskId);
        if (task == null) {
            log.warn("execTaskForJenkinsCallback task is null taskId: {}", taskId);
            return;
        }

        StopWatch stopWatch = new StopWatch("Jenkins执行代码检查任务回调接口");
        List<CodeCheckTaskDetail> details = new ArrayList<>();
        List<CodeCheckWarningDetail> warningDetails = new ArrayList<>();
        task.setExecTaskId(String.valueOf(execTaskInfo.getPiplineTaskId()));
        task.setStatus(execTaskInfo.getStatus().getCode());
        if (ExecTaskStatusEnum.SUCCESS.equals(execTaskInfo.getStatus())) {
            stopWatch.start("SUCCESS解析参数");
            List<WarningInfo> warningInfos = toStream(getListFromYamlToClass(execTaskInfo.getWarningText(), WarningInfo.class))
                    .filter(it -> WARNING.equals(it.getWarningType()) || ERROR.equals(it.getWarningType()))
                    .peek(it -> it.setFilePath(replaceJenkinsWorkPath(it.getFilePath(), execTaskInfo.getProjectName())))
                    .collect(Collectors.toList());
            List<CircleComplexityInfo> circleComplexityInfos = toStream(analysisCircleComplexityInfos(execTaskInfo.getCircleText(), taskId))
                    .peek(it -> it.setFilePath(replaceJenkinsWorkPath(it.getFilePath(), execTaskInfo.getProjectName())))
                    .collect(Collectors.toList());
            Map<String, CommentInfo> commentInfoMap = getMapFromYamlToClass(execTaskInfo.getCommentsText(), CommentInfo.class);
            //排除大约 30% 注释率的文件
            toStream(commentInfoMap.values())
                    .flatMap(value -> toStream(value.getChildren().values()))
                    .flatMap(StreamUtil::toStream)
                    .filter(report -> report.getStats().getComments() <= 0.3 * report.getStats().getCode())
                    .forEach(report -> report.setName(replaceJenkinsWorkPath(report.getName(), execTaskInfo.getProjectName())));
            stopWatch.stop();

            stopWatch.start("SUCCESS参数转换计算");
            //警告类型为 warning 数量
            task.setWarning((int) toStream(warningInfos).filter(it -> WARNING.equals(it.getWarningType())).count());
            //警告类型为 error 数量
            task.setError((int) toStream(warningInfos).filter(it -> ERROR.equals(it.getWarningType())).count());

            //获取项目下所有文件的注释情况
            CommentInfo totalCommentInfo = commentInfoMap.get(TOTAL);

            int totalCode = getTotalCode(totalCommentInfo);
            int totalComments = getTotalComments(totalCommentInfo);
            //int totalBlanks = getTotalBlanks(totalCommentInfo);
            log.info("totalCode:{},totalComments:{}",totalCode,totalComments);
            log.info("allCodes:{}",totalCode+totalComments);

            task.setCodes(totalCode + totalComments);
            task.setComments(totalComments);
            task.setBlanks(totalCommentInfo.getBlanks());

            //注释率不达标的数量
            int count = (int) toStream(commentInfoMap.entrySet())
                    .flatMap(entry -> toStream(entry.getValue().getChildren().values()))
                    .flatMap(StreamUtil::toStream)
                    .map(CommentInfo.Report::getStats)
                    .filter(stats -> stats.getCode() > 0)
                    .filter(stats -> codeCommentRate(stats.getComments(), stats.getCode(), stats.getBlanks()))
                    .count();
            task.setOffGradeComments(count);

            int averageCircleComplexity = (int) Math.round(circleComplexityInfos.stream()
                    .mapToInt(CircleComplexityInfo::getCircleComplexity)
                    .average()
                    .orElse(0.0));
            //平均圈复杂度
            task.setCircleComplexity(averageCircleComplexity);
            //最大圈复杂度
            task.setMaxCircleComplexity(circleComplexityInfos.stream()
                    .mapToInt(CircleComplexityInfo::getCircleComplexity)
                    .max()
                    .orElse(0));
            //不达标的圈复杂度个数
            task.setOffGradeCircleComplexity(calcOffGradeCircleComplexity(circleComplexityInfos));

            //组装执行任务明细表
            List<CodeCheckTaskDetailToDbVo> warningDetailList = getWarningDetailList(warningInfos, taskId);
            warningDetails.addAll(warningDetailList.stream().flatMap(it -> it.getWarningDetails().stream()).collect(Collectors.toList()));
            details.addAll(warningDetailList.stream().map(CodeCheckTaskDetailToDbVo::getDetail).collect(Collectors.toList()));
            details.addAll(getCircleComplexityDetailList(circleComplexityInfos, taskId));
            details.addAll(getCommentDetailList(commentInfoMap, taskId));
            stopWatch.stop();
        }
        if (ExecTaskStatusEnum.SUCCESS.equals(execTaskInfo.getStatus()) || ExecTaskStatusEnum.FAILED.equals(execTaskInfo.getStatus())) {
            task.setFinishTime(new Date());
            task.setMessage(StringUtils.defaultString(execTaskInfo.getMessage(), ""));
        }

        transactionalService.newTransaction(() -> {
            stopWatch.start("更新DB");
            //更新task表的状态等信息
            this.update(task);

            // 清理掉所有的detail
            LambdaQueryWrapper<CodeCheckTaskDetail> taskDetailWrapper = Wrappers.lambdaQuery(CodeCheckTaskDetail.class);
            taskDetailWrapper.eq(CodeCheckTaskDetail::getTaskId, taskId);
            codeCheckTaskDetailService.delete(taskDetailWrapper);
            // 清理掉所有的warning_detail
            LambdaQueryWrapper<CodeCheckWarningDetail> warningDetailWrapper = Wrappers.lambdaQuery(CodeCheckWarningDetail.class);
            warningDetailWrapper.eq(CodeCheckWarningDetail::getTaskId, taskId);
            codeCheckWarningDetailService.delete(warningDetailWrapper);

            //批量插入任务详情
            if (CollUtil.isNotEmpty(details)) {
                codeCheckTaskDetailService.insertBatch(details, 1000);
            }
            //批量插入静态扫描详情
            if (CollUtil.isNotEmpty(warningDetails)) {
                codeCheckWarningDetailService.insertBatch(warningDetails, 1000);
            }
            stopWatch.stop();
        });
        log.info(stopWatch.prettyPrint());
    }

    @Override
    @Transactional
    public void updateTaskComments(Long taskId) {
        LambdaQueryWrapper<CodeCheckTaskDetail> commentWrapper = Wrappers.lambdaQuery(CodeCheckTaskDetail.class)
                .eq(CodeCheckTaskDetail::getTaskId, taskId)
                .eq(CodeCheckTaskDetail::getType, "COMMENT");

        List<CodeCheckTaskDetail> commentList = codeCheckTaskDetailService.getList(commentWrapper);

        int totalCode = commentList.stream()
                .mapToInt(CodeCheckTaskDetail::getCodes)
                .sum();
        int totalComment = commentList.stream()
                .mapToInt(CodeCheckTaskDetail::getComments)
                .sum();

        //获取小于标准注释率的数量
        long offCommentCount = commentList.stream()
                .filter(item -> item.getOffGrade() == 1)
                .count();

        LambdaUpdateWrapper<CodeCheckTask> checkTaskLambdaUpdateWrapper = Wrappers.lambdaUpdate(CodeCheckTask.class)
                .eq(CodeCheckTask::getId, taskId);
        CodeCheckTask codeCheckTask = new CodeCheckTask();
        codeCheckTask.setId(taskId);
        codeCheckTask.setCodes(totalCode+totalComment);
        codeCheckTask.setComments(totalComment);
        codeCheckTask.setOffGradeComments((int) offCommentCount);

        codeCheckTaskService.update(codeCheckTask);
    }

    /**
     * 定时触发生成代码静态扫描任务并入库
     */
    @Override
    public void triggerCodeStaticScan(Long projectId) {
        LambdaQueryWrapper<Project> lambdaQueryWrapper = Wrappers.lambdaQuery(Project.class)
                .eq(Project::getScheduleStatus, 1);
        if (CompareUtils.greaterThanZero(projectId)) {
            lambdaQueryWrapper.eq(Project::getId, projectId);
        }
        List<Project> projects = projectService.getList(lambdaQueryWrapper);
        toStream(projects).forEach(it -> {
            AddCodeCheckTaskVO addCodeCheckTaskVO = new AddCodeCheckTaskVO();
            addCodeCheckTaskVO.setProjectCode(it.getProjectCode());
            addCodeCheckTaskVO.setBranch(it.getBranch());
            CodeCheckTask task = this.saveByAdmin(addCodeCheckTaskVO);
            log.info("【Scheduled】 triggerCodeStaticScan projectCode: {}, branch: {}, taskId: {}", task.getProjectCode(), task.getBranch(), task.getId());
        });
    }

    /**
     * 定时扫描启动待执行的任务
     * 数据库中存在待执行的任务则拉起执行，有执行中的在等待下一次扫描
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void scanAndExecuteTask() {
        //获取【执行中】的数据
        LambdaQueryWrapper<CodeCheckTask> lambdaQueryWrapper = Wrappers.lambdaQuery(CodeCheckTask.class);
        lambdaQueryWrapper.eq(CodeCheckTask::getUserId, 1L).eq(CodeCheckTask::getStatus, ExecTaskStatusEnum.ONGOING.getCode())
                .last("limit 1");
        CodeCheckTask goingTask = this.codeCheckTaskMapper.selectOne(lambdaQueryWrapper);
        if (goingTask != null) {
            log.info("【Scheduled】 scanAndExecuteTask 存在执行中的数据，等待下一轮扫描");
            //静态代码扫描提交时间超过3小时, 任然在执行中,那么自动处理为执行失败
            Date createTime = goingTask.getCreateTime();
            Date now = new Date();
            long betweenHour = DateUtil.between(createTime, now, DateUnit.HOUR);
            if (betweenHour > 3) {
                CodeCheckTask updateCodeCheckTask = new CodeCheckTask();
                updateCodeCheckTask.setId(goingTask.getId());
                updateCodeCheckTask.setStatus(ExecTaskStatusEnum.FAILED.getCode());
                codeCheckTaskMapper.updateById(updateCodeCheckTask);
            }
            return;
        }

        LambdaQueryWrapper<CodeCheckTask> lambdaQueryWrapper2 = Wrappers.lambdaQuery(CodeCheckTask.class);
        lambdaQueryWrapper2.eq(CodeCheckTask::getUserId, 1L).eq(CodeCheckTask::getStatus, ExecTaskStatusEnum.INIT.getCode())
                .last(" limit 1");
        CodeCheckTask codeCheckTask = this.codeCheckTaskMapper.selectOne(lambdaQueryWrapper2);
        //有待执行的任务，拉起执行
        if (codeCheckTask != null) {
            log.info("【Scheduled】 scanAndExecuteTask 拉起任务 taskId: {}", codeCheckTask.getId());
            //调用Jenkins接口执行任务
            this.execTaskForJenkins(codeCheckTask);
        }
    }

    /**
     * 通过项目编号获取统计内容
     *
     * @param projectParent
     * @return
     */
    @Override
    public CodeCheckStatisticsVo getListByProjectParent(String projectParent) {
        //根据项目名找到无法检查项目的原因
        List<ProjectCheck> projectChecks = projectCheckMapper.selectList(null);
        List<ProjectCheck> noCheckList = projectChecks.stream()
                .filter(projectCheck -> projectCheck.getProjectName().equals(projectParent))
                .collect(Collectors.toList());

        StringBuilder no_check_reason = new StringBuilder();

        if (noCheckList.size() == 1) {
            String status = noCheckList.get(0).getStatus();
            String notes = noCheckList.get(0).getNotes();
            no_check_reason.append(status).append(",").append(notes);
        }

        List<CodeCheckStatisticsVo> list = this.codeCheckTaskMapper.getNormalListByProjectParent(projectParent);
        for (CodeCheckStatisticsVo codeCheckStatisticsVo : list) {
            String language = codeCheckStatisticsVo.getLanguage();
            if (StringUtils.isEmpty(language)) {
                codeCheckStatisticsVo.setLanguage("c++");
            }
        }
        list.forEach(vo -> {
            double comRate = vo.getComments() * 1.0D / vo.getCodes();
            vo.setMinCommentsRate(Double.toString(comRate));
        });

        Map<String, List<CodeCheckStatisticsVo>> groupedByLanguage = list.stream().collect(Collectors.groupingBy(CodeCheckStatisticsVo::getLanguage));

        Map<String, Integer> languageToMinCommentRate = new HashMap<>();


        // 遍历 groupedByLanguage 找到每个 language 对应的最小注释率
        groupedByLanguage.forEach((language, statisticsList) -> {
            // 找到最小注释率对象
            Optional<CodeCheckStatisticsVo> minRateStatistics = statisticsList.stream()
                    .max(Comparator.comparingDouble(CodeCheckStatisticsVo::getMaxCircleComplexity));
            minRateStatistics.ifPresent(stat ->
                    languageToMinCommentRate.put(language, stat.getMaxCircleComplexity()));
        });


        CodeCheckStatisticsVo results = toStream(list)
                .reduce(new CodeCheckStatisticsVo(),
                        (result, vo) -> {
                            result.setProjectParent(vo.getProjectParent());
                            result.setCodes(result.getCodes() + vo.getCodes());
                            result.setComments(result.getComments() + vo.getComments());
                            result.setBlanks(result.getBlanks() + vo.getBlanks());
                            result.setOffGradeComments(result.getOffGradeComments() + vo.getOffGradeComments());
                            result.setOffGradeCircleComplexity(result.getOffGradeCircleComplexity() + vo.getOffGradeCircleComplexity());
                            result.setMaxCircleComplexity(Math.max(result.getMaxCircleComplexity(), vo.getMaxCircleComplexity()));
                            result.setWarning(result.getWarning() + vo.getWarning());
                            result.setError(result.getError() + vo.getError());
                            return result;
                        });
        //String jsonString = JSON.toJSONString(languageToMinCommentRate);
        results.setMaxComplex(languageToMinCommentRate);
        results.setCodeCheckStatisticsVoList(list);
        results.setProjectStatus(no_check_reason.toString());
        return results;
    }

    /**
     * 实时静态代码检查
     *
     * @param req
     * @return
     */
    @Override
    public RealTimeCodeCheckRes realTimeCheckCode(RealTimeCodeCheckReq req) {
        RealTimeCodeCheckRes res = new RealTimeCodeCheckRes();
        res.setStartLine(req.getStartLine());
        res.setContent(req.getContent());
        StopWatch stopWatch = new StopWatch("实时静态代码检查");
        //用户代码写入源码文件中
        stopWatch.start("写入源码内容");
        String sourcePathText = appConfig.getCodeCheckSourcePath();
        File sourcePath = FileUtil.file(sourcePathText);
        if (!sourcePath.exists()) {
            FileUtil.mkParentDirs(sourcePath);
        }
        FileUtil.writeUtf8String(req.getContent(), sourcePath);
        stopWatch.stop();
        //调用clang-tidy命令执行代码检查
        stopWatch.start("执行代码检查");
        String codeCheckResult = getCodeCheckResult(sourcePathText);
        stopWatch.stop();
        //处理结果并返回检查列表
        stopWatch.start("处理检查返回列表");
        res.setWarningList(toList(parseArray(defaultIfBlank(codeCheckResult, "[]")), WarningInfo.class));
        stopWatch.stop();
        return res;
    }

    /**
     * 大模型通过静态代码检查问题给出修改建议
     *
     * @return
     */
    @Override
    public CheckCodeSuggestAIVo checkCodeSuggest(CodeCheckSuggestReq req) {
        //组装提示词
        String content = req.getContent();
        String warning = req.getWarningMessage();
        String codeCheckSuggestPrompt = appConfig.getCodeCheckSuggestPrompt();
        String prompt = "被检查的代码内容：\n```" + content + "```\n警告位置：第" + req.getLineNumber() + "行，第" + req.getColumnNumber() + "列 \n警告内容：" + warning + "\n" + codeCheckSuggestPrompt;
        return checkCodeSuggestFromAI(prompt);
    }

    @Override
    public List<Long> saveNormal() {
        log.info("开始配置表代码仓库列表检查扫描 ");
        List<ProjectsCode> projectsCodesList = projectsCodeMapper.selectList(null);
        List<Long> taskIdList = new ArrayList<>(16);
        for (ProjectsCode projectsCode : projectsCodesList) {
            CodeCheckTask task = new CodeCheckTask();
            task.setUserId(1L);
            task.setUserName(ADMIN);
            task.setUserNo(ADMIN);
            task.setDepartmentId(103L);
            task.setDepartmentName("研发部门");
            task.setRootDepartmentId(101L);
            task.setRootDepartmentName("武汉");
            task.setStatus(ExecTaskStatusEnum.ONGOING.getCode());

            task.setProjectCode(projectsCode.getGitUrl());
            task.setBranch(projectsCode.getBranch());
            task.setType("ALL");
            Long taskId = saveCodeCheckTask2DB(task, true);
            taskIdList.add(taskId);
        }


        return taskIdList;
    }

    @Override
    public List<Long> saveProjectListTask(List<String> projectList) {
        //查询对应的gitUrl和branch
        QueryWrapper<ProjectsCode> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("project_name", projectList);
        List<ProjectsCode> projectsCodesList = projectsCodeMapper.selectList(queryWrapper);
        List<Long> taskIdList = new ArrayList<>(16);

        for (ProjectsCode projectsCode : projectsCodesList) {
            CodeCheckTask task = new CodeCheckTask();
            task.setUserId(1L);
            task.setUserName(ADMIN);
            task.setUserNo(ADMIN);
            task.setDepartmentId(103L);
            task.setDepartmentName("研发部门");
            task.setRootDepartmentId(101L);
            task.setRootDepartmentName("武汉");
            task.setStatus(ExecTaskStatusEnum.ONGOING.getCode());

            task.setProjectCode(projectsCode.getGitUrl());
            task.setBranch(projectsCode.getBranch());
            task.setType("ALL");

            //技术债评级
            String rating = null;

            String projectName = projectsCode.getRepoName();
            String url = "http://192.168.53.219:9000/api/measures/component?component=" + projectName + "&metricKeys=sqale_debt_ratio";
            String authorizationHeader = "Basic YWRtaW46MXFhekBXU1g=";
            //调用sonarqube接口获取 负债比率
            try {
                HttpResponse response = HttpRequest.get(url)
                        .header("Authorization", authorizationHeader)
                        .execute();
                System.out.println(response.body());
                JSONObject jsonObject = JSONUtil.parseObj(response.body());

                // 检查是否包含错误字段
                if (jsonObject.containsKey("errors")) {
                    rating = "sonarqube中没有配置该项目";
                } else {
                    // 解析正常响应
                    JSONObject component = jsonObject.getJSONObject("component");
                    JSONArray measures = component.getJSONArray("measures");
                    if (measures != null && !measures.isEmpty()) {
                        JSONObject measure = measures.getJSONObject(0);
                        String value = measure.getStr("value");
                        rating = getRating(Double.parseDouble(value));
                    } else {
                        System.out.println("No measures found.");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            task.setSqaleDebtRatio(rating);

            Long taskId = saveCodeCheckTask2DB(task, true);
            taskIdList.add(taskId);
        }

        return taskIdList;
    }

    private String getCodeCheckResult(String filePath) {
        Map<String, Object> map = Maps.newHashMap();
        map.put("filePath", filePath);
        // 通过AST服务分析函数的相关信息，定义等内容
        String url = appConfig.getPythonBasePath() + "/api/code-check/clang-tidy";

        String reqStr = JSONUtil.toJsonStr(map);
        log.info("getCodeCheckResult start url: {} req: {}", url, reqStr);
        String str = HttpUtil.post(url, reqStr, 10_000);
        log.info("getCodeCheckResult end url: {} res: {}", url, str);
        return str;
    }


    /**
     * children 累加 code
     *
     * @param commentInfo
     * @return
     */
    private static int getTotalCode(CommentInfo commentInfo) {
        int totalCode = 0;

        if (commentInfo.getChildren() != null) {
            for (List<CommentInfo.Report> reports : commentInfo.getChildren().values()) {

                totalCode += reports.stream()
                        .mapToInt(report -> report.getStats().getCode())
                        .sum();
            }
        }
        return totalCode;
    }


    /**
     * children 累加 comment
     *
     * @param commentInfo
     * @return
     */
    private static int getTotalComments(CommentInfo commentInfo) {
        int totalComments = 0;

        if (commentInfo.getChildren() != null) {
            for (List<CommentInfo.Report> reports : commentInfo.getChildren().values()) {
                // 累加每个 Report 的 `Stats.comments`
                totalComments += reports.stream()
                        .mapToInt(report -> report.getStats().getComments())
                        .sum();
            }
        }
        return totalComments;
    }

    /**
     * children 累加 blank
     *
     * @param commentInfo
     * @return
     */
    private static int getTotalBlanks(CommentInfo commentInfo) {
        int totalBlanks = 0;

        if (commentInfo.getChildren() != null) {
            for (List<CommentInfo.Report> reports : commentInfo.getChildren().values()) {
                // 累加每个 Report 的 `Stats.comments`
                totalBlanks += reports.stream()
                        .mapToInt(report -> report.getStats().getBlanks())
                        .sum();
            }
        }
        return totalBlanks;
    }


    /**
     * 静态检查问题通过大模型给出修改建议
     *
     * @param prompt
     * @return
     */
    private CheckCodeSuggestAIVo checkCodeSuggestFromAI(String prompt) {
        ChatBotVo.ChatRequest request = new ChatBotVo.ChatRequest();
        request.setModel(appConfig.getAiModel());
        request.setAppId(AI_CODE_SERVICE);
        request.setMax_tokens(4096);
        request.setMessages(ImmutableList.of(ChatBotVo.Message.builder().role("user").content(prompt).build()));
        ChatBotVo.ChatResponse chatResponse = chatbotFeign.chatCompletions(request);
        log.info("checkCodeSuggestFromAI chatCompletions req: {}, res: {}", request, chatResponse);
        if (isNotEmpty(chatResponse.getChoices())) {
            String codeBlock = extractFirstCodeBlockForJson(chatResponse.getChoices().get(0).getMessage().getContent());
            CheckCodeSuggestAIVo bean = JSONUtil.toBean(defaultIfBlank(codeBlock, "{}"), CheckCodeSuggestAIVo.class);
            bean.setSuggestCode(bean.getSuggestCode().replace("```cpp", "").replace("```json", "").replace("```", "")
                    .replace("修改后的代码内容:", "").replace("修改后的代码内容：", ""));
            return bean;
        }
        return null;
    }

    private Long saveCodeCheckTask2DB(CodeCheckTask task, boolean execTaskForJenkins) {
        //兼容不标准的project_code
        if (!task.getProjectCode().endsWith(GIT_POSTFIX)) {
            task.setProjectCode(task.getProjectCode() + GIT_POSTFIX);
        }
        transactionalService.newTransaction(() -> this.insert(task));

        //调用Jenkins接口执行任务
        if (execTaskForJenkins) {
            this.execTaskForJenkins(task);
        }
        return task.getId();
    }

    /**
     * 获取评论详细列表
     *
     * @param commentInfoMap 评论信息映射表
     * @param taskId         任务ID
     * @return 评论详细列表
     */
    private List<CodeCheckTaskDetail> getCommentDetailList(Map<String, CommentInfo> commentInfoMap, Long taskId) {
        return toStream(commentInfoMap) // 将评论信息映射表转化为流
                .flatMap(entry -> toStream(entry.getValue().getChildren()) // 将评论信息映射表的值获取评论报告列表并转化为流
                        .flatMap(it -> toStream(it.getValue()) // 将评论报告列表转化为流
                                .map(report -> {
                                    CommentInfo.Stats stats = report.getStats(); // 获取评论报告的统计信息
                                    CodeCheckTaskDetail detail = new CodeCheckTaskDetail(); // 创建一个CodeCheckTaskDetail对象
                                    detail.setId(KeyGenerate.generateId()); // 设置对象的ID
                                    detail.setTaskId(taskId); // 设置对象的任务ID
                                    detail.setType("COMMENT"); // 设置对象的类型为COMMENT
                                    detail.setBlanks(stats.getBlanks()); // 设置对象的空白行数
                                    detail.setCodes(stats.getCode()); // 设置对象的代码行数
                                    detail.setComments(stats.getComments()); // 设置对象的注释行数
                                    detail.setFilePath(report.getName()); // 设置对象的文件路径
                                    detail.setFileType(it.getKey()); // 设置对象的文件类型
                                    detail.setOffGrade(codeCommentRate(detail.getComments(), detail.getCodes(), detail.getBlanks()) ? 1 : 0); // 设置对象的不达标注释率标记
                                    detail.setCreateTime(new Date()); // 设置对象的创建时间
                                    return detail;
                                })))
                .collect(Collectors.toList()); // 将流转化为列表并返回
    }


    private List<CodeCheckTaskDetail> getCircleComplexityDetailList(List<CircleComplexityInfo> circleComplexityInfos, Long taskId) {
        return toStream(circleComplexityInfos).map(it -> {
            CodeCheckTaskDetail detail = new CodeCheckTaskDetail();
            detail.setId(KeyGenerate.generateId());
            detail.setTaskId(taskId);
            detail.setType("CIRCLE");
            detail.setCircleComplexity(it.getCircleComplexity());
            detail.setFilePath(it.getFilePath());
            detail.setFunName(it.getFunName());
            //是否达标 0：达标；1：不达标
            detail.setOffGrade(circleComplexity(it.getCircleComplexity(), it.getFilePath()) ? 1 : 0);
            detail.setCreateTime(new Date());
            return detail;
        }).collect(Collectors.toList());
    }

    /**
     * @param warningInfos 警告信息列表
     * @param taskId       任务ID
     * @return list<CodeCheckTaskDetailToDbVo> 警告详细列表
     * @brief 获取警告详细列表
     */
    private List<CodeCheckTaskDetailToDbVo> getWarningDetailList(List<WarningInfo> warningInfos, Long taskId) {
        // 将warningInfos按照filePath分组
        Map<String, List<WarningInfo>> groupedWarnings = warningInfos.stream()
                .collect(Collectors.groupingBy(WarningInfo::getFilePath));

        // 初始化结果列表
        List<CodeCheckTaskDetailToDbVo> result = new ArrayList<>();

        // 遍历分组后的warnings
        for (Map.Entry<String, List<WarningInfo>> entry : groupedWarnings.entrySet()) {
            // 打印taskId和当前分组的信息
            log.info("warning taskId: {} row: {}", taskId, JSONUtil.toJsonStr(entry));

            // 获取filePath和warnings列表
            String filePath = entry.getKey();
            List<WarningInfo> warnings = entry.getValue();

            // 初始化warningCount和errorCount
            int warningCount = 0;
            int errorCount = 0;

            // 遍历warnings列表
            for (WarningInfo warning : warnings) {
                // 根据warning类型增加对应计数
                if (warning.getWarningType().equals("warning")) {
                    warningCount++;
                } else if (warning.getWarningType().equals("error")) {
                    errorCount++;
                }
            }

            // 创建CodeCheckTaskDetail对象，并设置各个属性
            CodeCheckTaskDetail detail = new CodeCheckTaskDetail();
            detail.setId(KeyGenerate.generateId());
            detail.setTaskId(taskId);
            detail.setType("WARNING");
            detail.setWarning(warningCount);
            detail.setError(errorCount);
            detail.setFilePath(filePath);
            detail.setOffGrade((warningCount + errorCount) > 0 ? 1 : 0);
            detail.setCreateTime(new Date());

            // 创建CodeCheckTaskDetailToDbVo对象，并设置detail属性，并使用warnings列表创建warningDetails列表
            CodeCheckTaskDetailToDbVo vo = CodeCheckTaskDetailToDbVo.builder()
                    .detail(detail)
                    .warningDetails(
                            warnings.stream().map(it -> {
                                CodeCheckWarningDetail warningDetail = new CodeCheckWarningDetail();
                                warningDetail.setId(KeyGenerate.generateId());
                                warningDetail.setTaskDetailId(detail.getId());
                                warningDetail.setTaskId(detail.getTaskId());
                                warningDetail.setFilePath(filePath);
                                warningDetail.setWarningMessage(it.getWarningMessage());
                                warningDetail.setWarningType(it.getWarningType());
                                warningDetail.setLineNumber(it.getLineNumber());
                                warningDetail.setColumnNumber(it.getColumnNumber());
                                warningDetail.setCreateTime(new Date());
                                return warningDetail;
                            }).collect(Collectors.toList())
                    ).build();

            // 将vo添加到结果列表
            result.add(vo);
        }

        // 返回结果列表
        return result;
    }

    /**
     * @param circleComplexityInfoText 圆复杂度信息的文本
     * @param taskId                   任务ID
     * @return List<CircleComplexityInfo> 圆复杂度信息列表
     * @brief 分析圆复杂度信息
     */
    private List<CircleComplexityInfo> analysisCircleComplexityInfos(String circleComplexityInfoText, Long taskId) {
        if (StringUtils.isBlank(circleComplexityInfoText)) {
            return Collections.emptyList();
        }
        // 文本中包含了\n 这种特殊情况，先替换掉
        circleComplexityInfoText = circleComplexityInfoText.replace("\\n", "").replace("\\\n", "");
        // 将文本按换行符分割成字符串数组
        String[] list = circleComplexityInfoText.split("\n");
        // 创建一个原子整数计数器
        AtomicInteger count = new AtomicInteger();
        // 对数组进行流处理
        return Arrays.stream(list).map(it -> {
            // 获取原子整数的当前值并递增
            int andIncrement = count.getAndIncrement();
            // 打印日志，输出taskId、index和row
            log.info("circle taskId: {}  index: {} row: {}", taskId, andIncrement, it);
            // 将当前行按逗号分割成字符串数组
            String[] row = it.split(",");
            // 如果数组长度小于8，打印错误日志，输出taskId、index和row
            if (row.length < 8) {
                log.error("circle error taskId: {}  index: {} row: {}", taskId, andIncrement, it);
            }
            if (StringUtils.isNumeric(row[1]) && Integer.parseInt(row[1]) >= 10) {
                // 构建CircleComplexityInfo对象，并设置相应的属性值
                return CircleComplexityInfo.builder()
                        .circleComplexity(Integer.valueOf(row[1]))
                        .filePath(row[6].replace("\"", ""))
                        .funName(row[7].replace("\"", ""))
                        .build();
            } else {
                return null;
            }
        }).filter(Objects::nonNull).collect(Collectors.toList());
    }

    /**
     * 复杂度不符合要求的函数个数
     * 圈复杂度要求： .h <=10, .hpp <=10, .cpp <=10, .cxx <=10,  .cc <=10, .hxx<=10,.c++<=10,   .c <=15,   .java <=10
     * 其他暂时不参与计算
     *
     * @param circleComplexityInfos
     * @return
     */
    private int calcOffGradeCircleComplexity(List<CircleComplexityInfo> circleComplexityInfos) {
        // 判断传入的列表是否为空
        if (isEmpty(circleComplexityInfos)) {
            return 0;
        }
        // 使用流处理列表，过滤出满足条件的元素，并返回过滤后的元素数量
        return (int) circleComplexityInfos.stream()
                .filter(it -> circleComplexity(it.getCircleComplexity(), it.getFilePath()))
                .count();
    }


    /**
     * @param circleComplexity 圈复杂度阈值
     * @param filePath         文件路径
     * @return 如果给定的圈复杂度大于指定文件路径的圈复杂度阈值，则返回true；否则返回false
     * @brief 判断给定的圈复杂度是否大于指定文件路径的圈复杂度阈值
     */
    private static boolean circleComplexity(int circleComplexity, String filePath) {
        return circleComplexity > CIRCLE_COMPLEXITY_MAP.getOrDefault("." + extName(filePath), Integer.MAX_VALUE);
    }


    /**
     * @param comments 注释行数
     * @param codes    代码行数
     * @return 返回代码注释率是否小于30%
     * @brief 计算代码注释率
     */
    private static boolean codeCommentRate(int comments, int codes, int blank) {
        // 如果代码行数小于等于0，
        if (codes <= 0) {
            // 返回false
            return false;
        }
        // 返回代码行数与注释行数的比例乘以100是否小于30
        return (100.0D * comments / (codes)) < 30.0D;
    }

    /**
     * 处理jenkins 中 work path 动态变化的 情况
     * 例如：normal_webhook@12@tem => normal_webhook
     *
     * @param str
     * @return
     */
    private String replaceJenkinsWorkPath(String str, String projectName) {
        if (StringUtils.isBlank(str)) {
            return "";
        }
        if (StringUtils.isNotBlank(projectName)) {
            String[] dirs = str.split(projectName + "/");
            return dirs != null && dirs.length > 1 ? dirs[1] : str;
        }
        //理jenkins 中 work path 动态变化的 情况
        String path = str.replaceFirst("/normal_webhook[^/]*", "/normal_webhook");
        //把绝对路径修改为相对路径
        String[] dirs = path.split(appConfig.getJenkinsCloneDir());
        return dirs != null && dirs.length > 1 ? dirs[1] : path;
    }

}
