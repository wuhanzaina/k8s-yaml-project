/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddUserActivityVO.java
* 创建日期:2024-03-04
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
*
* 通过日期范围查询
*
*
* @author tiger
* @since 2024-03-04
*/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiModel(value = "DepartmentUsedStatisticReq", description = "部门使用插件情况统计")
public class RangeStatisticReq implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
    * 起始日期
    */
    @ApiModelProperty(value = "起始日期", required = true, position = 2)
    private String startDate;
    /**
    * 截止日期
    */
    @ApiModelProperty(value = "截止日期", required = true, position = 3)
    private String endDate;

}
