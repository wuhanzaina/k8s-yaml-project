/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddGitlabHookVO.java
* 创建日期:2024-03-26
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
*
* gitlab hook记录表
*
*
* @author tiger
* @since 2024-03-26
*/
@Data
@NoArgsConstructor
@ApiModel(value = "AddGitlabHookVO", description = "新增gitlab hook记录表")
public class AddGitlabHookVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
    * 内容
    */
    @ApiModelProperty(value = "内容", required = true, position = 2)
    private String content;
    /**
    * 状态
    */
    @ApiModelProperty(value = "状态", required = true, position = 3)
    @NotNull(message = "状态不能为空")
    private Integer status;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", required = true, position = 4)
    private Date createTime;

}
