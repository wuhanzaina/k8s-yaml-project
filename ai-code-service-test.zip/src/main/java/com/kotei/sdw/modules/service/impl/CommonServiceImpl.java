package com.kotei.sdw.modules.service.impl;

import cn.hutool.json.JSONUtil;
import com.kotei.sdw.api.ResultEnum;
import com.kotei.sdw.exception.BaseException;
import com.kotei.sdw.modules.config.AppConfig;
import com.kotei.sdw.modules.constant.CommonConst;
import com.kotei.sdw.modules.feign.SdwSystemFeign;
import com.kotei.sdw.modules.feign.vo.DeptRes.DeptVo;
import com.kotei.sdw.modules.feign.vo.DescendantDeptRes;
import com.kotei.sdw.modules.feign.vo.UserReq;
import com.kotei.sdw.modules.feign.vo.UserRes;
import com.kotei.sdw.modules.feign.vo.UserRes.UserVo;
import com.kotei.sdw.modules.service.CommonService;
import com.kotei.sdw.oss.bean.OSSFile;
import com.kotei.sdw.oss.storage.StorageFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @author tiger
 * @date 2024/3/5 17:17
 */
@Service
@Slf4j
public class CommonServiceImpl implements CommonService {
    @Autowired
    private SdwSystemFeign sdwSystemFeign;
    @Autowired
    private AppConfig appConfig;

    /**
     * @return 包含所有部门信息的列表
     * @brief 获取所有部门信息
     */
    @Override
    public List<DeptVo> getAllDepartment() {
        long now = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
        //缓存时间为空， 或者超过24小时
        if (CommonConst.cacheDepartmentTime == null || CommonConst.allDepartmentList == null || (CommonConst.cacheDepartmentTime + (appConfig.getCacheDepartmentTime() * 60 * 60 * 1000L)) < now) {
            //调用接口获取数据
            List<DeptVo> deptList = sdwSystemFeign.getAllDeptTree().getData();
            log.info("sdwSystemFeign get DeptTree {}", JSONUtil.toJsonStr(deptList));
            if (deptList == null || deptList.isEmpty()) {
                log.error("sdwSystemFeign get DeptTree is null.");
                return CommonConst.allDepartmentList;
            }
            //获取二级部门的人数
            for (DeptVo deptVo : deptList.get(0).getChildren()) {
                UserRes userRes = this.getUserList(UserReq.builder().deptId(deptVo.getId()).build());
                log.info("sdwSystemFeign get DeptStaff deptId: {}, deptName: {}, userRes: {}", deptVo.getId(), deptVo.getLabel(), JSONUtil.toJsonStr(userRes));
                if (userRes != null) {
                    deptVo.setStaffCount((int) userRes.getTotal());
                }
            }
            CommonConst.allDepartmentList = deptList;
            CommonConst.cacheDepartmentTime = now;
        }
        return CommonConst.allDepartmentList;
    }

    /**
     * @return 返回一个包含所有根部门信息的列表。
     * @brief 获取所有根部门信息
     * <p>
     * 该函数用于获取系统中所有的根部门信息。
     */

    @Override
    public List<DeptVo> getAllRootDepartment() {
        List<DeptVo> allDepartment = this.getAllDepartment();
        //第二层数据就是根节点部门
        List<DeptVo> root = allDepartment.get(0).getChildren();
        log.info("getAllRootDepartment rootDept: {}", root.stream().map(DeptVo::getLabel));
        return root;
    }

    /**
     * 根据任意depteId获取对应的根节点对象
     *
     * @param departmentId
     * @return
     */
    @Override
    public DeptVo getRootDepartment(Long departmentId) {
        DeptVo rootDept = findRootDept(departmentId, getAllRootDepartment());
        log.info("getRootDepartment departmentId: {}, rootDept: {}", departmentId, rootDept);
        return rootDept;
    }

    /**
     * 根据任意deptId获取部门信息
     *
     * @param departmentId
     * @return
     */
    @Override
    public DeptVo getDepartmentById(Long departmentId) {
        List<DeptVo> allDepartment = this.getAllDepartment();
        return findDepartmentById(departmentId, allDepartment);
    }

    /**
     * 根据当前节点ID获取自身和后代节点列表
     *
     * @param departmentId
     * @return
     */
    @Override
    public List<DeptVo> getDescendantDeptList(Long departmentId) {
        if (departmentId == null || departmentId <= 0) {
            return Collections.emptyList();
        }
        DescendantDeptRes res = this.sdwSystemFeign.getDescendantNodes(departmentId);
        if (res.getData() != null) {
            return res.getData().stream().map(it -> DeptVo.builder().id(it.getDeptId()).label(it.getDeptName()).build()).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    /**
     * @param userId 用户ID
     * @return UserVo 用户信息
     * @brief 获取指定用户的信息
     */
    @Override
    public UserVo getUserById(Long userId) {
        UserRes userRes = this.getUserList(UserReq.builder().userId(userId).build());
        if (userRes != null && !userRes.getRows().isEmpty()) {
            return userRes.getRows().get(0);
        }
        return null;
    }

    /**
     * @param userNo 用户编号
     * @return UserVo 用户信息
     * @brief 根据用户编号获取用户信息
     */
    @Override
    public UserVo getUserByNo(String userNo) {
        UserRes userRes = this.getUserList(UserReq.builder().userName(userNo).build());
        if (userRes != null && !userRes.getRows().isEmpty()) {
            return userRes.getRows().get(0);
        }
        return null;
    }

    /**
     * @param req 用户请求
     * @return 用户响应
     * @brief 获取用户列表
     */
    @Override
    public UserRes getUserList(UserReq req) {
        UserRes userRes = sdwSystemFeign.getUserList(req);
        log.info("getUserList req: {} userList: {}", JSONUtil.toJsonStr(req), JSONUtil.toJsonStr(userRes));
        return userRes;
    }

    /**
     * 文件上传
     *
     * @param multipartFile
     * @return
     */
    @Override
    public String upload(MultipartFile multipartFile) {
        String fileName = multipartFile.getOriginalFilename();
        // 文件上传
        OSSFile upload = null;
        try {
            upload = StorageFactory.build().upload(fileName, multipartFile.getInputStream());
            log.info("文件上传 fileName: {}, res: {}", fileName, JSONUtil.toJsonStr(upload));
        } catch (Exception e) {
            log.error(fileName + " 文件上传失败： ", e);
            throw new BaseException(ResultEnum.FILE_UPLOAD_ERROR.getCode(), fileName + " 文件上传失败.");
        }
        return upload.getPath();
    }

    /**
     * 从git用户名中获取工号
     *
     * @param gitUserName
     * @return
     */
    @Override
    public String getUserNoByGitUserName(String gitUserName) {
        // 使用正则表达式匹配工号
        String regex = "([A-Z]+\\d+|\\d+)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(gitUserName);
        // 查找第一个匹配项
        if (matcher.find()) {
            return matcher.group();
        }
        return "";
    }

    /**
     * @param departmentId 部门ID
     * @param departments  部门列表
     * @return 找到的部门对象，如果未找到则返回NULL
     * @brief 根据部门ID在部门列表中查找部门对象
     */
    private DeptVo findDepartmentById(Long departmentId, List<DeptVo> departments) {
        for (DeptVo department : departments) {
            // 遍历departments集合，每次循环将当前元素赋值给department变量
            if (department.getId().equals(departmentId)) {
                // 如果当前department的id与传入的departmentId相等
                return department;
                // 返回当前department
            } else if (department.getChildren() != null) {
                // 否则，如果当前department的子部门不为空
                DeptVo result = findDepartmentById(departmentId, department.getChildren());
                // 递归调用findDepartmentById方法，在当前department的子部门中继续查找departmentId
                if (result != null) {
                    // 如果返回的结果不为空
                    return result;
                    // 返回结果
                }
            }
        }
        return null;
        // 如果遍历完所有部门都没有找到对应的departmentId，则返回空值

    }

    /**
     * @param id      要查找的根部门的id
     * @param allDept 部门列表
     * @return DeptVo* 根部门的指针，如果找不到根部门则返回nullptr
     * @brief 根据给定的id和部门列表，查找根部门
     */
    private DeptVo findRootDept(Long id, List<DeptVo> allDept) {
        for (DeptVo dept : allDept) {
            if (dept.getId().equals(id)) {
                return dept;
            }
            if (this.findRootDept(id, dept)) {
                return dept;
            }
        }
        return null;
    }

    /**
     * @param id   要查找的部门ID
     * @param dept 部门对象
     * @return true 找到根部门
     * @return false 未找到根部门
     * @brief 递归查找根部门
     */
    private boolean findRootDept(Long id, DeptVo dept) {
        if (dept.getChildren() != null) {
            // 如果部门的子部门不为空
            for (DeptVo item : dept.getChildren()) {
                // 遍历子部门
                if (item.getId().equals(id)) {
                    // 如果子部门的ID等于目标ID
                    return true;
                    // 返回true
                } else {
                    if (findRootDept(id, item)) {
                        // 否则，递归调用findRootDept函数，传入目标ID和子部门
                        return true;
                        // 如果递归调用返回true，则返回true
                    }
                }
            }
        }
        return false;
        // 如果遍历完所有子部门都没有找到目标ID，则返回false

    }


}
