/**
* All rights Reserved, Designed By www.kote.net
* 项目名称:ai-code-service
* 文件名称:UserFeedbackMapper.java
* 创建日期:2024-03-11
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.mapper;

import com.kotei.sdw.modules.entity.UserFeedback;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
*
* 用户反馈表 Mapper
*
*
* @author tiger
* @since 2024-03-11
*/
@Mapper
public interface UserFeedbackMapper extends BaseMapper<UserFeedback> {

}
