/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:Project.java
* 创建日期:2024-04-02
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.entity;

import java.util.Date;
import com.kotei.sdw.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
*
* 项目列表
*
*
* @author tiger
* @since 2024-04-02
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("project")
@ApiModel(value = "Project", description = "项目列表")
public class Project extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 类型：SELF:自研项目; BUS:商务项目
    */
    @ApiModelProperty(value = "类型：SELF:自研项目; BUS:商务项目", position = 2)
    private String type;
    /**
    * 父项目工程名称
    */
    @ApiModelProperty(value = "父项目工程名称", position = 3)
    private String projectParent;
    /**
    * 项目工程名称
    */
    @ApiModelProperty(value = "项目工程名称", position = 4)
    private String projectName;
    /**
    * 项目工程标识
    */
    @ApiModelProperty(value = "项目工程标识", position = 5)
    private String projectCode;
    /**
    * git分支
    */
    @ApiModelProperty(value = "git分支", position = 6)
    private String branch;
    /**
    * git用户名
    */
    @ApiModelProperty(value = "git用户名", position = 7)
    private String gitUserName;
    /**
    * 负责人
    */
    @ApiModelProperty(value = "负责人", position = 8)
    private Long userId;
    /**
    * 负责人名称
    */
    @ApiModelProperty(value = "负责人名称", position = 9)
    private String userName;
    /**
    * git密码
    */
    @ApiModelProperty(value = "git密码", position = 10)
    private String gitUserPwd;
    /**
    * jenkins上配置的git的token
    */
    @ApiModelProperty(value = "jenkins上配置的git的token", position = 11)
    private String taskGitToken;
    /**
    * 负责人工号
    */
    @ApiModelProperty(value = "负责人工号", position = 12)
    private String userNo;
    /**
    * PM
    */
    @ApiModelProperty(value = "PM", position = 13)
    private Long pmUserId;
    /**
    * PM名称
    */
    @ApiModelProperty(value = "PM名称", position = 14)
    private String pmUserName;
    /**
    * PM工号
    */
    @ApiModelProperty(value = "PM工号", position = 15)
    private String pmUserNo;
    /**
    * int
    */
    @ApiModelProperty(value = "int", position = 16)
    private Integer scheduleStatus;
    /**
    * 状态 0：无效；1：有效
    */
    @ApiModelProperty(value = "状态 0：无效；1：有效", position = 17)
    private Integer status;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", position = 18)
    private Date createTime;
    /**
    * 项目排除扫描的路径
    */
    @ApiModelProperty(value = "项目排除扫描的路径", position = 18)
    private String excludeScanPaths;


}
