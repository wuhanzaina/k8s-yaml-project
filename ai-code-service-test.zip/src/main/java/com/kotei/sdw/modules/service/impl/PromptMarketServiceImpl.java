/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:PromptMarketServiceImpl.java
 * 创建日期:2024-05-14
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.entity.PromptMarket;
import com.kotei.sdw.modules.entity.PromptTemplate;
import com.kotei.sdw.modules.mapper.PromptMarketMapper;
import com.kotei.sdw.modules.service.PromptMarketService;
import com.kotei.sdw.modules.service.PromptTemplateService;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.security.utils.SecurityUtils;
import com.kotei.sdw.system.api.model.LoginUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 *
 * 提示词市场 ServiceImpl
 *
 *
 * @author tiger
 * @since 2024-05-14
 */
@Service
public class PromptMarketServiceImpl extends BaseServiceImpl<PromptMarket> implements PromptMarketService {
    @Autowired
    private PromptMarketMapper promptMarketMapper;
    @Autowired
    private PromptTemplateService promptTemplateService;

    @Override
    protected BaseMapper<PromptMarket> getMapper() {
        return promptMarketMapper;
    }

    @Override
    public PromptMarket get(Long id) {
        return promptMarketMapper.selectById(id);
    }

    @Override
    public IPage<PromptMarket> getList(PageVO<PromptMarket> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<PromptMarket> lambdaQueryWrapper = Wrappers.lambdaQuery(PromptMarket.class)
                .like(params.containsKey("name") && StringUtils.isNotBlank((String) params.get("name")), PromptMarket::getName, "%" + params.get("name") + "%")
                .eq(PromptMarket::getStatus, 1)
                .eq(params.containsKey("shareCount"), PromptMarket::getShareCount, params.get("shareCount"))
                .eq(params.containsKey("language"), PromptMarket::getLanguage, params.get("language"))
                .eq(params.containsKey("intro"), PromptMarket::getIntro, params.get("intro"))
                .eq(params.containsKey("context"), PromptMarket::getContext, params.get("context"))
                .eq(params.containsKey("createrId"), PromptMarket::getCreaterId, params.get("createrId"))
                .eq(params.containsKey("createrName"), PromptMarket::getCreaterName, params.get("createrName"))
                .eq(params.containsKey("createTime"), PromptMarket::getCreateTime, params.get("createTime"))
                .eq(params.containsKey("modifierId"), PromptMarket::getModifierId, params.get("modifierId"))
                .eq(params.containsKey("modifierName"), PromptMarket::getModifierName, params.get("modifierName"))
                .eq(params.containsKey("modifyTime"), PromptMarket::getModifyTime, params.get("modifyTime"));
        List<String> languageList = (List<String>) params.get("languageList");
        if (CollUtil.isNotEmpty(languageList)) {
            lambdaQueryWrapper.in(PromptMarket::getLanguage, languageList);
        }
        lambdaQueryWrapper.last(params.containsKey("orderBy") && StringUtils.isNotBlank((String) params.get("orderBy")), " order by " + params.get("orderBy") + " desc ");
        return promptMarketMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long insert(PromptMarket entity) {
        entity.setId(KeyGenerate.generateId());
        if (entity.getCreateTime() == null) {
            entity.setCreateTime(new Date());
        }
        promptMarketMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        promptMarketMapper.deleteById(id);
    }

    @Override
    public void update(PromptMarket entity) {
        promptMarketMapper.updateById(entity);
    }

    @Override
    public PromptMarket getByPtId(Long ptId) {
        LambdaQueryWrapper<PromptMarket> lambdaQueryWrapper = Wrappers.lambdaQuery(PromptMarket.class)
                .eq(PromptMarket::getPtId, ptId);
        lambdaQueryWrapper.last(" limit 1");
        return promptMarketMapper.selectOne(lambdaQueryWrapper);
    }
    @Override
    public PromptMarket getByName(String name) {
        LambdaQueryWrapper<PromptMarket> lambdaQueryWrapper = Wrappers.lambdaQuery(PromptMarket.class)
                .eq(PromptMarket::getName, name);
        lambdaQueryWrapper.last(" limit 1");
        return promptMarketMapper.selectOne(lambdaQueryWrapper);
    }

    /**
     * 市场中的提示词应用到我的提示词列表
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void used(Long id) {
        PromptMarket promptMarket = this.get(id);
        PromptTemplate ptDb = promptTemplateService.getByMarketIdAndUserId(id, SecurityUtils.getLoginUser().getUserid());
        if (ptDb == null) {
            PromptTemplate pt = getPromptTemplate(promptMarket);
            this.promptTemplateService.insert(pt);
        } else {
            PromptTemplate pt = new PromptTemplate();
            pt.setId(ptDb.getId());
            pt.setStatus(1);
            pt.setContext(promptMarket.getContext());
            pt.setIntro(promptMarket.getIntro());
            pt.setName(promptMarket.getName());
            this.promptTemplateService.update(pt);
        }
        //更新PM被应用的次数
        PromptMarket updatePm = new PromptMarket();
        updatePm.setId(promptMarket.getId());
        updatePm.setShareCount(promptMarket.getShareCount() + 1);
        this.promptMarketMapper.updateById(updatePm);
    }

    private static PromptTemplate getPromptTemplate(PromptMarket promptMarket) {
        // 获取当前登录用户信息
        LoginUser loginUser = SecurityUtils.getLoginUser();
        PromptTemplate pt = new PromptTemplate();
        pt.setCode("");
        pt.setName(promptMarket.getName() + "_" + loginUser.getSysUser().getNickName());
        pt.setStatus(1);
        pt.setPlayRole("");
        pt.setShare(0);
        pt.setMarketId(promptMarket.getId());
        pt.setLanguage(promptMarket.getLanguage());
        pt.setIntro(promptMarket.getIntro());
        pt.setContext(promptMarket.getContext());
        pt.setCreaterId(loginUser.getUserid());
        pt.setCreaterName(loginUser.getSysUser().getNickName());
        pt.setCreateTime(new Date());
        return pt;
    }

}
