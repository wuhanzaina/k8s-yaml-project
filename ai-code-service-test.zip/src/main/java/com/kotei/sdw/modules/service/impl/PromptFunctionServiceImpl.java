package com.kotei.sdw.modules.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.kotei.sdw.constant.GlobalConstant;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.entity.PromptFunction;
import com.kotei.sdw.modules.mapper.PromptFunctionMapper;
import com.kotei.sdw.modules.service.PromptFunctionService;
import com.kotei.sdw.modules.vo.AddPromptTemplateVO;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.security.utils.SecurityUtils;
import com.kotei.sdw.system.api.model.LoginUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class PromptFunctionServiceImpl extends BaseServiceImpl<PromptFunction> implements PromptFunctionService {

    @Autowired
    PromptFunctionMapper promptFunctionMapper;

    @Override
    protected BaseMapper<PromptFunction> getMapper() {
        return promptFunctionMapper;
    }

    @Override
    public PromptFunction get(Long id) {
        return promptFunctionMapper.selectById(id);
    }

    @Override
    @Transactional
    public Long insert(PromptFunction entity) {
        entity.setId(KeyGenerate.generateId());
        LoginUser loginUser = SecurityUtils.getLoginUser();
        entity.setCreaterId(loginUser.getUserid());
        entity.setCreaterName(loginUser.getSysUser().getNickName());
        promptFunctionMapper.insert(entity);
        return entity.getId();
    }

    @Override
    @Transactional
    public void update(PromptFunction entity) {
        LoginUser loginUser = SecurityUtils.getLoginUser();
        entity.setModifierId(loginUser.getUserid());
        entity.setModifierName(loginUser.getSysUser().getNickName());
        entity.setModifyTime(new Date());
        promptFunctionMapper.updateById(entity);
    }

    @Override
    public List<PromptFunction> getPromptFunctionsByUser() {
        LoginUser loginUser = SecurityUtils.getLoginUser();
        return promptFunctionMapper.getPromptFunctionsByUser(loginUser.getUserid());
    }

    @Override
    @Transactional
    public Long saveOrUpdate(AddPromptTemplateVO add) {
        LoginUser loginUser = SecurityUtils.getLoginUser();
        PromptFunction promptFunction = promptFunctionMapper.getPromptFunction(add.getName(), loginUser.getUserid());
        if (promptFunction == null) {
            // 新增
            PromptFunction pf = new PromptFunction();
            BeanUtil.copyProperties(add, pf);
            pf.setCode("");
            pf.setStatus(GlobalConstant.YES);
            pf.setCreateTime(new Date());
            pf.setId(KeyGenerate.generateId());
            return this.insert(pf);
        } else {
            // 编辑
            promptFunction.setContext(add.getContext());
            this.update(promptFunction);
            return promptFunction.getId();
        }
    }
}
