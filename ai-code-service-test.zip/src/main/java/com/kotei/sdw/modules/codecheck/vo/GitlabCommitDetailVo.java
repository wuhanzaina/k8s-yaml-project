package com.kotei.sdw.modules.codecheck.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class GitlabCommitDetailVo {
    @JsonProperty("id")
    @ApiModelProperty(value = "提交ID", notes = "提交的唯一标识符")
    private String commitId;

    @JsonProperty("short_id")
    @ApiModelProperty(value = "短提交ID", notes = "提交ID的简短版本")
    private String shortCommitId;

    @JsonProperty("created_at")
    @ApiModelProperty(value = "创建时间", notes = "提交创建的时间戳")
    private String createdAt;

    @JsonProperty("parent_ids")
    @ApiModelProperty(value = "父提交ID列表", notes = "父提交的ID列表")
    private List<String> parentIds;

    @ApiModelProperty(value = "标题", notes = "提交的标题")
    private String title;

    @ApiModelProperty(value = "消息", notes = "提交的消息")
    private String message;

    @JsonProperty("author_name")
    @ApiModelProperty(value = "作者姓名", notes = "提交作者的姓名")
    private String authorName;

    @JsonProperty("author_email")
    @ApiModelProperty(value = "作者邮箱", notes = "提交作者的邮箱")
    private String authorEmail;

    @JsonProperty("authored_date")
    @ApiModelProperty(value = "作者时间", notes = "提交作者的时间戳")
    private String authoredDate;

    @JsonProperty("committer_name")
    @ApiModelProperty(value = "提交者姓名", notes = "提交者的姓名")
    private String committerName;

    @JsonProperty("committer_email")
    @ApiModelProperty(value = "提交者邮箱", notes = "提交者的邮箱")
    private String committerEmail;

    @JsonProperty("committed_date")
    @ApiModelProperty(value = "提交时间", notes = "提交的时间戳")
    private String committedDate;

    @ApiModelProperty(value = "Web URL", notes = "提交在Web界面中的URL")
    private String webUrl;

    @ApiModelProperty(value = "统计信息", notes = "提交的统计信息")
    private CommitStats stats;

    @JsonProperty("project_id")
    @ApiModelProperty(value = "项目ID", notes = "项目的ID")
    private int projectId;

    @Data
    public static class CommitStats {
        @ApiModelProperty(value = "新增行数", notes = "提交中的新增行数")
        private int additions;

        @ApiModelProperty(value = "删除行数", notes = "提交中的删除行数")
        private int deletions;

        @ApiModelProperty(value = "总行数", notes = "提交中的总行数")
        private int total;

        // Getters and setters
    }

}

