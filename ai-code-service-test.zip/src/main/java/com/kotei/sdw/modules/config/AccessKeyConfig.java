package com.kotei.sdw.modules.config;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel(value = "AccessKeyConfig", description = "git相关配置")
public class AccessKeyConfig {
    /**
     * git key值
     */
    private String accessKey;
    /**
     * 替换地址
     */
    private String replace;
}
