/**
 * All rights Reserved, Designed By  www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:FunctionUsageVO
 * 创建日期:2024/3/6
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 **/
package com.kotei.sdw.modules.statistic.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 *
 * @author fox
 * @date 2024/3/6
 **/
@Data
@NoArgsConstructor
@ApiModel(value = "FunctionUsageVO", description = "功能使用情况")
public class FunctionUsageVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 类型.0:代码生成 1:代码纠错 2:代码解释 3:代码注释
     */
    @ApiModelProperty(value = "类型. 0：使用次数；1：功能采纳率；2：功能点赞次数；3：采纳代码行数；", position = 4)
    private Integer type;
    /**
     * 使用次数
     */
    @ApiModelProperty(value = "代码生成", position = 4)
    private String createCode;
    /**
     * 使用次数
     */
    @ApiModelProperty(value = "代码解释", position = 4)
    private String interpretation;
    /**
     * 使用次数
     */
    @ApiModelProperty(value = "添加注释 - 函数", position = 4)
    private String functionAnnotation;
    /**
     * 使用次数
     */
    @ApiModelProperty(value = "添加注释 - 逐行", position = 4)
    private String lineAnnotation;
    /**
     * 使用次数
     */
    @ApiModelProperty(value = "智能代码问答", position = 4)
    private String ask;

    public FunctionUsageVO (Integer type){
        this.type = type;
    }
}
