package com.kotei.sdw.modules.ut.vo;

/**
 * @author tiger
 * @date 2024/3/27 13:47
 */

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiModel(value = "GenerateTestCasesFromFunVo", description = "输入函数内容由大模型生成结构化UT")
public class GenerateTestCasesFromFunVo implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 项目标识
     */
    @ApiModelProperty(value = "项目标识(512)", required = true, position = 1)
    @NotNull(message = "项目标识不能为空")
    private String projectCode;

    /**
     * 分支
     */
    @ApiModelProperty(value = "分支(128)", required = true, position = 2)
    @NotNull(message = "分支不能为空")
    private String branch;

    /**
     * 源码文件相对地址
     */
    @ApiModelProperty(value = "源码文件相对地址(128)", required = true, position = 3)
    @NotNull(message = "源码文件相对地址不能为空")
    private String filePath;

    /**
     * 目标函数
     */
    @ApiModelProperty(value = "目标函数", required = true, position = 3)
    @NotNull(message = "目标函数不能为空")
    private String fun;

    /**
     * 任务类型
     */
    @ApiModelProperty(value = "任务类型 0：AI生成测试用例；1: AI补充测试用例", required = true, position = 3)
    private Integer type = 0;

    //AI补充测试用例-来源函数ID
    private Long codeCovFunId = 0L;
    /**
     * 批量生成UT任务ID
     */
    @ApiModelProperty(value = "批量生成UT任务ID", required = true, position = 4)
    private Long batchId = 0L;

    /**
     * 是否异步执行
     */
    @ApiModelProperty(value = "1:异步执行；2:同步执行", required = true, position = 5)
    private Integer async = 1;

}


