/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:CodeCovFun.java
* 创建日期:2024-04-22
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.entity;

import java.math.BigDecimal;
import com.kotei.sdw.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
*
* 代码覆盖率函数表
*
*
* @author tiger
* @since 2024-04-22
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("code_cov_fun")
@ApiModel(value = "CodeCovFun", description = "代码覆盖率函数表")
public class CodeCovFun extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 任务ID
    */
    @ApiModelProperty(value = "任务ID", position = 2)
    private Long covTaskId;
    /**
    * 文件路径
    */
    @ApiModelProperty(value = "文件路径", position = 3)
    private String filePath;
    /**
    * 函数内容
    */
    @ApiModelProperty(value = "函数名称", position = 4)
    private String funName;
    /**
    * 函数内容
    */
    @ApiModelProperty(value = "函数内容", position = 5)
    private String fun;
    /**
    * 代码覆盖率
    */
    @ApiModelProperty(value = "代码覆盖率", position = 6)
    private BigDecimal blocksPercent;
    /**
    * 行覆盖率
    */
    @ApiModelProperty(value = "行覆盖率", position = 6)
    private BigDecimal linePercent;
    /**
    * 分支覆盖率
    */
    @ApiModelProperty(value = "分支覆盖率", position = 6)
    private BigDecimal branchPercent;
    /**
    * 执行次数
    */
    @ApiModelProperty(value = "执行次数", position = 7)
    private Integer executionCount;
    /**
    * 函数起始行号
    */
    @ApiModelProperty(value = "函数起始行号", position = 8)
    private Integer lineNo;
    /**
    * 函数占用行数
    */
    @ApiModelProperty(value = "函数占用行数", position = 9)
    private Integer lineNum;
    /**
    * 返回执行次数
    */
    @ApiModelProperty(value = "返回执行次数", position = 10)
    private Integer returnedCount;


}
