package com.kotei.sdw.modules.feign.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;
import java.util.List;

/**
 * @author tiger
 * @date 2024/3/5 17:18
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "DeptVo", description = "用户部门数据")
public class DeptRes implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 列表数据 */
    private List<DeptVo> data;

    /** 消息状态码 */
    private int code;

    /** 消息内容 */
    private String msg;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class DeptVo implements Serializable {

        private Long id;
        /**
         * 部门名称
         */
        @ApiModelProperty(value = "部门名称", position = 4)
        private String label;
        /**
         * 员工数量
         */
        @ApiModelProperty(value = "员工数量", position = 5)
        private Integer staffCount;

        private List<DeptVo> children;
    }

}
