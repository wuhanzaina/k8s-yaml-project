package com.kotei.sdw.modules.codecheck.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * @author tiger
 * @date 2024/3/27 10:21
 */
public class CircleComplexityConst {

    //圈复杂度要求： .h <=10, .hpp <=10, .cpp <=10, .cxx <=10,  .cc <=10, .hxx<=10,.c++<=10,   .c <=15,  .java <=10 ,js <=15
    public static final Map<String, Integer> CIRCLE_COMPLEXITY_MAP = new HashMap<>();

    static {
        CIRCLE_COMPLEXITY_MAP.put(".h", 15);
        CIRCLE_COMPLEXITY_MAP.put(".hpp", 15);
        CIRCLE_COMPLEXITY_MAP.put(".cpp", 15);
        CIRCLE_COMPLEXITY_MAP.put(".cxx", 15);
        CIRCLE_COMPLEXITY_MAP.put(".cc", 15);
        CIRCLE_COMPLEXITY_MAP.put(".hxx", 15);
        CIRCLE_COMPLEXITY_MAP.put(".c++", 15);
        CIRCLE_COMPLEXITY_MAP.put(".c", 15);
        CIRCLE_COMPLEXITY_MAP.put(".java", 15);
        CIRCLE_COMPLEXITY_MAP.put(".py", 15);
        CIRCLE_COMPLEXITY_MAP.put(".js", 15);
        CIRCLE_COMPLEXITY_MAP.put(".ts",15);
    }
}
