/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddUserActivityVO.java
* 创建日期:2024-03-04
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
*
* 用户活跃度统计表
*
*
* @author tiger
* @since 2024-03-04
*/
@Data
@NoArgsConstructor
@ApiModel(value = "AddUserActivityVO", description = "新增用户活跃度统计表")
public class AddUserActivityVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
    * 用户ID
    */
    @ApiModelProperty(value = "用户ID", required = true, position = 2)
    @NotNull(message = "用户ID不能为空")
    @Min(value = 0, message = "用户ID不能小于0")
    private Long userId;
    /**
    * 日期
    */
    @ApiModelProperty(value = "日期(10)", required = true, position = 3)
    private String activityDate;
    /**
    * 部门ID
    */
    @ApiModelProperty(value = "部门ID", required = true, position = 4)
    @NotNull(message = "部门ID不能为空")
    @Min(value = 0, message = "部门ID不能小于0")
    private Long departmentId;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", required = true, position = 5)
    private Date createTime;

}
