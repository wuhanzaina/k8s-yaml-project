/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:FunctionUsageService.java
* 创建日期:2024-03-05
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.statistic.service;

import com.kotei.sdw.modules.statistic.entity.FunctionUsage;
import com.kotei.sdw.modules.statistic.vo.*;
import com.kotei.sdw.mvc.service.BaseService;

import java.util.Collection;
import java.util.List;

/**
*
* 功能使用情况 Service
*
*
* @author hk
* @since 2024-03-05
*/
public interface FunctionUsageService extends BaseService<FunctionUsage> {
    /**
     * 新增
     * @param addFunctionUsageVO
     * @return
     */
    Long insertOrUpdate(AddFunctionUsageVO addFunctionUsageVO);

    /**
     * 根据用户ID、日期和类型查询
     * @param useDate
     * @param userId
     * @return
     */
    FunctionUsage getByUseDateAndUserIdAndType(String useDate,Long userId,Integer type);

    /**
     * 列表查询
     * @param deptId
     * @param startDate
     * @param endDate
     * @return
     */
    Collection<FunctionUsageVO> list(Long deptId, String startDate, String endDate);

    /**
     * 分组查询
     * @param startDate
     * @param endDate
     * @return
     */
    List<GroupFunctionUsageVO> groupList(String startDate,String endDate);

    List<UsedTop10Vo> usedTop10(RangeStatisticReq req);

    /**
     * 采纳率 top10
     * @param req
     * @return
     */
    List<UsedTop10Vo> adoptionTop10(RangeStatisticReq req);

    /**
     * 开发人员提交代码周趋势分析-采纳大模型代码行数
     * @param beginWeekBeginDateStr
     * @param endWeekBeginDateStr
     * @param userId
     * @return
     */
    List<LineVO>  adoptionList(String beginWeekBeginDateStr, String endWeekBeginDateStr, Long userId);
    /**
     * 使用插件情况分析-整体概览
     * 今日、本月活跃用户数，累计活跃用户数
     * 今日、本月活跃用户数，累计使用次数
     *
     * @return
     */
    OverviewUserStatisticVo findOverviewUserStatistic();
}
