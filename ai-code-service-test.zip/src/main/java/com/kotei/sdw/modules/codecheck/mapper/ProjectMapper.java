/**
* All rights Reserved, Designed By www.kote.net
* 项目名称:ai-code-service
* 文件名称:ProjectMapper.java
* 创建日期:2024-04-02
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.mapper;

import com.kotei.sdw.modules.codecheck.entity.Project;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
*
* 项目列表 Mapper
*
*
* @author tiger
* @since 2024-04-02
*/
@Mapper
public interface ProjectMapper extends BaseMapper<Project> {

}
