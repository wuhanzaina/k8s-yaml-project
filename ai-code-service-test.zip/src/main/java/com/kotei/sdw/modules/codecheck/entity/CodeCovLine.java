/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:CodeCovLine.java
* 创建日期:2024-04-22
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.entity;

import com.kotei.sdw.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
*
* 代码覆盖率行记录表
*
*
* @author tiger
* @since 2024-04-22
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("code_cov_line")
@ApiModel(value = "CodeCovLine", description = "代码覆盖率行记录表")
public class CodeCovLine extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 任务ID
    */
    @ApiModelProperty(value = "任务ID", position = 2)
    private Long covTaskId;
    /**
    * 任务函数ID
    */
    @ApiModelProperty(value = "任务函数ID", position = 3)
    private Long covFunId;
    /**
    * 行号
    */
    @ApiModelProperty(value = "行号", position = 4)
    private Integer lineNumber;
    /**
     * 行执行次数
     */
    @ApiModelProperty(value = "行执行次数", position = 4)
    private Integer count;
    /**
    * 分支数
    */
    @ApiModelProperty(value = "分支数", position = 4)
    private Integer branchCount;
    /**
    * 未覆盖分支数
    */
    @ApiModelProperty(value = "未覆盖分支数", position = 4)
    private Integer offBranchCount;

    @ApiModelProperty(value = "分支详细内容JSON数据[{\"blockno\":0,\"count\":0,\"fallthrough\":false,\"throw\":false}]", position = 4)
    private String branches;

}
