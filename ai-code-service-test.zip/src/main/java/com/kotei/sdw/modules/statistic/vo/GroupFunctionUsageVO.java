/**
 * All rights Reserved, Designed By  www.kotei-info.com
 * 项目名称:ai-code-service
 * 文件名称:GroupFunctionUsageVO
 * 创建日期:2024/3/6
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 **/
package com.kotei.sdw.modules.statistic.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Collection;

/**
 * 功能使用情况-分组
 * @author fox
 * @date 2024/3/6
 **/
@Data
@NoArgsConstructor
@ApiModel(value = "GroupFunctionUsageVO", description = "功能使用情况-分组")
public class GroupFunctionUsageVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 部门信息
     */
    @ApiModelProperty(value = "部门信息", position = 3)
    private String deptName;
    /**
     * 统计信息
     */
    @ApiModelProperty(value = "统计信息", position = 4)
    private Collection<FunctionUsageVO> list;
}
