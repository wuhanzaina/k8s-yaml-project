package com.kotei.sdw.modules.codecheck.service.impl;


import com.kotei.sdw.modules.codecheck.entity.Project;
import com.kotei.sdw.modules.codecheck.entity.ProjectsCode;
import com.kotei.sdw.modules.codecheck.mapper.ProjectsCodeMapper;
import com.kotei.sdw.modules.codecheck.service.ProjectsCodeService;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author zhengyaow
 * @description 针对表【projects_code】的数据库操作Service实现
 * @createDate 2024-11-25 15:54:19
 */
@Service
public class ProjectsCodeServiceImpl extends BaseServiceImpl<ProjectsCode> implements ProjectsCodeService {

    @Autowired
    private ProjectsCodeMapper projectsCodeMapper;

    @Override
    protected BaseMapper<ProjectsCode> getMapper() {
        return null;
    }


    @Override
    public List<ProjectsCode> getProjectsCodeList() {
        return projectsCodeMapper.selectList(null);
    }
}




