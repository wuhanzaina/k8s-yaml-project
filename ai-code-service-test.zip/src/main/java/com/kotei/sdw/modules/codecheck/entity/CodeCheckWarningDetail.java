/**
* All rights Reserved, Designed By www.kote.com
* 项目名称:ai-code-service
* 文件名称:CodeCheckWarningDetail.java
* 创建日期:2024-03-28
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.entity;

import java.util.Date;
import com.kotei.sdw.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
*
* 代码静态扫描警告明细表
*
*
* @author tiger
* @since 2024-03-28
*/
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("code_check_warning_detail")
@ApiModel(value = "CodeCheckWarningDetail", description = "代码静态扫描警告明细表")
public class CodeCheckWarningDetail extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
    * 任务ID
    */
    @ApiModelProperty(value = "任务ID", position = 2)
    private Long taskId;
    /**
    * 任务明细ID
    */
    @ApiModelProperty(value = "任务明细ID", position = 3)
    private Long taskDetailId;
    /**
    * 文件地址
    */
    @ApiModelProperty(value = "文件地址", position = 4)
    private String filePath;
    /**
    * 行号
    */
    @ApiModelProperty(value = "行号", position = 5)
    private Integer lineNumber;
    /**
    * 列号
    */
    @ApiModelProperty(value = "列号", position = 6)
    private Integer columnNumber;
    /**
    * 警告类型
    */
    @ApiModelProperty(value = "警告类型", position = 7)
    private String warningType;
    /**
    * 警告信息
    */
    @ApiModelProperty(value = "警告信息", position = 8)
    private String warningMessage;
    /**
    * 状态
    */
    @ApiModelProperty(value = "状态", position = 9)
    private Integer status = 0;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", position = 10)
    private Date createTime;


}
