/**
* All rights Reserved, Designed By www.kotei-info.com
* 项目名称:ai-code-service
* 文件名称:AddGitlabCommitVO.java
* 创建日期:2024-04-09
* 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
* 警告:本内容仅限于光庭内部传阅。
*/
package com.kotei.sdw.modules.codecheck.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
*
* commit记录表
*
*
* @author tiger
* @since 2024-04-09
*/
@Data
@NoArgsConstructor
@ApiModel(value = "AddGitlabCommitVO", description = "新增commit记录表")
public class AddGitlabCommitVO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
    * gitlab对应的id
    */
    @ApiModelProperty(value = "gitlab对应的id(32)", required = true, position = 2)
    private String commitId;
    /**
    * gitlab对应的url
    */
    @ApiModelProperty(value = "gitlab对应的url(128)", required = true, position = 3)
    private String url;
    /**
    * 用户名
    */
    @ApiModelProperty(value = "用户名(32)", required = true, position = 4)
    private String authorName;
    /**
    * 邮箱
    */
    @ApiModelProperty(value = "邮箱(32)", required = true, position = 5)
    private String authorEmail;
    /**
    * 项目工程标识
    */
    @ApiModelProperty(value = "项目工程标识(512)", required = true, position = 6)
    private String projectCode;
    /**
    * 分支
    */
    @ApiModelProperty(value = "分支(128)", required = true, position = 7)
    private String branch;
    /**
    * 内容
    */
    @ApiModelProperty(value = "内容", required = true, position = 8)
    private String content;
    /**
    * 状态
    */
    @ApiModelProperty(value = "状态", required = true, position = 9)
    private Integer status;
    /**
    * 创建时间
    */
    @ApiModelProperty(value = "创建时间", required = true, position = 10)
    private Date createTime;

}
