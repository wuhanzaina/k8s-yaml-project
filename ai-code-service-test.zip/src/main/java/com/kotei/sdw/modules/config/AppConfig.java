package com.kotei.sdw.modules.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@ConfigurationProperties(prefix = "app")
@Data
public class AppConfig {

    /**
     * 部门缓存时间，单位小时
     */
    private long cacheDepartmentTime = 24;

    /**
     * gitlab Hook Url
     */
    private String gitlabHookUrl = "https://172.16.0.120/astri/RI-SmartDevelopII/SmartCodeWG_code/ai-code-web/hooks/1490/hook_logs/163232";

    /**
     * jenkins 执行静态代码扫描任务地址
     */
    private String execCodeCheckUrl = "http://192.168.52.165:9095/generic-webhook-trigger/invoke";

    /**
     * 定时触发生成代码静态扫描任务
     */
    private int triggerCodeStaticScan = 1;

    /**
     * 定时扫描启动待执行的任务
     */
    private int scanAndExecuteTask = 1;

    /**
     * 项目clone的base目录
     */
    private String gitCloneDir;

    /**
     * Jenkins扫描代码的时候，是绝对路径，系统中统一需改为路径
     */
    private String jenkinsCloneDir = "normal_webhook/";

    /**
     * 被扫描源码文件目录地址
     */
    private String codeCheckSourcePath = "/home/ai_project_git/code_check/bus_source.cpp";

    /**
     * ai-code-python 服务地址
     */
    private String pythonBasePath;

    /**
     * 补充类型定义
     */
    private Map<String, String> varSupplementMap = new HashMap<String, String>() {{
        this.put("PhmCharType", "using PhmCharType=uint8_t;");
    }};

    /**
     * 排除类型定义
     */
    private List<String> excludeVarSupplement = new ArrayList<String>() {{
        this.add("Deserializer");
        this.add("Serializer");
    }};


    /**
     * 大模型类型
     * gpt-3.5-turbo-16k ,
     * gpt-3.5-turbo ,
     * gpt4-4k,
     * deepseek-coder
     */
    private String aiModel = "deepseek-coder";

    private String dsCodeVersion = "v1.7.5";

    /**
     * 生成ut测试用例JSON格式的提示词
     */
    private String genTestCaseJsonPrompt = "你是C/C++ UT高手，现需要分析被测函数生成代码覆盖率达100%的测试用例。\n要求如下：\n" +
            "1.请分析被测函数的代码逻辑，生成入参、桩函数、条件分支、循环分支、其他影响代码逻辑的代码元素组合，具体内容请参考JSON格式模板；\n" +
            "2.如果被测函数涉及到了这些字段就要填写；\n" +
            "3.被测函数的入参放入functionParameters数组字段；\n" +
            "4.被调用函数列表中需要打桩的请放入stubbedFunctions数组字段；\n" +
            "5.如果被测函数中使用了public成员变量，那么把该变量赋值的逻辑代码放入publicMemberVariables数组字段；\n" +
            "6.每个测试用例的场景描述信息放入description字段；\n"+
            "7.确保被测函数的代码行覆盖率和分支覆盖率达到100%，生成所有场景的测试用例，返回内容不需要解释说明，直接返回JSON结构，放在JSON数组中，并使用Markdown代码块```json包裹。";
    /**
     * 生成UT测试用例代码的提示词
     */
    private String genTestCodeCasePrompt = "你是C/C++ UT高手，现需要分析被测函数根据已经编写完成的测试用例生成代码覆盖率达100%的其他测试用例代码。\n" +
            "要求如下：\n" +
            " 1.请分析被测函数的代码逻辑，分析入参、桩函数、条件分支、循环分支、其他影响代码逻辑的代码元素组合；\n" +
            " 2.TEST_CASE第一个参数固定为【UT_函数名_序列号】，第二个参数固定为【[函数名]】；\n" +
            " 3.Mock代码段描述的是需要被打桩的函数，被打桩的函数固定为【Sub_函数名】；\n" +
            " 4.为了返回内容更加容易解析，要求返回的内容参考JSON模板[{\"description\":\"场景说明，包括参数值、打桩函数Mock值等\",\"testCaseCode\":\"测试用例代码\"}]。\n" +
            " 5.确保被测函数的代码行覆盖率和分支覆盖率达到100%，生成其他所有场景的测试用例代码，已经生成的测试用例不要返回，返回内容不需要解释说明，如果代码中有双引号请使用转义符，以避免JSON无法反序列化，直接返回测试用例代码，放在JSON数组中，并使用MarkDown的```json包裹。";

    /**
     * 让AI补充测试用例的时候，获取已经存在的测试用例个数
     */
    private Integer numTestCases = 2;
    /**
     * 批量生成UT使用多线程
     * 0,表示不开启多线程
     */
    private Integer threadNum = 0;

    /**
     * 已经做了覆盖率扫描的添加的提示词
     */
    private String supplementTestCasePrompt= "现通过代码覆盖率工具扫描出这几行[{unCovLines}]未被测试用例覆盖，请按照要求补充测试用例，确保被测函数的代码行覆盖率和分支覆盖率达到100%";

    /**
     * 修复告警问题的提示词
     */
    private String codeCheckSuggestPrompt = "你是C++代码专家，以下代码通过静态扫描工具发现了一个告警问题，请根据这个警告问题的提示修复这段代码并完整保留与错误无关的代码。按照JSON格式要求返回解决方案描述和修改后完整的代码内容。" +
            "返回json格式字段要求如下：{\"suggest\":\"解决方案描述\",\"suggestCode\":\"修改后的代码内容\"}，按照要求的字段格式直接返回JSON，并使用Markdown代码块```json包裹。";

}
