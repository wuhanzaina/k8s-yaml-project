/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:CodeCheckTask.java
 * 创建日期:2024-03-26
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.codecheck.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.kotei.sdw.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 *
 * 代码检查任务表
 *
 *
 * @author tiger
 * @since 2024-03-26
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@TableName("projects_code")
@ApiModel(value = "ProjectsCode", description = "配置库管理项目")
public class ProjectsCode extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /**
     * 类型：ALL:全量扫描; INCREMENT:增量扫描
     */
    @ApiModelProperty(value = "项目花名", position = 1)
    @TableField("project_name")
    private String projectName;
    /**
     * 执行任务ID
     */
    @ApiModelProperty(value = "项目名称", position = 2)
    @TableField("repo_name")
    private String repoName;
    /**
     * hookId
     */

    @ApiModelProperty(value = "项目git仓库地址", position = 3)
    @TableField("git_url")
    private String gitUrl;
    /**
     * 用户ID
     */
    @ApiModelProperty(value = "项目git仓库分支", position = 4)
    @TableField("branch")
    private String branch;


}
