/**
 * All rights Reserved, Designed By www.kote.com
 * 项目名称:ai-code-service
 * 文件名称:FunctionUsageServiceImpl.java
 * 创建日期:2024-03-05
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw.modules.statistic.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Maps;
import com.kotei.sdw.constant.GlobalConstant;
import com.kotei.sdw.keygen.KeyGenerate;
import com.kotei.sdw.modules.constant.DictConstant;
import com.kotei.sdw.modules.dict.entity.DictData;
import com.kotei.sdw.modules.dict.service.DictDataService;
import com.kotei.sdw.modules.feign.vo.DeptRes.DeptVo;
import com.kotei.sdw.modules.service.CommonService;
import com.kotei.sdw.modules.statistic.entity.FunctionUsage;
import com.kotei.sdw.modules.statistic.mapper.FunctionUsageMapper;
import com.kotei.sdw.modules.statistic.service.FunctionUsageService;
import com.kotei.sdw.modules.statistic.vo.*;
import com.kotei.sdw.mvc.mapper.BaseMapper;
import com.kotei.sdw.mvc.service.impl.BaseServiceImpl;
import com.kotei.sdw.mvc.vo.PageVO;
import com.kotei.sdw.security.utils.SecurityUtils;
import com.kotei.sdw.system.api.model.LoginUser;
import com.kotei.sdw.util.StreamUtil;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.compress.utils.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * 功能使用情况 ServiceImpl
 *
 * @author hk
 * @since 2024-03-05
 */
@Service
@Log4j2
public class FunctionUsageServiceImpl extends BaseServiceImpl<FunctionUsage> implements FunctionUsageService {
    @Autowired
    private FunctionUsageMapper functionUsageMapper;
    @Autowired
    private DictDataService dictDataService;
    @Autowired
    private CommonService commonService;

    @Override
    protected BaseMapper<FunctionUsage> getMapper() {
        return functionUsageMapper;
    }

    @Override
    public FunctionUsage get(Long id) {
        return functionUsageMapper.selectById(id);
    }

    @Override
    public IPage<FunctionUsage> getList(PageVO<FunctionUsage> page) {
        Map<String, Object> params = page.getParams();
        LambdaQueryWrapper<FunctionUsage> lambdaQueryWrapper = Wrappers.lambdaQuery(FunctionUsage.class)
                .eq(params.containsKey("name"), FunctionUsage::getName, params.get("name"))
                .eq(params.containsKey("type"), FunctionUsage::getType, params.get("type"))
                .eq(params.containsKey("useTotal"), FunctionUsage::getUseTotal, params.get("useTotal"))
                .eq(params.containsKey("adoptionRate"), FunctionUsage::getAdoptionRate, params.get("adoptionRate"))
                .eq(params.containsKey("upvoteTotal"), FunctionUsage::getUpvoteTotal, params.get("upvoteTotal"))
                .eq(params.containsKey("adoptionLineTotal"), FunctionUsage::getAdoptionLineTotal, params.get("adoptionLineTotal"))
                .eq(params.containsKey("userId"), FunctionUsage::getUserId, params.get("userId"))
                .eq(params.containsKey("userName"), FunctionUsage::getUserName, params.get("userName"))
                .eq(params.containsKey("userNo"), FunctionUsage::getUserNo, params.get("userNo"))
                .eq(params.containsKey("deptId"), FunctionUsage::getDeptId, params.get("deptId"))
                .eq(params.containsKey("deptName"), FunctionUsage::getDeptName, params.get("deptName"))
                .eq(params.containsKey("useDate"), FunctionUsage::getUseDate, params.get("useDate"))
                .eq(params.containsKey("createrId"), FunctionUsage::getCreaterId, params.get("createrId"))
                .eq(params.containsKey("createrName"), FunctionUsage::getCreaterName, params.get("createrName"))
                .eq(params.containsKey("createTime"), FunctionUsage::getCreateTime, params.get("createTime"))
                .eq(params.containsKey("modifierId"), FunctionUsage::getModifierId, params.get("modifierId"))
                .eq(params.containsKey("modifierName"), FunctionUsage::getModifierName, params.get("modifierName"))
                .eq(params.containsKey("modifyTime"), FunctionUsage::getModifyTime, params.get("modifyTime"));
        return functionUsageMapper.selectPage(convertPage(page), lambdaQueryWrapper);
    }

    @Override
    public Long insert(FunctionUsage entity) {
        entity.setId(KeyGenerate.generateId());
        functionUsageMapper.insert(entity);
        return entity.getId();
    }

    @Override
    public void delete(Long id) {
        functionUsageMapper.deleteById(id);
    }

    @Override
    public void update(FunctionUsage entity) {
        functionUsageMapper.updateById(entity);
    }

    /**
     * @param addFunctionUsageVO 函数使用记录对象
     * @return 函数使用记录的ID
     * @brief 插入或更新函数使用记录
     * <p>
     * 该函数用于插入或更新函数使用记录。
     */

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long insertOrUpdate(AddFunctionUsageVO addFunctionUsageVO) {
        // 获取当前日期的格式化字符串
        String formatDate = DateUtil.formatDate(new Date());
        // 获取传入的使用类型
        Integer type = addFunctionUsageVO.getType();
        // 获取当前登录用户信息
        LoginUser loginUser = SecurityUtils.getLoginUser();
        // 根据类型和值从数据字典中获取字典数据
        DictData dictData = dictDataService.getByTypeAndValue(DictConstant.Type.FUNCTION_USAGE, type.toString());
        // 打印日志，记录使用功能信息
        log.info("记录使用功能：{} 使用了{}功能, addFunctionUsageVO: {}", loginUser.getUserid(), dictData.getDictValue(), JSONUtil.toJsonStr(addFunctionUsageVO));
        // 根据使用日期、用户ID和类型从数据库中查询对应的功能使用记录
        FunctionUsage functionUsage = this.getByUseDateAndUserIdAndType(formatDate, loginUser.getUserid(), type);
        // 如果功能使用记录为空，说明是新增操作
        if (ObjectUtil.isNull(functionUsage)) {
            // 获取当前登录用户的部门ID
            Long deptId = loginUser.getSysUser().getDeptId();
            // 获取当前登录用户的根部门信息
            DeptVo rootDepartment = commonService.getRootDepartment(deptId);
            // 创建新的功能使用记录对象
            functionUsage = new FunctionUsage();
            // 设置功能使用记录的各个属性值
            functionUsage.setUseTotal(addFunctionUsageVO.getUseTotal());
            functionUsage.setName(dictData.getDictLabel());
            functionUsage.setType(addFunctionUsageVO.getType());
            functionUsage.setAdoptionRate(addFunctionUsageVO.getAdoptionRate());
            functionUsage.setUpvoteTotal(addFunctionUsageVO.getUpvoteTotal());
            functionUsage.setAdoptionLineTotal(addFunctionUsageVO.getAdoptionLineTotal());
            functionUsage.setInputToken(addFunctionUsageVO.getInputToken());
            functionUsage.setOutputToken(addFunctionUsageVO.getOutputToken());
            functionUsage.setCost(addFunctionUsageVO.getCost());
            functionUsage.setUpvoteTotal(addFunctionUsageVO.getUpvoteTotal());
            functionUsage.setUserId(loginUser.getUserid());
            functionUsage.setUserName(loginUser.getSysUser().getNickName());
            functionUsage.setUserNo(loginUser.getSysUser().getUserName());
            functionUsage.setDeptId(deptId);
            functionUsage.setDeptName(loginUser.getSysUser().getDept().getDeptName());
            functionUsage.setRootDeptId(rootDepartment.getId());
            functionUsage.setRootDeptName(rootDepartment.getLabel());
            functionUsage.setUseDate(formatDate);
            functionUsage.setCreaterId(loginUser.getUserid());
            functionUsage.setCreaterName(loginUser.getSysUser().getNickName());
            functionUsage.setCreateTime(new Date());
            functionUsage.setId(KeyGenerate.generateId());
            // 插入功能使用记录到数据库，并返回插入的记录ID
            return this.insert(functionUsage);
        } else { // 否则，说明是更新操作
            // 更新功能使用记录的各个属性值
            functionUsage.setUseTotal(addFunctionUsageVO.getUseTotal());
            functionUsage.setAdoptionRate(addFunctionUsageVO.getAdoptionRate());
            functionUsage.setUpvoteTotal(addFunctionUsageVO.getUpvoteTotal());
            functionUsage.setAdoptionLineTotal(addFunctionUsageVO.getAdoptionLineTotal());
            functionUsage.setInputToken(addFunctionUsageVO.getInputToken());
            functionUsage.setOutputToken(addFunctionUsageVO.getOutputToken());
            functionUsage.setCost(addFunctionUsageVO.getCost());
            functionUsage.setUpvoteTotal(addFunctionUsageVO.getUpvoteTotal());
            functionUsage.setModifierId(loginUser.getUserid());
            functionUsage.setModifierName(loginUser.getSysUser().getNickName());
            functionUsage.setModifyTime(new Date());
            // 更新功能使用记录到数据库
            this.update(functionUsage);
            // 返回更新后的记录ID
            return functionUsage.getId();
        }
    }

    /**
     * 根据使用日期、用户ID和类型获取函数用法
     *
     * @param useDate 使用日期
     * @param userId  用户ID
     * @param type    类型
     * @return 匹配的函数用法
     */
    @Override
    public FunctionUsage getByUseDateAndUserIdAndType(String useDate, Long userId, Integer type) {
        LambdaQueryWrapper<FunctionUsage> lambdaQueryWrapper = Wrappers.lambdaQuery(FunctionUsage.class)
                .eq(FunctionUsage::getUseDate, useDate)
                .eq(FunctionUsage::getUserId, userId)
                .eq(FunctionUsage::getType, type);
        return functionUsageMapper.selectOne(lambdaQueryWrapper);
    }

    /**
     * @param deptId    部门ID
     * @param startDate 开始日期
     * @param endDate   结束日期
     * @return 返回包含功能使用情况的集合
     * @brief 列出特定部门在给定时间范围内的功能使用情况
     */

    @Override
    public Collection<FunctionUsageVO> list(Long deptId, String startDate, String endDate) {
        // 获取后代节点列表
        List<DeptVo> descendantDeptList = commonService.getDescendantDeptList(deptId);
        // 调用commonService的getDescendantDeptList方法获取后代节点列表
        List<Long> deptIds = StreamUtil.toStream(descendantDeptList)  // 将descendantDeptList转换为流
                .map(DeptVo::getId)  // 使用流的map方法，获取每个DeptVo对象的id属性
                .collect(Collectors.toList());  // 将id属性收集到一个新的List中
        LambdaQueryWrapper<FunctionUsage> lambdaQueryWrapper = Wrappers.lambdaQuery(FunctionUsage.class)
                // 创建一个LambdaQueryWrapper对象
                .between(FunctionUsage::getUseDate, startDate, endDate)
                // 使用between方法设置查询条件，查询FunctionUsage的useDate属性在startDate和endDate之间的记录
                .in(FunctionUsage::getDeptId, CollUtil.isEmpty(deptIds) ? Collections.singleton(deptId) : deptIds);
        // 使用in方法设置查询条件，查询FunctionUsage的deptId属性在deptIds中的记录
        List<FunctionUsage> list = functionUsageMapper.selectList(lambdaQueryWrapper);
        // 执行查询，获取符合条件的记录列表
        return this.functionUsageTotal(list);
        // 调用functionUsageTotal方法，对查询结果进行处理并返回
    }

    /**
     * @param startDate 起始日期
     * @param endDate   结束日期
     * @return 组使用情况列表
     * @brief 获取指定日期范围内的组使用情况列表
     */

    @Override
    public List<GroupFunctionUsageVO> groupList(String startDate, String endDate) {
        // 创建结果列表
        List<GroupFunctionUsageVO> results = Lists.newArrayList();
        // 创建存储部门ID和功能使用列表的映射
        Map<Long, List<FunctionUsage>> maps = Maps.newHashMap();
        // 创建存储部门ID和部门名称的映射
        Map<Long, String> deptMaps = Maps.newHashMap();

        // 创建查询条件
        LambdaQueryWrapper<FunctionUsage> lambdaQueryWrapper = Wrappers.lambdaQuery(FunctionUsage.class)
                .between(FunctionUsage::getUseDate, startDate, endDate);
        // 查询符合条件的功能使用列表
        List<FunctionUsage> list = functionUsageMapper.selectList(lambdaQueryWrapper);

        // 遍历功能使用列表
        list.forEach(vo -> {
            // 如果映射中已存在该部门ID，则将该功能使用对象加入到对应部门的功能使用列表中
            if (maps.containsKey(vo.getRootDeptId())) {
                List<FunctionUsage> functionUsages = maps.get(vo.getRootDeptId());
                functionUsages.add(vo);
            }
            // 否则，创建新的功能使用列表，将该功能使用对象加入，并将新的功能使用列表和部门名称添加到映射中
            else {
                List<FunctionUsage> functionUsages = Lists.newArrayList();
                functionUsages.add(vo);
                maps.put(vo.getRootDeptId(), functionUsages);
                deptMaps.put(vo.getRootDeptId(), vo.getRootDeptName());
            }
        });

        // 遍历映射中的元素
        maps.forEach((key, value) -> {
            // 创建GroupFunctionUsageVO对象
            GroupFunctionUsageVO groupFunctionUsageVO = new GroupFunctionUsageVO();
            // 设置部门名称
            groupFunctionUsageVO.setDeptName(deptMaps.get(key));
            // 计算功能使用总数，并设置到GroupFunctionUsageVO对象中
            groupFunctionUsageVO.setList(this.functionUsageTotal(value));
            // 将GroupFunctionUsageVO对象添加到结果列表中
            results.add(groupFunctionUsageVO);
        });

        // 返回结果列表
        return results;
    }


    /**
     * usedTop10
     *
     * @param req
     * @return
     */
    @Override
    public List<UsedTop10Vo> usedTop10(RangeStatisticReq req) {
        return functionUsageMapper.usedTop10(req);
    }

    /**
     * adoptionTop10
     *
     * @param req
     * @return
     */
    @Override
    public List<UsedTop10Vo> adoptionTop10(RangeStatisticReq req) {
        return functionUsageMapper.adoptionTop10(req);
    }

    /**
     * @param beginWeekBeginDateStr 开始周的起始日期字符串
     * @param endWeekBeginDateStr   结束周的起始日期字符串
     * @param userId                用户ID
     * @return 采纳列表
     * @brief 获取采纳列表
     * <p>
     * 根据开始周的起始日期、结束周的起始日期和用户ID获取采纳列表。
     */

    @Override
    public List<LineVO> adoptionList(String beginWeekBeginDateStr, String endWeekBeginDateStr, Long userId) {
        // 创建一个空的结果列表
        List<LineVO> results = Lists.newArrayList();

        // 将传入的日期字符串解析为DateTime对象
        DateTime beginWeekBeginDate = DateUtil.parse(beginWeekBeginDateStr, DatePattern.NORM_DATE_FORMAT);
        DateTime endWeekBeginDate = DateUtil.parse(endWeekBeginDateStr, DatePattern.NORM_DATE_FORMAT);

        // 计算日期范围内的周数
        long l = DateUtil.betweenWeek(beginWeekBeginDate, endWeekBeginDate, Boolean.FALSE);

        // 循环遍历每一周
        for (int i = 0; i <= l; i++) {
            // 根据起始日期和周偏移量计算出当前周的起始日期和结束日期
            DateTime dateTime = DateUtil.offsetWeek(beginWeekBeginDate, i);
            String beginOfWeek = DateUtil.beginOfWeek(dateTime).toDateStr();
            String endOfWeek = DateUtil.endOfWeek(dateTime).toDateStr();

            // 创建一个LambdaQueryWrapper对象，用于构建查询条件
            LambdaQueryWrapper<FunctionUsage> lambdaQueryWrapper = Wrappers.lambdaQuery(FunctionUsage.class)
                    .between(FunctionUsage::getUseDate, beginOfWeek, endOfWeek);

            // 如果传入了userId，则添加userId的等值条件
            if (ObjectUtil.isNotNull(userId)) {
                lambdaQueryWrapper.eq(FunctionUsage::getUserId, userId);
            }

            // 根据查询条件查询数据库并得到结果列表
            List<FunctionUsage> list = functionUsageMapper.selectList(lambdaQueryWrapper);

            // 创建一个AtomicReference对象，用于计算adoptionLineTotal的总和
            AtomicReference<Integer> adoptionLineTotal = new AtomicReference<>(GlobalConstant.NO);

            // 遍历结果列表，累加adoptionLineTotal的值
            list.forEach(vo -> adoptionLineTotal.set(adoptionLineTotal.get() + vo.getAdoptionLineTotal()));

            // 创建一个LineVO对象，并设置其属性值
            LineVO lineVO = new LineVO();
            lineVO.setBeginOfWeek(beginOfWeek);
            lineVO.setEndOfWeek(endOfWeek);
            lineVO.setLineTotal(adoptionLineTotal.get());

            // 将LineVO对象添加到结果列表中
            results.add(lineVO);
        }

        // 返回结果列表
        return results;
    }


    /**
     * 使用插件情况分析-整体概览
     * 今日、本月活跃用户数，累计活跃用户数
     * 今日、本月活跃用户数，累计使用次数
     *
     * @return
     */
    @Override
    public OverviewUserStatisticVo findOverviewUserStatistic() {
        //今日、本月活跃用户数，累计活跃用户数
        int todayActiveUserCount = functionUsageMapper.findTodayActiveUserCount();
        int monthActiveUserCount = functionUsageMapper.findMonthActiveUserCount();
        int totalActiveUserCount = functionUsageMapper.findTotalActiveUserCount();

        //今日、本月活跃用户数，累计使用次数
        OverviewUserStatisticVo today = functionUsageMapper.findTodayUsageCount();
        OverviewUserStatisticVo month = functionUsageMapper.findMonthUsageCount();
        OverviewUserStatisticVo total = functionUsageMapper.findTotalUsageCount();

        return OverviewUserStatisticVo.builder()
                .todayActiveUserCount(todayActiveUserCount)
                .monthActiveUserCount(monthActiveUserCount)
                .totalActiveUserCount(totalActiveUserCount)

                .todayUsageCount(today.getTodayUsageCount())
                .monthUsageCount(month.getMonthUsageCount())
                .totalUsageCount(total.getTotalUsageCount())

                .todayTokenCount(today.getTodayTokenCount())
                .monthTokenCount(month.getMonthTokenCount())
                .totalTokenCount(total.getTotalTokenCount())

                .todayCostCount(today.getTodayCostCount())
                .monthCostCount(month.getMonthCostCount())
                .totalCostCount(total.getTotalCostCount())
                .build();
    }


    /**
     * @param s1 第一个百分数字符串
     * @param s2 第二个百分数字符串
     * @return 平均值的百分数字符串
     * @brief 计算两个百分数的平均值
     */
    private String averagePercentage(String s1, String s2) {
        // 将参数s1中的百分号替换为空格，并将结果转换为double类型赋值给变量d1
        double d1 = Double.parseDouble(s1.replace("%", ""));
        // 将参数s2中的百分号替换为空格，并将结果转换为double类型赋值给变量d2
        double d2 = Double.parseDouble(s2.replace("%", ""));
        // 计算d1和d2的平均值，赋值给变量avg
        double avg = (d1 + d2) / 2;
        // 格式化avg的值，保留两位小数，并加上百分号后赋值给变量result
        return String.format("%.2f", avg) + "%";
    }

    /**
     * Calculates the total number of function usages based on the given parameters.
     *
     * @param total           - the current total number of function usages
     * @param functionUsageVO - the object containing information about a function usage
     * @param type            - the type of function usage
     * @return the updated total number of function usages
     */
    private void functionUsageTotal(Integer total, FunctionUsageVO functionUsageVO, Integer type) {
        // 检查total是否为空，若为空则直接返回
        if (ObjectUtil.isNull(total)) {
            return;
        }
        // 根据type的值进行不同的操作
        switch (type) {
            case 0: {
                // 获取FunctionUsageVO对象的createCode属性值
                String createCode = functionUsageVO.getCreateCode();
                // 将createCode转换为整数，若为空则设置为0
                int i = StrUtil.isNotBlank(createCode) ? Integer.parseInt(createCode) : GlobalConstant.NO;
                // 将createCode设置为原值加上total的值，并转换为字符串类型
                functionUsageVO.setCreateCode((i + total) + "");
                break;
            }
            case 1: {
                // 获取FunctionUsageVO对象的interpretation属性值
                String interpretation = functionUsageVO.getInterpretation();
                // 将interpretation转换为整数，若为空则设置为0
                int i = StrUtil.isNotBlank(interpretation) ? Integer.parseInt(interpretation) : GlobalConstant.NO;
                // 将interpretation设置为原值加上total的值，并转换为字符串类型
                functionUsageVO.setInterpretation((i + total) + "");
                break;
            }
            case 2: {
                // 获取FunctionUsageVO对象的functionAnnotation属性值
                String functionAnnotation = functionUsageVO.getFunctionAnnotation();
                // 将functionAnnotation转换为整数，若为空则设置为0
                int i = StrUtil.isNotBlank(functionAnnotation) ? Integer.parseInt(functionAnnotation) : GlobalConstant.NO;
                // 将functionAnnotation设置为原值加上total的值，并转换为字符串类型
                functionUsageVO.setFunctionAnnotation((i + total) + "");
                break;
            }
            case 3: {
                // 获取FunctionUsageVO对象的lineAnnotation属性值
                String lineAnnotation = functionUsageVO.getLineAnnotation();
                // 将lineAnnotation转换为整数，若为空则设置为0
                int i = StrUtil.isNotBlank(lineAnnotation) ? Integer.parseInt(lineAnnotation) : GlobalConstant.NO;
                // 将lineAnnotation设置为原值加上total的值，并转换为字符串类型
                functionUsageVO.setLineAnnotation((i + total) + "");
                break;
            }
            case 4: {
                // 获取FunctionUsageVO对象的ask属性值
                String ask = functionUsageVO.getAsk();
                // 将ask转换为整数，若为空则设置为0
                int i = StrUtil.isNotBlank(ask) ? Integer.parseInt(ask) : GlobalConstant.NO;
                // 将ask设置为原值加上total的值，并转换为字符串类型
                functionUsageVO.setAsk((i + total) + "");
                break;
            }
            default: {
                // 输出日志，表示不存在该type的值
                log.info("not exists this type: {}", type);
                break;
            }
        }
    }


    /**
     * @param adoptionRate    The adoption rate.
     * @param functionUsageVO The function usage VO.
     * @param type            The type.
     * @return The total function usage.
     * @brief Calculates the total function usage based on the adoption rate and function usage VO.
     */
    private void functionUsageTotal(String adoptionRate, FunctionUsageVO functionUsageVO, Integer type) {
        if (StrUtil.isBlank(adoptionRate)) {
            // 判断adoptionRate是否为空
            return; // 如果为空，直接返回
        }
        switch (type) {
            // 根据type的值进行不同的操作
            case 0: { // 如果type为0
                String createCode = functionUsageVO.getCreateCode(); // 获取functionUsageVO中的createCode
                String i = StrUtil.isNotBlank(createCode) ? createCode : "0%"; // 如果createCode不为空，则i等于createCode，否则i等于"0%"
                functionUsageVO.setCreateCode(this.averagePercentage(adoptionRate, i)); // 将adoptionRate和i进行平均操作，并将结果设置到functionUsageVO的createCode中
                break; // 跳出switch语句
            }
            case 1: {
                // 如果type为1
                String interpretation = functionUsageVO.getInterpretation(); // 获取functionUsageVO中的interpretation
                String i = StrUtil.isNotBlank(interpretation) ? interpretation : "0%"; // 如果interpretation不为空，则i等于interpretation，否则i等于"0%"
                functionUsageVO.setInterpretation(this.averagePercentage(adoptionRate, i)); // 将adoptionRate和i进行平均操作，并将结果设置到functionUsageVO的interpretation中
                break; // 跳出switch语句
            }
            case 2: {
                // 如果type为2
                String functionAnnotation = functionUsageVO.getFunctionAnnotation(); // 获取functionUsageVO中的functionAnnotation
                String i = StrUtil.isNotBlank(functionAnnotation) ? functionAnnotation : "0%"; // 如果functionAnnotation不为空，则i等于functionAnnotation，否则i等于"0%"
                functionUsageVO.setFunctionAnnotation(this.averagePercentage(adoptionRate, i)); // 将adoptionRate和i进行平均操作，并将结果设置到functionUsageVO的functionAnnotation中
                break; // 跳出switch语句
            }
            case 3: {
                // 如果type为3
                String lineAnnotation = functionUsageVO.getLineAnnotation(); // 获取functionUsageVO中的lineAnnotation
                String i = StrUtil.isNotBlank(lineAnnotation) ? lineAnnotation : "0%"; // 如果lineAnnotation不为空，则i等于lineAnnotation，否则i等于"0%"
                functionUsageVO.setLineAnnotation(this.averagePercentage(adoptionRate, i)); // 将adoptionRate和i进行平均操作，并将结果设置到functionUsageVO的lineAnnotation中
                break; // 跳出switch语句
            }
            case 4: {
                // 如果type为4
                String ask = functionUsageVO.getAsk(); // 获取functionUsageVO中的ask
                String i = StrUtil.isNotBlank(ask) ? ask : "0%"; // 如果ask不为空，则i等于ask，否则i等于"0%"
                functionUsageVO.setAsk(this.averagePercentage(adoptionRate, i)); // 将adoptionRate和i进行平均操作，并将结果设置到functionUsageVO的ask中
                break; // 跳出switch语句
            }
            default: { // 如果type不是上述情况
                log.info("not exists this type: {}", type); // 打印日志，表示不存在该类型
            }
        }
    }


    /**
     * @param list The list of FunctionUsage objects.
     * @return A collection of FunctionUsageVO objects representing the total usage of each function.
     * @brief Calculates the total usage of each function in the given list.
     * <p>
     * This function takes a list of FunctionUsage objects as input and calculates the total usage of each function. It returns a collection of FunctionUsageVO objects representing the total usage of each function.
     */
    private Collection<FunctionUsageVO> functionUsageTotal(List<FunctionUsage> list) {
        Map<Integer, FunctionUsageVO> maps = Maps.newHashMap();
        List<DictData> dictDatas = dictDataService.getListByType(DictConstant.Type.FUNCTION_USAGE_X);
        dictDatas.forEach(vo -> {
            int type = Integer.parseInt(vo.getDictValue());
            maps.put(Integer.parseInt(vo.getDictValue()), new FunctionUsageVO(type));
        });
        list.forEach(vo -> {
            //使用次数
            Integer useTotal = vo.getUseTotal();
            FunctionUsageVO useTotalFunctionUsage = maps.get(0);
            this.functionUsageTotal(useTotal, useTotalFunctionUsage, vo.getType());
            //功能采纳率
            String adoptionRate = vo.getAdoptionRate();
            FunctionUsageVO adoptionRateFunctionUsage = maps.get(1);
            this.functionUsageTotal(adoptionRate, adoptionRateFunctionUsage, vo.getType());
            //功能点赞次数
            Integer upvoteTotal = vo.getUpvoteTotal();
            FunctionUsageVO upvoteTotalFunctionUsage = maps.get(2);
            this.functionUsageTotal(upvoteTotal, upvoteTotalFunctionUsage, vo.getType());
            //采纳代码行数
            Integer adoptionLineTotal = vo.getAdoptionLineTotal();
            FunctionUsageVO adoptionLineTotalFunctionUsage = maps.get(3);
            this.functionUsageTotal(adoptionLineTotal, adoptionLineTotalFunctionUsage, vo.getType());

        });
        return maps.values();
    }
}
