/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:smart-develop
 * 文件名称:SmartDevelopApplication.java
 * 创建日期:2022-04-14
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 * 这是一个注释内容
 * 这是一个注释内容
 * 这是一个注释内容
 * 这是一个注释内容
 */
package com.kotei.sdw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;


@ServletComponentScan(basePackages = "com.kotei")
@SpringBootApplication(scanBasePackages = "com.kotei",exclude={DataSourceAutoConfiguration.class})
@EnableDiscoveryClient
@EnableFeignClients(basePackages = "com.kotei.sdw.modules.feign")
@EnableScheduling
public class AiCodeApplication {
    public static void main(String[] args) {
        try {
            SpringApplication.run(AiCodeApplication.class, args);
        }catch(Exception e) {
            e.printStackTrace();
        }
    }

    static {
        System.setProperty("nacos.logging.default.config.enabled","false");
        System.setProperty("druid.mysql.usePingMethod", "false");
    }
}
