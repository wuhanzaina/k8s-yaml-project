/**
 * All rights Reserved, Designed By www.kotei-info.com
 * 项目名称:smart-develop
 * 文件名称:SmartDevelopApplicationTests.java
 * 创建日期:2022-04-14
 * 版权所有:COPYRIGHT©2019 武汉光庭信息技术股份有限公司 鄂ICP备12013351号-1
 * 警告:本内容仅限于光庭内部传阅。
 */
package com.kotei.sdw;

import com.kotei.sdw.generator.CodeGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("local")
class AiCodeApplicationTests {
    @Autowired
    private CodeGenerator codeGenerator;

    static {
        System.setProperty("nacos.logging.default.config.enabled", "false");
    }
    @Test
    void init() {
        codeGenerator.generator("com.kotei.sdw.modules", "ut", "tiger", false,
                new String[] {"batch_code_ut_test_case"}, null);
    }
}
