package com.kotei.sdw.devops.deploycenter.enums;

public enum PipelineSpeedEnum {

    /**
     * Performance-optimized: much faster (requires clean shutdown to save running pipelines)
     */
    PERFORMANCE_OPTIMIZED,
    /**
     * Less durability, a bit faster (specialty use only)
     */
    SURVIVABLE_NONATOMIC,
    /**
     * Maximum durability but slowest (previously the only option)
     */
    MAX_SURVIVABILITY
}
