package com.kotei.sdw.devops.deploycenter.enums;

public enum JobStageEnum {

    /**
     * 队列中
     */
    queue,
    /**
     * 构建中
     */
    build,

    cancelled,

    /**
     * 未知状态。通常为任务已经不在queue，并且查不到查询queue历史信息（queue的数据在弹出后只会保留5分钟）时
     */
    unknown
}
