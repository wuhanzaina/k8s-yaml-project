package com.kotei.sdw.devops.deploycenter.entity;

import lombok.Data;

@Data
public class RoleConfig {

    private String typeCode;

    private RoleConfigRole globalRole;

    private RoleConfigRole projectRole;

    private RoleConfigRole slaveRole;
}
