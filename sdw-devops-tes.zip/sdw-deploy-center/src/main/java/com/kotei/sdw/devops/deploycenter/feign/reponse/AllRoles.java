package com.kotei.sdw.devops.deploycenter.feign.reponse;

import lombok.Data;

import java.util.Map;

@Data
public class AllRoles {

    private String msg;

    private Integer code;

    private Map<String, String[]> data;
}
