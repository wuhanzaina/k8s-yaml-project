package com.kotei.sdw.devops.deploycenter.feign.reponse;

import lombok.Data;

import java.util.Map;

@Data
public class RoleInfo {

    private Map<String, Boolean> permissionIds;

    private String pattern;

    private String[] sids;
}
