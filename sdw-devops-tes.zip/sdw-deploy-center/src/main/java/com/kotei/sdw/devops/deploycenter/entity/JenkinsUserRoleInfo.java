package com.kotei.sdw.devops.deploycenter.entity;

import lombok.Data;
import lombok.ToString;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;


@Data
@ToString
@Document
public class JenkinsUserRoleInfo {

  private String name;

  private List<String> permissions;

  private String pattern;

  private List<String> userNames;

}
