package com.kotei.sdw.devops.deploycenter.service;

import com.google.common.collect.Lists;
import com.kotei.sdw.devops.deploycenter.cmmon.Constants;
import com.kotei.sdw.devops.deploycenter.entity.JenkinsUserRole;
import com.kotei.sdw.devops.deploycenter.entity.JenkinsUserRoleInfo;
import com.kotei.sdw.devops.deploycenter.entity.RoleConfig;
import com.kotei.sdw.devops.deploycenter.entity.RolePermissionPair;
import com.kotei.sdw.devops.deploycenter.enums.JenkinsRoleTypeEnum;
import com.kotei.sdw.devops.deploycenter.feign.reponse.RoleInfo;
import com.kotei.sdw.devops.deploycenter.feign.request.AddRoleRequest;
import com.kotei.sdw.devops.deploycenter.feign.request.AssignRoleRequest;
import com.kotei.sdw.devops.deploycenter.repository.RoleConfigRepository;
import com.kotei.sdw.devops.deploycenter.repository.UserRoleRepository;
import com.kotei.sdw.devops.deploycenter.utils.JenkinsHelper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@AllArgsConstructor
@Service
public class UserRoleService {

    private UserRoleRepository userRoleRepository;

    private RoleConfigRepository roleConfigRepository;

    private JenkinsHelper jenkinsHelper;

    public void syncRoleFromJenkins() {

        Map<String, String[]> allRoles = jenkinsHelper.getAllRoles();
        if(!CollectionUtils.isEmpty(allRoles)){
            List<JenkinsUserRole> jenkinsUserRoleList = Lists.newArrayList();
            allRoles.forEach((key, value) -> {
                JenkinsUserRole jenkinsUserRole = new JenkinsUserRole();
                jenkinsUserRole.setName(key);
                RoleInfo globalRoleInfo = jenkinsHelper.getRole(key, JenkinsRoleTypeEnum.globalRoles.name());
                jenkinsUserRole.setGlobalRole(getMongoRoleInfo(globalRoleInfo));

                RoleInfo projectRoleInfo = jenkinsHelper.getRole(key, JenkinsRoleTypeEnum.projectRoles.name());
                jenkinsUserRole.setProjectRole(getMongoRoleInfo(projectRoleInfo));

                RoleInfo slaveRoleInfo = jenkinsHelper.getRole(key, JenkinsRoleTypeEnum.slaveRoles.name());
                jenkinsUserRole.setSlaveRole(getMongoRoleInfo(slaveRoleInfo));
                jenkinsUserRoleList.add(jenkinsUserRole);
            });
            userRoleRepository.deleteAll();
            userRoleRepository.insert(jenkinsUserRoleList);
        }
    }

    /**
     * jenkins接口的角色数据结构转换成mongo数据结构
     * @param jenkinsRoleInfo
     * @return
     */
    private JenkinsUserRoleInfo getMongoRoleInfo(RoleInfo jenkinsRoleInfo){

        JenkinsUserRoleInfo globalRoleInfo = new JenkinsUserRoleInfo();
        globalRoleInfo.setPattern(jenkinsRoleInfo.getPattern());
        if (ArrayUtils.isNotEmpty(jenkinsRoleInfo.getSids())){
            globalRoleInfo.setUserNames(Lists.newArrayList(jenkinsRoleInfo.getSids()));
        }
        if (!CollectionUtils.isEmpty(jenkinsRoleInfo.getPermissionIds())){
            globalRoleInfo.setPermissions(
                    jenkinsRoleInfo.getPermissionIds().entrySet().stream()
                            .filter(Map.Entry::getValue)
                            .map(Map.Entry::getKey)
                            .collect(Collectors.toList())
            );
        }
        return globalRoleInfo;
    }

    /**
     * 根据模板创建默认角色，并绑定用户
     *
     * @param userName
     * @param applicationCode
     * @param projectCode
     */
    public void createDefaultRoleAndBindUser(String userName, String applicationCode, String projectCode){

        RoleConfig roleConfigParam = new RoleConfig();
        roleConfigParam.setTypeCode(Constants.DEFAULT_ROLE_CONFIG_APPLICATION_PROJECT);
        Example<RoleConfig> example = Example.of(roleConfigParam);
//        Optional<RoleConfig> roleConfigOptional = roleConfigRepository.findOne(example);
        Optional<RoleConfig> roleConfigOptional = roleConfigRepository.findById("6406e1c527ea8dee2d7ac984");
        RoleConfig roleConfig = roleConfigOptional.orElse(null);
        if(roleConfig == null){
            log.warn("默认配置未空");
            return;
        }

        String roleName = applicationCode;
        String pattern = applicationCode;
        if(StringUtils.isNotBlank(projectCode)){
            roleName += "-" + projectCode + "-" + RandomStringUtils.randomAlphanumeric(6);
            pattern += "/" + projectCode;
        }
        pattern += pattern + "|" + pattern + "/.*";

        //新增global角色
        if (roleConfig.getGlobalRole() != null && !CollectionUtils.isEmpty(roleConfig.getGlobalRole().getPermissions())){
            AddRoleRequest addGlobalRoleRequest = new AddRoleRequest();
            addGlobalRoleRequest.setRoleName(roleName);
            addGlobalRoleRequest.setType(JenkinsRoleTypeEnum.globalRoles.name());
            List<String> permissionList = roleConfig.getGlobalRole().getPermissions().stream().map(RolePermissionPair::getJenkinsCode).collect(Collectors.toList());
            addGlobalRoleRequest.setPermissionIds(StringUtils.join(permissionList, ","));
//            jenkinsRestClient.addRole(addGlobalRoleRequest);

//            String json = JSON.toJSON(addGlobalRoleRequest).toString();
//            Map param = JSON.parseObject(json, HashMap.class);
//            jenkinsRestClient.addRoleByMap(param);

            jenkinsHelper.addRole(addGlobalRoleRequest);

            AssignRoleRequest assignRoleRequest = new AssignRoleRequest();
            assignRoleRequest.setRoleName(roleName);
            assignRoleRequest.setType(JenkinsRoleTypeEnum.globalRoles.name());
            assignRoleRequest.setSid(userName);
            jenkinsHelper.assignRole(assignRoleRequest);
        }

        //新增project角色
        if (roleConfig.getProjectRole() != null && !CollectionUtils.isEmpty(roleConfig.getProjectRole().getPermissions())){
            AddRoleRequest addProjectRoleRequest = new AddRoleRequest();
            addProjectRoleRequest.setRoleName(roleName);
            addProjectRoleRequest.setType(JenkinsRoleTypeEnum.projectRoles.name());
            addProjectRoleRequest.setPattern(pattern);
            List<String> permissionList = roleConfig.getProjectRole().getPermissions().stream().map(RolePermissionPair::getJenkinsCode).collect(Collectors.toList());
            addProjectRoleRequest.setPermissionIds(StringUtils.join(permissionList, ","));
//            jenkinsRestClient.addRole(addProjectRoleRequest);

//            String json = JSON.toJSON(addProjectRoleRequest).toString();
//            Map param = JSON.parseObject(json, HashMap.class);
//            jenkinsRestClient.addRoleByMap(param);
//
            jenkinsHelper.addRole(addProjectRoleRequest);

            AssignRoleRequest assignRoleRequest = new AssignRoleRequest();
            assignRoleRequest.setRoleName(roleName);
            assignRoleRequest.setType(JenkinsRoleTypeEnum.projectRoles.name());
            assignRoleRequest.setSid(userName);
            jenkinsHelper.assignRole(assignRoleRequest);
        }

        //新增slave角色
        if (roleConfig.getSlaveRole() != null && !CollectionUtils.isEmpty(roleConfig.getSlaveRole().getPermissions())){
            AddRoleRequest addSlaveRoleRequest = new AddRoleRequest();
            addSlaveRoleRequest.setRoleName(roleName);
            addSlaveRoleRequest.setType(JenkinsRoleTypeEnum.slaveRoles.name());
            addSlaveRoleRequest.setPattern(pattern);
            List<String> permissionList = roleConfig.getSlaveRole().getPermissions().stream().map(RolePermissionPair::getJenkinsCode).collect(Collectors.toList());
            addSlaveRoleRequest.setPermissionIds(StringUtils.join(permissionList, ","));
//            jenkinsRestClient.addRole(addSlaveRoleRequest);

//            String json = JSON.toJSON(addSlaveRoleRequest).toString();
//            Map param = JSON.parseObject(json, HashMap.class);
//            jenkinsRestClient.addRoleByMap(param);
//
            jenkinsHelper.addRole(addSlaveRoleRequest);

            AssignRoleRequest assignRoleRequest = new AssignRoleRequest();
            assignRoleRequest.setRoleName(roleName);
            assignRoleRequest.setType(JenkinsRoleTypeEnum.slaveRoles.name());
            assignRoleRequest.setSid(userName);
            jenkinsHelper.assignRole(assignRoleRequest);
        }
    }

    public void syncRoleToJenkins(){

        List<JenkinsUserRole> jenkinsUserRoleList = userRoleRepository.findAll();
    }

}
