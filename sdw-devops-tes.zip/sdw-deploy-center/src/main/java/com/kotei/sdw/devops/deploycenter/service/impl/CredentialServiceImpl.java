package com.kotei.sdw.devops.deploycenter.service.impl;


import com.kotei.sdw.devops.deploycenter.context.CredentialContext;
import com.kotei.sdw.devops.deploycenter.strategy.CredentialStrategy;
import com.kotei.sdw.devops.deploycenter.entity.Credential;
import com.kotei.sdw.devops.deploycenter.repository.CredentialRepository;
import com.kotei.sdw.devops.deploycenter.response.PageData;
import com.kotei.sdw.devops.deploycenter.response.Result;
import com.kotei.sdw.devops.deploycenter.service.CredentialService;
import com.kotei.sdw.devops.deploycenter.utils.JenkinsApiUtil;
import com.kotei.sdw.devops.deploycenter.utils.PageUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class CredentialServiceImpl implements CredentialService {
    @Autowired
    private CredentialContext credentialContext;
    @Autowired
    private CredentialRepository credentialRepository;
    @Autowired
    private JenkinsApiUtil jenkinsApiUtil;

    @Override
    public Result<Credential> createCredential(Credential credential, MultipartFile file) {
        //credential.setFileName(file.getName());
        CredentialStrategy credentialStrategy = credentialContext.CredentialHandle(credential.getType());

        Result<Credential> result = credentialStrategy.createCredential(credential,file);
        return result;
    }

    @Override
    public Result deleteCredential(String id) {
        //删库
        credentialRepository.deleteById(id);
        //删jenkins凭证
        jenkinsApiUtil.deleteCredential(id);

        return Result.success();
    }

    @Override
    public PageData<Credential> findCredentialPage(PageRequest pageRequest) {
        pageRequest.getSort().and(Sort.by(Sort.Order.desc("type")));
        Credential credential = new Credential();
        Example<Credential> example = Example.of(credential);

        Page<Credential> page = credentialRepository.findAll(example, pageRequest);
        return PageUtil.buildMongoData(page);

    }

    /**
     * userPassword 只能修改用户名和密码
     * github 修改 key
     * secret text 只能修改 secret
     * secret_file 只能修改文件
     *
     * @param credential
     * @param multipartFile
     * @return
     */
    @Override
    public Result<Credential> updateCredential(Credential credential, MultipartFile multipartFile) {
        Credential credentialResult;
        Credential saveCredential = credentialRepository.findById(credential.getId()).get();
        BeanUtils.copyProperties(credential, saveCredential);
        credentialResult = saveCredential;
        //删除
        this.deleteCredential(saveCredential.getId());
        //添加
        return this.createCredential(credentialResult, multipartFile);
    }


}
