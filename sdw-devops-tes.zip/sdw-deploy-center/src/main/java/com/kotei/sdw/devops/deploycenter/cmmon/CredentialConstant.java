package com.kotei.sdw.devops.deploycenter.cmmon;

public class CredentialConstant {
    public static final String USER_PASSWORD = "UserPassword";

    public static final String GIT_HUB = "Git_Hub";



   //user password
    public static final String USER_PASSWORD_STAPLER_CLASS = "com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl";
    public static final String USER_PASSWORD_CLASS = "com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl";

    //github
    public static final String GIT_HUB_STAPLER_CLASS = "org.jenkinsci.plugins.github_branch_source.GitHubAppCredentials";
    public static final String GIT_HUB_CLASS = "org.jenkinsci.plugins.github_branch_source.GitHubAppCredentials";

    //secret text
    public static final String SECRET_STAPLER_CLASS= "org.jenkinsci.plugins.plaincredentials.impl.StringCredentialsImpl";
    public static final String SECRET_CLASS = "org.jenkinsci.plugins.plaincredentials.impl.StringCredentialsImpl";


    //secret text
    public static final String SECRET_FILE_STAPLER_CLASS= "org.jenkinsci.plugins.plaincredentials.impl.FileCredentialsImpl";
    public static final String SECRET_FILE_CLASS = "org.jenkinsci.plugins.plaincredentials.impl.FileCredentialsImpl";


}
