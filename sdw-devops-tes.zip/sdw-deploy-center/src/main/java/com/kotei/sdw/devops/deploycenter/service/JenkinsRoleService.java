package com.kotei.sdw.devops.deploycenter.service;

import com.kotei.sdw.devops.deploycenter.feign.JenkinsRestClient;
import com.kotei.sdw.devops.deploycenter.repository.JenkinsRoleRepository;
import com.kotei.sdw.devops.deploycenter.utils.JenkinsHelper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@AllArgsConstructor
@Service
public class JenkinsRoleService {

    private JenkinsRoleRepository jenkinsRoleRepository;

    private JenkinsHelper jenkinsHelper;

    private JenkinsRestClient jenkinsClient;

    public String syncFromJenkins() {

        jenkinsClient.getAllRoles();

        return null;
    }

}
