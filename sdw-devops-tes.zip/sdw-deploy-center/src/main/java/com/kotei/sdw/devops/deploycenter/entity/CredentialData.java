package com.kotei.sdw.devops.deploycenter.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Data
@ToString
@Document
public class CredentialData {

    private String id;

    private String scope;
    //user_password
    private String username;

    private Boolean usernameSecret;

    private String password;

    private String description;

    @JSONField(name = "stapler-class")
    private String stapler_class;

    @JSONField(name = "$class")
    private String _class;
    // github
    private String appID;

    private String apiUri;

    private String privateKey;

    private String owner;
    // secret
    private String secret;
    //secret file
    private String file = "file0";
}
