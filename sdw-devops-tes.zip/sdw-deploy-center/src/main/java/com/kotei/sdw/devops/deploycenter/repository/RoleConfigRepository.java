package com.kotei.sdw.devops.deploycenter.repository;

import com.kotei.sdw.devops.deploycenter.entity.JenkinsUserRole;
import com.kotei.sdw.devops.deploycenter.entity.RoleConfig;
import org.springframework.data.domain.Example;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RoleConfigRepository extends MongoRepository<RoleConfig, String> {

}
