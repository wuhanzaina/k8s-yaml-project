package com.kotei.sdw.devops.deploycenter.request;

import com.kotei.sdw.devops.deploycenter.entity.Pipeline;
import com.kotei.sdw.devops.deploycenter.enums.PipelineSpeedEnum;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;

import java.util.List;
import java.util.Map;

@Data
@ToString
public class CreatePipelineByScriptRequest {

    @Schema(name = "应用id")
    private String applicationId;

    @Schema(name = "项目id")
    private String projectId;

    @Schema(name = "流水线名称")
    private String name;

    @Schema(name = "流水线描述")
    private String description;

    @Schema(name = "静默期")
    private Integer quietPeriod;

    @Schema(name = "触发远程构建 (例如,使用脚本)身份验证令牌")
    private String authToken;

    @Schema(name = "是否运行并发构建")
    private Pipeline.ConcurrentBuildsJob concurrentBuildsJob;

    @Schema(name = "参数化构建过程")
    private List<Map<String, ?>> parameterDefinitions;

    @Schema(name = "构建触发条件")
    private Pipeline.BuildTriggers buildTriggers;

    @Schema(name = "流水线效率、持久保存设置覆盖", description = "PERFORMANCE_OPTIMIZED, SURVIVABLE_NONATOMIC, MAX_SURVIVABILITY")
    private PipelineSpeedEnum pipelineSpeed;

    @Schema(name = "")
    private Pipeline.RateLimit rateLimit;

    @Schema(name = "流水线启用/禁用")
    private String disabled;

    @Schema(name = "流水线脚本")
    private Pipeline.Flow flow;

}
