package com.kotei.sdw.devops.deploycenter.cmmon;

public class Constants {

    /**
     * 数据删除状态标志 - 已删除
     */
    public static final String DELETED_FLAG_Y = "1";

    /**
     * 数据删除状态标志 - 未删除
     */
    public static final String DELETED_FLAG_N = "0";

    public static final String DEFAULT_ROLE_CONFIG_APPLICATION_PROJECT = "applicationProjectDefault";


    public static final String AUTH_TOKEN_DATE_PATTERN = "yyyyMMddHHmmssZ";
    /**
     * 请求header - 签名
     */
    public static final String AUTH_TOKEN_SIGNATURE = "X-SDW-SIGNATURE";

    /**
     * 请求header - 签名时间
     */
    public static final String AUTH_TOKEN_DATE = "X-SDW-DATE";


    public static final String DEPLOY_CENTER_JOB_ID = "deployCenterJobId";
}
