package com.kotei.sdw.devops.deploycenter.entity;

import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Map;

@Data
@ToString
@Document
public class User {
    @Id
    private String id;

    private String jenkinsUserName;

    private String jenkinsPassword;

    private String applicationCode;

    private String projectCode;

    private String jenkinsApiTokens;

    private JenkinsUserRole jenkinsUserRole;

    /**
     * accessKeyId accessKeySecret
     */
    private Map<String,String> accessKey;
}
