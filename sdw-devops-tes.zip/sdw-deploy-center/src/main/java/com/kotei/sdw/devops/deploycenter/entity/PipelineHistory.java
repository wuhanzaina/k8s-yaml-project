package com.kotei.sdw.devops.deploycenter.entity;

import com.kotei.sdw.devops.deploycenter.enums.JobRateLimitDurationEnum;
import com.kotei.sdw.devops.deploycenter.enums.PipelineSpeedEnum;
import com.kotei.sdw.devops.deploycenter.enums.ReverseBuildTriggerConditionEnum;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;
import java.util.Map;


@Data
@ToString
@Document
public class PipelineHistory {

  @Id
  private String id;

  /**
   * 应用id
   */
  private String applicationId;
  /**
   * 项目id
   */
  private String projectId;

  /**
   * 应用code
   */
  private String applicationCode;

  /**
   * 项目code
   */
  private String projectCode;

  /**
   * 流水线名称
   */
  private String name;
  private Pipeline.RateLimit rateLimit;
  /**
   * 流水线启用/禁用
   */
  private String disabled;

  /**
   * 描述
   */
  private String description;
  /**
   * 流水线效率、持久保存设置覆盖
   * PERFORMANCE_OPTIMIZED
   * SURVIVABLE_NONATOMIC
   * MAX_SURVIVABILITY
   */
  private PipelineSpeedEnum pipelineSpeed;


  /**
   * 静默期
   */
  private Integer quietPeriod;

  /**
   * 触发远程构建 (例如,使用脚本)身份验证令牌
   */
  private String authToken;

  private Pipeline.Flow flow;

  /**
   * 其他工程构建后触发
   */
  private Pipeline.BuildTriggers buildTriggers;

  /**
   * 参数化构建过程
   */
  private List<Map<String, ?>> parameterDefinitions;

  /**
   * 创建人
   */
  private String createdBy;

  /**
   * 创建时间
   */
  private Date createdTime;

}
