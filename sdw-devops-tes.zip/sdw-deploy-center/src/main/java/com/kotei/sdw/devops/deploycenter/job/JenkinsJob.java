package com.kotei.sdw.devops.deploycenter.job;

import com.kotei.sdw.devops.deploycenter.service.JobService;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@AllArgsConstructor
@Component
public class JenkinsJob {

    private JobService jobService;

    @XxlJob("queueHandler")
    public ReturnT<String> queueHandler() throws Exception {
        log.info("start run job:queueHandler.");

        jobService.updateJobStatus();
        return ReturnT.SUCCESS;
    }
}
