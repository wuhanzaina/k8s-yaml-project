package com.kotei.sdw.devops.deploycenter.exception;

import com.kotei.sdw.devops.deploycenter.enums.ResultEnum;

public class ServiceException extends RuntimeException {

    private static final long serialVersionUID = 4073319052914718296L;
    private Integer code;
    private String msg;

    public ServiceException(ResultEnum resultEnum) {
        this((ResultEnum) resultEnum, (Throwable) null);
    }

    public ServiceException(ResultEnum resultEnum, Throwable e) {
        super(resultEnum.getMsg(), e);
        this.code = resultEnum.getCode();
        this.msg = resultEnum.getMsg();
    }

    public ServiceException(String msg) {
        this(ResultEnum.FAILED.getCode(), msg, (Throwable) null);
    }

    public ServiceException(Integer code, String msg) {
        this(code, msg, (Throwable) null);
    }

    public ServiceException(Integer code, String msg, Throwable e) {
        super(msg, e);
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
