package com.kotei.sdw.devops.deploycenter.utils;

import com.cdancy.jenkins.rest.JenkinsApi;
import com.cdancy.jenkins.rest.JenkinsClient;
import com.cdancy.jenkins.rest.domain.common.IntegerResponse;
import com.cdancy.jenkins.rest.domain.common.RequestStatus;
import com.cdancy.jenkins.rest.domain.job.Stage;
import com.cdancy.jenkins.rest.domain.job.Workflow;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.kotei.sdw.devops.deploycenter.cmmon.Constants;
import com.kotei.sdw.devops.deploycenter.entity.*;
import com.kotei.sdw.devops.deploycenter.exception.ServiceException;
import com.kotei.sdw.devops.deploycenter.feign.JenkinsRestClient;
import com.kotei.sdw.devops.deploycenter.feign.reponse.RoleInfo;
import com.kotei.sdw.devops.deploycenter.feign.request.AddRoleRequest;
import com.kotei.sdw.devops.deploycenter.feign.request.AssignRoleRequest;
import com.kotei.sdw.devops.deploycenter.response.BuildInfo;
import com.kotei.sdw.devops.deploycenter.response.WorkflowStage;
import com.kotei.sdw.devops.deploycenter.response.WorkflowVO;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.*;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
@Component
public class JenkinsHelper {

    @Value("${jenkins.endPoint}")
    private String jenkinsEndpoint;

    @Value("${jenkins.user.admin.name}")
    private String adminName;

    @Value("${jenkins.user.admin.password}")
    private String adminPassword;

    @Value("${spring.freemarker.template-loader-path}")
    private String templatePath;

    private final JenkinsRestClient jenkinsRestClient;

    public final static String EAMILSUFFIX = "@kotei.com";

    public JenkinsApi getJenkinsClientSdk(String clientCode) {

        return JenkinsClient.builder()
                .endPoint(jenkinsEndpoint)
                .credentials("")
                .build()
                .api();
    }

    public JenkinsApi getJenkinsAdminClientSdk() {

        return JenkinsClient.builder()
                .endPoint(jenkinsEndpoint)
                .credentials(String.join(":", adminName, adminPassword))
//                .credentials("admin:1qaz@WSX")
                .build()
                .api();
    }

    /**
     * 创建文件夹
     *
     * @param jenkinsApi
     * @param folder
     */
    public void createFolder(JenkinsApi jenkinsApi, String folder) {

        String configText = getJenkinsResourceConfig("classpath:jenkins-config/folder.xml");
        int lastSplit = StringUtils.lastIndexOf(folder, "/");
        String parentPath = null;
        if (lastSplit > 0) {
            parentPath = folder.substring(0, lastSplit);
        }
        String subFolder = folder.substring(lastSplit + 1);
        RequestStatus requestStatus = jenkinsApi.jobsApi().create(parentPath, subFolder, configText);

        if (!requestStatus.value()) {
            throw new ServiceException(String.format("创建资源失败[%s]", folder));
        }
    }

    /**
     * 创建流水线
     *
     * @param jenkinsApi
     * @param folder
     * @param pipelineName
     * @param model
     */
    public void createPipeline(JenkinsApi jenkinsApi, String folder, String pipelineName, Pipeline model) {

        String configText = getJenkinsResourceConfig("pipeline-flow-definition.ftl", model);
        RequestStatus requestStatus = jenkinsApi.jobsApi().create(folder, pipelineName, configText);

        if (!requestStatus.value()) {
            throw new ServiceException(String.format("创建资源失败[%s/%s]", folder, pipelineName));
        }
    }

    /**
     * 更新流水线
     *
     * @param jenkinsApi
     * @param folder
     * @param pipelineName
     * @param model
     */
    public void updatePipeline(JenkinsApi jenkinsApi, String folder, String pipelineName, Pipeline model) {

        String configText = getJenkinsResourceConfig("pipeline-flow-definition.ftl", model);
        boolean result = jenkinsApi.jobsApi().config(folder, pipelineName, configText);

        if (!result) {
            throw new ServiceException(String.format("创建资源失败[%s/%s]", folder, pipelineName));
        }
    }

    /**
     * 启动一个不带参数的流水线任务
     *
     * @param jenkinsApi
     * @param path
     * @return
     */
    public Integer startJob(JenkinsApi jenkinsApi, String path, String jobId) {

        return startJob(jenkinsApi, path, null);
    }

    /**
     * 启动一个带参数的流水线任务
     *
     * @param jenkinsApi
     * @param path
     * @param param
     * @return
     */
    public Integer startJob(JenkinsApi jenkinsApi, String path, String jobId, LinkedHashMap<String, String> param) {

        String[] splitPath = splitJenkinsPath(path);

        if (ArrayUtils.isNotEmpty(splitPath)) {
            String folder = splitPath[0];
            String pipelineName = splitPath[1];
            IntegerResponse response = null;
            if (CollectionUtils.isEmpty(param)) {
                param = Maps.newLinkedHashMap();
            }

            param.put(Constants.DEPLOY_CENTER_JOB_ID, jobId);
            Map<String, List<String>> jenkinsParam = new HashMap<>();
            for(Map.Entry entry : param.entrySet()){
                jenkinsParam.put((String)entry.getKey(), Lists.newArrayList((String)entry.getValue()));
            }
            response = jenkinsApi.jobsApi().buildWithParameters(folder, pipelineName, jenkinsParam);

            if (!CollectionUtils.isEmpty(response.errors())) {
                log.error("启动任务失败[{}/{}]:{}", folder, pipelineName, response.errors());
                throw new ServiceException(String.format("启动任务失败[%s/%s]", folder, pipelineName));
            }
            return response.value();
        }
        return null;
    }

    /**
     * 查询角色权限和绑定的用户信息
     *
     * @param roleName
     * @param type
     * @return
     */
    public RoleInfo getRole(String roleName, String type) {

        return jenkinsRestClient.getRole(roleName, type);
    }

    /**
     * 查询所有角色
     *
     * @return
     */
    public Map<String, String[]> getAllRoles() {

        return jenkinsRestClient.getAllRoles();
    }

    public void addRole(AddRoleRequest addRoleRequest) {
        jenkinsRestClient.addRoleByParam(addRoleRequest.getType(),
                addRoleRequest.getRoleName(),
                addRoleRequest.getPermissionIds(),
                addRoleRequest.isOverwrite(),
                addRoleRequest.getPattern());
    }

    public void assignRole(AssignRoleRequest assignRoleRequest) {
        jenkinsRestClient.assignRole(assignRoleRequest);
    }

    /**
     * 将一个jenkins job的路径字符串拆分成文件夹路径和job两个字符串
     *
     * @param path
     * @return String[0]:文件夹路径 <br/> String[1]:job名称
     */
    public String[] splitJenkinsPath(String path) {

        if (StringUtils.isEmpty(path)) {
            return null;
        }

        List<String> pathList = Arrays.stream(path.split("/")).filter(StringUtils::isNotEmpty).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(pathList)) {
            String folder = null;
            String pipelineName = null;
            if (pathList.size() > 1) {
                pipelineName = pathList.get(pathList.size() - 1);
                pathList.remove(pathList.size() - 1);
                folder = String.join("/", pathList);
            } else {
                pipelineName = pathList.get(0);
            }
            return new String[]{folder, pipelineName};
        }
        return null;
    }

    /**
     * 跟模板生成jenkins资源配置
     *
     * @param resource
     * @return
     */
    public String getJenkinsResourceConfig(String resource) {

        try {
            return FileUtils.readFileToString(ResourceUtils.getFile(resource), StandardCharsets.UTF_8);
        } catch (IOException e) {
            log.error(String.format("配置文件读取失败[%s]", resource));
            return null;
        }
    }

    /**
     * 跟模板生成jenkins资源配置
     *
     * @param resource
     * @return
     */
    public String getJenkinsResourceConfig(String resource, Object model) {

        Configuration configuration = new Configuration(Configuration.getVersion());
        try {
            File basePath = ResourceUtils.getFile(templatePath);
            configuration.setDirectoryForTemplateLoading(basePath);
            configuration.setBooleanFormat("true,false");
            Template template = configuration.getTemplate(resource);

            StringWriter writer = new StringWriter();
            template.process(model, writer);
            return writer.toString();
        } catch (IOException | TemplateException e) {
            throw new RuntimeException(e);
        }
    }

    public BuildInfo jenkinsBuildInfoToResponse(com.cdancy.jenkins.rest.domain.job.BuildInfo jenkinsBuildInfo) {
        if (jenkinsBuildInfo == null) {
            return null;
        }

        BuildInfo buildInfo = new BuildInfo();
        buildInfo.setBuilding(jenkinsBuildInfo.building());
        buildInfo.setBuildId(jenkinsBuildInfo.id());
        buildInfo.setBuiltOn(jenkinsBuildInfo.builtOn());
        buildInfo.setDescription(jenkinsBuildInfo.description());
        buildInfo.setDuration(jenkinsBuildInfo.duration());
        buildInfo.setKeepLog(jenkinsBuildInfo.keepLog());
        buildInfo.setUrl(jenkinsBuildInfo.url());
        buildInfo.setResult(jenkinsBuildInfo.result());
        buildInfo.setTimestamp(jenkinsBuildInfo.timestamp());
        buildInfo.setQueueId(jenkinsBuildInfo.queueId());
        buildInfo.setEstimatedDuration(jenkinsBuildInfo.estimatedDuration());
        return buildInfo;
    }

    public WorkflowVO jenkinsWorkflowInfoToResponse(Workflow workflowInfo) {
        if (workflowInfo == null) {
            return null;
        }

        WorkflowVO workflow = new WorkflowVO();
        workflow.setName(workflowInfo.name());
        workflow.setStatus(workflowInfo.status());
        workflow.setStartTimeMillis(workflowInfo.startTimeMillis());
        workflow.setDurationTimeMillis(workflowInfo.durationTimeMillis());
        if(!CollectionUtils.isEmpty(workflowInfo.stages())){
            List<WorkflowStage> workflowStageList = Lists.newArrayList();
            for(Stage stage : workflowInfo.stages()){
                WorkflowStage workflowStage = new WorkflowStage();
                workflowStage.setId(stage.id());
                workflowStage.setName(stage.name());
                workflowStage.setStartTimeMillis(stage.startTimeMillis());
                workflowStage.setEndTimeMillis(stage.endTimeMillis());
                workflowStage.setPauseDurationMillis(stage.pauseDurationMillis());
                workflowStage.setDurationMillis(stage.durationMillis());
                workflowStage.setStatus(stage.status());
                workflowStageList.add(workflowStage);
            }
            workflow.setStages(workflowStageList);
        }

        return workflow;
    }

    /**
     * 创建jenkins用户
     * @param user
     */
    public void createJenkinsUser(User user) {
        jenkinsRestClient.addJenkinsUser(user.getJenkinsUserName(),
                user.getJenkinsPassword(),
                user.getJenkinsPassword(),
                user.getJenkinsUserName(),
                user.getJenkinsUserName() + EAMILSUFFIX);
    }


    /**
     * 删除jenkins用户
     * @param username
     */
    public void deleteJenkinsUser(String username) {
        jenkinsRestClient.deleteJenkinsUser(username);
    }

}
