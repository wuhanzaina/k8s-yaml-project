package com.kotei.sdw.devops.deploycenter.strategy;

import com.kotei.sdw.devops.deploycenter.entity.Credential;
import com.kotei.sdw.devops.deploycenter.response.Result;
import org.springframework.web.multipart.MultipartFile;

public interface CredentialStrategy {

    Result<Credential> createCredential(Credential credential, MultipartFile file);
}
