package com.kotei.sdw.devops.deploycenter.context;

import com.kotei.sdw.devops.deploycenter.strategy.CredentialFactory;
import com.kotei.sdw.devops.deploycenter.enums.CredentialsEnum;
import com.kotei.sdw.devops.deploycenter.strategy.CredentialStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Optional;

/**
 * 凭证策略上下文
 */
@Component
public class CredentialContext {
    @Autowired
    private CredentialFactory credentialFactory;

    public CredentialStrategy CredentialHandle(String credentialType) {
        Optional<CredentialsEnum> credentialsEnumOptional = Arrays.stream(CredentialsEnum.class.getEnumConstants())
                .filter((credential) -> credential.getCredentialType().equals(credentialType))
                .findAny();

        CredentialsEnum credentialsEnum = credentialsEnumOptional.get();

        return credentialFactory.getCredentialStrategy(credentialsEnum);
    }
}
