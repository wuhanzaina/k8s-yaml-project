package com.kotei.sdw.devops.deploycenter.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class BuildInfo {

    @Schema(name = "是否构建中")
    public boolean building;

    @Schema(name = "是否构建中")
    public String description;

    @Schema(name = "持续时间")
    public long duration;

    @Schema(name = "预计持续时间")
    public long estimatedDuration;

    @Schema(name = "构建任务id")
    public String buildId;

    @Schema(name = "")
    public boolean keepLog;

    @Schema(name = "任务队列id")
    public int queueId;

    @Schema(name = "构建结果")
    public String result;

    @Schema(name = "是否构建中")
    public long timestamp;

    @Schema(name = "jenkins url")
    public String url;

    @Schema(name = "")
    public String builtOn;

}
