package com.kotei.sdw.devops.deploycenter.utils;

import com.kotei.sdw.devops.deploycenter.entity.Project;
import com.kotei.sdw.devops.deploycenter.response.PageData;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import java.util.List;
import java.util.stream.Collectors;

public class PageUtil {

    public static PageRequest buildMongoPageFromRequest(Integer page, Integer size) {

        page = page == null ? 0 : page - 1;
        size = size == null ? 0 : size;
        return PageRequest.of(page, size);
    }

    public static PageData buildMongoData(Page<?> page) {

        PageData pageData = new PageData();

        if (page == null){
            return pageData;
        }
        pageData.setTotal((int) page.getTotalElements());
        pageData.setRecords(page.stream().collect(Collectors.toList()));
        pageData.setSize(page.getSize());
        pageData.setCurrent(page.getNumber() + 1);
        pageData.setPages(page.getTotalPages());
        return pageData;
    }

    /**
     *
     * @param total
     * @param records
     * @param size
     * @param current
     * @return
     */
    public static PageData fromMongoPage(int total, List<?> records, int size, int current){

        PageData pageData = new PageData();
        pageData.setTotal(total);
        pageData.setRecords(records);
        pageData.setSize(size);
        pageData.setCurrent(current);
        return pageData;
    }
}
