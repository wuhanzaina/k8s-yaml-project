package com.kotei.sdw.devops.deploycenter.repository;

import com.kotei.sdw.devops.deploycenter.entity.PipelineHistory;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PipelineHistoryRepository extends MongoRepository<PipelineHistory, String> {


}
