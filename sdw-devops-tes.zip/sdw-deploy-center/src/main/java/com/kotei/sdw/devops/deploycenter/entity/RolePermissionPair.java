package com.kotei.sdw.devops.deploycenter.entity;

import lombok.Data;

@Data
public class RolePermissionPair {

    private String platformCode;

    private String jenkinsCode;
}
