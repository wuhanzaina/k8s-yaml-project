package com.kotei.sdw.devops.deploycenter.utils;


import com.alibaba.fastjson.JSON;
import com.kotei.sdw.devops.deploycenter.entity.Application;
import com.kotei.sdw.devops.deploycenter.entity.CredentialData;
import com.kotei.sdw.devops.deploycenter.entity.User;
import com.kotei.sdw.devops.deploycenter.entity.jenkinsCredential;
import com.kotei.sdw.devops.deploycenter.enums.ResultEnum;
import com.kotei.sdw.devops.deploycenter.exception.ServiceException;
import com.kotei.sdw.devops.deploycenter.repository.JenkinsUserRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.data.domain.Example;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class JenkinsApiUtil {

    @Value("${jenkins.endPoint}")
    private String jenkinsEndpoint;
    @Value("${jenkins.user.admin.defaultPassword}")
    private String defaultPassword;
    @Value("${jenkins.user.admin.name}")
    private String adminName;
    @Value("${jenkins.user.admin.password}")
    private String adminPassword;
    @Value("${jenkins.user.admin.token}")
    private String adminToken;

    public final static String CREATE_USER_API = "/securityRealm/createAccountByAdmin";
    public final static String DELETE_USER_API = "/securityRealm/user/{username}/doDelete";
    public final static String CREATE_CREDENTIAL = "/manage/credentials/store/system/domain/_/createCredentials";
    public final static String DELETE_CREDENTIAL = "/manage/credentials/store/system/domain/_/credential/{id}/doDelete";

    public final static String EAMILSuffix = "@kotei.com";

    private RestTemplate restTemplate = new RestTemplate();

    @Autowired
    private JenkinsUserRepository jenkinsUserRepository;
    @Autowired
    private JenkinsHelper jenkinsHelper;

    /**
     * 创建jenkins用户
     *
     * @param application
     */
    public String createUser(Application application) {
        User user = new User();
        user.setJenkinsUserName(application.getCode());
        user.setJenkinsPassword(defaultPassword);
        String apiToken = jenkinsHelper.getJenkinsAdminClientSdk().userApi().generateNewToken(defaultPassword).toString();
        user.setJenkinsApiTokens(apiToken);
        //用戶入庫
        User insertUser = jenkinsUserRepository.insert(user);
        if (ObjectUtils.isEmpty(insertUser)) {
            throw new ServiceException("创建用户失败");
        }
        //创建jenkins用户
        Map<String, Object> dataMap = new HashMap<>(16);
        dataMap.put("username", application.getCode());
        dataMap.put("password1", defaultPassword);
        dataMap.put("password2", defaultPassword);
        dataMap.put("fullname", application.getCode());
        dataMap.put("email", application.getName() + EAMILSuffix);


        return doPost(jenkinsEndpoint + CREATE_USER_API, dataMap, null);
    }

    /**
     * 删除App
     *
     * @param code
     */
    public String deleteUser(String code) {
        //删库
        User jenkinsUser = new User();
        jenkinsUser.setJenkinsUserName(code);
        Example<User> of = Example.of(jenkinsUser);
        List<User> users = jenkinsUserRepository.findAll(of);
        users.forEach(user -> {
            jenkinsUserRepository.deleteById(user.getId());
        });
        //调用jenkinsApi 删除jenkins用户
        String deleteUrl = StringUtils.replace(DELETE_USER_API, "{username}", code);

        return doPost(jenkinsEndpoint + deleteUrl, null, null);
    }

    /**
     * 创建凭证
     *
     * @param credentialData {
     *                       "credentials": {
     *                       "scope": "GLOBAL",
     *                       "username": "beijing",
     *                       "usernameSecret": false,
     *                       "password": "test",
     *                       "description": "test2222666666",
     *                       "stapler-class": "com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl",
     *                       "$class": "com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl"
     *                       }
     *                       }
     */
    public void createCredential(CredentialData credentialData, MultipartFile file) {
        jenkinsCredential jenkinsCredential = new jenkinsCredential();
        jenkinsCredential.setCredentials(credentialData);
        String credentialDataJson = JSON.toJSONString(jenkinsCredential);
        credentialDataJson = credentialDataJson.replace("stapler_class", "stapler-class");
        Map<String, Object> resultMap = new HashMap<>(16);
        resultMap.put("json", credentialDataJson);
        if (!ObjectUtils.isEmpty(file)) {
            //格式转化
            File resultFile = multipartFileToFile(file);
            FileSystemResource fileSystemResource = new FileSystemResource(resultFile);
            resultMap.put("file0", fileSystemResource);
        }
        doPost(jenkinsEndpoint + CREATE_CREDENTIAL, resultMap, file);
    }

    /**
     * 删除凭证
     *
     * @param id
     */
    public void deleteCredential(String id) {
        String deleteUrl = StringUtils.replace(DELETE_CREDENTIAL, "{id}", id);
        doPost(jenkinsEndpoint + deleteUrl, null, null);
    }

    public String doPost(String url, Map<String, Object> dataMap, MultipartFile file) {
        HttpHeaders headers = new HttpHeaders();
        if (!ObjectUtils.isEmpty(dataMap))
            if (dataMap.containsKey("json")) {
                headers = new HttpHeaders();
                headers.setContentType(MediaType.MULTIPART_FORM_DATA);
            } else {
                headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            }
        headers.setBasicAuth(adminName, adminToken);
        MultiValueMap<String, Object> multiValueDataMap = new LinkedMultiValueMap<>(16);
        if (!ObjectUtils.isEmpty(dataMap)) {
            dataMap.forEach((k, v) -> {
                multiValueDataMap.put(k, Collections.singletonList(dataMap.get(k)));
            });
        }
        HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(multiValueDataMap, headers);
        log.info(entity.toString());
        try {
            ResponseEntity<String> stringResponseEntity = restTemplate.postForEntity(url, entity, String.class);
            return stringResponseEntity.getBody();
        } catch (Exception e) {
            throw new ServiceException(ResultEnum.CREATED_CREDENTIAL_FAIL);
        }
    }

    public static File multipartFileToFile(MultipartFile multipartFile) {
        File file = null;
        String originalFilename = multipartFile.getOriginalFilename();
        String prefix = originalFilename.substring(originalFilename.lastIndexOf("."));
        try {
            file = File.createTempFile(originalFilename, prefix);
            multipartFile.transferTo(file);
            file.deleteOnExit();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return file;
    }
}
