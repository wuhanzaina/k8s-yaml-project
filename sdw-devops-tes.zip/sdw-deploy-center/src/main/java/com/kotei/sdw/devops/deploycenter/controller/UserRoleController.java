package com.kotei.sdw.devops.deploycenter.controller;

import com.kotei.sdw.devops.deploycenter.response.Result;
import com.kotei.sdw.devops.deploycenter.service.UserRoleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@Tag(name = "用户和角色管理")
@AllArgsConstructor
@RestController
@RequestMapping("/user")
public class UserRoleController {

    private UserRoleService userRoleService;

    /**
     * 从jenkins同步角色数据到平台
     *
     * @return
     */
    @Operation(summary = "从jenkins同步角色数据到平台")
    @PostMapping("syncRoleFromJenkins")
    @ResponseStatus(HttpStatus.OK)
    public Result<Void> syncRoleFromJenkins() {

        userRoleService.syncRoleFromJenkins();
        return Result.success();
    }

    /**
     * 从平台同步角色数据到jenkins
     *
     * @return
     */
    @Operation(summary = "从平台同步角色数据到jenkins")
    @PostMapping("syncRoleToJenkins")
    @ResponseStatus(HttpStatus.OK)
    public Result<Void> syncRoleToJenkins() {

        userRoleService.syncRoleToJenkins();
        return Result.success();
    }

    @Operation(summary = "为应用或应用-项目创建默认的角色，并关联用户")
    @PostMapping("createDefaultRoleAndBindUser")
    @ResponseStatus(HttpStatus.OK)
    public Result<Void> createDefaultRoleAndBindUser(String userName, String applicationCode, String projectCode) {

        userRoleService.createDefaultRoleAndBindUser(userName, applicationCode, projectCode);
        return Result.success();
    }
}
