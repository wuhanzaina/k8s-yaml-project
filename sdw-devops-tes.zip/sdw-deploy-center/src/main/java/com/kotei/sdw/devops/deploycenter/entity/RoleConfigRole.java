package com.kotei.sdw.devops.deploycenter.entity;

import lombok.Data;

import java.util.List;

@Data
public class RoleConfigRole {

    private List<RolePermissionPair> permissions;
}
