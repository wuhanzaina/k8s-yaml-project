package com.kotei.sdw.devops.deploycenter.controller;

import com.kotei.sdw.devops.deploycenter.entity.Application;
import com.kotei.sdw.devops.deploycenter.entity.Project;
import com.kotei.sdw.devops.deploycenter.response.PageData;
import com.kotei.sdw.devops.deploycenter.response.Result;
import com.kotei.sdw.devops.deploycenter.service.ApplicationService;
import com.kotei.sdw.devops.deploycenter.utils.AKSKUtil;
import com.kotei.sdw.devops.deploycenter.utils.PageUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Tag(name = "应用管理")
@RestController
@RequestMapping("/application")
public class ApplicationController {
    @Autowired
    private ApplicationService applicationService;

    @Operation(summary = "创建App")
    @PostMapping("/createApp")
    public Result<Application> createApp(@RequestBody Application application) {
        return applicationService.save(application);
    }

    @Operation(summary = "根据ID删除App")
    @DeleteMapping("/delete/{id}")
    public Result<Application> deleteApp(@PathVariable("id") String id) {
        return applicationService.delete(id);
    }

    @Operation(summary = "分页查询")
    @GetMapping("/page")
    public Result<PageData<Application>> getApp(@RequestParam Integer page,
                                                @RequestParam Integer limit) {
        PageRequest pageRequest = PageUtil.buildMongoPageFromRequest(page, limit);
        PageData<Application> pageData = applicationService.findPage(pageRequest);
        return Result.success(pageData);
    }
    @Operation(summary = "根据appId 查询 project")
    @GetMapping("/app/{appId}")
    public Result<PageData<Project>> getApp(@PathVariable("appId") String appId,
                                            @RequestParam Integer page,
                                            @RequestParam Integer limit) {
        PageRequest pageRequest = PageUtil.buildMongoPageFromRequest(page, limit);
        PageData<Project> projectPageData = applicationService.findProjectPageByAppId(appId, pageRequest);
        return Result.success(projectPageData);
    }

    //TODO 创建api token。1.调用AKSKUtil.genAccessKey生成key。2.把key写入mongo

    // TODO: 2023/3/3 (颁发accessKeyId 和 accessKey Secret)
    //修改应用api token 信息


    // TODO: 2023/3/3
    // 删除api token 信息

    //TODO JenkinsApiUtil拆分到JenkinsHelper和JenkinsRestClient

    //TODO com.kotei.sdw.devops.deploycenter.Context / com.kotei.sdw.devops.deploycenter.Strategy 检查包名要全小写

    //TODO service不用接口和实现分开，直接写实现

}
