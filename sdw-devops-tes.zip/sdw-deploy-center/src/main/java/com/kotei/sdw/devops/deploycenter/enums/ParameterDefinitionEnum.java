package com.kotei.sdw.devops.deploycenter.enums;

import com.kotei.sdw.devops.deploycenter.entity.Pipeline;

public enum ParameterDefinitionEnum {

    /**
     * 布尔类型
     */
    bool,
    /**
     * 选项类型
     */
    choice,
    /**
     * 凭据类型
     */
    credential,
    /**
     * 密码类型
     */
    password,
    /**
     * 运行时类型
     */
    runParameter,
    /**
     * 文本类型
     */
    string
}
