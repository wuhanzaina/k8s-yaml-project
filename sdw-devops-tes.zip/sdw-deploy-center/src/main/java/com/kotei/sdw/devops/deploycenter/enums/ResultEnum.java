package com.kotei.sdw.devops.deploycenter.enums;

public enum ResultEnum {
    SUCCESS(0, "成功"),
    FAILED(-1, "失败"),
    BAD_REQUEST(400, "错误的请求"),
    UNAUTHORIZED(401, "未授权的访问"),
    FORBIDDEN(403, "禁止访问"),
    NOT_FOUND(404, "访问的资源不存在"),
    METHOD_NOT_ALLOWED(405, "方法不被允许"),
    NOT_ACCEPTABLE(406, "请求的资源的内容特性无法满足请求头中的条件，因而无法生成响应实体。"),
    REQUEST_TIME_OUT(408, "请求超时"),
    UNSUPPORTED_MEDIA_TYPE(415, "不支持的媒体类型"),
    INTERNAL_SERVER_ERROR(500, "系统发生异常,请联系管理员"),
    SERVICE_UNAVAILABLE(503, "服务不可用"),
    NOT_SUPPORT_CLIENT(700, "非法请求,未知客户端"),
    TOKEN_MISS(701, "非法请求,缺少访问凭证"),
    SIGN_MISS(702, "非法请求,缺少签名"),
    SIGN_INVALID(703, "非法请求,签名无效"),
    FIELD_LENGTH_TOO_LONG(800, "字段长度超出限制"),
    NOT_SUPPORT_BRAW(801, "emoji表情或非法字符"),
    HAD_EXIST_DATA(802, "重复的数据"),
    FILE_SIZE_TOO_LONG(803, "文件大小超出限制"),
    FILE_UPLOAD_ERROR(804, "上传文件发生异常"),
    PARAM_MISS(900, "缺少请求参数"),
    PARAM_PARSE_FAILED(901, "参数解析失败"),
    PARAM_BIND_FAILED(902, "参数绑定失败"),
    PARAM_TYPE_MISMATCH(903, "参数数据类型不匹配"),
    PARAM_VERIFICATION_FAILED(904, "参数校验失败"),
    ACCOUNT_NOT_EXIST(1000, "账号不存在"),
    ACCOUNT_OR_PASSWORD_ERROR(1001, "账号或密码错误"),
    ACCOUNT_IS_DISABLED(1002, "账号已被禁用"),
    ACCOUNT_IS_LOCKED(1003, "账号已被锁定"),
    ACCOUNT_IS_FIRST_LOGIN(1004, "第一次登录,请修改密码后再访问"),
    LOGIN_FAILURES_TOO_MANY(1005, "登录失败次数过多,请稍后再试"),
    TOKEN_PARSE_INVALID(1006, "无效的认证信息,访问凭证解析失败"),
    TOKEN_INVALID(1007, "无效的认证信息,不合法的访问凭证"),
    TOKEN_HAS_EXPIRED(1008, "无效的认证信息!访问凭证已过期,请重新登录"),
    AUTHENTICATION_FAILED(1009, "无效的认证信息,身份认证失败"),

    APP_DELETE_FAILED(1100, "应用中还有项目，无法删除应用"),

    CREATED_CREDENTIAL_FAIL(1101, "创建凭证失败");

    private Integer code;
    private String msg;

    private ResultEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
