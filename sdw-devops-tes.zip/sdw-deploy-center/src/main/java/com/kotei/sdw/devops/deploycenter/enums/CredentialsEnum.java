package com.kotei.sdw.devops.deploycenter.enums;

public enum CredentialsEnum {

    //    usernameWithPassword,
//
//    GitHubApp,
//
//    KubernetesServiceAccount,
//
//    OpenShiftUsernameAndPassword,
//
//    SSHUserNameWithPrivateKey,
//
//    SecretFile,
//
//    SecretText,
//
//    X509ClientCertificate,
//
//    Certificate,

    /**
     * 用户名和密码凭证
     */
    USER_PASSWORD("UserPassword", "userPasswordCredentialStrategy"),

    /**
     * github凭证
     */
    GITHUB_APP("GitHubApp", "gitHubAppCredentialStrategy"),
    /**
     * secret凭证
     */
    SECRET_TEXT("Secret_Text","secretTextCredentialStrategy"),
    /**
     * secret文件凭证
     */
    SECRET_FILE("Secret_File","secretFileCredentialStrategy");

    /**
     * 凭证类型
     */
    private String credentialType;
    /**
     * bean名称
     */
    private String className;


    CredentialsEnum(String credentialType, String className) {
        this.credentialType = credentialType;
        this.className = className;
    }

    public String getCredentialType() {
        return credentialType;
    }

    public String getClassName() {
        return className;
    }
}
