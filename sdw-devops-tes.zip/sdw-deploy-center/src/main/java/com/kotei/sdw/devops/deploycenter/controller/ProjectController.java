package com.kotei.sdw.devops.deploycenter.controller;

import com.kotei.sdw.devops.deploycenter.entity.Project;
import com.kotei.sdw.devops.deploycenter.feign.JenkinsRestClient;
import com.kotei.sdw.devops.deploycenter.request.CreateProjectRequest;
import com.kotei.sdw.devops.deploycenter.request.QueryProjectRequest;
import com.kotei.sdw.devops.deploycenter.request.UpdateProjectRequest;
import com.kotei.sdw.devops.deploycenter.response.PageData;
import com.kotei.sdw.devops.deploycenter.response.Result;
import com.kotei.sdw.devops.deploycenter.service.ProjectService;
import com.kotei.sdw.devops.deploycenter.utils.PageUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Tag(name = "项目管理")
@AllArgsConstructor
@RestController
@RequestMapping("/project")
public class ProjectController {

    private ProjectService projectService;

    private JenkinsRestClient jenkinsClient;

    /**
     * 创建项目
     *
     * @param request
     * @return
     */
    @Operation(summary = "创建项目")
    @PostMapping("create")
    @ResponseStatus(HttpStatus.OK)
    public Result<String> createProject(@RequestBody CreateProjectRequest request) {

        return Result.success(projectService.createProject(request));
    }

    /**
     * 修改项目
     *
     * @param request
     * @return
     */
    @Operation(summary = "修改项目")
    @PutMapping("update/{projectId}")
    @ResponseStatus(HttpStatus.OK)
    public Result<Void> updateProject(@PathVariable("projectId") String projectId, @RequestBody UpdateProjectRequest request) {

        projectService.updateProject(projectId, request);
        return Result.success();
    }

    /**
     * 删除项目
     *
     * @param projectId
     * @return
     */
    @Operation(summary = "删除项目")
    @DeleteMapping("delete/{projectId}")
    @ResponseStatus(HttpStatus.OK)
    public Result<Void> deleteProject(@PathVariable("projectId") String projectId) {

        projectService.deleteProject(projectId);
        return Result.success();
    }

    /**
     * 分页查询项目列表
     *
     * @param request
     * @return
     */
    @Operation(summary = "分页查询项目列表")
    @GetMapping("page")
    @ResponseStatus(HttpStatus.OK)
    public Result<PageData<Project>> pageProject(QueryProjectRequest request,
                                        @RequestParam Integer page,
                                        @RequestParam Integer limit) {

        PageData<Project> data = projectService.pageProject(request, PageUtil.buildMongoPageFromRequest(page, limit));
        return Result.success(data);
    }

    /**
     * 查询全部项目列表
     *
     * @param request
     * @return
     */
    @Operation(summary = "查询全部项目列表")
    @GetMapping("list")
    @ResponseStatus(HttpStatus.OK)
    public Result<List<Project>> listProject(QueryProjectRequest request) {

        List<Project> data = projectService.listProject(request);
        return Result.success(data);
    }

}
