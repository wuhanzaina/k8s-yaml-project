package com.kotei.sdw.devops.deploycenter.response;


import com.kotei.sdw.devops.deploycenter.enums.JobResultEnum;
import com.kotei.sdw.devops.deploycenter.enums.JobStageEnum;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@Schema(description ="构建任务信息")
public class JobInfoVO {

    @Schema(name = "任务id")
    private String id;

    @Schema(name = "任务阶段")
    private JobStageEnum stage;

    @Schema(name = "任务队列id")
    private Integer queueId;

    @Schema(name = "任务序号")
    private Integer jobNumber;

    @Schema(name = "任务结果")
    private JobResultEnum result;

    @Schema(name = "任务信息")
    private BuildInfo buildInfo;
}
