package com.kotei.sdw.devops.deploycenter.repository;

import com.kotei.sdw.devops.deploycenter.entity.Credential;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CredentialRepository extends MongoRepository<Credential, String> {
}
