package com.kotei.sdw.devops.deploycenter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients(basePackages = "com.kotei.sdw.devops")
@SpringBootApplication(scanBasePackages = "com.kotei.sdw.devops")
public class DeployCenterApplication {

    public static void main(String[] args) {
        SpringApplication.run(DeployCenterApplication.class, args);
    }
}
