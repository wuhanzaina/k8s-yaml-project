package com.kotei.sdw.devops.deploycenter.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description ="控制台日志")
public class BuildProgressiveText {


    @Schema(name = "日志文本内容")
    public String text;

    @Schema(name = "日志数据大小")
    public int size;

    @Schema(name = "是否有更多日志")
    public boolean hasMoreData;
}
