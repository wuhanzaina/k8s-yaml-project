package com.kotei.sdw.devops.deploycenter.repository;

import com.kotei.sdw.devops.deploycenter.entity.JenkinsRole;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JenkinsRoleRepository extends MongoRepository<JenkinsRole, String> {

}
