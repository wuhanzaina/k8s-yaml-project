package com.kotei.sdw.devops.deploycenter.config;

import com.kotei.sdw.devops.deploycenter.exception.ServiceException;
import com.kotei.sdw.devops.deploycenter.response.Result;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class ControllerExceptionHandler {

    @ResponseBody
    @ExceptionHandler
    public ResponseEntity<Result<?>> handleServiceException(ServiceException e) {
        return ResponseEntity.status(HttpStatus.OK).body(Result.failed(e.getMsg()));
    }
}
