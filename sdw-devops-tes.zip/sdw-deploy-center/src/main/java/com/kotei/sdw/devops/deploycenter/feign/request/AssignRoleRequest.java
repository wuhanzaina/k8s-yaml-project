package com.kotei.sdw.devops.deploycenter.feign.request;

import lombok.Data;

@Data
public class AssignRoleRequest {

    /**
     * 角色类型
     * 角色类型
     */
    private String type;

    /**
     * 角色名称
     */
    private String roleName;

    /**
     * 用户名
     */
    private String sid;

}
