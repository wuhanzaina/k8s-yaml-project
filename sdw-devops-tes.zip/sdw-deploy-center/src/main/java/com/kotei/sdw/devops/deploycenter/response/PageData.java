package com.kotei.sdw.devops.deploycenter.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Schema(name = "分页")
@NoArgsConstructor
@Data
public class PageData<T> {

    @Schema(name = "查询数据列表")
    private List<T> records;

    @Schema(name = "总条数")
    private int total;

    @Schema(name = "每页条数")
    private int size;

    @Schema(name = "当前页数")
    private int current;

    @Schema(name = "总页数")
    private int pages;


}
