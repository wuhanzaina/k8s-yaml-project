package com.kotei.sdw.devops.deploycenter.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kotei.sdw.devops.deploycenter.entity.Credential;
import com.kotei.sdw.devops.deploycenter.response.PageData;
import com.kotei.sdw.devops.deploycenter.response.Result;
import com.kotei.sdw.devops.deploycenter.service.CredentialService;
import com.kotei.sdw.devops.deploycenter.utils.PageUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


@Tag(name = "凭证管理")
@RestController
@RequestMapping("/credential")
public class CredentialController {

    @Autowired
    private CredentialService credentialService;
    @Operation(summary = "创建Credential")
    @PostMapping("/createCredential")
    public Result<Credential> createCredential(@RequestParam String credential,
                                               @RequestParam(name = "file0", required = false) MultipartFile file0) {
        Credential parseObject = JSONObject.parseObject(credential, Credential.class);
        return credentialService.createCredential(parseObject, file0);
    }
    @Operation(summary = "根据id删除Credential")
    @DeleteMapping("/delete/{id}")
    public Result deleteCredential(@PathVariable("id") String id) {

        return credentialService.deleteCredential(id);
    }

    @Operation(summary = "分页查询credentials")
    @GetMapping("/page")
    public Result<PageData<Credential>> getCrePage(@RequestParam Integer page,
                                                   @RequestParam Integer limit) {
        PageRequest pageRequest = PageUtil.buildMongoPageFromRequest(page, limit);
        PageData<Credential> credentialPageData = credentialService.findCredentialPage(pageRequest);
        return Result.success(credentialPageData);
    }
    @Operation(summary = "更新credentials")
    @PutMapping("/update")
    public Result<Credential> updateCre(@RequestParam String credential,
                                        @RequestParam(name = "file0", required = false) MultipartFile file0) {
        Credential parseObject = JSONObject.parseObject(credential, Credential.class);
        return credentialService.updateCredential(parseObject,file0);
    }
}
