package com.kotei.sdw.devops.deploycenter.strategy.strategyImpl;

import com.kotei.sdw.devops.deploycenter.cmmon.CredentialConstant;
import com.kotei.sdw.devops.deploycenter.strategy.CredentialStrategy;
import com.kotei.sdw.devops.deploycenter.entity.Credential;
import com.kotei.sdw.devops.deploycenter.entity.CredentialData;
import com.kotei.sdw.devops.deploycenter.repository.CredentialRepository;
import com.kotei.sdw.devops.deploycenter.response.Result;
import com.kotei.sdw.devops.deploycenter.utils.JenkinsApiUtil;
import com.kotei.sdw.devops.deploycenter.utils.JenkinsHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.UUID;

/**
 * secret 凭证创建
 */
@Service
public class SecretTextCredentialStrategy implements CredentialStrategy {
    @Autowired
    private JenkinsApiUtil jenkinsApiUtil;
    @Autowired
    private CredentialRepository credentialRepository;
    @Autowired
    private JenkinsHelper jenkinsHelper;
    @Override
    public Result<Credential> createCredential(Credential credential, MultipartFile file) {
        String id = UUID.randomUUID().toString();
        credential.setId(id);
        CredentialData credentialData = credential.getCredentialData();
        credentialData.setStapler_class(CredentialConstant.SECRET_STAPLER_CLASS);
        credentialData.set_class(CredentialConstant.SECRET_CLASS);
        credentialData.setId(id);
        //创建jenkins凭证
        jenkinsApiUtil.createCredential(credentialData,null);
        //入库
        credential.setCreatedTime(new Date());
        credentialRepository.insert(credential);
        System.out.println("secret-text 的凭证创建");
        return Result.success(credential);
    }
}
