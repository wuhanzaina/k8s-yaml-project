package com.kotei.sdw.devops.deploycenter.service;

import com.kotei.sdw.devops.deploycenter.entity.Credential;
import com.kotei.sdw.devops.deploycenter.response.PageData;
import com.kotei.sdw.devops.deploycenter.response.Result;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.multipart.MultipartFile;

public interface CredentialService {
    /**
     * 创建凭证
     * @param credential
     * @return
     */
    Result<Credential> createCredential(Credential credential, MultipartFile file);

    /**
     * 删除凭证
     * @param id
     * @return
     */
    Result deleteCredential(String id);

    /**
     * 分页查询
     * @param pageRequest
     * @return
     */
    PageData<Credential> findCredentialPage(PageRequest pageRequest);

    /**
     * 根据ID修改凭证
     * @param credential
     * @return
     */
    Result<Credential> updateCredential(Credential credential,MultipartFile multipartFile);
}
