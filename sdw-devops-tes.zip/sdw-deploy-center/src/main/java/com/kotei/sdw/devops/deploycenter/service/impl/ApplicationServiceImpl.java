package com.kotei.sdw.devops.deploycenter.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.cdancy.jenkins.rest.features.JobsApi;
import com.kotei.sdw.devops.deploycenter.entity.Application;
import com.kotei.sdw.devops.deploycenter.entity.Project;
import com.kotei.sdw.devops.deploycenter.entity.User;
import com.kotei.sdw.devops.deploycenter.enums.ResultEnum;
import com.kotei.sdw.devops.deploycenter.exception.ServiceException;
import com.kotei.sdw.devops.deploycenter.repository.ApplicationRepository;
import com.kotei.sdw.devops.deploycenter.repository.JenkinsUserRepository;
import com.kotei.sdw.devops.deploycenter.repository.ProjectRepository;
import com.kotei.sdw.devops.deploycenter.response.PageData;
import com.kotei.sdw.devops.deploycenter.response.Result;
import com.kotei.sdw.devops.deploycenter.service.ApplicationService;
import com.kotei.sdw.devops.deploycenter.service.UserRoleService;
import com.kotei.sdw.devops.deploycenter.utils.AKSKUtil;
import com.kotei.sdw.devops.deploycenter.utils.JenkinsApiUtil;
import com.kotei.sdw.devops.deploycenter.utils.JenkinsHelper;
import com.kotei.sdw.devops.deploycenter.utils.PageUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class ApplicationServiceImpl implements ApplicationService {

    public static String APP_IS_CREATED = "项目已经创建，请重新创建";

    @Value("${jenkins.endPoint}")
    private String jenkinsEndpoint;
    @Value("${jenkins.user.admin.defaultPassword}")
    private String defaultPassword;
    @Value("${jenkins.user.admin.name}")
    private String adminName;
    @Value("${jenkins.user.admin.password}")
    private String adminPassword;
    @Value("${jenkins.user.admin.token}")
    private String adminToken;

    public final static String CREATE_USER_API = "/securityRealm/createAccountByAdmin";
    public final static String DELETE_USER_API = "/securityRealm/user/{username}/doDelete";
    public final static String CREATE_CREDENTIAL = "/manage/credentials/store/system/domain/_/createCredentials";
    public final static String DELETE_CREDENTIAL = "/manage/credentials/store/system/domain/_/credential/{id}/doDelete";

    public final static String EAMILSuffix = "@kotei.com";

    @Autowired
    private ApplicationRepository applicationRepository;
    @Autowired
    private JenkinsApiUtil jenkinsApiUtil;
    @Autowired
    private JenkinsHelper jenkinsHelper;
    @Autowired
    private ProjectRepository projectRepository;
    @Autowired
    private UserRoleService userRoleService;

    @Override
    public Result<Application> save(Application application) {
        //校验一级文件夹是否创建
        Application app = applicationRepository.findByName(application.getName());
        if (!ObjectUtils.isEmpty(app)) {
            throw new ServiceException(application.getCode() + APP_IS_CREATED);
        } else {
            //创建一级文件夹
            Application insert = applicationRepository.insert(application);
            if (!ObjectUtils.isEmpty(insert)) {
                jenkinsHelper.createFolder(jenkinsHelper.getJenkinsAdminClientSdk(), application.getName());
                //根据admin token 创建出 jenkins用户（文件夹名称是jenkins用户名 ,默认密码 创建用户
                User user = new User();
                user.setJenkinsUserName(application.getCode());
                user.setJenkinsPassword(defaultPassword);
                //api token
                String apiToken = jenkinsHelper.getJenkinsAdminClientSdk().userApi().generateNewToken(defaultPassword).data().tokenValue();
                user.setJenkinsApiTokens(apiToken);
                //创建一个ApplicationName ItemRole 绑定权限
                userRoleService.createDefaultRoleAndBindUser(application.getCode(),application.getCode(),null);
                //添加accessKey
                String[] accessStrArr = AKSKUtil.genAccessKey();
                Map<String,String> accessKeyMap = new HashMap<>(16);
                accessKeyMap.put(accessStrArr[0],accessStrArr[1]);
                user.setAccessKey(accessKeyMap);
                //创建jenkins用户
                jenkinsHelper.createJenkinsUser(user);

                return Result.success(insert);
            }
        }
        return null;
    }

    @Override
    public Result<Application> delete(String id) {
        List<Project> projectList = projectRepository.findByAppId(id);
        Application application = applicationRepository.findById(id).get();
        if (ObjectUtils.isEmpty(projectList)) {
            //删除用户
            jenkinsHelper.deleteJenkinsUser(application.getCode());
            applicationRepository.deleteById(id);
            //jenkins folder delete
            jenkinsHelper.getJenkinsAdminClientSdk().jobsApi().delete(application.getCode(), application.getCode());
            return Result.result(ResultEnum.SUCCESS);
        }
        return Result.result(ResultEnum.APP_DELETE_FAILED);
    }

    @Override
    public PageData<Application> findPage(PageRequest pageRequest) {

        pageRequest.getSort().and(Sort.by(Sort.Order.desc("name")));
        Application application = new Application();
        Example<Application> example = Example.of(application);

        Page<Application> page = applicationRepository.findAll(example, pageRequest);
        return PageUtil.buildMongoData(page);

    }

    @Override
    public PageData<Project> findProjectPageByAppId(String appId, PageRequest pageRequest) {
        pageRequest.getSort().and(Sort.by(Sort.Order.desc("name")));
        Project project = new Project();
        project.setAppId(appId);
        Example<Project> example = Example.of(project);
        Page<Project> projectPageData = projectRepository.findAll(example, pageRequest);

        return PageUtil.buildMongoData(projectPageData);
    }
}
