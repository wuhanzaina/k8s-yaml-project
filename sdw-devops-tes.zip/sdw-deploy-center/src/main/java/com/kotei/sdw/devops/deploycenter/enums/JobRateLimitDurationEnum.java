package com.kotei.sdw.devops.deploycenter.enums;

public enum JobRateLimitDurationEnum {

    second,
    minute,
    hour,
    day,
    week,
    month,
    year,
}
