package com.kotei.sdw.devops.deploycenter.service;

import com.cdancy.jenkins.rest.JenkinsApi;
import com.cdancy.jenkins.rest.domain.common.RequestStatus;
import com.cdancy.jenkins.rest.domain.job.JobInfo;
import com.kotei.sdw.devops.deploycenter.cmmon.Constants;
import com.kotei.sdw.devops.deploycenter.entity.Application;
import com.kotei.sdw.devops.deploycenter.entity.Pipeline;
import com.kotei.sdw.devops.deploycenter.entity.PipelineHistory;
import com.kotei.sdw.devops.deploycenter.entity.Project;
import com.kotei.sdw.devops.deploycenter.exception.ServiceException;
import com.kotei.sdw.devops.deploycenter.repository.ApplicationRepository;
import com.kotei.sdw.devops.deploycenter.repository.PipelineHistoryRepository;
import com.kotei.sdw.devops.deploycenter.repository.PipelineRepository;
import com.kotei.sdw.devops.deploycenter.repository.ProjectRepository;
import com.kotei.sdw.devops.deploycenter.request.CreatePipelineByScriptRequest;
import com.kotei.sdw.devops.deploycenter.request.QueryPipelineRequest;
import com.kotei.sdw.devops.deploycenter.request.QueryProjectRequest;
import com.kotei.sdw.devops.deploycenter.request.UpdatePipelineByScriptRequest;
import com.kotei.sdw.devops.deploycenter.response.PageData;
import com.kotei.sdw.devops.deploycenter.utils.JenkinsHelper;
import com.kotei.sdw.devops.deploycenter.utils.PageUtil;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Service
public class PipelineService {

    private ApplicationRepository applicationRepository;

    private ProjectRepository projectRepository;

    private PipelineRepository pipelineRepository;

    private PipelineHistoryRepository pipelineHistoryRepository;

    private JenkinsHelper jenkinsHelper;

    public String createPipelineByScript(CreatePipelineByScriptRequest request) {

        Optional<Application> applicationOptional = applicationRepository.findById(request.getApplicationId());
        Application application = applicationOptional.orElseThrow(
                () -> new ServiceException(String.format("应用不存在[id:%s]", request.getApplicationId()))
        );
        Optional<Project> projectOptional = projectRepository.findById(request.getProjectId());
        Project project = projectOptional.orElseThrow(
                () -> new ServiceException(String.format("项目不存在[id:%s]", request.getProjectId()))
        );

        JenkinsApi jenkinsApi = jenkinsHelper.getJenkinsAdminClientSdk();
        JobInfo jobInfo = jenkinsApi.jobsApi().jobInfo(application.getCode(), project.getCode());
        if (jobInfo == null) {
            throw new ServiceException(String.format("数据异常[applicationCode:%s,project:%s]", application.getCode(), project.getCode()));
        }

        Pipeline pipeline = new Pipeline();
        BeanUtils.copyProperties(request, pipeline);
        pipeline.setPath(String.join("/", application.getCode(), project.getCode(), request.getName()));
        pipeline.setApplicationCode(application.getCode());
        pipeline.setProjectCode(project.getCode());
        pipeline.setCreatedTime(new Date());
        pipeline.setDeleted(Constants.DELETED_FLAG_N);
        jenkinsHelper.createPipeline(
                jenkinsHelper.getJenkinsAdminClientSdk(),
                String.join("/", application.getCode(), project.getCode()),
                pipeline.getName(),
                pipeline);
        pipelineRepository.save(pipeline);

        PipelineHistory pipelineHistory = new PipelineHistory();
        BeanUtils.copyProperties(pipeline, pipelineHistory);
        pipelineHistoryRepository.save(pipelineHistory);

        return pipeline.getId();
    }

    public void updatePipelineByScript(String pipelineId, UpdatePipelineByScriptRequest request) {

        Optional<Pipeline> pipelineOptional = pipelineRepository.findById(pipelineId);
        Pipeline pipeline = pipelineOptional.orElseThrow(
                () -> new ServiceException(String.format("流水线不存在[id:%s]", pipelineId))
        );

        JenkinsApi jenkinsApi = jenkinsHelper.getJenkinsAdminClientSdk();
        JobInfo jobInfo = jenkinsApi.jobsApi().jobInfo(String.format("%s/%s", pipeline.getApplicationCode(), pipeline.getProjectCode()),
                pipeline.getName());
        if (jobInfo == null) {
            throw new ServiceException(String.format("流水线数据异常[applicationCode:'%s', projectCode:'%s', name:'%s']",
                    pipeline.getApplicationCode(), pipeline.getProjectCode(), pipeline.getName()));
        }

        Pipeline upPipeline = new Pipeline();
        BeanUtils.copyProperties(request, upPipeline);
        upPipeline.setApplicationCode(pipeline.getApplicationCode());
        upPipeline.setProjectCode(pipeline.getProjectCode());
        upPipeline.setUpdatedTime(new Date());
        jenkinsHelper.updatePipeline(
                jenkinsHelper.getJenkinsAdminClientSdk(),
                String.join("/", pipeline.getApplicationCode(), pipeline.getProjectCode()),
                pipeline.getName(),
                upPipeline);
        pipelineRepository.save(upPipeline);
    }

    public void deletePipeline(String pipelineId) {

        Optional<Pipeline> pipelineOptional = pipelineRepository.findById(pipelineId);
        Pipeline pipeline = pipelineOptional.orElseThrow(
                () -> new ServiceException(String.format("流水线不存在[id:%s]", pipelineId))
        );

        JenkinsApi jenkinsApi = jenkinsHelper.getJenkinsAdminClientSdk();
        RequestStatus requestStatus = jenkinsApi.jobsApi().delete(
                String.join("/", pipeline.getApplicationCode(), pipeline.getProjectCode()),
                pipeline.getName()
        );
        if (!requestStatus.value()) {
            throw new ServiceException(String.format("删除流水线失败[applicationCode:%s, projectCode:%s, name:%s]",
                    pipeline.getApplicationCode(), pipeline.getProjectCode(), pipeline.getName()));
        }

        Pipeline upPipeline = new Pipeline();
        upPipeline.setDeleted(Constants.DELETED_FLAG_Y);
        upPipeline.setId(pipeline.getId());
        pipelineRepository.save(upPipeline);

        PipelineHistory pipelineHistory = new PipelineHistory();
        pipelineHistory.setCreatedTime(new Date());
        BeanUtils.copyProperties(pipeline, pipelineHistory);
        pipelineHistoryRepository.save(pipelineHistory);
    }


    public PageData<Pipeline> pagePipeline(QueryPipelineRequest request, PageRequest pageRequest) {

        pageRequest.getSort().and(Sort.by(Sort.Order.desc("name")));
        Pipeline pipeline = new Pipeline();
        BeanUtils.copyProperties(request, pipeline);
        Example<Pipeline> example = Example.of(pipeline);

        Page<Pipeline> page = pipelineRepository.findAll(example, pageRequest);
        return PageUtil.buildMongoData(page);
    }

    public List<Pipeline> listPipeline(QueryPipelineRequest request) {

        Pipeline pipeline = new Pipeline();
        BeanUtils.copyProperties(request, pipeline);
        Example<Pipeline> example = Example.of(pipeline);

        return pipelineRepository.findAll(example);
    }
}
