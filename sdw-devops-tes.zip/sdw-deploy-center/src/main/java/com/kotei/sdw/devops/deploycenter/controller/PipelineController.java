package com.kotei.sdw.devops.deploycenter.controller;

import com.kotei.sdw.devops.deploycenter.entity.Pipeline;
import com.kotei.sdw.devops.deploycenter.request.CreatePipelineByScriptRequest;
import com.kotei.sdw.devops.deploycenter.request.QueryPipelineRequest;
import com.kotei.sdw.devops.deploycenter.request.UpdatePipelineByScriptRequest;
import com.kotei.sdw.devops.deploycenter.response.PageData;
import com.kotei.sdw.devops.deploycenter.response.Result;
import com.kotei.sdw.devops.deploycenter.service.PipelineService;
import com.kotei.sdw.devops.deploycenter.utils.PageUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Tag(name = "流水线管理")
@AllArgsConstructor
@RestController
@RequestMapping("/pipeline")
public class PipelineController {

    private PipelineService pipelineService;

    @Operation(summary = "创建流水线")
    @PostMapping("create/script")
    @ResponseStatus(HttpStatus.OK)
    public Result<String> createByScript(@RequestBody CreatePipelineByScriptRequest request) {

        return Result.success(pipelineService.createPipelineByScript(request));
    }

    @Operation(summary = "修改流水线")
    @PutMapping("update/script/{pipelineId}")
    @ResponseStatus(HttpStatus.OK)
    public Result<Void> updateByScript(@PathVariable("pipelineId") String pipelineId, @RequestBody UpdatePipelineByScriptRequest request) {

        pipelineService.updatePipelineByScript(pipelineId, request);
        return Result.success();
    }

    @Operation(summary = "删除流水线")
    @DeleteMapping("delete/{pipelineId}")
    @ResponseStatus(HttpStatus.OK)
    public Result<Void> deletePipeline(@PathVariable("pipelineId") String pipelineId) {

        pipelineService.deletePipeline(pipelineId);
        return Result.success();
    }


    /**
     * 分页查询项目列表
     *
     * @param request
     * @return
     */
    @Operation(summary = "分页查询流水线列表")
    @GetMapping("page")
    @ResponseStatus(HttpStatus.OK)
    public Result<PageData<Pipeline>> pagePipeline(QueryPipelineRequest request,
                                                   @RequestParam Integer page,
                                                   @RequestParam Integer limit) {

        PageData<Pipeline> data = pipelineService.pagePipeline(request, PageUtil.buildMongoPageFromRequest(page, limit));
        return Result.success(data);
    }

    /**
     * 查询全部项目列表
     *
     * @param request
     * @return
     */
    @Operation(summary = "查询全部项目列表")
    @GetMapping("list")
    @ResponseStatus(HttpStatus.OK)
    public Result<List<Pipeline>> listPipeline(QueryPipelineRequest request) {

        List<Pipeline> data = pipelineService.listPipeline(request);
        return Result.success(data);
    }

    @Operation(summary = "按流水线id查询详情")
    @DeleteMapping("info/{pipelineId}")
    @ResponseStatus(HttpStatus.OK)
    public Result<Void> info(@PathVariable("pipelineId") String pipelineId) {

        return Result.success();
    }

    @Operation(summary = "按流水线id查询历史版本")
    @DeleteMapping("history/{pipelineId}")
    @ResponseStatus(HttpStatus.OK)
    public Result<Void> history(@PathVariable("pipelineId") String pipelineId) {

        return Result.success();
    }
}
