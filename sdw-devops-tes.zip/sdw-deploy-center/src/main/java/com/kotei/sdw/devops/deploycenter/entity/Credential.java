package com.kotei.sdw.devops.deploycenter.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;


@Data
@ToString
@Document
public class Credential {


    private String id;

    /**
     * 凭证类型
     */
    private String type;

    /**
     * 凭证数据
     */
    private CredentialData credentialData;

    /**
     * 上传文件类型的凭据
     */
//    @JsonIgnore
//    private transient MultipartFile file;
//    /**
//     * 上传文件名称
//     */
//    private String fileName;
    /**
     * 创建时间
     */
    private Date createdTime;


    /**
     * 更新时间
     */
    private Date updatedTime;




}
