package com.kotei.sdw.devops.deploycenter.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class QueryProjectRequest {

    @Schema(name = "应用编码")
    private String applicationCode;
}
