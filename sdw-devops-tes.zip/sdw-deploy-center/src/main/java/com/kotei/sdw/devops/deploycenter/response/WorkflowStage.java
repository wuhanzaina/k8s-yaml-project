package com.kotei.sdw.devops.deploycenter.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class WorkflowStage {

    public String id;

    public String name;

    public String status;

    @Schema(name = "开始执行时间戳")
    public long startTimeMillis;

    @Schema(name = "结束执行时间戳")
    public long endTimeMillis;

    @Schema(name = "停止执行时长")
    public long pauseDurationMillis;

    @Schema(name = "持续时间")
    public long durationMillis;

}
