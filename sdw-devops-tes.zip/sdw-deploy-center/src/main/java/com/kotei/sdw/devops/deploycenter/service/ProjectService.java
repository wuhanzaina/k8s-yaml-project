package com.kotei.sdw.devops.deploycenter.service;

import com.cdancy.jenkins.rest.JenkinsApi;
import com.cdancy.jenkins.rest.domain.job.JobInfo;
import com.kotei.sdw.devops.deploycenter.cmmon.Constants;
import com.kotei.sdw.devops.deploycenter.entity.Project;
import com.kotei.sdw.devops.deploycenter.exception.ServiceException;
import com.kotei.sdw.devops.deploycenter.repository.ProjectRepository;
import com.kotei.sdw.devops.deploycenter.request.CreateProjectRequest;
import com.kotei.sdw.devops.deploycenter.request.QueryProjectRequest;
import com.kotei.sdw.devops.deploycenter.request.UpdateProjectRequest;
import com.kotei.sdw.devops.deploycenter.response.PageData;
import com.kotei.sdw.devops.deploycenter.utils.JenkinsHelper;
import com.kotei.sdw.devops.deploycenter.utils.PageUtil;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Service
public class ProjectService {

    private ProjectRepository projectRepository;

    private JenkinsHelper jenkinsHelper;

    public String createProject(CreateProjectRequest request) {

        JenkinsApi jenkinsApi = jenkinsHelper.getJenkinsAdminClientSdk();
        JobInfo jobInfo = jenkinsApi.jobsApi().jobInfo(request.getApplicationCode(), request.getCode());
        if (jobInfo != null) {
            throw new ServiceException("项目已存在");
        }

        String path = String.join("/", request.getApplicationCode(), request.getCode());
        jenkinsHelper.createFolder(jenkinsApi, path);
        Project project = new Project();
        BeanUtils.copyProperties(request, project);
        project.setCreatedTime(new Date());
        project.setDeleted(Constants.DELETED_FLAG_N);
        project.setPath(path);
        projectRepository.save(project);
        return project.getId();

        //TODO 创建jenkins用户和角色，并绑定关系
    }


    public void updateProject(String projectId, UpdateProjectRequest request) {

        Project project = new Project();
        project.setId(projectId);
        if(request.getName() != null){
            project.setName(request.getName());
        }
        if(request.getDescription() != null){
            request.setDescription(request.getDescription());
        }
        project.setUpdatedTime(new Date());
        projectRepository.save(project);
    }

    public void deleteProject(String projectId) {

        Optional<Project> projectOptional = projectRepository.findById(projectId);
        Project project = projectOptional.orElseThrow(
                ()->new ServiceException(String.format("项目不存在[id:%s]", projectId))
        );
        //TODO 校验项目下是否存在流水线

        JenkinsApi jenkinsApi = jenkinsHelper.getJenkinsAdminClientSdk();
        jenkinsApi.jobsApi().delete(project.getApplicationCode(), project.getCode());

        Project upProject = new Project();
        project.setId(projectId);
        project.setDeleted(Constants.DELETED_FLAG_N);
        projectRepository.save(upProject);
    }

    public PageData<Project> pageProject(QueryProjectRequest request, PageRequest pageRequest) {

        pageRequest.getSort().and(Sort.by(Sort.Order.desc("name")));
        Project project = new Project();
        BeanUtils.copyProperties(request, project);
        Example<Project> example = Example.of(project);

        Page<Project> page = projectRepository.findAll(example, pageRequest);
        return PageUtil.buildMongoData(page);
    }

    public List<Project> listProject(QueryProjectRequest request) {

        Project project = new Project();
        BeanUtils.copyProperties(request, project);
        Example<Project> example = Example.of(project);

        return projectRepository.findAll(example);
    }
}
