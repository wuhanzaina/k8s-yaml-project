package com.kotei.sdw.devops.deploycenter.controller;

import com.cdancy.jenkins.rest.domain.job.Workflow;
import com.kotei.sdw.devops.deploycenter.response.BuildProgressiveText;
import com.kotei.sdw.devops.deploycenter.response.JobInfoVO;
import com.kotei.sdw.devops.deploycenter.response.Result;
import com.kotei.sdw.devops.deploycenter.response.WorkflowVO;
import com.kotei.sdw.devops.deploycenter.service.JobService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;


@Tag(name = "任务管理")
@AllArgsConstructor
@RestController
@RequestMapping("/job")
public class JobController {

    private JobService jobService;

    @Operation(summary = "启动流水线")
    @PostMapping("start/{pipelineId}")
    @ResponseStatus(HttpStatus.OK)
    public Result<String> startJob(@PathVariable String pipelineId, @RequestBody(required = false) LinkedHashMap<String, String> param) {

        return Result.success(jobService.startJob(pipelineId, param));
    }

    @Operation(summary = "按流水线查询全部任务")
    @GetMapping("list")
    @ResponseStatus(HttpStatus.OK)
    public Result<List<Workflow>> jobListByPipelineId(@RequestParam("pipelineId") String pipelineId) {

        return Result.success(jobService.jobListByPipelineId(pipelineId));
    }

    @Operation(summary = "按单个任务查询构建任务信息")
    @GetMapping("buildInfo/{jobId}")
    @ResponseStatus(HttpStatus.OK)
    public Result<JobInfoVO> buildInfo(@PathVariable("jobId") String jobId) {

        return Result.success(jobService.buildInfo(jobId));
    }

    @Operation(summary = "按单个任务查询流水线构建详情，包括每一步的状态")
    @GetMapping("workflowInfo/{jobId}")
    @ResponseStatus(HttpStatus.OK)
    public Result<WorkflowVO> workFlowInfo(@PathVariable("jobId") String jobId) {
        return Result.success(jobService.workFlowInfo(jobId));
    }

    @Operation(summary = "停止任务")
    @GetMapping("stop/{jobId}")
    @ResponseStatus(HttpStatus.OK)
    public Result<Void> stop(@PathVariable("jobId") String jobId) {

        jobService.stop(jobId);
        return Result.success();
    }

    @Operation(summary = "杀死任务")
    @GetMapping("kill/{jobId}")
    @ResponseStatus(HttpStatus.OK)
    public Result<Void> kill(@PathVariable("jobId") String jobId) {

        jobService.kill(jobId);
        return Result.success();
    }

    @Operation(summary = "按单个任务查询控制台日志")
    @GetMapping("consoleLog/{jobId}")
    @ResponseStatus(HttpStatus.OK)
    public Result<BuildProgressiveText> getJobConsoleLog(@PathVariable("jobId") String jobId) {

        return Result.success(jobService.getJobConsoleLog(jobId));
    }

    @Operation(summary = "更新job状态")
    @GetMapping("updateStatus")
    @ResponseStatus(HttpStatus.OK)
    public Result<Void> updateJobStatus() {

        jobService.updateJobStatus();
        return Result.success();
    }
}
