package com.kotei.sdw.devops.deploycenter.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class QueryPipelineRequest {

    @Schema(name = "应用id")
    private String applicationId;

    @Schema(name = "项目id")
    private String projectId;
}
