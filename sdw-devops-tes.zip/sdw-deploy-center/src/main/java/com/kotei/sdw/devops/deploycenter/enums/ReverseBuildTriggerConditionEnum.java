package com.kotei.sdw.devops.deploycenter.enums;

public enum ReverseBuildTriggerConditionEnum {
    /**
     * 只有构建稳定时触发
     */
    success_green,
    /**
     * 即使构建不稳定时也会触发
     */
    success_yellow,
    /**
     * 即使构建失败时也会触发
     */
    fail,
    /**
     * 总是触发，除非任务被取消
     */
    always
}
