package com.kotei.sdw.devops.deploycenter.entity;

import com.kotei.sdw.devops.deploycenter.enums.JobRateLimitDurationEnum;
import com.kotei.sdw.devops.deploycenter.enums.PipelineSpeedEnum;
import com.kotei.sdw.devops.deploycenter.enums.ReverseBuildTriggerConditionEnum;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.awt.*;
import java.util.Date;
import java.util.List;
import java.util.Map;


@Data
@ToString
@Document
public class Pipeline {

  @Id
  private String id;

  /**
   * 应用id
   */
  private String applicationId;
  /**
   * 项目id
   */
  private String projectId;

  /**
   * 应用code
   */
  private String applicationCode;

  /**
   * 项目code
   */
  private String projectCode;

  /**
   * 流水线名称
   */
  private String name;
  private RateLimit rateLimit;
  /**
   * 流水线启用/禁用
   */
  private String disabled;

  /**
   * 描述
   */
  private String description;
  /**
   * 流水线效率、持久保存设置覆盖
   * PERFORMANCE_OPTIMIZED
   * SURVIVABLE_NONATOMIC
   * MAX_SURVIVABILITY
   */
  private PipelineSpeedEnum pipelineSpeed;


  /**
   * 静默期
   */
  private Integer quietPeriod;

  /**
   * 触发远程构建 (例如,使用脚本)身份验证令牌
   */
  private String authToken;

  private Flow flow;

  /**
   * 其他工程构建后触发
   */
  private BuildTriggers buildTriggers;

  /**
   * 参数化构建过程
   */
  private List<Map<String, ?>> parameterDefinitions;

  private String path;

  /**
   * 创建人
   */
  private String createdBy;

  /**
   * 创建时间
   */
  private Date createdTime;

  /**
   * 跟新人
   */
  private String updatedBy;

  /**
   * 更新时间
   */
  private Date updatedTime;

  /**
   * 是否已删除
   */
  private String deleted;

  /**
   * 是否运行并发构建
   */
  @Data
  @ToString
  public static class ConcurrentBuildsJob {
    /**
     * 是否取消前序任务
     */
    private String abortPrevious;
  }

  @Data
  @ToString
  public static class DurabilityHintJob {
    /**
     * 是否取消前序任务
     */
    private String hint;
  }

  /**
   * 其他工程构建后触发
   */
  @Data
  @ToString
  public static class BuildTriggers {
    private ReverseBuildTrigger reverseBuildTrigger;
    /**
     * 轮询SCM
     */
    private SCMTrigger scmTrigger;
    /**
     * 定时触发，cron表达式
     */
    private String timerTrigger;

    @Data
    @ToString
    public static class ReverseBuildTrigger {
      private String upstreamProjects;

      private ReverseBuildTriggerConditionEnum condition;

    }

    /**
     * 轮询SCM
     */
    @Data
    @ToString
    public static class SCMTrigger {
      /**
       * 忽略钩子
       */
      private String ignorePostCommitHooks;
      /**
       * 定时触发，cron表达式
       */
      private String spec;

    }

    /**
     * 布尔类型
     */
    @Data
    @ToString
    public static class Bool {
      private String defaultValue;
      private String description;
      private String name;

    }

  }

  public static class Choice {
    private String[] choices;
    private String description;
    private String name;
  }

  /**
   * 凭据类型
   */
  @Data
  @ToString
  public static class Credential {
    private String defaultValue;
    private String description;
    private String name;
    /**
     * 是否必填
     */
    private String required;
    /**
     * 凭据类型
     */
    private String type;

  }


  /**
   * 密码类型
   */
  @Data
  @ToString
  public static class Password {
    private String defaultValue;
    private String description;
    private String name;

  }


  /**
   * 运行时类型
   */
  @Data
  @ToString
  public static class RunParameter {
    private String defaultValue;
    private String description;
    /**
     * 过滤选项，所有构建：ALL 执行完成的构建：COMPLETED 成功的构建：SUCCESSFUL 稳定的构建：STABLE
     */
    private String filter;
    private String name;

  }

  /**
   * 文本类型
   */
  @Data
  @ToString
  public static class StringClass {
    private String defaultValue;
    private String description;
    private String name;
    /**
     * 是否去空格，默认false
     */
    private String trim;

  }


  @Data
  @ToString
  public static class RateLimit {
    /**
     * 构建数
     */
    private String count;
    /**
     * 周期类型，second
     * minute
     * hour
     * day
     * week
     * month
     * year
     */
    private JobRateLimitDurationEnum duration;

    private String userBoost;

  }

  @Data
  @ToString
  public static class Flow {
    private String sandbox;
    private String script;

  }
}
