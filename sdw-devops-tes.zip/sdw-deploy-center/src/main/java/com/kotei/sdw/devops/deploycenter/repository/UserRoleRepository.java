package com.kotei.sdw.devops.deploycenter.repository;

import com.kotei.sdw.devops.deploycenter.entity.JenkinsUserRole;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRoleRepository extends MongoRepository<JenkinsUserRole, String> {

}
