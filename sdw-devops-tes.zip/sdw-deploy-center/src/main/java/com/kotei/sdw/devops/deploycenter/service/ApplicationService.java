package com.kotei.sdw.devops.deploycenter.service;

import com.kotei.sdw.devops.deploycenter.entity.Application;
import com.kotei.sdw.devops.deploycenter.entity.Project;
import com.kotei.sdw.devops.deploycenter.response.PageData;
import com.kotei.sdw.devops.deploycenter.response.Result;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;


public interface ApplicationService {

    /**
     * 创建应用
     *
     * @param application
     * @return
     */
    Result<Application> save(Application application);

    /**
     * 删除应用
     *
     * @param id
     * @return
     */
    Result<Application> delete(String id);


    /**
     * 分页插叙App
     * @param pageRequest
     * @return
     */
    PageData<Application> findPage(PageRequest pageRequest);

    /**
     * 根据appId 分页查询 project
     *
     * @param appId
     * @param pageRequest
     * @return
     */
    PageData<Project> findProjectPageByAppId(String appId, PageRequest pageRequest);

}
