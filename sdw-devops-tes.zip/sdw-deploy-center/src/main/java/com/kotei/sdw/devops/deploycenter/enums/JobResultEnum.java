package com.kotei.sdw.devops.deploycenter.enums;

public enum JobResultEnum {

    /**
     * 执行中
     */
    PROCESSING,
    /**
     * 成功
     */
    SUCCESS,
    /**
     * 取消
     */
    ABORTED,

    /**
     * 失败
     */
    FAILURE
}
