package com.kotei.sdw.devops.deploycenter.entity;

import lombok.Data;

@Data
public class jenkinsCredential {
    CredentialData credentials;
}
