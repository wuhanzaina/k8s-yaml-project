package com.kotei.sdw.devops.deploycenter.config;

import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import com.google.common.collect.Maps;
import com.kotei.sdw.devops.deploycenter.cmmon.Constants;
import com.kotei.sdw.devops.deploycenter.exception.ServiceException;
import com.kotei.sdw.devops.deploycenter.repository.JenkinsUserRepository;
import com.kotei.sdw.devops.deploycenter.utils.AKSKUtil;
import com.kotei.sdw.devops.deploycenter.utils.SpringUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.util.CollectionUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;


@Slf4j
public class AccessAuthInterceptor implements HandlerInterceptor {


    /**
     * @param request
     * @param response
     * @param handler
     * @return
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {

        if (!SpringUtil.getBean(Environment.class).getProperty("auth.api.verify", Boolean.class, false)) {
            return true;
        }
        String path = request.getRequestURI();
        String method = request.getMethod();
        String querySting = request.getQueryString();
        String signature = null;

        String authTokenDate = request.getHeader(Constants.AUTH_TOKEN_DATE);
        if (StringUtils.isBlank(authTokenDate)) {
            throw new ServiceException("请求参数验证失败");
        }

        try {
            Date signDate = new SimpleDateFormat(Constants.AUTH_TOKEN_DATE_PATTERN).parse(authTokenDate);
            long between = DateUtil.between(signDate, new Date(), DateUnit.SECOND);
            long maxBetween = SpringUtil.getBean(Environment.class).getProperty("auth.api.max-between", Long.class, 60L);
            if (between > maxBetween) {
                throw new ServiceException("请求参数验证失败");
            }
        } catch (ParseException e) {
            throw new ServiceException("请求参数验证失败");
        }


        Map<String, String> headers = Maps.newHashMap();
        if (request.getHeaderNames() != null) {
            while (request.getHeaderNames().hasMoreElements()) {
                String headerName = request.getHeaderNames().nextElement();
                if (Constants.AUTH_TOKEN_SIGNATURE.equals(headerName)) {
                    signature = request.getHeader(headerName);
                    continue;
                }
                headers.put(headerName, request.getHeader(headerName));
            }
        }
        Map<String, String> paramMap = Maps.newHashMap();
        if (!CollectionUtils.isEmpty(request.getParameterMap())) {
            Set<Map.Entry<String, String[]>> entrySet = request.getParameterMap().entrySet();
            for (Map.Entry<String, String[]> entry : entrySet) {
                if (ArrayUtils.isNotEmpty(entry.getValue())) {
                    paramMap.put(entry.getKey(), entry.getValue()[0]);
                }
            }
        }

        JenkinsUserRepository jenkinsUserRepository = SpringUtil.getBean(JenkinsUserRepository.class);
        String accessKeyId = StringUtils.substringBefore(signature, ":");
        if (!AKSKUtil.verify(accessKeyId, "", method, path, headers, paramMap, signature)) {
            throw new ServiceException("请求参数验证失败");
        }
        return true;
    }

}
