package com.kotei.sdw.devops.deploycenter.strategy;

import com.kotei.sdw.devops.deploycenter.enums.CredentialsEnum;
import com.kotei.sdw.devops.deploycenter.exception.ServiceException;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;

/**
 * 凭证策略 工厂
 */
@Component
public class CredentialFactory {
    @Resource
    private Map<String, CredentialStrategy> credentialStrategyMap;


    /**
     * 获取 创建凭证实现类
     *
     * @param credentialsEnum
     * @return
     */
    public CredentialStrategy getCredentialStrategy(CredentialsEnum credentialsEnum) {
        if (!credentialStrategyMap.containsKey(credentialsEnum.getClassName())) {
            throw new ServiceException("没有对应创建凭证的策略，无法进行创建");
        }
        return credentialStrategyMap.get(credentialsEnum.getClassName());
    }

}
