package com.kotei.sdw.devops.deploycenter.enums;

public enum JenkinsRoleTypeEnum {

    /**
     * Global roles
     */
    globalRoles,
    /**
     * Item roles
     */
    projectRoles,
    /**
     * Agent roles
     */
    slaveRoles
}
