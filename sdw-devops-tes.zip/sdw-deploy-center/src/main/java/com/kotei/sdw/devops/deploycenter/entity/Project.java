package com.kotei.sdw.devops.deploycenter.entity;

import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;


@Data
@ToString
@Document
public class Project {

  @Id
  private String id;

  /**
   * 名称
   */
  private String name;

  /**
   * 编码
   */
  private String code;

  /**
   * 应用编码
   */
  private String applicationCode;

  /**
   * 描述
   */
  private String description;

  /**
   * jenkins完整path
   */
  private String path;

  /**
   * 创建人
   */
  private String createdBy;

  /**
   * 创建时间
   */
  private Date createdTime;

  /**
   * 跟新人
   */
  private String updatedBy;

  /**
   * 更新时间
   */
  private Date updatedTime;

  /**
   * 是否已删除
   */
  private String deleted;

  private String appId;

}
