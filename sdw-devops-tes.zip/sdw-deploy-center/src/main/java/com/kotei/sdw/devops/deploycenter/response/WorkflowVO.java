package com.kotei.sdw.devops.deploycenter.response;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
@Schema(description ="流水线构建详情")
public class WorkflowVO {

    @Schema(name = "任务编号")
    public String name;

    @Schema(name = "状态")
    public String status;

    @Schema(name = "持续时间")
    public long startTimeMillis;

    @Schema(name = "预计持续时间")
    public long durationTimeMillis;

    @Schema(name = "构建步骤列表")
    public List<WorkflowStage> stages;

}
