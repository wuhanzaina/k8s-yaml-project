package com.kotei.sdw.devops.deploycenter.utils;

import com.google.common.collect.Maps;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.RandomStringUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.*;

public class AKSKUtil {
    private static final String HMAC_SHA1_ALGORITHM = "HmacSHA1";

    /**
     * 计算 AK/SK 签名
     *
     * @param accessKeyId     AccessKeyId
     * @param accessKeySecret AccessKeySecret
     * @param method          HTTP 请求方法
     * @param path            HTTP 请求路径
     * @param headers         HTTP 请求头
     * @param queryParams     HTTP 查询参数
     * @param body            HTTP 请求体
     * @return 签名字符串
     */
    public static String sign(String accessKeyId, String accessKeySecret,
                              String method, String path, Map<String, String> headers, Map<String, String> queryParams, Map<String, Object> body) {
        String stringToSign = getStringToSign(method, path, headers, queryParams, body);
        String signature = calculateSignature(accessKeySecret, stringToSign);
        return accessKeyId + ":" + signature;
    }

    /**
     * 计算 AK/SK 签名
     *
     * @param accessKeyId     AccessKeyId
     * @param accessKeySecret AccessKeySecret
     * @param method          HTTP 请求方法
     * @param path            HTTP 请求路径
     * @param headers         HTTP 请求头
     * @param queryParams     HTTP 查询参数
     * @return 签名字符串
     */
    public static String sign(String accessKeyId, String accessKeySecret,
                              String method, String path, Map<String, String> headers, Map<String, String> queryParams) {
        String stringToSign = getStringToSign(method, path, headers, queryParams);
        String signature = calculateSignature(accessKeySecret, stringToSign);
        return accessKeyId + ":" + signature;
    }

    /**
     * 验证 AK/SK 签名的正确性
     *
     * @param accessKeyId     AccessKeyId
     * @param accessKeySecret AccessKeySecret
     * @param method          HTTP 请求方法
     * @param path            HTTP 请求路径
     * @param headers         HTTP 请求头
     * @param queryParams     HTTP 查询参数
     * @param body            HTTP 请求体
     * @param signature       签名字符串
     * @return 签名是否正确
     */
    public static boolean verify(String accessKeyId, String accessKeySecret, String method, String path, Map<String, String> headers, Map<String, String> queryParams, Map<String, Object> body, String signature) {
        String stringToSign = getStringToSign(method, path, headers, queryParams, body);
        String expectedSignature = calculateSignature(accessKeySecret, stringToSign);
        String expectedAuthorization = accessKeyId + ":" + expectedSignature;
        return expectedAuthorization.equals(signature);
    }

    /**
     * 验证 AK/SK 签名的正确性
     *
     * @param accessKeyId     AccessKeyId
     * @param accessKeySecret AccessKeySecret
     * @param method          HTTP 请求方法
     * @param path            HTTP 请求路径
     * @param headers         HTTP 请求头
     * @param queryParams     HTTP 查询参数
     * @param signature       签名字符串
     * @return 签名是否正确
     */
    public static boolean verify(String accessKeyId, String accessKeySecret, String method, String path, Map<String, String> headers, Map<String, String> queryParams, String signature) {
        String stringToSign = getStringToSign(method, path, headers, queryParams);
        String expectedSignature = calculateSignature(accessKeySecret, stringToSign);
        String expectedAuthorization = accessKeyId + ":" + expectedSignature;
        return expectedAuthorization.equals(signature);
    }

    /**
     * 按照规范生成待签名字符串
     *
     * @param method      HTTP 请求方法
     * @param path        HTTP 请求路径
     * @param headers     HTTP 请求头
     * @param queryParams HTTP 查询参数
     * @param body        HTTP 请求体
     * @return 待签名字符串
     */
    private static String getStringToSign(String method, String path, Map<String, String> headers, Map<String, String> queryParams, Map<String, Object> body) {
        return method.toUpperCase() + "\n" +
                path + "\n" +
                getSortedHeadersString(headers)
                + "\n" + getSortedParamsString(queryParams)
//                + "\n" + getSortedBodyString(body)
                ;
    }

    /**
     * 按照规范生成待签名字符串
     *
     * @param method      HTTP 请求方法
     * @param path        HTTP 请求路径
     * @param headers     HTTP 请求头
     * @param queryParams HTTP 查询参数
     * @return 待签名字符串
     */
    private static String getStringToSign(String method, String path, Map<String, String> headers, Map<String, String> queryParams) {
        return method.toUpperCase() + "\n" +
                path + "\n" +
                getSortedHeadersString(headers)
                + "\n" + getSortedParamsString(queryParams)
//                + "\n" + getSortedBodyString(body)
                ;
    }

    /**
     * 获取按照字母顺序排序后的请求头字符串
     *
     * @param headers HTTP 请求头
     * @return 排序后的请求头字符串
     */
    private static String getSortedHeadersString(Map<String, String> headers) {
        if (headers == null || headers.isEmpty()) {
            return "";
        }

        TreeMap<String, String> sortedHeaders = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        sortedHeaders.putAll(headers);

        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> entry : sortedHeaders.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            sb.append(key.toLowerCase()).append(":").append(value.trim()).append("\n");
        }
        return sb.toString();
    }

    /**
     * 获取按照字母顺序排序后的请求参数字符串
     *
     * @param params HTTP 请求参数
     * @return 排序后的请求参数字符串
     */
    private static String getSortedParamsString(Map<String, String> params) {
        if (params == null || params.isEmpty()) {
            return "";
        }

        TreeMap<String, String> sortedParams = new TreeMap<>(params);

        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> entry : sortedParams.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            sb.append(key).append("=").append(value).append("&");
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb.toString();
    }

    /**
     * 生成经过签名的请求Body字符串
     *
     * @param bodyMap 请求的Body参数，Map<String, Object> 类型
     * @return 经过签名的请求Body字符串
     */
    public static String getSortedBodyString(Map<String, Object> bodyMap) {
        // 1. 将参数 key 按照字典升序排序
        SortedMap<String, Object> sortedParams = new TreeMap<>(bodyMap);

        // 2. 拼接参数 key 和 value
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Object> entry : sortedParams.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (value != null) {
                sb.append(key).append("=");
                if (value instanceof Map) {
                    sb.append(getSortedBodyString((Map<String, Object>) value));
                } else {
                    sb.append(value.toString());
                }
                sb.append("&");
            }
        }

        // 3. 去掉拼接字符串末尾的 &
        if (sb.length() > 0) {
            sb.setLength(sb.length() - 1);
        }
        return sb.toString();
    }

    /**
     * 计算 HMAC-SHA1 签名
     *
     * @param accessKeySecret AccessKeySecret
     * @param data            待签名数据
     * @return 签名字符串
     */
    private static String calculateSignature(String accessKeySecret, String data) {
        try {
            SecretKeySpec signingKey = new SecretKeySpec(accessKeySecret.getBytes(StandardCharsets.UTF_8), HMAC_SHA1_ALGORITHM);
            Mac mac = Mac.getInstance(HMAC_SHA1_ALGORITHM);
            mac.init(signingKey);
            byte[] rawHmac = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeBase64String(rawHmac);
        } catch (NoSuchAlgorithmException | InvalidKeyException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 生成accessKey
     * [0]:accessKeyId
     * [1]:accessKeySecret
     * @return
     */
    public static String[] genAccessKey() {
        return new String[]{RandomStringUtils.randomAlphanumeric(16), RandomStringUtils.randomAlphanumeric(32)};
    }

    public static void main(String[] args) {
        genAccessKey();
        System.out.println(new SimpleDateFormat("yyyyMMddHHmmssZ").format(new Date()));

        // AK/SK 认证信息
        String accessKeyId = "your-access-key-id";
        String accessKeySecret = "your-access-key-secret";

        // HTTP 请求信息
        String method = "POST";
        String path = "/example/api";
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("X-SDW-Date", "20220308T171423Z");

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("key1", "value1");
        queryParams.put("key2", "value2");
        Map<String, Object> body = new HashMap<>();
        body.put("param1", "value1");
        body.put("param2", "value2");
        Map<String, Object> s1 = Maps.newHashMap();
        s1.put("param3-1", 1);
        s1.put("param3-2", 2);
        body.put("param2", s1);

        // 计算签名
        String signature = AKSKUtil.sign(accessKeyId, accessKeySecret, method, path, headers, queryParams);
        System.out.println("Signature: " + signature);
        headers.put("X-SDW-SIGNATURE", signature);

        // 验证签名
        boolean isValid = AKSKUtil.verify(accessKeyId, accessKeySecret, method, path, headers, queryParams, signature);
        System.out.println("Is valid: " + isValid);
    }
}