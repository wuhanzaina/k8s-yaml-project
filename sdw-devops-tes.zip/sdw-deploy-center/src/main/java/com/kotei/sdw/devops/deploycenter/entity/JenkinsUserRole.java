package com.kotei.sdw.devops.deploycenter.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.mongodb.core.mapping.Document;


@Data
@ToString
@Document
public class JenkinsUserRole {

    @Schema(name = "角色名称")
    private String name;

    @Schema(name = "全局角色")
    private JenkinsUserRoleInfo globalRole;

    @Schema(name = "item角色")
    private JenkinsUserRoleInfo projectRole;

    @Schema(name = "salve角色")
    private JenkinsUserRoleInfo slaveRole;

}
