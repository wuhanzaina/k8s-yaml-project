package com.kotei.sdw.devops.deploycenter.service;

import com.alibaba.fastjson.JSON;
import com.cdancy.jenkins.rest.JenkinsApi;
import com.cdancy.jenkins.rest.domain.common.RequestStatus;
import com.cdancy.jenkins.rest.domain.job.BuildInfo;
import com.cdancy.jenkins.rest.domain.job.ProgressiveText;
import com.cdancy.jenkins.rest.domain.job.Workflow;
import com.cdancy.jenkins.rest.domain.queue.QueueItem;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kotei.sdw.devops.deploycenter.entity.Job;
import com.kotei.sdw.devops.deploycenter.entity.Pipeline;
import com.kotei.sdw.devops.deploycenter.enums.JobResultEnum;
import com.kotei.sdw.devops.deploycenter.enums.JobStageEnum;
import com.kotei.sdw.devops.deploycenter.exception.ServiceException;
import com.kotei.sdw.devops.deploycenter.repository.JobRepository;
import com.kotei.sdw.devops.deploycenter.repository.PipelineRepository;
import com.kotei.sdw.devops.deploycenter.response.BuildProgressiveText;
import com.kotei.sdw.devops.deploycenter.response.JobInfoVO;
import com.kotei.sdw.devops.deploycenter.response.WorkflowVO;
import com.kotei.sdw.devops.deploycenter.utils.JenkinsHelper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;

@Slf4j
@AllArgsConstructor
@Service
public class JobService {

    private PipelineRepository pipelineRepository;
    private JobRepository jobRepository;

    private JenkinsHelper jenkinsHelper;

    public String startJob(String pipelineId, LinkedHashMap<String, String> param) {

        Optional<Pipeline> pipelineOptional = pipelineRepository.findById(pipelineId);
        Pipeline pipeline = pipelineOptional.orElseThrow(
                () -> new ServiceException(String.format("流水线不存在[id:%s]", pipelineId))
        );

        String jobId = new Date().getTime() + RandomStringUtils.randomAlphanumeric(10);
        JenkinsApi jenkinsApi = jenkinsHelper.getJenkinsAdminClientSdk();
        Integer queueId = jenkinsHelper.startJob(jenkinsApi, pipeline.getPath(), jobId, param);

        Job job = new Job();
        job.setId(jobId);
        job.setApplicationId(pipeline.getApplicationId());
        job.setProjectId(pipeline.getProjectId());
        job.setPipelineName(pipeline.getName());
        job.setPath(pipeline.getPath());
        job.setCreatedTime(new Date());
        job.setQueueId(queueId);
        job.setStage(JobStageEnum.queue);
        job.setVersion(new Date().getTime());
        job = jobRepository.insert(job);
        return job.getId();
    }

    public void updateJobStatus() {

        Job jobProbe = new Job();
        jobProbe.setStage(JobStageEnum.queue);
        Example<Job> jobExample = Example.of(jobProbe);
        List<Job> jobList = jobRepository.findAll(jobExample);
        if (!CollectionUtils.isEmpty(jobList)) {

            JenkinsApi jenkinsApi = jenkinsHelper.getJenkinsAdminClientSdk();
            for (Job job : jobList) {
                Job upJob = null;
                try {
                    QueueItem queueItem = jenkinsApi.queueApi().queueItem(job.getQueueId());
                    if (queueItem.cancelled()) {
                        upJob = new Job();
                        BeanUtils.copyProperties(job, upJob);
                        upJob.setStage(JobStageEnum.cancelled);
                    }
                    if (queueItem.executable() != null) {
                        upJob = new Job();
                        BeanUtils.copyProperties(job, upJob);
                        upJob.setStage(JobStageEnum.build);
                        upJob.setJobNumber(queueItem.executable().number());

                        String[] splitPath = jenkinsHelper.splitJenkinsPath(job.getPath());
                        BuildInfo buildInfo = jenkinsApi.jobsApi().buildInfo(splitPath[0], splitPath[1], queueItem.executable().number());
                        if (buildInfo.result() != null) {
                            upJob.setResult(JobResultEnum.valueOf(buildInfo.result()));
                        } else {
                            upJob.setResult(JobResultEnum.PROCESSING);
                        }
                    }
                } catch (Exception e){
                    if("org.jclouds.rest.ResourceNotFoundException".equals(e.getClass().getName())){
                        try {
                            HashMap message = JSON.parseObject(e.getMessage(), HashMap.class);
                            if(!CollectionUtils.isEmpty(message)){
                                if("404".equals(message.get("status"))){
                                    upJob = new Job();
                                    BeanUtils.copyProperties(job, upJob);
                                    upJob.setStage(JobStageEnum.unknown);
                                }
                            }
                        } catch (Exception e1){
                            log.error(e.getMessage(), e1);
                        }
                    }
                    log.error(e.getMessage(), e);
                }
                if (upJob != null) {
                    upJob.setId(job.getId());
                    upJob.setVersion(new Date().getTime());
                    upJob.setUpdatedTime(new Date());
                    jobRepository.save(upJob);
                }
            }
        }
    }

    public List<Workflow> jobListByPipelineId(String pipelineId) {

        Optional<Pipeline> pipelineOptional = pipelineRepository.findById(pipelineId);
        Pipeline pipeline = pipelineOptional.orElseThrow(
                () -> new ServiceException(String.format("流水线不存在[id:%s]", pipelineId))
        );

        List<Workflow> workflowList = jenkinsHelper.getJenkinsAdminClientSdk().jobsApi().runHistory(
                String.join("/", pipeline.getApplicationCode(), pipeline.getProjectCode()),
                pipeline.getName()
        );
        return workflowList;
    }

    public JobInfoVO buildInfo(String jobId) {

        Optional<Job> jobOptional = jobRepository.findById(jobId);
        Job job = jobOptional.orElseThrow(
                () -> new ServiceException(String.format("任务不存在[id:%s]", jobId))
        );

        if (job.getQueueId() == null) {
            throw new ServiceException(String.format("任务数据异常[jobId:'%s']", jobId));
        }

        JobInfoVO jobInfoVO = new JobInfoVO();
        if (job.getJobNumber() != null) {
            jobInfoVO.setJobNumber(job.getJobNumber());
            String[] splitPath = jenkinsHelper.splitJenkinsPath(job.getPath());
            jobInfoVO.setResult(job.getResult());
            BuildInfo buildInfo = jenkinsHelper.getJenkinsAdminClientSdk().jobsApi().buildInfo(splitPath[0], splitPath[1], job.getJobNumber());
            jobInfoVO.setBuildInfo(jenkinsHelper.jenkinsBuildInfoToResponse(buildInfo));
            if (buildInfo.result() != null) {
                jobInfoVO.setResult(JobResultEnum.valueOf(buildInfo.result()));
            } else {
                jobInfoVO.setResult(JobResultEnum.PROCESSING);
            }
        }
        jobInfoVO.setId(jobId);
        jobInfoVO.setStage(job.getStage());
        jobInfoVO.setQueueId(job.getQueueId());

        return jobInfoVO;
    }

    public WorkflowVO workFlowInfo(String jobId) {

        Optional<Job> jobOptional = jobRepository.findById(jobId);
        Job job = jobOptional.orElseThrow(
                () -> new ServiceException(String.format("任务不存在[id:%s]", jobId))
        );

        if (job.getQueueId() == null) {
            throw new ServiceException(String.format("任务数据异常[jobId:'%s']", jobId));
        }

        if (job.getJobNumber() != null) {
            String[] splitPath = jenkinsHelper.splitJenkinsPath(job.getPath());
            Workflow workflow = jenkinsHelper.getJenkinsAdminClientSdk().jobsApi().workflow(splitPath[0], splitPath[1], job.getJobNumber());
            return jenkinsHelper.jenkinsWorkflowInfoToResponse(workflow);
        }
        return null;
    }

    public void stop(String jobId) {

        Optional<Job> jobOptional = jobRepository.findById(jobId);
        Job job = jobOptional.orElseThrow(
                () -> new ServiceException(String.format("任务不存在[id:%s]", jobId))
        );

        String[] splitPath = jenkinsHelper.splitJenkinsPath(job.getPath());
        RequestStatus requestStatus = jenkinsHelper.getJenkinsAdminClientSdk().jobsApi().stop(splitPath[0], splitPath[1], job.getJobNumber());
        if (!requestStatus.value()) {
            throw new ServiceException("停止任务失败");
        }
    }

    public void kill(String jobId) {

        Optional<Job> jobOptional = jobRepository.findById(jobId);
        Job job = jobOptional.orElseThrow(
                () -> new ServiceException(String.format("任务不存在[id:%s]", jobId))
        );

        String[] splitPath = jenkinsHelper.splitJenkinsPath(job.getPath());
        RequestStatus requestStatus = jenkinsHelper.getJenkinsAdminClientSdk().jobsApi().kill(splitPath[0], splitPath[1], job.getJobNumber());
        if (!requestStatus.value()) {
            throw new ServiceException("停止任务失败");
        }
    }

    public BuildProgressiveText getJobConsoleLog(String jobId) {

        Optional<Job> jobOptional = jobRepository.findById(jobId);
        Job job = jobOptional.orElseThrow(
                () -> new ServiceException(String.format("任务不存在[id:%s]", jobId))
        );

        if(job.getJobNumber() == null){
            BuildProgressiveText progressiveText = new BuildProgressiveText();
            progressiveText.setText("");
            return progressiveText;
        }

        String[] splitPath = jenkinsHelper.splitJenkinsPath(job.getPath());
        log.info("fetch jenkins log text:{folder:{}, jobName:{}, jobNumber:{}}", splitPath[0], splitPath[1], job.getJobNumber());
        ProgressiveText progressiveText = jenkinsHelper.getJenkinsAdminClientSdk().jobsApi().progressiveText(splitPath[0], splitPath[1], job.getJobNumber());

        BuildProgressiveText buildProgressiveText = new BuildProgressiveText();
        if(progressiveText != null){
            String text = StringUtils.substringAfter(progressiveText.text(), System.lineSeparator());
            buildProgressiveText.setText(text);
            buildProgressiveText.setSize(progressiveText.size());
            buildProgressiveText.setHasMoreData(progressiveText.hasMoreData());
        }


        return buildProgressiveText;
    }
}
