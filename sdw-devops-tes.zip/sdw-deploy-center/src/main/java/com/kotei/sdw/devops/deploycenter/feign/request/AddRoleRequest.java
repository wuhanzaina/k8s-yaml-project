package com.kotei.sdw.devops.deploycenter.feign.request;

import lombok.Data;

@Data
public class AddRoleRequest {

    /**
     * 角色类型
     * 角色类型
     */
    private String type;

    /**
     * 角色名称
     */
    private String roleName;

    /**
     * 权限
     */
    private String permissionIds;

    /**
     * 是否覆盖
     */
    private boolean overwrite;

    /**
     * 数据权限表达式
     */
    private String pattern;
}
