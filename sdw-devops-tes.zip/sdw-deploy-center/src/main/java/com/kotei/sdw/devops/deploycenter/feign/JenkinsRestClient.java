package com.kotei.sdw.devops.deploycenter.feign;

import com.kotei.sdw.devops.deploycenter.config.JenkinsFeignConfig;
import com.kotei.sdw.devops.deploycenter.feign.reponse.RoleInfo;
import com.kotei.sdw.devops.deploycenter.feign.request.AddRoleRequest;
import com.kotei.sdw.devops.deploycenter.feign.request.AssignRoleRequest;
import feign.Headers;
import feign.QueryMap;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.core.io.FileSystemResource;
import org.springframework.data.web.config.EnableSpringDataWebSupport;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.Map;

@EnableSpringDataWebSupport
@FeignClient(name = "jenkins-client", url = "${jenkins.endPoint}", configuration = JenkinsFeignConfig.class)
public interface JenkinsRestClient {
    /**
     * 创建用户
     *
     * @param username
     * @param password1
     * @param password2
     * @param fullname
     * @param email
     */
    @Headers({"Authorization: Basic YWRtaW46MTFlZWJjMGJjMWY5ZGVhOWRhZTkwOTE2MTRkMzM2MjcwNg=="})
    @PostMapping(value = "/securityRealm/createAccountByAdmin",
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    void addJenkinsUser(@RequestParam("username") String username,
                        @RequestParam("password1") String password1,
                        @RequestParam("password2") String password2,
                        @RequestParam("fullname") String fullname,
                        @RequestParam("email") String email);

    /**
     * 删除用户
     *
     * @param username
     */
    @Headers({"Authorization: Basic YWRtaW46MTFlZWJjMGJjMWY5ZGVhOWRhZTkwOTE2MTRkMzM2MjcwNg=="})
    @PostMapping(value = "/securityRealm/user/{username}/doDelete",
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    void deleteJenkinsUser(@PathVariable("username") String username);


//    @Headers({"Authorization: Basic YWRtaW46MTFlZWJjMGJjMWY5ZGVhOWRhZTkwOTE2MTRkMzM2MjcwNg=="})
//    @PostMapping(value = "/manage/credentials/store/system/domain/_/createCredentials",
//            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
//            produces = MediaType.APPLICATION_JSON_VALUE)
//    void createCredential(@RequestParam("json") String json, @RequestPart("file0") File file0);

    /**
     * 查询角色权限详情
     *
     * @param roleName
     * @param type
     * @return
     */
    @GetMapping(value = "/role-strategy/strategy/getRole", consumes = MediaType.APPLICATION_JSON_VALUE)
    RoleInfo getRole(@RequestParam("roleName") String roleName, @RequestParam("type") String type);

    /**
     * 查询所有角色
     *
     * @return
     */
    @GetMapping(value = "/role-strategy/strategy/getAllRoles", consumes = MediaType.APPLICATION_JSON_VALUE)
    Map<String, String[]> getAllRoles();

    /**
     * 创建角色
     *
     * @param addRoleRequest
     */
    @PostMapping(value = "/role-strategy/strategy/addRole",
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    void addRole(@RequestParam AddRoleRequest addRoleRequest);

    @PostMapping(value = "/role-strategy/strategy/addRole",
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    void addRoleByMap(@QueryMap Map map);

    @PostMapping(value = "/role-strategy/strategy/addRole",
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    void addRoleByParam(@RequestParam("type") String type, @RequestParam("roleName") String roleName,
                        @RequestParam("permissionIds") String permissionIds, @RequestParam("overwrite") boolean overwrite,
                        @RequestParam("pattern") String pattern);

    /**
     * 角色关联用户
     *
     * @param assignRoleRequest
     */
    @PostMapping(value = "/role-strategy/strategy/assignRole",
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    void assignRole(AssignRoleRequest assignRoleRequest);
}
