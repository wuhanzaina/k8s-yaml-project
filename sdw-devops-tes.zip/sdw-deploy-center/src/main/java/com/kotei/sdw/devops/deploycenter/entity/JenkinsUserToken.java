package com.kotei.sdw.devops.deploycenter.entity;

import lombok.Data;
import lombok.ToString;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@ToString
@Document
public class JenkinsUserToken {

    private String name;

    private String token;

}
