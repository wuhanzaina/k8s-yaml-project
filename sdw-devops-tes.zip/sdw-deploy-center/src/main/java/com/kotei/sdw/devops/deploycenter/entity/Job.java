package com.kotei.sdw.devops.deploycenter.entity;

import com.kotei.sdw.devops.deploycenter.enums.JobResultEnum;
import com.kotei.sdw.devops.deploycenter.enums.JobStageEnum;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;


@Data
@ToString
@Document
public class Job {

  @Id
  private String id;

  /**
   * 应用id
   */
  private String applicationId;

  /**
   * 项目id
   */
  private String projectId;

  /**
   * 流水线名称
   */
  private String pipelineName;

  /**
   * 任务号
   */
  private Integer jobNumber;

  /**
   * 任务队列id
   */
  private Integer queueId;


  /**
   * jenkins完整path
   */
  private String path;

  /**
   * 任务阶段状态
   */
  private JobStageEnum stage;

  private JobResultEnum result;

  private Long version;

  /**
   * 创建人
   */
  private String createdBy;

  /**
   * 创建时间
   */
  private Date createdTime;

  /**
   * 跟新人
   */
  private String updatedBy;

  /**
   * 更新时间
   */
  private Date updatedTime;

  /**
   * 是否已删除
   */
  private String deleted;

}
