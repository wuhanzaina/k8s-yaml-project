import common.Utils
import groovy.text.SimpleTemplateEngine
import groovy.text.Template
import org.codehaus.groovy.runtime.NullObject

import java.text.SimpleDateFormat


def call(inParams) {
    pipeline {
        def current_time = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
        def label_random = "build_${inParams.project_name}_${current_time}"

        //inParams.k8s.env.type不填，默认为开发环境
        if (!inParams.k8s || !inParams.k8s.env || !inParams.k8s.env.type) {
            if (!inParams.k8s.env) {
                inParams.k8s.env = ["type": "dev"]
            } else {
                inParams.k8s.env.type == "dev"
            }
        }


        def harbor_prefix = inParams.harbor_prefix ? inParams.harbor_prefix : common.Utils.getSysValue("default_harbor_prefix", inParams.k8s.env.type)
        inParams.harbor_prefix = harbor_prefix
        def worker_cluster = inParams.worker_cluster ? inParams.worker_cluster : ""
        def pod_run_machine = common.Utils.getSysValue("default_pod_run_machine",inParams.k8s.env.type)

        podTemplate(
                label: "$label_random",
                cloud: "${worker_cluster}",
                containers: [
                        containerTemplate(
                                name: 'git',
                                image: "${harbor_prefix}/bitnami/git:2.39.2",
                                ttyEnabled: true,
                                privileged: true,
                                runAsUser: '0',
                                resourceRequestCpu: '0.5',
                                resourceRequestMemory: '512Mi',
                                command: 'cat'
                        ),
                        containerTemplate(
                                name: 'node',
                                image: "${harbor_prefix}/smart-develop/node:18.19-alpine",
                                ttyEnabled: true,
                                privileged: true,
                                resourceRequestCpu: '3',
                                resourceRequestMemory: '4Gi',
                                runAsUser: '1000',
                                command: 'cat'
                        ),
                        containerTemplate(name: 'docker',
                                image: "${harbor_prefix}/default/docker:20.10.16-dind",
                                privileged: true,
                                ttyEnabled: true,
                                runAsUser: '0',
                                resourceRequestCpu: '0.5',
                                resourceRequestMemory: '512Mi',
                                command: 'cat'
                        ),
                        containerTemplate(name: 'sonar',
                                image: "${harbor_prefix}/smart-develop/sonarsource/sonar-scanner-cli:5.0.1",
                                privileged: true,
                                ttyEnabled: true,
                                runAsUser: '1000',
                                resourceRequestCpu: '0.5',
                                resourceRequestMemory: '512Mi',
                                command: 'cat'
                        ),
                        containerTemplate(name: 'kubectl',
                                image: "${harbor_prefix}/theohbrothers/docker-kubectl:20220919.0.0-v1.22.14-alpine-3.8",
                                privileged: true,
                                ttyEnabled: true,
                                runAsUser: '1000',
                                resourceRequestCpu: '0.5',
                                resourceRequestMemory: '512Mi',
                                command: 'cat'
                        )

                ],
                volumes: [
                        hostPathVolume(
                                hostPath: '/var/run/docker.sock',
                                mountPath: '/var/run/docker.sock'
                        ),
                        hostPathVolume(
                                hostPath: '/usr/bin/docker',
                                mountPath: '/usr/bin/docker'
                        )
                ],
                nodeSelector: "kubernetes.io/hostname=${pod_run_machine}",


        ) {
            node("$label_random") {

                def gitlab_credential_id = common.Utils.getSysValue("default_gitlab_credential_id", inParams.k8s.env.type)
                def code_source_git_url = common.Utils.getSysValue("default_code_source_git_url", inParams.k8s.env.type)
                def harbor_url = common.Utils.getSysValue("default_harbor_url", inParams.k8s.env.type)
                def harbor_credential_id = common.Utils.getSysValue("default_harbor_credential_id", inParams.k8s.env.type)
                def npm_registry = common.Utils.getSysValue("default_npm_registry", inParams.k8s.env.type)

                def image_version = new Date().format("yyyyMMddHHmmss") + ".DEV"
                if (inParams.sys_version) {
                    image_version = inParams.sys_version
                }
                println('this images_version = '+image_version)
                def harbor_project = inParams.harbor_project_smart_develop ? inParams.harbor_project_smart_develop : "smart-develop"
                def image = "${harbor_prefix}/${harbor_project}/front/${inParams.project_name}:${image_version}"
                def sub_project_path = inParams.sub_project_path ? "/${inParams.sub_project_path}" : ""
                def project_path = "${WORKSPACE}${sub_project_path}"
                def exec_dockerfile_path = "${project_path}/dockerfile"
                def docker_build_root_path = "${project_path}/nginx-docker-${UUID.randomUUID().toString()}"

                def kube_config_resource_file = null
                def kube_config_file_arg = ""
                def kube_config_file_name = "kube_config.yml"
//                if (["test"].contains(inParams.k8s.env.type)) {
                    //生产或开发环境部署在jenkins所在的ks，不需要指定kubeconfig。其他环境需要指定kubeconfig
                    kube_config_resource_file = "k8s/kubeconfig/env_${inParams.k8s.env.type}.yml"
                    kube_config_file_arg = " --kubeconfig ${kube_config_file_name} "
//                }

                inParams.commit_tag = inParams.commit_tag ? inParams.commit_tag : false
                inParams.k8s.namespace = inParams.k8s.namespace ? inParams.k8s.namespace : "smart-develop-${inParams.k8s.env.type}"
                inParams.k8s.project_name = inParams.project_name ? inParams.project_name : "${JOB_BASE_NAME}"
                inParams.k8s.containers[0].image = image
                inParams.web_context = inParams.web_context ? inParams.web_context : ""

                inParams.k8s.config_mount_path = "/var/www"
                if(inParams.web_context && !"".equals(inParams.web_context)){
                    inParams.k8s.config_mount_path += "/${inParams.web_context}"
                }
                inParams.k8s.config_mount_path += "/config"

                if (!inParams.k8s.config_map) {
                    inParams.k8s.config_map = [:]
                }
                if (!inParams.k8s.config_map.data) {
                    inParams.k8s.config_map.data = [:]
                }
                inParams.docker_file_path = inParams.docker_file_path ? inParams.docker_file_path : "lib:frontend/dockerfile/default/Dockerfile.tfl"

                println("params:" + inParams)

                stage('Checkout Code') {
                    container("git") {
                        stage("checkout source code") {
                            git branch: "${inParams.code_source_git_branch}",
                                    credentialsId: "${gitlab_credential_id}",
                                    url: "${code_source_git_url}/${inParams.git_url}"
                        }

                        stage("git tag") {
                            if (inParams.commit_tag == true) {
                                steps {
                                    println("commit git tag:${image_version}")
                                    withCredentials([gitUsernamePassword(credentialsId: "${gitlab_credential_id}", gitToolName: "Default")]) {
                                        sh """
                                            git config --global --add safe.directory ${project_path}
                                            git config --global user.email ${Utils.getSysValue("git_user_email")}
                                            git config --global user.name ${common.Utils.getSysValue("git_user_name")}
                                            git tag -a ${image_version} -m 'tag ${image_version} by jenkins'
                                            git push --tags
                                        """
                                    }
                                }
                            }
                        }
                    }
                }

//                stage('checkCode') {
//                    container("sonar") {
//                        sh """
//                            sonar-scanner -Dsonar.projectKey=front_project  -Dsonar.sources=. -Dsonar.host.url=http://192.168.53.219:9000 -Dsonar.login=c3e7a785c5d34b3616f6c9cf426fd4e20e034082
//                        """
//                    }
//                }

                stage("code-review") {
                    container("sonar") {

                        if ( inParams.code_review != null && inParams.code_review ) {

                            sh """
                            cd ${project_path}
                            sonar-scanner -Dsonar.exclusions=public/**/* -Dsonar.projectKey=${inParams.project_name}  -Dsonar.sources=. -Dsonar.host.url=http://192.168.53.219:9000 -Dsonar.login=c3e7a785c5d34b3616f6c9cf426fd4e20e034082
                            
                           """
                        } else{
                            print("跳过代码静态扫描")
                        }
                    }
                }

                stage('Compile & Package') {
                    container("node") {
                        sh """
                            pwd 
                            
                            rm -rf yarn.lock package-lock.json
                            npm config set registry http://192.168.52.165:8081/repository/npm-public/  
                            
                            
                           npm install && npm run build
                        """
                    }
                    //npm cache clean --force
                }

                stage('Build docker image') {
                    container('docker') {
                        stage("Prepare deploy files") {
                            println("prepare Dockerfile:${inParams.docker_file_path}")
                            if (inParams.docker_file_path.startsWith("lib:")) {
                                println("load Dockerfile:${inParams.docker_file_path.substring(4)}")
                                def dockerfileTfl = libraryResource(inParams.docker_file_path.substring(4))
                                def nginxConfigTxt = common.Utils.renderTemplate(dockerfileTfl, inParams)
                                println("dockerfile:" + nginxConfigTxt)
                                println("write Dockerfile to:${exec_dockerfile_path}")
                                writeFile file: "${exec_dockerfile_path}", text: nginxConfigTxt
                            } else {
                                sh "cp ${WORKSPACE}/${inParams.docker_file_path} ${docker_build_root_path}/"
                            }

                            println("prepare nginx.conf")
                            def nginxConfTflPath = "frontend/dockerfile/default/nginx.conf.tfl"
                            println("load nginx.conf.tfl:${nginxConfTflPath}")
                            def nginxConfigTflTxt = libraryResource(nginxConfTflPath)
                            def nginxConfigTxt = common.Utils.renderTemplate(nginxConfigTflTxt, inParams)
                            println("nginx.conf text:\n${nginxConfigTxt}")
                            println("write nginx.conf to ${docker_build_root_path}/default.conf")
                            writeFile file: "${docker_build_root_path}/nginx.conf", text: nginxConfigTxt


                            println("prepare nginx-root.conf")
                            def nginxRootConfigPath = "frontend/dockerfile/default/nginx-root.conf"
                            println("load nginx-root.conf:${nginxRootConfigPath}")
                            def nginxRootConfigTxt = libraryResource(nginxRootConfigPath)
                            println("nginx-root.conf text:\n${nginxRootConfigTxt}")
                            println("write nginx-root.conf to ${docker_build_root_path}/nginx.conf")
                            writeFile file: "${docker_build_root_path}/nginx-root.conf", text: nginxRootConfigTxt


                            println("prepare start-nginx.sh")
                            def startNginxPath = "frontend/dockerfile/default/start-nginx.sh"
                            println("load start-nginx.sh:${startNginxPath}")
                            def startNginxTxt = libraryResource(startNginxPath)
                            println("nginx-root.conf text:\n${startNginxTxt}")
                            println("write start-nginx.sh to ${docker_build_root_path}/start-nginx.sh")
                            writeFile file: "${docker_build_root_path}/start-nginx.sh", text: startNginxTxt

                            println("copy dist to temp docker build dir:${docker_build_root_path}")
                            sh """
                                mkdir -p ${docker_build_root_path}
                                mv ${WORKSPACE}/dist ${docker_build_root_path}
                            """
                        }

                        stage("docker build & push") {
                            docker.withRegistry("${harbor_url}", "${harbor_credential_id}") {
                                dir("${docker_build_root_path}") {
                                    sh """
                                    docker build -t ${image} -f '${exec_dockerfile_path}' .
                                    docker push ${image}
                                """
                                }
                            }
                        }
                    }
                }

                stage("deploy to k8s") {
                    container("kubectl") {
                        if(inParams.run_deploy == true){
                            def target_config_folder = "${project_path}/pipetmp_${current_time}/k8s_apply_config"
                            println("prepare k8s apply files to ${target_config_folder}")
                            sh "mkdir -p ${target_config_folder}"

                            def resource_types = inParams.deploy_resource_type.split(",")
                            if (resource_types != null && resource_types.size() > 0) {
                                sh "mkdir -p ${target_config_folder}"
                                for (resource_type in resource_types) {
                                    println("prepare [${resource_type}] apply file")
                                    def tflPath = "frontend/k8sftl/default/${resource_type}.yml.tfl"
                                    println("render file:${tflPath}")
                                    def tflTxt = libraryResource(tflPath)
                                    def k8sResConfigtxt = Utils.renderTemplate(tflTxt, inParams.k8s)
                                    println(k8sResConfigtxt)
                                    println("write ${target_config_folder}/${resource_type}.yml")
                                    writeFile file: "${target_config_folder}/${resource_type}.yml", text: k8sResConfigtxt
                                }
                            }

                            println("prepare kubeconfig")
                            if (kube_config_resource_file) {
                                println("load kubeconfig file：${kube_config_resource_file}")
                                def kubeconfigTxt = libraryResource(kube_config_resource_file)
                                println("write kubeconfig file")
                                writeFile file: "${kube_config_file_name}", text: kubeconfigTxt
                            }

                            println("kubectl apply")
                            println("deploy command: kubectl apply -f ${target_config_folder} ${kube_config_file_arg}.")
                            sh """
                            kubectl apply -f ${target_config_folder} ${kube_config_file_arg} 
                               
                            
                            """
                        } else {
                            println("do not deploy. because run_deploy == false")
                        }
                    }
                }
            }
        }
    }
}


