pipeline {
    agent any
    environment{
        target_envi="devcpweb"  // ${target_envi}
        target_gitlab_name = "DEV_CP_Web"
        target_gitlab="git@172.16.0.120:astri/RI-KCarOS-AP/PanShi_Tools_SourceCode/DEV_CP_SourceCode/DEV_CP_Web.git"
        target_branch="develop"
        origin_branch="${gitlabBranch}"
        submitter_email="${gitlabUserEmail}"
        tool_sdk_dir="$WORKSPACE/jenkinsfiles/script_tool/tool_sdk_lib"
        DOCKER_NAME="tool_${target_envi}"
        DOCKER_NAME_CHECK="tool_${target_envi}_check"
    }
    stages {
        // 删除工作空间
        stage("delete workspace"){
            steps {
                script {
                    println("删除工作空间, clone script")
                    deleteDir()
                    sh """
                cd $WORKSPACE
                git clone git@172.16.0.120:astri/RI-KCarOS-AP/jenkinsfiles.git
                docker run -dit -v /home/jenkins/.jenkins:/home/jenkins/.jenkins -w "$WORKSPACE/jenkinsfiles/script_tool" --name $DOCKER_NAME npm:latest || docker start $DOCKER_NAME
                docker run -dit -v /home/jenkins/.jenkins:/home/jenkins/.jenkins -w "/home/jenkins/.jenkins/CI-CD/src" --name $DOCKER_NAME_CHECK alby117/tool_static_check:v1 || docker start $DOCKER_NAME_CHECK
                """
                }
            }
        }
        // 下载代码
        stage("GetCode") {  // 阶段名称
            steps {  // 步骤
                timeout(time:20, unit:"MINUTES") {
                    println("获取代码")
                    sh """
                    mkdir -p $tool_sdk_dir
                    cd $tool_sdk_dir
                    git clone $target_gitlab -b $target_branch;
                    """
                }
            }
        }
        // merge origin_branch to target_branch -- local
        stage("merge origin_branch to target_branch in local"){
            steps{
                timeout(time: 5, unit:"MINUTES"){
                    script{
                        print("在本地将源分支合并到目标分支,提交的分支${origin_branch}");
                        sh """
                        cd $tool_sdk_dir/$target_gitlab_name;
                        git pull origin "$origin_branch"
                        """
                    }
                }
            }
            post{
                failure{
                    script{
                        currentBuild.result="ABORTED"
                    }
                    mail to:"${submitter_email},zhong.lei@kotei.com.cn",
                            subject:"[${target_gitlab_name}]${origin_branch}分支错误",
                            body:"""STATUS FOR PROJECT:${currentBuild.fullDisplayName}\n提交分支${origin_branch}不存在或冲突导致错误\nPATH: ${JOB_URL}
                        """
                }
            }
        }
        // 代码扫描
        stage("CodeScan"){
            steps{
                //catchError(buildResult:'SUCCESS', stageResult:'FAILURE'){
                timeout(time: 20, unit:"MINUTES"){
                    script{
                        sh """echo "执行CICD检查代码"
                            docker exec -i ${DOCKER_NAME_CHECK} python3 main.py -p ${tool_sdk_dir}/${target_gitlab_name} ${target_envi};
                            cd $JENKINS_HOME/CI-CD/result/config_${target_envi}; cat results.log;cp results.log $WORKSPACE/;
                            cp *.xlsx $WORKSPACE/
                            """
                    }
                }
                //}
            }
            post{
                failure{
                    mail to:"zhong.lei@kotei.com.cn",
                            subject:"代码扫描分支错误",
                            body:"""STATUS FOR PROJECT:${currentBuild.fullDisplayName}\n查看PATH: ${JOB_URL}
                        """
                }
            }
        }
        // 打包

    }
    // 构建后操作
    post{
        success{
            emailext(
                    body: """STATUS FOR PROJECT:${currentBuild.fullDisplayName}\n
        提交分支${origin_branch}代码质量检查结果见附件，
        点击以下链接查看结果\n
                         PATH: ${JOB_URL}
                         """,
                    attachmentsPattern: "**/results.log,**/*_Report.xlsx",
                    from: "jenkins@kotei.com.cn",
                    replyTo: "zhong.lei@kotei.com.cn",
                    subject: "[${target_gitlab_name}]${origin_branch} ${currentBuild.result}",
                    to: "${submitter_email},zhong.lei@kotei.com.cn"
            )
        }

        failure{
            emailext(
                    body: """STATUS FOR PROJECT:${currentBuild.fullDisplayName}\n
        提交分支${origin_branch}代码质量检查结果见附件，
        点击以下链接查看结果\n
                         PATH: ${JOB_URL}
                         """,
                    attachmentsPattern: "**/results.log,**/*_Report.xlsx",
                    from: "jenkins@kotei.com.cn",
                    replyTo: "zhong.lei@kotei.com.cn",
                    subject: "[${target_gitlab_name}]${origin_branch} ${currentBuild.result}",
                    to: "zhong.lei@kotei.com.cn"
            )
        }
        aborted{
            script{
                println("构建取消")
                currentBuild.decription += "\n 构建取消！"
            }
        }
        always{
            script{
                sh """
                echo "删除容器";
                docker stop $DOCKER_NAME || echo "已停止";
                docker rm $DOCKER_NAME || echo "已删除";
                docker stop $DOCKER_NAME_CHECK || echo "已停止";
                docker rm $DOCKER_NAME_CHECK || echo "已删除";
                """
            }
        }
    }
}