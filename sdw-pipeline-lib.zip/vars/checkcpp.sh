root@KI-ZJ-2914:/home/wzy/codeType# cat checkcpp.sh
#!/bin/bash

workspace=$1
dir=$2
#dirs=$(echo "$dir" | jq -r 'map(.)[]')
newdir=""
#---------------------------------
excludes=""
cppcheckExcludeDir=""
if [ -z $dir ]; then
   echo "排除参数为空"
else
  newdir=${dir//,/ }
  for i in ${newdir} ;do
          excludes+="-x "${workspace}/${i}/* "
  done
  echo ${excludes}
  #----------------------------------
  for i in ${newdir} ;do
          cppcheckExcludeDir+=" -i $i"
  done
  echo ${cppcheckExcludeDir}
fi




#----------------------------------
str=${workspace}

result=$(ls ${workspace})

echo ${result}

cd ${workspace}

if [[ ${result} =~ "ULite" ]]; then
    echo "你好"
    cppcheck ${workspace}/ULite --addon=misra.py --language=c++  ${cppcheckExcludeDir}    -j 6  --suppress=unknownMacro &> /home/wzy/codeType/c++error.log
    python3 /home/wzy/codeType/analyzercppcheck.py
    lizard ${workspace}/ULite  ${excludes} -C 15 --csv > /home/wzy/codeType/lizard.csv
    tokei ${workspace}/ULite  --output yaml > /home/wzy/codeType/tokei.yaml

else

    cppcheck ${workspace} --addon=misra.py --language=c++  ${cppcheckExcludeDir}   -j 6  --suppress=unknownMacro &> /home/wzy/codeType/c++error.log
    python3 /home/wzy/codeType/analyzercppcheck.py
   # echo "lizard ${workspace} ${excludes}  -C 15 --csv > /home/wzy/codeType/lizard.csv"
   # lizard ${workspace} ${excludes}  -C 15 --csv > /home/wzy/codeType/lizard.csv
    tokei ${workspace}  --output yaml > /home/wzy/codeType/tokei.yaml
fi

cp /home/wzy/codeType/warning_.json /home/
cp /home/wzy/codeType/lizard.csv /home/
cp /home/wzy/codeType/tokei.yaml /home/

#rm -rf ${workspace}/*