list = []
list.push(123)
list << ("wuhan")
print(list)


list.stream().forEach {
    (item) -> {
        print(item)
    }
}