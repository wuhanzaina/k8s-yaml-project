def count = 0
def stringType = "wzy"
def booleanType = true
def integerType = 123

pipeline {
    agent any

    stages {
        stage('loop_trigger_all') {
            steps {
                script {
                    while (count < 3) {
                        echo "当次执行流水线是第 ${count}  次"
                        build job: 'static_scan_code', parameters: [
                                stringParam('stringPar',stringType),
                                booleanParam('boolPar', booleanType),
                                integerParam('integerPar', integerType )

                        ]
                        count++
                    }

                }
            }
        }
    }
}