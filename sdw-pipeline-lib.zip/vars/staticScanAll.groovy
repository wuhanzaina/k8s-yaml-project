pipeline {
    agent {
        label "dev-14:192.168.53.14"
    }

    parameters {
        string(name: 'stringPar', defaultValue: '', description: 'wuhan')
        integer(name: 'integerPar', defaultValue: 0, description: 'shanghai')
        booleanParam(name: 'boolPar', defaultValue: true, description: 'beijing')

    }

    stages {
        stage('Process Parameters') {
            steps {
                echo "stringPar : ${params.stringPar}"
                echo "integerPar: ${params.integerPar}"
                echo "boolPar: ${params.boolPar}"

            }
        }
    }
}