import common.Utils

import java.text.SimpleDateFormat

def call(inParams) {
    pipeline {
        def label_random = "build_${inParams.project_name}_${new SimpleDateFormat("yyyyMMddhhmmss").format(new Date())}"

        def harbor_prefix = inParams.default_harbor_url


        podTemplate(
                label: "$label_random",



                containers: [
                        containerTemplate(
                                name: 'git',
                                image: "192.168.52.66:32001/bitnami/git:2.39.2",
                                ttyEnabled: true,
                                privileged: true,
                                runAsUser: '0',
                                resourceRequestCpu: '0.5',
                                resourceRequestMemory: '512Mi',
                                command: 'cat'
                        ),
                        containerTemplate(name: 'sonar',
                                image: "192.168.52.66:32001/smart-develop/sonarsource/sonar-scanner-cli:5.0.1",
                                privileged: true,
                                ttyEnabled: true,
                                runAsUser: '1000',
                                resourceRequestCpu: '0.5',
                                resourceRequestMemory: '512Mi',
                                command: 'cat'
                        ),
                        containerTemplate(
                                name: 'maven',
                                image: "192.168.52.66:32001/default/maven:3.8.6-jdk-11",
                                ttyEnabled: true,
                                runAsUser: '0',
                                resourceRequestCpu: '0.5',
                                resourceRequestMemory: '512Mi',
                                command: 'cat'
                        ),
                ],
                volumes: [
                        hostPathVolume(
                                hostPath: '/var/run/docker.sock',
                                mountPath: '/var/run/docker.sock'
                        ),
                        hostPathVolume(
                                hostPath: '/usr/bin/docker',
                                mountPath: '/usr/bin/docker'
                        )
                ]
        ) {
            node("$label_random") {
                def appId = "cli_a7835063f37f500c"
                def app_secret = "sgRE51U7Q0ut9Yua2kpIbcfe6wpd28fQ"
                def gitlab_credential_id = common.Utils.getSysValue("default_gitlab_credential_id", inParams.k8s.env.type)
                def code_source_git_url = common.Utils.getSysValue("default_code_source_git_url", inParams.k8s.env.type)
                def userEmail = common.Utils.getEmailFromUsername(inParams.people)
                println(inParams.people)
                println(userEmail)

                println(inParams)

                container("git") {
                    stage("checkout source code") {
                        git branch: "${inParams.code_source_git_branch}",
                                credentialsId: "${gitlab_credential_id}",
                                url: "${code_source_git_url}/${inParams.git_url}"
                        println("git_credential:" + gitlab_credential_id)
                    }
                }

                container("maven") {
                    stage("code-review") {
                        println("prepare MavenSettings.xml")
                        def mavenSettingsTxt = ""
                        if (["preview", "prod"].contains(inParams.k8s.env.type)) {
                            println("use ${inParams.k8s.env.type}MavenSettings.xml")
                            mavenSettingsTxt = libraryResource("backend/maven/${inParams.k8s.env.type}MavenSettings.xml")
                        } else {
                            println("use defaultMavenSettings.xml")
                            mavenSettingsTxt = libraryResource("backend/maven/defaultMavenSettings.xml")
                        }
                        writeFile file: "${WORKSPACE}/settings.xml", text: mavenSettingsTxt
                        sh """
                                cd ${WORKSPACE}
                                   
                                mvn package verify -Dmaven.test.skip=true -s ${WORKSPACE}/settings.xml
                            """
                    }

                    stage("code-review") {
                        sh """
                              cd ${WORKSPACE}
                               ls -la 

                               mvn  sonar:sonar  -Dsonar.projectKey=${inParams.project_name} -Dsonar.host.url=http://192.168.53.219:9000  -Dsonar.login=c3e7a785c5d34b3616f6c9cf426fd4e20e034082  -s ${WORKSPACE}/settings.xml 
        
                        """
                    }
                }
            }
        }
    }
}


