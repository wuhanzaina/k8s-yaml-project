
import groovy.json.JsonOutput

def httpUrl = "http://192.168.146.16/sdw/aiCode/base/common/exec-task/callback"
//凭证
def cert =[
        "3edf4d6f-d148-4510-8a55-14b252f6bab9", //dcs.codecheck
        "59657740-a0d7-44ab-8b1e-505f0ec2a206", //DigitalCar_CodeChecker
        "3444ca7f-0acb-4162-a7b2-6d15aa365513",


]
def resultCert = null

def gitRepos1 = [  //dcs.codechecker:ocsa@2024!
                   "https://172.16.0.120/astri/RI-KCAROS-BSWCP/KT_CP/KT_CP_code.git",
                   "https://172.16.0.120/astri/zcrjbzsys/RI_FuSa_LAB/RI_KCarOS_COMFS_Product/RI-KCarOS-COMFS_Src.git",
                   "https://172.16.0.120/astri/RI-SmartDevelopII/SmartCodeWG_code/ai-code-service.git",
                   "https://172.16.0.120/astri/RI-SmartDevelopII/SmartCodeWG_code/clang-tidy.git"


]

def gitRepos2 = [// DigitalCar_CodeChecker:ocsa@202403!
                 "https://172.16.0.120/astri/RI-DreamCarStudio-DigitalCar/OpenX_src.git",
                 "https://172.16.0.120/astri/VirECU/code.git",
                 "https://172.16.0.120/astri/RI-DreamCarStudio-DigitalCar/UE_TaggingTool.git"

]
def gitRepos3 = [

]

def gitRepos4 = [

]

if (gitRepos1.contains(env.gitHttpUrl)){
    resultCert = cert[0]
    println(resultCert)
} else if (gitRepos1.contains(env.gitHttpUrl)){
    resultCert = cert[1]
    println(resultCert)
} else if (gitRepos1.contains(env.gitHttpUrl)){
    resultCert = cert[2]
    println(resultCert)
}else if (gitRepos1.contains(env.gitHttpUrl)){
    resultCert = cert[3]
    println(resultCert)
}

pipeline {
    agent {
        label "dev-14:192.168.53.14"
    }
    stages {
        stage('gitclone') {
            steps {

                checkout scmGit(branches: [[name: '${branch}']], extensions: [], userRemoteConfigs:
                        [[credentialsId: resultCert, url: '${gitHttpUrl}']])

                script {
                    echo "当前构建编号: ${BUILD_NUMBER}"
                }
            }
            post {
                always {
                    script {
                        def requestBody = [
                                "taskId"       : "${taskId}",
                                "piplineTaskId": env.BUILD_NUMBER,
                                "status"       : "ONGOING"
                        ]

                        def result = httpRequest(
                                httpMode: "POST",
                                ignoreSslErrors: true,
                                contentType: 'APPLICATION_JSON',
                                requestBody: JsonOutput.toJson(requestBody),
                                url: httpUrl
                        )
                        print(result.content)
                    }
                }

            }

        }

        stage("analyzer") {
            steps {
                sh """
                /home/wzy/codeType/check.sh $WORKSPACE
                """
            }

        }
        stage("http") {
            steps {
                script {
                    def commentFile
                    def complexityFile
                    def staticScanFile
                    try{
                        def request="http://192.168.53.219/sdw/aiCode/base/common/exec-task/callback"

                        commentFile = readFile("/home/tokei.yaml")
                        complexityFile = readFile("/home/lizard.csv")
                        staticScanFile = readFile("/home/warning_.json")


                        def requestBody = [
                                "taskId":"${taskId}",
                                "commentsText": commentFile,
                                "circleText": complexityFile,
                                "warningText": staticScanFile,
                                "piplineTaskId": env.BUILD_NUMBER,
                                "status": "SUCCESS"
                        ]

                        def  result = httpRequest (
                                httpMode: "POST",
                                ignoreSslErrors: true,
                                contentType: 'APPLICATION_JSON',
                                requestBody: JsonOutput.toJson(requestBody),
                                url: httpUrl
                        )
                        print(result.content)
                    }catch (Exception e) {
                        def requestBody = [
                                "taskId"       : "${taskId}",
                                "piplineTaskId": env.BUILD_NUMBER,
                                "status"       : "FAILED",
                                "message"      : "${e.getMessage()}"
                        ]
                        def result = httpRequest(
                                httpMode: "POST",
                                ignoreSslErrors: true,
                                contentType: 'APPLICATION_JSON',
                                requestBody: JsonOutput.toJson(requestBody),
                                url: httpUrl
                        )
                        println("执行失败，：${e.getMessage()}")
                    }
                }

            }
        }
    }

}
