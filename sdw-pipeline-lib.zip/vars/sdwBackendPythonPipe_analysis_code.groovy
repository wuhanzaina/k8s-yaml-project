import common.Utils

import java.text.SimpleDateFormat

def call(inParams) {
    pipeline {
        def label_random = "build_${inParams.project_name}_${new SimpleDateFormat("yyyyMMddhhmmss").format(new Date())}"

        //inParams.k8s.env.type不填，默认为开发环境
        if (!inParams.k8s || !inParams.k8s.env || !inParams.k8s.env.type) {
            if (!inParams.k8s.env) {
                inParams.k8s.env = ["type": "dev"]
            } else {
                inParams.k8s.env.type == "dev"
            }
        }

        def harbor_prefix = inParams.harbor_prefix ? inParams.harbor_prefix : common.Utils.getSysValue("default_harbor_prefix", inParams.k8s.env.type)
        inParams.harbor_prefix = harbor_prefix

        podTemplate(
                label: "$label_random",
                containers: [
                        containerTemplate(
                                name: 'python',
                                image: "${harbor_prefix}/smart-develop/python:3.8.10",
                                ttyEnabled: true,
                                runAsUser: '0',
                                command: 'cat'
                        ),
                        containerTemplate(name: 'kubectl',
                                image: "${harbor_prefix}/theohbrothers/docker-kubectl:20220919.0.0-v1.22.14-alpine-3.8",
                                privileged: true,
                                ttyEnabled: true,
                                runAsUser: '0',
                                command: 'cat'
                        )
                ],
                volumes: [
                        hostPathVolume(
                                hostPath: '/var/run/docker.sock',
                                mountPath: '/var/run/docker.sock'
                        ),
                        hostPathVolume(
                                hostPath: '/usr/bin/docker',
                                mountPath: '/usr/bin/docker'
                        )
                ]
        ) {
            node("$label_random") {

                def gitlab_credential_id = common.Utils.getSysValue("default_gitlab_credential_id", inParams.k8s.env.type)
                def code_source_git_url = common.Utils.getSysValue("default_code_source_git_url", inParams.k8s.env.type)
                def harbor_url = common.Utils.getSysValue("default_harbor_url", inParams.k8s.env.type)
                def harbor_credential_id = common.Utils.getSysValue("default_harbor_credential_id", inParams.k8s.env.type)

                def harbor_project = inParams.harbor_project ? inParams.harbor_project : "smart-develop"
                def sub_project_path = inParams.sub_project_path ? "/${inParams.sub_project_path}" : ""
                def project_path = "${WORKSPACE}${sub_project_path}"
                def image_version = new Date().format("yyyyMMddHHmmss") + ".DEV"
                if (inParams.sys_version) {
                    image_version = inParams.sys_version
                }
                def image = "${harbor_prefix}/${harbor_project}/backend/${inParams.project_name}:${image_version}"
                def exec_dockerfile_path = "${project_path}/dockerfile"

                def kube_config_resource_file = null
                def kube_config_file_arg = ""
                def kube_config_file_name = "kube_config.yml"
                if (["test"].contains(inParams.k8s.env.type)) {
                    //生产或开发环境部署在jenkins所在的ks，不需要指定kubeconfig。其他环境需要指定kubeconfig
                    kube_config_resource_file = "k8s/kubeconfig/env_${inParams.k8s.env.type}.yml"
                    kube_config_file_arg = " --kubeconfig ${kube_config_file_name} "
                }
                inParams.k8s.config_mount_path = "/code/config"
                def new_project_name = ''
                def flag = false
                if (inParams.git_url.contains("ServiceSrc") || inParams.git_url.contains("drawuml") || inParams.git_url.contains("shelf_info") || inParams.git_url.contains("sdw-flowchart")
                        || inParams.git_url.contains("sdw-sys-manage") || inParams.git_url.contains("sdw-search")) {
                    flag = true
                }

                inParams.k8s.namespace = inParams.k8s.namespace ? inParams.k8s.namespace : "smart-develop-${inParams.k8s.env.type}"
                inParams.k8s.project_name = inParams.project_name ? inParams.project_name : "${JOB_BASE_NAME}"
                inParams.k8s.containers[0].image = image
                inParams.k8s.default_harbor_prefix = harbor_prefix
                inParams.WORKSPACE = "${WORKSPACE}"
                if (!inParams.k8s.config_map) {
                    inParams.k8s.config_map = [:]
                }
                if (!inParams.k8s.config_map.data) {
                    inParams.k8s.config_map.data = [:]
                }
                //inParams.k8s.config_map.data.SYS_VERSION = image_version
                //inParams.docker_file_path = inParams.docker_file_path ? inParams.docker_file_path : "lib:backend/dockerfile/default/jdk${inParams.compile_env.java.version}.tfl"


                println("params:" + inParams)

                stage('Checkout & Build') {
                    container("python") {

                        stage("checkout source code") {
                            git branch: "${inParams.source_code_git_branch}",
                                    credentialsId: "${gitlab_credential_id}",
                                    url: "${code_source_git_url}/${inParams.git_url}"
                            println("git_credential:" + gitlab_credential_id)
                        }

                        stage("git tag") {
                            if (inParams.commit_tag && inParams.commit_tag == true) {
                                println("make git tag:${image_version}")
                                withCredentials([gitUsernamePassword(credentialsId: "${gitlab_credential_id}", gitToolName: "Default")]) {
                                    sh """
                                        git config --global --add safe.directory ${project_path}
                                        git config --global user.email ${Utils.getSysValue("git_user_email")}
                                        git config --global user.name ${Utils.getSysValue("git_user_name")}
                                        git tag -a ${image_version} -m 'tag ${image_version} by jenkins'
                                        git push --tags
                                    """
                                }
                            } else {
                                println("pass git tag")
                            }
                        }
                    }
                }
                



                stage('Build image') {
                    container('python') {

                        stage("perpare Dockerfile") {
                            def dockerfileTflTxt = libraryResource('backend/dockerfile/default/defaultpython_analysis_code.tfl')

                            def dockerfileTxt = Utils.renderTemplate(dockerfileTflTxt, inParams)
                            println("dockerfileTfl:" + dockerfileTxt)
                            writeFile file: "${exec_dockerfile_path}", text: dockerfileTxt
                        }

                        stage("docker build & push") {
                            docker.withRegistry("${harbor_url}", "${harbor_credential_id}") {
                                sh """
                                cd ${project_path}
                                sleep 6000
                                docker build -t ${image} -f '${exec_dockerfile_path}' .
                                docker push ${image}
                                """
                            }
                        }
                    }
                }



                stage('deploy') {
                    container("kubectl") {

                        stage("prepare config.yml") {
                            def tflPath = "python/k8sftl/all.yml.tfl"
                            println("render config.yml by ${tflPath}")
                            def tflTxt = libraryResource(tflPath)
                            def k8sResConfigtxt = common.Utils.renderTemplate(tflTxt, inParams.k8s)
                            println(k8sResConfigtxt)
                            println("write config.yml")
                            writeFile file: 'config.yml', text: k8sResConfigtxt
                        }

                        stage("prepare kubeconfig") {
                            if (kube_config_resource_file) {
                                println("load kubeconfig file：${kube_config_resource_file}")
                                def kubeconfigTxt = libraryResource(kube_config_resource_file)
                                println("write kubeconfig file")
                                writeFile file: "${kube_config_file_name}", text: kubeconfigTxt
                            }
                        }

                        stage("kubectl apply") {
                            println("deploy command: kubectl apply -f config.yml ${kube_config_file_arg}. use kubeconfig file:${inParams.run_deploy}")
                            if (inParams.run_deploy) {
                                sh """
                                    kubectl apply -f config.yml ${kube_config_file_arg}
                                """
                            }
                        }
                    }
                }
            }
        }
    }
}


