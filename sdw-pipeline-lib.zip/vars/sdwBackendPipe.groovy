import common.Utils

import java.text.SimpleDateFormat

def call(inParams) {
    pipeline {
        def current_time = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
        def label_random = "build_${inParams.project_name}_${current_time}"

        //inParams.k8s.env.type不填，默认为开发环境
        if (!inParams.k8s || !inParams.k8s.env || !inParams.k8s.env.type) {
            if (!inParams.k8s.env) {
                inParams.k8s.env = ["type": "dev"]
            } else {
                inParams.k8s.env.type == "dev"
            }
        }


        def harbor_prefix = inParams.harbor_prefix ? inParams.harbor_prefix : common.Utils.getSysValue("default_harbor_prefix", inParams.k8s.env.type)
        inParams.harbor_prefix = harbor_prefix
        def worker_cluster = inParams.worker_cluster ? inParams.worker_cluster : ""
        def pod_run_machine = common.Utils.getSysValue("default_pod_run_machine", inParams.k8s.env.type)

        podTemplate(
                label: "$label_random",
                cloud: "${worker_cluster}",
                containers: [
//                        containerTemplate(
//                                name: 'jnlp',
//                                image: "${harbor_prefix}/jenkins/inbound-agent:3107.v665000b_51092-2",
//                                ttyEnabled: true,
//                                resourceRequestCpu: '0.5',
//                                resourceRequestMemory: '512Mi',
//                                command: 'cat'
//                        ),
containerTemplate(
        name: 'git',
        image: "${harbor_prefix}/bitnami/git:2.39.2",
        ttyEnabled: true,
        privileged: true,
        runAsUser: '0',
        resourceRequestCpu: '0.5',
        resourceRequestMemory: '512Mi',
        command: 'cat'
),
containerTemplate(
        name: 'maven',
        image: "${harbor_prefix}/default/maven:3.8.6-jdk-${inParams.compile_env.java.version}",
        ttyEnabled: true,
        runAsUser: '0',
        resourceRequestCpu: '0.5',
        resourceRequestMemory: '512Mi',
        command: 'cat'
),
containerTemplate(name: 'docker',
        image: "${harbor_prefix}/default/docker:20.10.16-dind",
        privileged: true,
        ttyEnabled: true,
        runAsUser: '0',
        resourceRequestCpu: '0.5',
        resourceRequestMemory: '512Mi',
        command: 'cat'
),
containerTemplate(name: 'kubectl',
        image: "${harbor_prefix}/theohbrothers/docker-kubectl:20220919.0.0-v1.22.14-alpine-3.8",
        privileged: true,
        ttyEnabled: true,
        runAsUser: '1000',
        resourceRequestCpu: '0.5',
        resourceRequestMemory: '512Mi',
        command: 'cat'
)
                ],
                volumes: [
                        hostPathVolume(
                                hostPath: '/var/run/docker.sock',
                                mountPath: '/var/run/docker.sock'
                        ),
                        hostPathVolume(
                                hostPath: '/usr/bin/docker',
                                mountPath: '/usr/bin/docker'
                        )

                ],
                nodeSelector: "kubernetes.io/hostname=${pod_run_machine}",
        ) {
            node("$label_random") {

                def gitlab_credential_id = common.Utils.getSysValue("default_gitlab_credential_id", inParams.k8s.env.type)
                def code_source_git_url = common.Utils.getSysValue("default_code_source_git_url", inParams.k8s.env.type)
                def harbor_url = common.Utils.getSysValue("default_harbor_url", inParams.k8s.env.type)
                def harbor_credential_id = common.Utils.getSysValue("default_harbor_credential_id", inParams.k8s.env.type)

                def harbor_project = inParams.harbor_project ? inParams.harbor_project : "smart-develop"
                def sub_project_path = inParams.sub_project_path ? "/${inParams.sub_project_path}" : ""
                def project_path = "${WORKSPACE}${sub_project_path}"
                def image_version = new Date().format("yyyyMMddHHmmss") + ".DEV"
                if (inParams.sys_version) {
                    image_version = inParams.sys_version.trim()
                }
                def image = "${harbor_prefix}/${harbor_project}/backend/${inParams.project_name}:${image_version}"
                def exec_dockerfile_path = "${project_path}/dockerfile"

                def kube_config_resource_file = null
                def kube_config_file_arg = ""
                def kube_config_file_name = "kube_config.yml"
                def sky_walking_path = "skywalking.monitoring:11800"
                def sky_walking_java_opts = "-javaagent:/skywalking/agent/skywalking-agent.jar"


                def cmake = inParams.cmake
                cmake = cmake != null || cmake
//                if (["test"].contains(inParams.k8s.env.type)) {
                //生产或开发环境部署在jenkins所在的ks，不需要指定kubeconfig。其他环境需要指定kubeconfig
                kube_config_resource_file = "k8s/kubeconfig/env_${inParams.k8s.env.type}.yml"
                kube_config_file_arg = " --kubeconfig ${kube_config_file_name} "
                def recordParam = "--record "
//                }

                def flag = false
                if (inParams.git_url.contains("ServiceSrc") || inParams.git_url.contains("drawuml") || inParams.git_url.contains("shelf_info") || inParams.git_url.contains("sdw-flowchart")
                        || inParams.git_url.contains("sdw-sys-manage")) {
                    flag = true
                }
                inParams.commit_tag = inParams.commit_tag ? inParams.commit_tag : false
                inParams.k8s.namespace = inParams.k8s.namespace ? inParams.k8s.namespace : "smart-develop-${inParams.k8s.env.type}"
                inParams.k8s.project_name = inParams.project_name ? inParams.project_name : "${JOB_BASE_NAME}"
                inParams.k8s.containers[0].image = image
                inParams.k8s.default_harbor_prefix = harbor_prefix
                if (!inParams.k8s.config_map) {
                    inParams.k8s.config_map = [:]
                }
                if (!inParams.k8s.config_map.data) {
                    inParams.k8s.config_map.data = [:]
                }
//                inParams.k8s.config_map.data.SW_AGENT_NAME = inParams.project_name
//                inParams.k8s.config_map.data.SW_AGENT_COLLECTOR_BACKEND_SERVICES = sky_walking_path
//                if (!inParams.k8s.config_map.data.JAVA_OPTS ) {
//                    inParams.k8s.config_map.data.JAVA_OPTS = ""
//                }
//                inParams.k8s.config_map.data.JAVA_OPTS = sky_walking_java_opts + " " + inParams.k8s.config_map.data.JAVA_OPTS
//
//
//                inParams.k8s.config_map.data.SYS_VERSION = image_version
                inParams.docker_file_path = inParams.docker_file_path ? inParams.docker_file_path : "lib:backend/dockerfile/default/java.tfl"
                inParams.deploy_resource_type = inParams.deploy_resource_type ? inParams.deploy_resource_type : "all"

                if (!inParams.docker_file || !inParams.docker_file.base_image || "" == inParams.docker_file.base_image) {
                    println("getDefaultBaseImage:jdk${inParams.compile_env.java.version}")
                    def base_image = common.Utils.getDefaultBaseImage("jdk" + inParams.compile_env.java.version)
                    println("base_image:${base_image}")
                    if (!inParams.docker_file) {
                        inParams.docker_file = [:]
                    }
                    inParams.docker_file.base_image = "${harbor_prefix}/${base_image}"
                }

                println("params:" + inParams)

                stage('Checkout & Build') {
                    container("git") {
                        stage("Checkout source code") {
                            sh """
                                git config --global http.sslverify false
                                git config --global https.sslverify false
                            """
                            git branch: "${inParams.code_source_git_branch}",
                                    credentialsId: "${gitlab_credential_id}",
                                    url: "${code_source_git_url}/${inParams.git_url}"
                        }




                        stage("Commit git tag") {
                            if (inParams.commit_tag == true) {
                                println("commit git tag:${image_version}")
                                withCredentials([gitUsernamePassword(credentialsId: "${gitlab_credential_id}", gitToolName: "Default")]) {
                                    sh """
                                            git config --global --add safe.directory ${project_path}
                                            git config --global user.email ${common.Utils.getSysValue("git_user_email")}
                                            git config --global user.name ${common.Utils.getSysValue("git_user_name")}
                                            git tag -a ${image_version} -m 'tag ${image_version} by jenkins'
                                            git push --tags
                                        """
                                }
                            }
                        }
                    }
                    container("maven") {
                        stage("Build package") {
                            println("prepare MavenSettings.xml")
                            def mavenSettingsTxt = ""
                            if (["preview", "prod"].contains(inParams.k8s.env.type)) {
                                println("use ${inParams.k8s.env.type}MavenSettings.xml")
                                mavenSettingsTxt = libraryResource("backend/maven/${inParams.k8s.env.type}MavenSettings.xml")
                            } else {
                                println("use defaultMavenSettings.xml")
                                mavenSettingsTxt = libraryResource("backend/maven/defaultMavenSettings.xml")
                            }
                            writeFile file: "${project_path}/settings.xml", text: mavenSettingsTxt
                            sh """
                                cd ${project_path}
                                   
                                   mvn package verify -Dmaven.test.skip=true -s ${project_path}/settings.xml 
                            """
                        }
                        stage("code-review") {
                            if ( inParams.code_review != null && inParams.code_review ) {
                                sh """
                                   cd ${project_path}
                                   mvn  sonar:sonar -Dsonar.exclusions=${project_path}/src/test/**/* -Dsonar.projectKey=${inParams.project_name} -Dsonar.host.url=http://192.168.53.219:9000  -Dsonar.login=9d3d843d73b70b78f3a25a904158844e997dd063  -s ${project_path}/settings.xml 
            
                                """
                            } else{
                                print("跳过代码静态扫描")

                            }
                        }

                    }
                }
//                verify sonar:sonar -Dsonar.projectKey=backend_project   -Dsonar.host.url=http://192.168.53.219:9000  -Dsonar.login=9d3d843d73b70b78f3a25a904158844e997dd063

                stage('Build image') {
                    container('docker') {
                        println("perpare Dockerfile")
                        if (inParams.docker_file_path.startsWith("lib:")) {
                            def dockerfileTflTxt = libraryResource(inParams.docker_file_path.substring(4))
                            println("dockerfileTfl:" + dockerfileTflTxt)
                            def dockerfileTxt = Utils.renderTemplate(dockerfileTflTxt, inParams)
                            writeFile file: "${exec_dockerfile_path}", text: dockerfileTxt
                        } else {
                            sh "cp ${WORKSPACE}/${inParams.docker_file_path} ${project_path}/"
                        }

                        println("docker build & push")
                        docker.withRegistry("${harbor_url}", "${harbor_credential_id}") {
                            sh """
                                cd ${project_path}/target
                                
                                docker build -t ${image} -f '${exec_dockerfile_path}' .
                                docker push ${image}
                            """
                        }
                    }
                }

                stage('Deploy to k8s') {
                    container("kubectl") {
                        if (inParams.run_deploy == true) {
                            def target_config_folder = "${project_path}/pipetmp_${current_time}/k8s_apply_config"
                            println("prepare k8s apply files to ${target_config_folder}")
                            sh "mkdir -p ${target_config_folder}"

                            def resource_types = inParams.deploy_resource_type.split(",")
                            if (resource_types != null && resource_types.size() > 0) {
                                sh "mkdir -p ${target_config_folder}"
                                for (resource_type in resource_types) {
                                    println("prepare [${resource_type}] apply file")
                                    def tflPath = "backend/k8sftl/default/${resource_type}.yml.tfl"
                                    println("render file:${tflPath}")
                                    def tflTxt = libraryResource(tflPath)
                                    def k8sResConfigtxt = Utils.renderTemplate(tflTxt, inParams.k8s)
                                    println(k8sResConfigtxt)
                                    println("write ${target_config_folder}/${resource_type}.yml")
                                    writeFile(file: "${target_config_folder}/${resource_type}.yml", text: k8sResConfigtxt)
                                }
                            }

                            println("prepare kubeconfig")
                            if (kube_config_resource_file) {
                                println("load kubeconfig file：${kube_config_resource_file}")
                                def kubeconfigTxt = libraryResource(kube_config_resource_file)
                                println("write kubeconfig file")
                                writeFile file: "${kube_config_file_name}", text: kubeconfigTxt
                            }

                            println("kubectl apply")
                            println("deploy command: kubectl apply -f ${target_config_folder} ${kube_config_file_arg}.")

                            sh """
                            kubectl apply -f ${target_config_folder} ${kube_config_file_arg} 
                            
                            """
                        } else {
                            println("do not deploy. because run_deploy == false")
                        }
                    }
                }
            }
        }
    }
}


