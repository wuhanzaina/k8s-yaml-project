import common.Utils

static def getVersion(){
    def currentTime = new Date().format("yyyyMMddHHmmss")
    def version = currentTime + '-dev'
    return version
}

def call(initParams){
    pipeline {
        agent {
            label "${initParams.tag}"
        }
        environment {
            DOCKER_IMAGE = '192.168.52.66:32001/default/node:18.19-alpine'  // 使用 Python 3.8 Docker 镜像作为构建环境
        }
        stages {
            stage('Checkout Code') {
                steps {
                    checkout scmGit(branches: [[name: "${initParams.branch}"]], extensions: [], userRemoteConfigs: [[credentialsId: '2e10a840-a8f2-481a-8abe-693015d523da',
                                                                                                                     url          : "${initParams.git_url}"]])
                }
            }
            stage('web build') {
                steps {
                    script {
                        print("${WORKSPACE}")
                        sh """
                    ls -la 
                    """
                        docker.image("${DOCKER_IMAGE}").inside("-v ${WORKSPACE}:/code") {
                            sh """
                            cd /code/
                            ls -la 
                            rm -rf yarn.lock package-lock.json
                            npm config set registry http://192.168.52.165:8081/repository/npm-public/  

                            npm install && npm run build
                      
                      """
                        }
                    }
                }
            }


            stage('Docker Image build') {
                 steps {
                     script {

                         def version = getVersion()
                         println("准备default.conf")
                         def nginxConfPath = 'frontend/dockerfile/default/nginx.conf.tfl'
                         //根据目录读取模板文件
                         def nginxConfTmp = libraryResource(nginxConfPath)
                         //填充模板参数
                         def nginxConfTmpRes = Utils.renderTemplate(nginxConfTmp,initParams)
                         println("nginx.conf: \n ${nginxConfTmpRes}")
                         writeFile file: "${WORKSPACE}/nginx.conf" ,text : nginxConfTmpRes

                         println("准备nginx.conf")
                         def nginxRootConfPath = 'frontend/dockerfile/default/nginx-root.conf'
                         //根据目录读取模板文件
                         def nginxRootConfTmp = libraryResource(nginxRootConfPath)
                         println("nginx.conf: \n ${nginxRootConfTmp}")
                         writeFile file: "${WORKSPACE}/nginx-root.conf" ,text : nginxRootConfTmp

                         println("准备nginx容器启动脚本")
                         def startNginxConfPath = 'frontend/dockerfile/default/start-nginx.sh'
                         //根据目录读取模板文件
                         def startNginxConTmp = libraryResource(startNginxConfPath)
                         println("nginx.conf: \n ${startNginxConTmp}")
                         writeFile file: "${WORKSPACE}/start-nginx.sh" ,text : startNginxConTmp

                         println("准备Dockerfile文件")
                         def dockerfilePath = 'frontend/dockerfile/default/Dockerfile.tfl'
                         //根据目录读取模板文件
                         def dockerfilePathTmp = libraryResource(dockerfilePath)
                         def dockerfileTmpRes = Utils.renderTemplate(dockerfilePathTmp,initParams)
                         println("nginx.conf: \n ${dockerfileTmpRes}")
                         writeFile file: "${WORKSPACE}/Dockerfile" ,text : dockerfileTmpRes

                         println("开始构建docker镜像")
                         sh """
                         cd ${WORKSPACE}/
                         ls -la
                         docker build -t ${initParams.project_name}:${version} -f Dockerfile  .

                         """

                     }
                 }
             }

        }


    }
}