import common.Utils

import java.text.SimpleDateFormat

def call(inParams) {
    pipeline {
        def label_random = "build_${inParams.project_name}_${new SimpleDateFormat("yyyyMMddhhmmss").format(new Date())}"

        def harbor_prefix = inParams.default_harbor_url


        podTemplate(
                label: "$label_random",

                containers: [
                        containerTemplate(
                                name: 'git',
                                image: "192.168.52.66:32001/bitnami/git:2.39.2",
                                ttyEnabled: true,
                                privileged: true,
                                runAsUser: '0',
                                resourceRequestCpu: '0.5',
                                resourceRequestMemory: '512Mi',
                                command: 'cat'
                        ),
                        containerTemplate(name: 'sonar',
                                image: "192.168.52.66:32001/smart-develop/sonarsource/sonar-scanner-cli:5.0.1",
                                privileged: true,
                                ttyEnabled: true,
                                runAsUser: '1000',
                                resourceRequestCpu: '0.5',
                                resourceRequestMemory: '512Mi',
                                command: 'cat'
                        )
                ],
                volumes: [
                        hostPathVolume(
                                hostPath: '/var/run/docker.sock',
                                mountPath: '/var/run/docker.sock'
                        ),
                        hostPathVolume(
                                hostPath: '/usr/bin/docker',
                                mountPath: '/usr/bin/docker'
                        )
                ]
        ) {
            node("$label_random") {

                def gitlab_credential_id = common.Utils.getSysValue("default_gitlab_credential_id", inParams.k8s.env.type)
                def code_source_git_url = common.Utils.getSysValue("default_code_source_git_url", inParams.k8s.env.type)

                container("git") {
                    stage("checkout source code") {
                        git branch: "${inParams.code_source_git_branch}",
                                credentialsId: "${gitlab_credential_id}",
                                url: "${code_source_git_url}/${inParams.git_url}"
                        println("git_credential:" + gitlab_credential_id)
                    }
                }

                container("sonar") {
                    stage("code-review") {
                        sh """
                               cd ${WORKSPACE}/${inParams.filePath}
    sleep 3600
                               sonar -scanner  -Dsonar.projectKey=${inParams.project_name} -Dsonar.host.url=http://192.168.53.219:9000  -Dsonar.login=9d3d843d73b70b78f3a25a904158844e997dd063      
                        """

                    }
                }

            }
        }
    }
}


