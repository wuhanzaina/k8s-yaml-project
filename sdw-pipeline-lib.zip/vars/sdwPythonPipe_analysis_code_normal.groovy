import common.Utils

import java.text.SimpleDateFormat

def call(inParams) {
    pipeline {
        def label_random = "build_${inParams.project_name}_${new SimpleDateFormat("yyyyMMddhhmmss").format(new Date())}"

        def harbor_prefix = inParams.default_harbor_url



        podTemplate(
                label: "$label_random",



                containers: [
                        containerTemplate(
                                name: 'git',
                                image: "192.168.52.66:32001/bitnami/git:2.39.2",
                                ttyEnabled: true,
                                privileged: true,
                                runAsUser: '0',
                                resourceRequestCpu: '0.5',
                                resourceRequestMemory: '512Mi',
                                command: 'cat'
                        ),
                        containerTemplate(name: 'sonar',
                                image: "192.168.52.66:32001/smart-develop/sonarsource/sonar-scanner-cli:5.0.1",
                                privileged: true,
                                ttyEnabled: true,
                                runAsUser: '1000',
                                resourceRequestCpu: '0.5',
                                resourceRequestMemory: '512Mi',
                                command: 'cat'
                        ),
                        containerTemplate(name: 'kubectl',
                                image: "192.168.52.66:32001/theohbrothers/docker-kubectl:20220919.0.0-v1.22.14-alpine-3.8",
                                privileged: true,
                                ttyEnabled: true,
                                runAsUser: '0',
                                command: 'cat'
                        )
                ],
                volumes: [
                        hostPathVolume(
                                hostPath: '/var/run/docker.sock',
                                mountPath: '/var/run/docker.sock'
                        ),
                        hostPathVolume(
                                hostPath: '/usr/bin/docker',
                                mountPath: '/usr/bin/docker'
                        )
                ]
        ) {
            node("$label_random") {
                def appId = "cli_a7835063f37f500c"
                def app_secret = "sgRE51U7Q0ut9Yua2kpIbcfe6wpd28fQ"
                def gitlab_credential_id = common.Utils.getSysValue("default_gitlab_credential_id", inParams.k8s.env.type)
                def code_source_git_url = common.Utils.getSysValue("default_code_source_git_url", inParams.k8s.env.type)
                def userEmail = common.Utils.getEmailFromUsername(inParams.people)
                println(inParams.people)
                println(userEmail)

                println(inParams)

                container("git") {
                    stage("checkout source code") {
                        git branch: "${inParams.code_source_git_branch}",
                                credentialsId: "${gitlab_credential_id}",
                                url: "${code_source_git_url}/${inParams.git_url}"
                        println("git_credential:" + gitlab_credential_id)
                    }
                }


                container("sonar") {
                    stage("code-review") {
                        script {

//                            def access_token = common.Utils.get_tenant_access_token(env.appId, env.app_secret)
//                            def chatId = common.Utils.getGroupChatId(access_token, inParams.groupName)
//                            common.Utils.sendMessageByChatId(access_token, chatId)


                        sh """
                             cd ${WORKSPACE}/${inParams.filePath}
                             ls -la
                             sonar-scanner -Dsonar.projectKey=${inParams.project_name}  -Dsonar.sources=. -Dsonar.host.url=http://192.168.53.219:9000 -Dsonar.login=c3e7a785c5d34b3616f6c9cf426fd4e20e034082

                            """
//curl -u admin:1qaz@WSX http://192.168.53.219:9000/api/pdfreport/get?componentKey=${inParams.project_name} -o report.pdf

                        emailext(
                                body: """
                                <html>
                                <body>
                                <h1>来自 Jenkins ！ 代码静态扫描完成</h1>
                                <p>代码检查分支：${inParams.code_source_git_branch}</p>
                                <p> 源分支：${inParams.source_branch} ，目标分支：${inParams.code_source_git_branch}  </p>
                                <p>项目地址：http://192.168.53.219:9000/dashboard?id=${inParams.project_name} </p>
                                <p> 使用台式机访问 </p>
                                <p>用户名：jenkins</p>
                                <p>密码：1qaz@WSX</p>
                                </body>
                                </html>
                            """,

                                from: "wang.zhengyao@kotei.com.cn",
                                replyTo: "wang.zhengyao@kotei.com.cn",
                                subject: "${inParams.code_source_git_branch}分支静态检查报告",
                                mimeType: 'text/html',
                                to: "${userEmail},cc:wang.zhengyao@kotei.com.cn,cc:wang.wei@kotei.com.cn,cc:yu.huiming@kotei.com.cn,cc:wang.dingxiong@kotei.com.cn,cc:wang.ning9354@kotei.com.cn,cc:li.daqiang@kotei.com.cn,cc:wan.fangzhan@kotei.com.cn,cc:huang.wenjie@kotei.com.cn,cc:liu.shuang086@kotei.com.cn,cc:chen.guang@kotei.com.cn",

                        )
                            //attachmentsPattern: "**/report.pdf",
                        }
                    }
                }

            }
        }
    }
}


