package common

import groovy.text.GStringTemplateEngine
import groovy.text.Template
import groovy.json.JsonOutput
import groovy.json.JsonSlurperClassic
import groovy.json.JsonSlurper

static def renderTemplate(tflTxt, k8sParam) {

    Template template = new GStringTemplateEngine().createTemplate(tflTxt.toString())
    return template.make(k8sParam).toString()
}

static def getSysValueDefault(key, defaultValue) {
    return getSysValueDefault(key, null, defaultValue)
}

static def getSysValueDefault(key, env, defaultValue) {
    def value = getSysValue(key, env)
    if (value == null) {
        return defaultValue
    }
}

static def getSysValue(key) {
    getSysValue(key, null)
}


static def getEmailFromUsername(username) {
    def emailList = [
            "genhud7838"    : "dong.genhu@kotei.com.cn",
            "ningw9354"     : "wang.ning9354@kotei.com.cn",
            "daqiangl"      : "li.daqiang@kotei.com.cn",
            "fangzhanw9303" : "wan.fangzhan@kotei.com.cn",
            "dingxiongw9273": "wang.dingxiong@kotei.com.cn",
            "wenjieh8997"   : "huang.wenjie@kotei.com.cn",
            "zhengyaow7783" : "wang.zhengyao@kotei.com.cn"
    ]
    return emailList[username]
}

static def get_tenant_access_token(appId, app_secret) {

    def headers = ["Content-Type": "application/json; charset=utf-8"]
    def data = [app_id: appId, app_secret: app_secret]

    def url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal/"
    def connection = new URL(url).openConnection() as HttpURLConnection
    connection.requestMethod = 'POST'
    connection.setRequestProperty('Content-Type', 'application/json; charset=utf-8')
    connection.doOutput = true

    def jsonData = JsonOutput.toJson(headers)

    connection.outputStream.withWriter("UTF-8") { writer ->
        writer << jsonData
    }

    def responseCode = connection.responseCode

    if (responseCode == HttpURLConnection.HTTP_OK) {
        def response = connection.inputStream.withReader("UTF-8") { reader ->
            new JsonSlurper().parse(reader)
        }
        return response.tenant_access_token
    } else {
        def errorMessage = connection.errorStream.withReader("UTF-8") { reader ->
            reader.text
        }
        throw new RuntimeException("Failed to get Feishu tenant_access_token: ${responseCode} - ${errorMessage}")
    }

}

static def getGroupChatId(token, groupName) {
    def chatId = ""
    def url = new URL("https://open.feishu.cn/open-apis/im/v1/chats")
    def connection = url.openConnection() as HttpURLConnection
    connection.requestMethod = 'GET'
    connection.setRequestProperty('Authorization', "Bearer ${token}")

    def responseCode = connection.responseCode
    if (responseCode == 200) {
        echo "Get feishu group chat_id succeed"

        // 解析 JSON 响应
        def responseText = connection.inputStream.withReader("UTF-8") { reader ->
            reader.text
        }
        def returnJson = new JsonSlurper().parseText(responseText)

        // 遍历 items 找到匹配的 group_name
        returnJson.data.items.each { item ->
            if (item.name == groupName) {
                chatId = item.chat_id
            }
        }

        if (!chatId) {
            echo "No match group ${groupName} found"
        }

        return chatId
    } else {
        def errorMessage = connection.errorStream.withReader("UTF-8") { reader ->
            reader.text
        }
        error("Get feishu group chat_id failed: ${responseCode} - ${errorMessage}")
        return false
    }
}

static def sendMessageByChatId(token, chatId) {
    def url = new URL("https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id")
    def connection = url.openConnection() as HttpURLConnection
    connection.requestMethod = 'POST'
    connection.setRequestProperty('Authorization', "Bearer ${token}")
    connection.setRequestProperty('Content-Type', 'application/json')
    connection.setRequestProperty('charset', 'utf-8')
    connection.doOutput = true

    def strResult = [
            text: "静态检测完成，详情请查看 http://192.168.53.219:9000/dashboard?id=doc-python"
    ]
    def req = [
            receive_id: chatId,
            msg_type  : "text",
            content   : JsonOutput.toJson(strResult)
    ]
    def payload = JsonOutput.toJson(req)

    connection.outputStream.withWriter("UTF-8") { writer ->
        writer << payload
    }

    def responseCode = connection.responseCode
    if (responseCode == 200) {
        echo "Send feishu group message succeed"
        def responseText = connection.inputStream.withReader("UTF-8") { reader ->
            reader.text
        }
        return new JsonSlurper().parseText(responseText)
    } else {
        def errorMessage = connection.errorStream.withReader("UTF-8") { reader ->
            reader.text
        }
        error("Failed to send feishu group message: ${responseCode} - ${errorMessage}")
        return null
    }
}




static def getSysValue(key, env) {
    def constants = [
            default_pod_run_machine     : [
                    dev     : "node2",
                    test    : "node2",
                    tdd     : "node2",
                    preview : "node1",
                    prod    : "bm-node1",
                    dmz     : "bm1",
                    pressure: "node3"
            ],

            default_gitlab_credential_id: [
                    dev     : "2e10a840-a8f2-481a-8abe-693015d523da",
                    test    : "2e10a840-a8f2-481a-8abe-693015d523da",
                    tdd     : "5a139783-6670-435e-ad96-41b59b17a4e3",
                    preview : "9ea560ff-cd90-4ed7-9176-cbb69650641d",
                    prod    : "6ca16a4f-8254-40aa-ad23-7be77cbf7da8",
                    dmz     : "6ca16a4f-8254-40aa-ad23-7be77cbf7da8",
                    pressure: "5a139783-6670-435e-ad96-41b59b17a4e3",
                    protect : "2e10a840-a8f2-481a-8abe-693015d523da"
            ],
            default_code_source_git_url : [
                    dev     : "https://192.168.52.165:10000",
                    test    : "https://192.168.52.165:10000",
                    tdd     : "https://172.16.0.120",
                    preview : "https://172.16.0.120",
                    prod    : "https://192.168.52.165:10000",
                    dmz     : "https://192.168.52.165:10000",
                    pressure: "https://192.168.52.165:10000",
                    protect : "http://192.168.20.12"
            ],
            default_harbor_credential_id: [
                    dev     : "4fea993f-14e7-4c8a-b8da-8150b2f8c868",
                    test    : "4fea993f-14e7-4c8a-b8da-8150b2f8c868",
                    tdd     : "4fea993f-14e7-4c8a-b8da-8150b2f8c868",
                    preview : "4fea993f-14e7-4c8a-b8da-8150b2f8c868",
                    prod    : "ef7e91bb-0938-4b64-8a07-4f4ccedd651f",
                    dmz     : "ef7e91bb-0938-4b64-8a07-4f4ccedd651f",
                    pressure: "4fea993f-14e7-4c8a-b8da-8150b2f8c868",


            ],
            default_harbor_prefix       : [
                    dev     : "192.168.52.66:32001",
                    test    : "192.168.52.66:32001",
                    tdd     : "192.168.52.66:32001",
                    preview : "172.16.0.41:5000",
                    prod    : "192.168.146.10:5000",
                    dmz     : "192.168.146.10:5000",
                    pressure: "192.168.52.66:32001"
            ],
            default_harbor_url          : [
                    dev     : "http://192.168.52.66:32001",
                    test    : "http://192.168.52.66:32001",
                    tdd     : "http://192.168.52.66:32001",
                    preview : "http://172.16.0.41:5000",
                    prod    : "http://192.168.146.10:5000",
                    dmz     : "http://192.168.146.10:5000",
                    pressure: "http://192.168.52.66:32001"
            ],
            default_npm_registry        : [
                    dev     : "http://192.168.52.165:8081/repository/npm-public/",
                    test    : "http://192.168.52.165:8081/repository/npm-public/",
                    tdd     : "http://192.168.52.165:8081/repository/npm-public/",
                    preview : "http://192.168.52.165:8081/repository/npm-public/",
                    prod    : "http://192.168.52.165:8081/repository/npm-public/",
                    dmz     : "http://192.168.52.165:8081/repository/npm-public/",
                    pressure: "http://192.168.52.165:8081/repository/npm-public/"
            ],

            git_user_email              : "jenkins@kotei.com.cn",
            git_user_name               : "jenkins"
    ]

    def entry = constants.get(key)
    if (entry == null) {
        return entry
    }
    if (entry instanceof Map) {
        if (env == null || "" == env) {
            return entry.get("dev")
        } else if ("emailList" == key) {
            return entry.get("key")
        } else {
            return entry.get(env)
        }
    } else {
        return entry
    }
}


static def getDefaultBaseImage(key) {
    println("key" + key)
    def defaultBaseImage = [
            jdk8   : "default/oracle-jdk8:python",
            jdk11  : "adoptopenjdk/openjdk11:x86_64-ubuntu-jre-11.0.18_10",
            jdk8uml: "smart-develop/oracle-jdk8:umlchinese",
            jdk17  : "smart-develop/ibm-semeru-runtimes:open-17-jre"

    ]
    return defaultBaseImage.get(key)
}
