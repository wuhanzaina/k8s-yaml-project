#!/bin/sh
# This script is baked into the appsmith-editor Dockerfile and is used to boot Nginx when the Docker container starts
# Refer: /app/client/Dockerfile
set -ue
exec nginx -g 'daemon off;'
