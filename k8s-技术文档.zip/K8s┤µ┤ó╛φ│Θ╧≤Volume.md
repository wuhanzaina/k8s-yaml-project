# K8s存储卷抽象Volume

---

* [https://yinwu.blog.csdn.net/article/details/109806383](https://yinwu.blog.csdn.net/article/details/109806383?spm=1001.2014.3001.5502)

---

### 文章目录

* [1.单体版Petclinic](#1Petclinic_1)

  * [2.迹象演练](#2_4)

    * [2.1资源配置清单准备](#21_5)
    * [2.2发布mysql-svc和petclinic-svc](#22mysqlsvcpetclinicsvc_94)
    * [2.3浏览器校验](#23_106)
    * [2.4重启Mysql Pod](#24Mysql_Pod_108)
    * [2.5浏览器再次校验](#25_116)
  * [3.K8s存储卷抽象Volume](#3K8sVolume_118)
  * [4.增加hostPath存储卷](#4hostPath_122)
  * [5.再次发布mysql-svc和petclinic-svc](#5mysqlsvcpetclinicsvc_170)
  * [6.浏览器校验](#6_181)
  * [7.tmp/data0目录下生成mysql和petclinic数据文件](#7tmpdata0mysqlpetclinic_183)
  * [8.重启mysql pod](#8mysql_pod_185)
  * [9.浏览器校验仍然成功](#9_188)
  * [10.总结](#10_190)

### 1.单体版Petclinic

此架构为单机版的Petclinic微服务，Mysql pod未配置存储机制，这样会引来一个问题，Mysql启动时会使用容器内的临时存储，当Pod重启时，就会初始化对应的数据， 使数据达不到永久存储机制，一般我们的Worker节点由多个构成，Mysql pod重启后可能会调度到另外一台Worker节点  
 ![在这里插入图片描述](assets/20201119113713771-20221008134810-sr3xxyq.png)​

### 2.迹象演练

#### 2.1资源配置清单准备

```sql
[root@k8s7-200.host.com /data/k8s-yaml/k8s-msa-in-action/ch07/01]# cat mysql-dp.yaml 
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mysql
spec:
  selector:
    matchLabels:
      app: mysql
  replicas: 1
  template:
    metadata:
      labels:
        app: mysql
    spec:
      containers:
        - name: mysql
          image: harbor.od.com/bobo/mysql:5.7.30
          env:
            - name: MYSQL_ROOT_PASSWORD
              value: petclinic
            - name: MYSQL_DATABASE
              value: petclinic

        
[root@k8s7-200.host.com /data/k8s-yaml/k8s-msa-in-action/ch07/01]# cat mysql-svc.yaml 
apiVersion: v1
kind: Service
metadata:
  name: mysql
spec:
  selector:
    app: mysql
  ports:
    - name: tcp
      port: 3306
      targetPort: 3306
  type: ClusterIP


[root@k8s7-200.host.com /data/k8s-yaml/k8s-msa-in-action/ch07/01]# cat petclinic-dp.yaml 
apiVersion: apps/v1
kind: Deployment
metadata:
  name: petclinic
spec:
  selector:
    matchLabels:
      app: petclinic
  replicas: 1
  template:
    metadata:
      labels:
        app: petclinic
    spec:
      containers:
        - name: petclinic
          image: harbor.od.com/bobo/spring-petclinic:1.0.1.RELEASE
          env:
            - name: SPRING_PROFILES_ACTIVE
              value: mysql
            - name: DATASOURCE_URL
              value: jdbc:mysql://mysql/petclinic
            - name: DATASOURCE_USERNAME
              value: root
            - name: DATASOURCE_PASSWORD
              value: petclinic
            - name: DATASOURCE_INIT_MODE
              value: always
            
[root@k8s7-200.host.com /data/k8s-yaml/k8s-msa-in-action/ch07/01]# cat petclinic-svc.yaml 
apiVersion: v1
kind: Service
metadata:
  name: petclinic
spec:
  ports:
    - name: http
      port: 8080
      targetPort: 8080
      nodePort: 3665
  selector:
    app: petclinic
  type: NodePort

```

#### 2.2发布mysql-svc和petclinic-svc

```sql
[root@k8s7-21.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch07/01/mysql-dp.yaml
pod/mysql created
[root@k8s7-21.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch07/01/mysql-svc.yaml
service/mysql created
[root@k8s7-21.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch07/01/petclinic-dp.yaml
deployment.apps/petclinic created
[root@k8s7-21.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch07/01/petclinic-svc.yaml
service/petclinic created

```

#### 2.3浏览器校验

![在这里插入图片描述](assets/20201119120341857-20221008134810-dsv4zy1.png)​

#### 2.4重启Mysql Pod

`kubectl delete pod $mysql-pod`  
 ![在这里插入图片描述](assets/20201119124441881-20221008134810-wv1iqdb.png)  
 这时候需要重启petclinic-pod，它会重新初始化mysql中的petclinic数据库表和种子数据，相关配置参数：DATASOURCE_INIT_MODE

```sql
[root@k8s7-21.host.com ~]# kubectl delete pod petclinic-8f7d88bc-hj6tr
pod "petclinic-8f7d88bc-hj6tr" deleted
```

#### 2.5浏览器再次校验

![在这里插入图片描述](assets/20201119125055340-20221008134810-h574cva.png)​

### 3.K8s存储卷抽象[Volume](https://so.csdn.net/so/search?q=Volume&spm=1001.2101.3001.7020)

官网地址：[https://kubernetes.io/docs/concepts/storage/volumes/](https://kubernetes.io/docs/concepts/storage/volumes/)  
 上述演练过程中我们发现Docker容器中数据存储都是临时保存的，只有容器在存活期间是可访问的，如果重启或者挂了之后，对应的数据就会丢失，在实际场景中，例如Mysql，无论是重启还是挂掉，对应的数据都应当保留，为了解决数据持久化存储方案，K8S引入了存储卷Volume抽象；Volume是和Pod相关联的一种概念，Volume可以挂载到容器的文件系统中，另一方面，其他Pod也可进行挂载  
 ![在这里插入图片描述](assets/20201119135903260-20221008134810-mgrz9f7.png)​

### 4.增加hostPath存储卷

```sql
[root@k8s7-200.host.com /data/k8s-yaml/k8s-msa-in-action/ch07/01]# cat mysql-svc.yaml 
apiVersion: v1
kind: Service
metadata:
  name: mysql
spec:
  selector:
    app: mysql
  ports:
    - name: tcp
      port: 3306
      targetPort: 3306
  type: ClusterIP

[root@k8s7-200.host.com /data/k8s-yaml/k8s-msa-in-action/ch07/01]# cat mysql-dp.yaml 
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mysql
spec:
  selector:
    matchLabels:
      app: mysql
  replicas: 1
  template:
    metadata:
      labels:
        app: mysql
    spec:
      containers:
        - name: mysql
          image: harbor.od.com/bobo/mysql:5.7.30
          env:
            - name: MYSQL_ROOT_PASSWORD
              value: petclinic
            - name: MYSQL_DATABASE
              value: petclinic
          volumeMounts:
            - name: mysql-persistent-volume
              mountPath: /var/lib/mysql
      volumes:
        - name: mysql-persistent-volume
          hostPath:
            path: /tmp/data01		#worker节点创建
            type: DirectoryOrCreate
```

### 5.再次发布mysql-svc和petclinic-svc

```sql
[root@k8s7-22.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch07/01/mysql-dp.yaml
deployment.apps/mysql created
[root@k8s7-22.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch07/01/mysql-svc.yaml
service/mysql created
[root@k8s7-22.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch07/01/petclinic-dp.yaml
deployment.apps/petclinic created
[root@k8s7-22.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch07/01/petclinic-svc.yaml
service/petclinic created
```

### 6.浏览器校验

![在这里插入图片描述](assets/20201119141522170-20221008134810-z3zizb3.png)​

### 7.tmp/data0目录下生成mysql和petclinic数据文件

![在这里插入图片描述](assets/20201119141557836-20221008134810-kybggdv.png)​

### 8.重启mysql pod

![在这里插入图片描述](assets/20201119141802382-20221008134810-jcqq5sx.png)​

### 9.浏览器校验仍然成功

![在这里插入图片描述](assets/20201119141742987-20221008134810-4rrdv29.png)​

### 10.总结

1.存储卷Volume是K8s提供的一种存储抽象，可以挂载到容器文件系统  
2.存储卷类型：

* 持久化的(Persistent) ～ Pod重启后数据存在
* 临时的(Ephemeral) ～ Pod重启后数据丢失

3.存储卷可以对接云存储/远程存储，或者本地存储
