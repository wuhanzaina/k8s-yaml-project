# 使用国内的镜像源搭建 kubernetes集群

---

* [https://blog.csdn.net/u011181989/article/details/121514332](https://blog.csdn.net/u011181989/article/details/121514332)

---

**目录**

[1. 概述](#t0 "1. 概述")

[2. 场景说明](#t1 "2. 场景说明")

[3. kubernetes（k8s）安装（CentOS7）](#t2 "3. kubernetes（k8s）安装（CentOS7）")

[4. kubernetes（k8s）集群搭建（CentOS7）](#t3 "4. kubernetes（k8s）集群搭建（CentOS7）")

[5. 综述](#t4 "5. 综述")

[6. 个人公众号](#t5 "6. 个人公众号")

---

## **1. 概述**

老话说的好：努力学习，提高自己，让自己知道的比别人多，了解的别人多。

言归正传，之前我们聊了 [Docker](https://so.csdn.net/so/search?q=Docker&spm=1001.2101.3001.7020)，随着业务的不断扩大，Docker 容器不断增多，物理机也不断增多，此时我们会发现，登录到每台机器去手工操作 Docker 是一件很麻烦的事情。

这时，我们需要一个好用的工具来管理 Docker，帮我们创建、运行、调整、销毁这些容器，帮我们监控哪个容器宕掉了，然后重新启动这个容器等等。

[kubernetes](https://so.csdn.net/so/search?q=kubernetes&spm=1001.2101.3001.7020)（k8s）就是一个很好的选择，今天我们先来聊聊 kubernetes（k8s）是如何搭建的。

## **2. 场景说明**

服务器A IP：192.168.1.12

服务器B IP：192.168.1.11

服务器C IP：192.168.1.15

服务器A hostname：zhuifengren2

服务器B hostname：zhuifengren3

服务器C hostname：zhuifengren4

准备三台服务器，[CentOS7](https://so.csdn.net/so/search?q=CentOS7&spm=1001.2101.3001.7020) 操作系统。

三台服务器都已安装了 Docker，关于 Docker 的安装可参见我的另一篇文章《Docker 急速入门》（[Docker 急速入门_追风人的博客-CSDN博客](https://blog.csdn.net/u011181989/article/details/121443068 "Docker 急速入门_追风人的博客-CSDN博客")）

服务器A 作为 Master 节点，服务器B 和 服务器C 作为数据节点。

## **3. kubernetes（k8s）安装（CentOS7）**

**3.1 官网地址**

https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/

**3.2 服务器配置要求**

内存至少2G

CPU至少2核

硬盘至少20G

**3.3 关闭 SELinux**

**方式一：**

```
# setenforce 0
# sed -i 's/^SELINUX=enforcing$/SELINUX=permissive/' /etc/selinux/config
```

**方式二：**

```
# vim /etc/sysconfig/selinux

SELINUX=enforcing 改为 SELINUX=disabled
重启服务器
```


**3.4 设置路由**

```
# cat <<EOF | sudo tee /etc/modules-load.d/k8s.conf
br_netfilter
EOF

# cat <<EOF | sudo tee /etc/sysctl.d/k8s.conf
 net.bridge.bridge-nf-call-ip6tables = 1
 net.bridge.bridge-nf-call-iptables = 1
EOF

# sysctl --system
```

**3.5 关闭系统的 Swap**

```
# vi /etc/fstab
注释掉 SWAP 的自动挂载

# vi /etc/sysctl.d/k8s.conf
添加下面一行：
 vm.swappiness=0

# sysctl -p /etc/sysctl.d/k8s.conf
# swapoff -a

```

**3.6 安装并启动 kubernetes（K8s）**

```
# cat <<EOF > /etc/yum.repos.d/kubernetes.repo

 [kubernetes]
 name=Kubernetes
 baseurl=https://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64/
 enabled=1
 gpgcheck=0
 repo_gpgcheck=0
 gpgkey=https://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg https://mirrors.aliyun.com/kubernetes/yum/doc/rpm-package-key.gpg
 exclude=kubernetes
 EOF

# yum install -y kubelet kubeadm kubectl --disableexcludes=kubernetes
# systemctl enable kubelet
# systemctl restart kubelet

```

**3.3 到 3.6 的步骤在3台服务器上都执行**

## **4. kubernetes（k8s）集群搭建（CentOS7）**

**4.1 修改 Docker 配置**

```
# cat > /etc/docker/daemon.json <<EOF
 {
 "exec-opts": ["native.cgroupdriver=systemd"],
 "log-driver": "json-file",
 "log-opts": {
 "max-size": "100m"
 },
 "storage-driver": "overlay2",
 "storage-opts": [
 "overlay2.override_kernel_check=true"
 ],
 "data-root": "/data/docker"
 }
EOF

# systemctl daemon-reload
# systemctl restart docker

```

**4.2 查看需要的镜像**

# kubeadm config images list

```java
k8s.gcr.io/kube-apiserver:v1.22.3
k8s.gcr.io/kube-controller-manager:v1.22.3
k8s.gcr.io/kube-scheduler:v1.22.3
k8s.gcr.io/kube-proxy:v1.22.3
k8s.gcr.io/pause:3.5
k8s.gcr.io/etcd:3.5.0-0
k8s.gcr.io/coredns/coredns:v1.8.4
```

**4.3 从国内源拉取镜像**

由于 k8s.cgr.io 无法访问，因此我们需要先使用国内镜像源拉下来，再改tag

执行下面脚本：

```java
#/bin/bash
docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/kube-apiserver:v1.22.3
docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/kube-controller-manager:v1.22.3
docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/kube-scheduler:v1.22.3
docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/kube-proxy:v1.22.3
docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/pause:3.5
docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/etcd:3.5.0-0
docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/coredns:v1.8.4
docker pull quay.io/coreos/flannel:v0.15.1-amd64

docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/kube-apiserver:v1.22.3 k8s.gcr.io/kube-apiserver:v1.22.3
docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/kube-controller-manager:v1.22.3 k8s.gcr.io/kube-controller-manager:v1.22.3
docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/kube-scheduler:v1.22.3 k8s.gcr.io/kube-scheduler:v1.22.3
docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/kube-proxy:v1.22.3 k8s.gcr.io/kube-proxy:v1.22.3
docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/pause:3.5 k8s.gcr.io/pause:3.5
docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/etcd:3.5.0-0 k8s.gcr.io/etcd:3.5.0-0
docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/coredns:v1.8.4 k8s.gcr.io/coredns/coredns:v1.8.4

docker rmi registry.cn-hangzhou.aliyuncs.com/google_containers/kube-apiserver:v1.22.3
docker rmi registry.cn-hangzhou.aliyuncs.com/google_containers/kube-controller-manager:v1.22.3
docker rmi registry.cn-hangzhou.aliyuncs.com/google_containers/kube-scheduler:v1.22.3
docker rmi registry.cn-hangzhou.aliyuncs.com/google_containers/kube-proxy:v1.22.3
docker rmi registry.cn-hangzhou.aliyuncs.com/google_containers/pause:3.5
docker rmi registry.cn-hangzhou.aliyuncs.com/google_containers/etcd:3.5.0-0
docker rmi registry.cn-hangzhou.aliyuncs.com/google_containers/coredns:v1.8.4
```

**4.1 4.2 4.3 的步骤在三台服务器都需要执行**

**4.4 初始化集群**

```
在 Master 节点执行
# kubeadm init --apiserver-advertise-address=192.168.1.12 --pod-network-cidr=10.244.0.0/16
其中，192.168.1.12 是 Master 节点的 IP 地址，可根据实际情况修改。
```


**4.5 Get "http://localhost:10248/healthz": dial tcp [::1]:10248: connect: connection refused 报错解决**

初始化集群时，如果报以上的错误，在 Master 节点按以下步骤操作即可：

```
# vi /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf

增加：
Environment="KUBELET_SYSTEM_PODS_ARGS=--pod-manifest-path=/etc/kubernetes/manifests --allow-privileged=true --fail-swap-on=false"

cat > /var/lib/kubelet/config.yaml <<EOF
 apiVersion: kubelet.config.k8s.io/v1beta1
 kind: KubeletConfiguration
 cgroupDriver: systemd
 EOF

# systemctl daemon-reload
# systemctl restart kubelet
# kubeadm reset -f

```

**4.6 再次执行集群初始化命令**

在 Master 节点执行

```
# kubeadm init --apiserver-advertise-address=192.168.1.12 --pod-network-cidr=10.244.0.0/16

```

出现以下信息，说明初始化成功：

```bash
Your Kubernetes control-plane has initialized successfully!

To start using your cluster, you need to run the following as a regular user:

mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config

Alternatively, if you are the root user, you can run:

export KUBECONFIG=/etc/kubernetes/admin.conf

You should now deploy a pod network to the cluster.
Run "kubectl apply -f [podnetwork].yaml" with one of the options listed at:
https://kubernetes.io/docs/concepts/cluster-administration/addons/

Then you can join any number of worker nodes by running the following on each as root:

kubeadm join 192.168.1.12:6443 --token x0u0ou.q6271pyjm7cv5hxl \
--discovery-token-ca-cert-hash sha256:907ffb03d73f7668b96024c328880f95f4249e98da1be44d1caeb01dd62173da
```

**4.7 根据上一步的信息 export config 文件 及设置网络**

```
# export KUBECONFIG=/etc/kubernetes/admin.conf

这里我们使用 flannel 网络
# kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml

```

**到此为止，Master 节点搭建完毕。**


**4.8 根据 4.6 步骤的信息，将两个数据节点加入集群**

在 服务器B 和 服务器C，执行如下命令（来源于 4.6 步骤的信息）：

```
# kubeadm join 192.168.1.12:6443 --token x0u0ou.q6271pyjm7cv5hxl \
 --discovery-token-ca-cert-hash sha256:907ffb03d73f7668b96024c328880f95f4249e98da1be44d1caeb01dd62173da

```

**如果执行不成功，或者数据节点始终是 NotReady 状态，则参见 4.5 步骤，修改配置。**


**4.9 在 Master 节点，查看集群信息**

# kubectl get node

如果状态都是 Ready，则 Kubernetes（K8s）集群搭建成功。

![](assets/22e236fde82c099dd977495c61025468-20220919100225-fga5uv1.png)​
