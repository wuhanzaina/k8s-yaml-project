# harbor管理helm-charts

---

* [https://blog.csdn.net/qq_40251815/article/details/122662922](https://blog.csdn.net/qq_40251815/article/details/122662922)

---

## 版本信息

```
harbor version： 1.8.1
helm version： v3.6.2
docker version: 18.06.3
docker-compose version: 1.25.4
```

## 安装chartmuseum插件

harbor 安装的时候 默认没有helm charts的仓库

```
docker-compose stop
./install.sh  --with-chartmuseum
```

安装完成之后登录页面上就会有了 helm charts 了，页面上也可以直接上传charts

![](assets/24459121481b44632c4ada7c293e4e6a-20220915150810-en69i3i.png)​

## helm 安装push插件

```
# 安装插件
helm plugin install https://github.com/chartmuseum/helm-push

# 查看
[root@k8s-master ~]# helm plugin list
NAME   	VERSION	DESCRIPTION                    
cm-push	0.10.1 	Push chart package to ChartMuseum
```

创建一个charts项目

![](assets/8a13310e52e2b031539881ed147e4ce0-20220915150810-mo9z2ua.png)​

## 添加仓库

```
helm repo add harbor https://harbor.xxx.com/chartrepo/library

# 如需要配置用户名密码
helm repo add harbor --username=xxx --password=xxx https://harbor.xxx.com/chartrepo/library
```

查看

```
[root@k8s-master ~]# helm repo list
NAME         	URL                                     
bitnami      	https://charts.bitnami.com/bitnami      
ingress-nginx	https://kubernetes.github.io/ingress-nginx
harbor       	http://harbor.aimm.cn/chartrepo/library   
```

## 上传到仓库

```
# 查找charts
[root@k8s-master ~]# helm search repo redis
NAME                 	CHART VERSION	APP VERSION	DESCRIPTION                                     
bitnami/redis        	15.0.4       	6.2.5      	Open source, advanced key-value store. It is of...
bitnami/redis-cluster	6.3.6        	6.2.5      	Open source, advanced key-value store. It is of...

# 下载到本地
[root@k8s-master ~]# helm pull bitnami/redis
[root@k8s-master ~]# ls redis-15.0.4.tgz 
redis-15.0.4.tgz

# 上传到私有仓库
[root@k8s-master ~]# helm cm-push --username=admin --password=Harbor12345 redis-15.0.4.tgz harbor 
Pushing redis-15.0.4.tgz to harbor...
Done.
```

上传完成后到harbor仓库查看

![](assets/6aa6f1bd303ccd7ec5b76413009c223c-20220915150810-ya1uodd.png)​

强制推送

```
[root@k8s-master ~]# helm cm-push --force redis-15.0.4.tgz harbor 
Pushing redis-15.0.4.tgz to harbor...
Done.
```

直接推送到URL

```
[root@k8s-master ~]# helm cm-push redis-15.0.4.tgz https://harbor.xxx.com/chartrepo/library
Pushing redis-15.0.4.tgz to https://harbor.xxx.com/chartrepo/library
Done.
```

## 报错解决：

```
[root@k8s-master ~]# helm cm-push redis-15.0.4.tgz harbor
Pushing redis-15.0.4.tgz to harbor...
Error: 401: could not properly parse response JSON: {"code":401,"message":"Unauthorized"}
......
Error: plugin "cm-push" exited with error
```

添加用户名密码即可。
