# Helm 如何简单地离线安装

参考这里：

`https://metacontroller.github.io/metacontroller/guide/helm-install.html`

---

简要：

1. 取得 `chart` 代码
2. 用 `helm package` 打包（会得到一个 `.tgz` 文件）
3. 用 `helm install` 安装（把原本写安装来源的位置写成那个 `.tgx` 文件的路径就是了）

---

详细示例：

1. 首先用 `helm pull` 或者 `git clone` 等等方式获得 `chart` 的代码：

    ```
    git clone -- https://ghproxy.com/https://github.com/metacontroller/metacontroller.git metacontroller/metacontroller &&
    cd metacontroller/metacontroller
    ```
2. 然后用 `helm package` 命令把目录打包：

    ```
    helm package --destination deploy/helm -- deploy/helm/metacontroller
    ##:  _______ _____________.___________ __.__________________________
    ##: | CMD   | set out put dir or .    |   paras[1]: be packaged dir
    ```

    out:

    ```
    Successfully packaged chart and saved it to: deploy/helm/metacontroller-v2.0.12.tgz
    ```
3. 有了那个打包就能**离线安装**了：

    ```
    helm install --namespace metacontroller --create-namespace -- metacontroller deploy/helm/metacontroller-v2.0.12.tgz
    ##:  _______ ___________.______________ __________________ __.______________,______________________________________
    ##: | CMD   | ns set flag              | auto create set  |   paras[1]: helm app name set, paras[2]: the path of package
    ```

    out:

    ```
    NAME: metacontroller
    LAST DEPLOYED: Mon Nov 22 09:42:03 2021
    NAMESPACE: metacontroller
    STATUS: deployed
    REVISION: 1
    TEST SUITE: None
    ```
