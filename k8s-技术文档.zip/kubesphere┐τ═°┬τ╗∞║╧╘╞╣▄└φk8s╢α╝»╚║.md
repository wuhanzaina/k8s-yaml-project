# kubesphere跨网络混合云管理k8s多集群

---

* [https://blog.csdn.net/sltin/article/details/111598567](https://blog.csdn.net/sltin/article/details/111598567)

---

## 添加[混合云](https://so.csdn.net/so/search?q=%E6%B7%B7%E5%90%88%E4%BA%91&spm=1001.2101.3001.7020)集群管理

* 首要条件 已经安装完成多集群 host member等
* **第一种情况** ：云上和云下通过vpn对等连接或者专线打通(这里直接连接即可)
* **第二种情况** ：云上k8s集群apiserver有公网ip(这种方式也可直接连接)
* **第三种情况** ：云上k8s集群apiserver无公网ip host管理集群有公网ip，使用代理方式连接
* 这里用腾讯云托管的k8s云上+本地自建做测试( **其实这里腾讯云托管的apiserver是可以设置公网ip的用第二种情况也可以实现连通，但是apiserver直接暴露到公网不太安全，所以通过第三种 host集群代理的方式** )


## 在腾讯云已有的k8s集群上部署kubesphere

### 1.下载下部署配置文件

```shell
wget https://github.com/kubesphere/ks-installer/releases/download/v3.0.0/kubesphere-installer.yaml
wget https://github.com/kubesphere/ks-installer/releases/download/v3.0.0/cluster-configuration.yaml
```

### 2.运行installer安装器

```shell
kubectl apply -f kubesphere-installer.yaml
```

### 3.配置service

```shell
kubectl apply -f cluster-configuration.yaml
```

### 4.查看installer 安装进度日志

```shell
kubectl logs -n kubesphere-system $(kubectl get pod -n kubesphere-system -l app=ks-install -o jsonpath='{.items[0].metadata.name}') -f
```

* **提示k8s 版本需要大于1.5 这里是之前在腾讯云建立的k8s集群有些时间了，所以版本较低为1.14.3，这里操作升级一下**

```shell
TASK [preinstall : Stop if kubernetes version is nonsupport] *******************
fatal: [localhost]: FAILED! => { 
    "assertion": "kubernetes_version.stdout is version('v1.15.0', '>=')",
    "changed": false,
    "evaluated_to": false,
    "msg": "The current k8s version is not supported"
}
```

* 升级腾讯云k8s版本 注意腾讯云这里需要版本一次一次升级，从1.4.3到最新1.18.4 需要操作多次升级，master和node要一起升级

![](assets/25acb88b406ee57d4527a9f76a67c857-20220927132305-pkgdw87.png)​

* 升级后最新的版本如下， 升级成功后 再重新部署

![](assets/67e90c5ae4875f4a4531410ee741ab19-20220927132305-6m33hr7.png)​

```shell
//这里进行replace替换重新部署，会删除之前service 所以service也要重新加上
kubectl replace --force -f kubesphere-installer.yaml
kubectl apply -f cluster-configuration.yaml
```

* 4.再次查看installer 安装进度日志

```shell
kubectl logs -n kubesphere-system $(kubectl get pod -n kubesphere-system -l app=ks-install -o jsonpath='{.items[0].metadata.name}') -f

//等待到以下输出则安装成功 登陆修改密码即可
**************************************************
#####################################################
###              Welcome to KubeSphere!           ###
#####################################################

Console: http://10.0.0.12:30880
Account: admin
Password: P@88w0rd

NOTES：
  1. After logging into the console, please check the
     monitoring status of service components in
     the "Cluster Management". If any service is not
     ready, please wait patiently until all components
     are ready.
  2. Please modify the default password after login.

#####################################################
https://kubesphere.io             2020-12-23 11:56:55
#####################################################
```

* 5.安装成功 等待到以下输出则安装成功 登陆修改密码即可

## 把腾讯云上部署的kubesphere纳入到云下host集群管理

![](assets/1c449f56d129dce7ece872037a6fb770-20220927132305-hixrhmd.png)​

### 获取host的Secret

```shell
kubectl -n kubesphere-system get cm kubesphere-config -o yaml | grep -v "apiVersion" | grep jwtSecret

jwtSecret: "HryBNMQBjzXMJnzkxxxxxxxxxx"
```

### 获取host的Secret

```shell
kubectl -n kubesphere-system get cm kubesphere-config -o yaml | grep -v "apiVersion" | grep jwtSecret

jwtSecret: "HryBNMQBjzXMJnzkxxxxxxxxxx"
```

### 修改腾讯云上的集群角色为member

```shell
kubectl edit cc ks-installer -n kubesphere-system

//修改下面这两个参数 第二个从none改为member 然后保存等待安装器更新
authentication:
  jwtSecret: "上个命令获得的Secret"

multicluster:
  clusterRole: member
```

### 查看更新进度

```shell
kubectl logs -n kubesphere-system $(kubectl get pod -n kubesphere-system -l app=ks-install -o jsonpath='{.items[0].metadata.name}') -f
```

### 成功后在host集群添加member成员集群

![](assets/3d582a75f40816150aa67f909565b54a-20220927132305-no7jxeu.png)​

### 这里先通过对  **第二种情况** ：云上k8s集群apiserver假设有公网ip，直接连接做个测试

![](assets/afa204cb296eca307e9e4be6da4598af-20220927132305-lw8c5fr.png)​

### 如下腾讯云的已经纳入统一管理了

![](assets/ac359175db3b71f247b592639f8c6f42-20220927132305-9pmhz2x.png)​

### 现在对 **第三种情况** ：云上k8s集群apiserver无公网ip host管理集群有公网ip，使用代理方式连接做个测试

* 先在host集群所在机器编辑代理服务配置公网ip

```shell
kubectl -n kubesphere-system edit clusterconfiguration ks-installer

//定位到这个配置 下面增加一样代理地址 设置外网端口负载均衡到host集群tower服务的端口
multicluster:
    clusterRole: host
    proxyPublishAddress: http://xxxx:xxx #增加这一行

```

### 添加集群通过代理方式

![](assets/941e28a5ad990e4e29362fc7275d7ab5-20220927132305-wsx35p7.png)​

### 通过代理管理会有个等待加入过程 按照页面步骤在腾讯云上部署代理agent

![](assets/29ff8eba246e0731df2fe92ee302b040-20220927132305-hmq1fex.png)​

### cluster-agent 则是该容器

![](assets/18f80ec17b1012f79d99e9595d366986-20220927132305-b3u7ycs.png)​

### 最后通过2种连接模式都成功可以管理混合云的这种集群，方便统一维护 ，阿里云，华为云等原理一样哦，建议通过第二种代理方式管理

![](assets/44dd1aeebed7a2b2ffdcf83600098aab-20220927132305-ml9rbtb.png)​
