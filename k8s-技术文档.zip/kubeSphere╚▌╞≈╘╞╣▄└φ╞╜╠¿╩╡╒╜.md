# kubeSphere容器云管理平台实战

---

* [https://blog.csdn.net/qq_35029061/article/details/127124079]()

---

## 一、kubekey&KubeSphere简介

### 1、kubekey简介

kubeykey是KubeSphere基于Go 语言开发的集群部署工具，使用 KubeKey，您可以轻松、高效、灵活地单独或整体安装Kubernetes和KubeSphere。

官网：

KubeKey可以用于以下三种安装场景：

* 仅安装 Kubernetes集群；
* 使用一个命令安装 Kubernetes 和 KubeSphere；
* 已有Kubernetes集群，使用ks-installer 在其上部署 KubeSphere；


```bash
export KKZONE=cn
curl -sfL https://get-kk.kubesphere.io | VERSION=v1.2.1 sh -
chmod +x kk

# 生成安装k8s的脚本
./kk create config config-sample.yaml

# 生成安装带有kubesphere的脚本
./kk create config --with-kubesphere v3.2.1 config-sample.yaml

# 创建集群
./kk create cluster -f config-sample.yaml
```

### 2、KubeSphere简介

KubeSphere 是在目前主流容器调度平台 Kubernetes 之上构建的企业级分布式多租户容器平台，提供简单易用的操作界面以及向导式操作方式，在降低用户使用容器调度平台学习成本的同时，极大减轻开发、测试、运维的日常工作的复杂度，旨在解决 Kubernetes 本身存在的存储、网络、安全和易用性等痛点。

除此之外，平台已经整合并优化了多个适用于容器场景的功能模块，以完整的解决方案帮助企业轻松应对敏捷开发与自动化运维、微服务治理、多租户管理、工作负载和集群管理、服务与网络管理、应用编排与管理、镜像仓库管理和存储管理等业务场景。

相比较易捷版，KubeSphere 高级版提供企业级容器应用管理服务，支持更强大的功能和灵活的配置，满足企业复杂的业务需求。比如支持 Master 和 etcd 节点高可用、可视化 CI/CD 流水线、多维度监控告警日志、多租户管理、LDAP 集成、新增支持 HPA (水平自动伸缩) 、容器健康检查以及 Secrets、ConfigMaps 的配置管理等功能，新增微服务治理、灰度发布、s2i、代码质量检查等，后续还将提供和支持多集群管理、大数据、人工智能等更为复杂的业务场景。

总之，通过 KubeSphere 可以快速管理 Kubernetes 集群、部署应用、服务发现、CI/CD 流水线、集群扩容、微服务治理、日志查询和监控告警。换句话说，Kubernetes 是一个很棒的开源项目（或被认为是一个框架），但是 KubeSphere 是一款非常专业的企业级平台产品，专注于解决用户在复杂业务场景中的痛点，提供更友好更专业的用户体验。


|KubeSphere|Kubernetes 对照释义|
| --------------| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|项目|Namespace， 为 Kubernetes 集群提供虚拟的隔离作用，详见。|
|容器组|Pod，是 Kubernetes 进行资源调度的最小单位，每个 Pod 中运行着一个或多个密切相关的业务容器|
|部署|Deployments，表示用户对 Kubernetes 集群的一次更新操作，详见。|
|有状态副本集|StatefulSets，用来管理有状态应用，可以保证部署和 scale 的顺序，详见。|
|守护进程集|DaemonSets，保证在每个 Node 上都运行一个容器副本，常用来部署一些集群的日志、监控或者其他系统管理应用，详见。|
|任务|Jobs，在 Kubernetes 中用来控制批处理型任务的资源对象，即仅执行一次的任务，它保证批处理任务的一个或多个 Pod 成功结束。任务管理的 Pod 根据用户的设置将任务成功完成就自动退出了。比如在创建工作负载前，执行任务，将镜像上传至镜像仓库。详见。|
|定时任务|CronJob，是基于时间的 Job，就类似于 Linux 系统的 crontab，在指定的时间周期运行指定的 Job，在给定时间点只运行一次或周期性地运行。详见|
|服务|Service， 一个 Kubernete 服务是一个最小的对象，类似 Pod，和其它的终端对象一样，详见。|
|应用路由|Ingress，是授权入站连接到达集群服务的规则集合。可通过 Ingress 配置提供外部可访问的 URL、负载均衡、SSL、基于名称的虚拟主机等，详见。|
|镜像仓库|Image Registries，镜像仓库用于存放 Docker 镜像，Docker 镜像用于部署容器服务， 详见。|
|存储卷|PersistentVolumeClaim（PVC），满足用户对于持久化存储的需求，用户将 Pod 内需要持久化的数据挂载至存储卷，实现删除 Pod 后，数据仍保留在存储卷内。Kubesphere 推荐使用动态分配存储，当集群管理员配置存储类型后，集群用户可一键式分配和回收存储卷，无需关心存储底层细节。详见[Persistent Volumes|
|存储类型|StorageClass，为管理员提供了描述存储 “Class（类）” 的方法，包含 Provisioner、 ReclaimPolicy 和 Parameters 。详见。|
|流水线|Pipeline，简单来说就是一套运行在 Jenkins 上的 CI/CD 工作流框架，将原来独立运行于单个或者多个节点的任务连接起来，实现单个任务难以完成的复杂流程编排和可视化的工作。|
|企业空间|Workspace，是 KubeSphere 实现多租户模式的基础，是您管理项目、 DevOps 工程和企业成员的基本单位。|



### 3、KubeSphere功能说明


KubeSphere 为企业用户提供高性能可伸缩的容器应用管理服务，旨在帮助企业完成新一代互联网技术驱动下的，加速业务的快速迭代与交付，以满足企业日新月异的业务需求。


* 面向开发、测试、运维友好的用户界面，向导式用户体验，降低 Kubernetes 学习成本的设计理念；
* 用户基于应用模板可以一键部署一个完整应用的所有服务，UI 提供全生命周期管理；


* 自动弹性伸缩：部署 (Deployment) 支持根据访问量进行动态横向伸缩和容器资源的弹性扩缩容，保证集群和容器资源的高可用；
* 提供健康检查：支持为容器设置健康检查探针来检查容器的健康状态，确保业务的可靠性；


* 简单易用的 DevOps：基于 Jenkins 的可视化 CI/CD 流水线编辑，无需对 Jenkins 进行配置，同时内置丰富的 CI/CD 流水线模版；
* Source to Image (s2i)：从已有的代码仓库中获取代码，并通过 s2i 自动构建镜像完成应用部署并自动推送至镜像仓库，无需编写 Dockerfile；
* 端到端的流水线设置：支持从仓库 (GitHub / SVN / Git)、代码编译、镜像制作、镜像安全、推送仓库、版本发布、到定时构建的端到端流水线设置；
* 安全管理：支持代码静态分析扫描以对 DevOps 工程中代码质量进行安全管理；
* 日志：日志完整记录 CI / CD 流水线运行全过程；


* 灵活的微服务框架：基于 Istio 微服务框架提供可视化的微服务治理功能，将 Kubernetes 的服务进行更细粒度的拆分，支持无侵入的微服务治理；
* 完善的治理功能：支持灰度发布、熔断、流量监测、流量管控、限流、链路追踪、智能路由等完善的微服务治理功能；


* 支持 GlusterFS、CephRBD、NFS 等开源存储方案，支持有状态存储；
* NeonSAN CSI 插件对接 QingStor NeonSAN，以更低时延、更加弹性、更高性能的存储，满足核心业务需求；
* QingCloud CSI 插件对接 QingCloud 云平台各种性能的块存储服务；


* 支持 Calico、Flannel 等开源网络方案；
* 分别开发了 QingCloud 云平台负载均衡器插件 和适用于物理机部署 Kubernetes 的 负载均衡器插件 Porter；
* 商业验证的 SDN 能力：可通过 QingCloud CNI 插件对接 QingCloud SDN，获得更安全、更高性能的网络支持；


* KubeSphere 全监控运维功能可通过可视化界面操作，同时，开放标准接口对接企业运维系统，以统一运维入口实现集中化运维；
* 可视化秒级监控：秒级频率、双重维度、十六项指标立体化监控；提供服务组件监控，快速定位组件故障；
* 提供按节点、企业空间、项目等资源用量排行；
* 支持基于多租户、多维度的监控指标告警，目前告警策略支持集群节点级别和工作负载级别等两个层级；
* 提供多租户日志管理，在 KubeSphere 的日志查询系统中，不同的租户只能看到属于自己的日志信息；


KubeSphere®️ 作为企业级的全栈化容器平台，为用户提供了一个具备极致体验的 Web 控制台，让您能够像使用任何其他互联网产品一样，快速上手各项功能与服务。KubeSphere 目前提供了工作负载管理、微服务治理、DevOps 工程、Source to Image、多租户管理、多维度监控、日志查询与收集、告警通知、服务与网络、应用管理、基础设施管理、镜像管理、应用配置密钥管理等功能模块，开发了适用于适用于物理机部署 Kubernetes 的 负载均衡器插件 Porter，并支持对接多种开源的存储与网络方案，支持高性能的商业存储与网络服务。

![](assets/6c47c72c5a5831d6002335cda80edbb9-20221101141634-u9h9cfd.png)​

以下从专业的角度为您详解各个模块的功能服务：


对底层 Kubernetes 中的多种类型的资源提供极简的图形化向导式 UI 实现工作负载管理、镜像管理、服务与应用路由管理 (服务发现)、密钥配置管理等，并提供弹性伸缩 (HPA) 和容器健康检查支持，支持数万规模的容器资源调度，保证业务在高峰并发情况下的高可用性。

![](assets/c73d2652086dc681293385c82b491c1d-20221101141634-dnhln9b.png)​


* 灵活的微服务框架：基于 Istio 微服务框架提供可视化的微服务治理功能，将 Kubernetes 的服务进行更细粒度的拆分；
* 完善的治理功能：支持熔断、灰度发布、流量管控、限流、链路追踪、智能路由等完善的微服务治理功能，同时，支持代码无侵入的微服务治理；

![](assets/95d54e831166542bce62d630b035c6b4-20221101141634-yk6b4tl.png)​


* ​​：提供基于角色的细粒度多租户统一认证与三层级权限管理；
* ​​：支持与企业基于 LDAP / AD 协议的集中认证系统对接，支持单点登录 (SSO)，以实现租户身份的统一认证；
* ​​：权限等级由高至低分为集群、企业空间与项目三个管理层级，保障多层级不同角色间资源共享且互相隔离，充分保障资源安全性；

![](assets/ae0699e6420e338d8f1059111dcb719b-20221101141634-lsryq26.png)​


* 开箱即用的 DevOps：基于 Jenkins 的可视化 CI / CD 流水线编辑，无需对 Jenkins 进行配置，同时内置丰富的 CI/CD 流水线插件；
* CI/CD 图形化流水线提供邮件通知功能，新增多个执行条件；
* 端到端的流水线设置：支持从仓库 (GitHub / SVN / Git)、代码编译、镜像制作、镜像安全、推送仓库、版本发布、到定时构建的端到端流水线设置；
* 安全管理：支持代码静态分析扫描以对 DevOps 工程中代码质量进行安全管理；
* 日志：日志完整记录 CI / CD 流水线运行全过程；

![](assets/f8477eeb0bef7c85971987063b3287ea-20221101141634-3ntk9cu.png)​


提供 Source to Image (s2i) 的方式从已有的代码仓库中获取代码，并通过 Source to Image 构建镜像的方式来完成部署，并将镜像推送至目标仓库，每次构建镜像的过程将以任务 (Job) 的方式去完成。

![](assets/a78368134e9b84b8aad7f72c3fc90ad3-20221101141635-fo871i1.png)​


* KubeSphere 全监控运维功能可通过可视化界面操作，同时，开放标准接口，易于对接企业运维系统，以统一运维入口实现集中化运维；
* 立体化秒级监控：秒级频率、双重维度、十六项指标立体化监控：

1. 在集群资源维度，提供 CPU 利用率、内存利用率、CPU 平均负载、磁盘使用量、inode 使用率、磁盘吞吐量、IOPS、网卡速率、容器组运行状态、ETCD 监控、API Server 监控等多项指标；
2. 在应用资源维度，提供针对应用的 CPU 用量、内存用量、容器组数量、网络流出速率、网络流入速率等五项监控指标。并支持按用量排序和自定义时间范围查询，快速定位异常；

* 提供按节点、企业空间、项目等资源用量排行；
* 提供服务组件监控，快速定位组件故障；

![](assets/3667515c0b1cc3f0599e8dd70b545afb-20221101141635-heg3h57.png)​


* 支持基于多租户、多维度的监控指标告警，目前告警策略支持集群管理员对节点级别和租户对工作负载级别等两个层级；
* 灵活的告警策略：可自定义包含多个告警规则的告警策略，并且可以指定通知规则和重复告警的规则；
* 丰富的监控告警指标：提供节点级别和工作负载级别的监控告警指标，包括容器组、CPU、内存、磁盘、网络等多个监控告警指标；
* 灵活的告警规则：可自定义某监控指标的检测周期长度、持续周期次数、告警等级等；
* 灵活的通知发送规则：可自定义发送通知时间段及通知列表，目前支持邮件通知；
* 自定义重复告警规则：支持设置重复告警周期、最大重复次数并和告警级别挂钩；

![](assets/fd65201cece6538c0d7c9971b6484c91-20221101141634-smollde.png)​


* 提供多租户日志管理，在 KubeSphere 的日志查询系统中，不同的租户只能看到属于自己的日志信息；
* 多级别的日志查询 (项目/工作负载/容器组/容器以及关键字)、灵活方便的日志收集配置选项等；
* 支持多种日志收集平台，如 Elasticsearch、Kafka、Fluentd；

![](assets/11b8a1d5210d96e984df275b3ddfe977-20221101141635-ylhsnon.png)​


* 使用开源的  提供应用商店和应用仓库服务，为用户提供应用全生命周期管理功能；
* 用户基于应用模板可以快速便捷地部署一个完整应用的所有服务；

![](assets/1547e7897f3c83d68a7eccf598fb3821-20221101141635-gpwtofw.png)​


提供存储类型管理、主机管理和监控、资源配额管理，并且支持镜像仓库管理、权限管理、镜像安全扫描。内置 Harbor 镜像仓库，支持添加 Docker 或私有的 Harbor 镜像仓库。

![](assets/8bdf4ac0f54f1f681f99683e64824ffe-20221101141635-5dcz54m.png)​


* 支持 GlusterFS、CephRBD、NFS 等开源存储方案，支持有状态存储；
* NeonSAN CSI 插件对接 QingStor NeonSAN，以更低时延、更加弹性、更高性能的存储，满足核心业务需求；
* QingCloud CSI 插件对接 QingCloud 云平台各种性能的块存储服务；

![](assets/16f5662d715550e77ba40c1f241f0a76-20221101141634-wym2ptv.png)​


* 支持 Calico、Flannel 等开源网络方案；
* 开发了适用于适用于物理机部署 Kubernetes 的 ；

### 4、KubeSphere架构

KubeSphere 采用了​​，实现了​​，后端的各个功能组件可通过 REST API 对接外部系统，可参考 。KubeSphere 无底层的基础设施依赖，可以运行在任何 Kubernetes、私有云、公有云、VM 或物理环境（BM）之上。

![](assets/8e638b8006053a8b356b714c990b4c12-20221101141635-b1ouwoi.png)​

|后端组件|功能说明|
| -----------------------| ---------------------------------------------------------------------------------------------------|
|ks-account|提供用户、权限管理相关的 API|
|ks-apiserver|整个集群管理的 API 接口和集群内部各个模块之间通信的枢纽，以及集群安全控制|
|ks-apigateway|负责处理服务请求和处理 API 调用过程中的所有任务|
|ks-console|提供 KubeSphere 的控制台服务|
|ks-controller-manager|实现业务逻辑的，例如创建企业空间时，为其创建对应的权限；或创建服务策略时，生成对应的 Istio 配置等|
|Metrics-server|Kubernetes 的监控组件，从每个节点的 Kubelet 采集指标信息|
|Elasticsearch|提供集群的日志索引、查询、数据管理等服务，在安装时也可对接您已有的 ES 减少资源消耗|
|Prometheus|提供集群、节点、工作负载、API 对象等相关监控数据与服务|
|Fluent Bit|提供日志接收与转发，可将采集到的⽇志信息发送到 ElasticSearch、Kafka|
|Jenkins|提供 CI/CD 流水线服务|
|SonarQube|可选安装项，提供代码静态检查与质量分析|
|Source-to-Image|将源代码自动将编译并打包成 Docker 镜像，方便快速构建镜像|
|Istio|提供微服务治理与流量管控，如灰度发布、金丝雀发布、熔断、流量镜像等|
|Jaeger|收集 Sidecar 数据，提供分布式 Tracing 服务|
|OpenPitrix|提供应用模板、应用部署与管理的服务|
|Alert|提供集群、Workload、Pod、容器级别的自定义告警服务|
|Notification|通用的通知服务，目前支持邮件通知|
|redis|将 ks-console 与 ks-account 的数据存储在内存中的存储系统|
|MySQL|集群后端组件的数据库，监控、告警、DevOps、OpenPitrix 共用 MySQL 服务|
|PostgreSQL|SonarQube 和 Harbor 的后端数据库|
|OpenLDAP|负责集中存储和管理用户账号信息与对接外部的 LDAP|
|存储|内置 CSI 插件对接云平台存储服务，可选安装开源的 NFS/Ceph/Gluster 的客户端|
|网络|可选安装 Calico/Flannel 等开源的网络插件，支持对接云平台 SDN|

除了上述列表的组件，KubeSphere 还支持 Harbor 与 GitLab 作为可选安装项，您可以根据项目需要进行安装。以上列表中每个功能组件下还有多个服务组件，关于服务组件的说明，可参考 。

![](assets/9646fc7aaa8ce71cacffbdb0036edd94-20221101141634-xzxa1if.png)​

### 5、KubeSphere应用场景

KubeSphere®️ 适用于企业在数字化转型时所面临的敏捷开发与自动化运维、微服务应用架构与流量治理、自动弹性伸缩和业务高可用、DevOps 持续集成与交付等应用场景。


企业用户部署于物理机、传统虚拟化环境的业务系统，各业务模块会深度耦合，资源不能灵活的水平扩展。 KubeSphere 帮助企业将 IT 环境容器化并提供完整的运维管理功能，同时依托青云QingCloud 为企业提供强大的网络、存储支持，并可高效对接企业原监控、运维系统，一站式高效完成企业 IT 容器化改造。


无论将业务架构在 Kubernetes 平台上的用户，还是使用多套来自不同厂商提供的 Kubernetes 平台的用户，复杂的运维管理使企业压力倍增。KubeSphere 可提供统一平台纳管异构 Kubernetes 集群，支持应用自动化部署，减轻日常运维压力。同时，完善的监控告警与日志管理系统有效节省运维人工成本，使企业能够将更多精力投放到业务创新上。


DevOps 将开发团队与运营团队通过一套流程或方法建立更具协作性、更高效的的关系，使得开发、测试、发布应用能够更加敏捷、高效、可靠。KubeSphere CI / CD 功能可为企业DevOps 提供敏捷开发与自动化运维。同时， KubeSphere 的微服务治理功能，帮助企业以一种细粒度的方式开发、测试和发布服务，有效推动企业 DevOps 落地。


微服务架构可轻量级构建冗余，可扩展性强，非常适合构建云原生应用程序。KubeSphere 基于主流微服务解决方案 Istio，提供无代码侵入的微服务治理平台。后续将集成 SpringCloud，便于企业构建 Java 应用，助力企业一步实现微服务架构，实现应用云原生转型。


支持在全物理环境部署全栈容器架构，利用物理交换机，为 KubeSphere 提供负载均衡器服务，同时，通过 KubeSphere 与 QingCloud VPC 以及QingStor NeonSAN 的组合，可打通负载均衡、容器平台、网络、存储全栈功能，实现真正意义上的物理环境一体化多租户容器架构解决方案，并实现自主可控、统一管理。避免虚拟化带来的性能损耗，释放硬件最大效能。

## 二、kubekey安装高可用K8s集群

### 1、安装方式选择


![](assets/69d497b508f84d08a8837846fabb0645-20221101141635-l9i2c5h.png)​


![](assets/ee4f61f43a334127a555d552d18287e6-20221101141634-czz9w0d.png)​

节点规划：

![](assets/a3cf32cca1104f0183e3bcf80811f813-20221101141635-6qrr8co.png)​

### 2、下载kubekey

我们这里，将采用第二种安装方式，internal loadBalancer；可以不用额外的机器资源，内部负载均衡：

```bash
export KKZONE=cn
curl -sfL https://get-kk.kubesphere.io | VERSION=v1.2.1 sh -
chmod +x kk
# ⽣成安装k8s的脚本
./kk create config -f config-sample.yaml
```

修改配置文件：

```css
apiVersion: kubekey.kubesphere.io/v1alpha1
kind: Cluster
metadata:
  name: sample
spec:
  hosts:
  - {name: master1, address: 10.4.7.60, internalAddress: 10.4.7.60, user: root, password: '123456'}
  - {name: master2, address: 10.4.7.61, internalAddress: 10.4.7.61, user: root, password: '123456'}
  - {name: master3, address: 10.4.7.62, internalAddress: 10.4.7.62, user: root, password: '123456'}
  - {name: node1, address: 10.4.7.70, internalAddress: 10.4.7.70, user: root, password: '123456'}
  - {name: node2, address: 10.4.7.71, internalAddress: 10.4.7.71, user: root, password: '123456'}
  roleGroups:
    etcd:
    - master1
    - master2
    - master3
    master:
    - master1
    - master2
    - master3
    worker:
    - node1
    - node2
  controlPlaneEndpoint:
    ##Internal loadbalancer for apiservers
    internalLoadbalancer: haproxy

    domain: lb.kubesphere.local
    address: ""
    port: 6443
  kubernetes:
    version: v1.21.5
    clusterName: cluster.local
  network:
    plugin: calico
    kubePodsCIDR: 10.233.64.0/18
    kubeServiceCIDR: 10.233.0.0/18
  registry:
    registryMirrors: []
    insecureRegistries: []
  addons: []
```

```bash
apiVersion: kubekey.kubesphere.io/v1alpha1
kind: Cluster
metadata:
  name: sample
spec:
  hosts:
  - {name: node1, address: 10.4.7.80, internalAddress: 10.4.7.80, user: root, password: '123456'}
  roleGroups:
    etcd:
    - node1
    master:
    - node1
    worker:
    - node1
  controlPlaneEndpoint:
##Internal loadbalancer for apiservers
#internalLoadbalancer: haproxy

    domain: lb.kubesphere.local
    address: ""
    port: 6443
  kubernetes:
    version: v1.21.5
    clusterName: cluster.local
  network:
    plugin: calico
    kubePodsCIDR: 10.233.64.0/18
    kubeServiceCIDR: 10.233.0.0/18
  registry:
    registryMirrors: []
    insecureRegistries: []
addons: []
```

### 3、安装k8s集群

```lua
# 直接安装k8s集群
./kk create cluster -f config-sample.yaml

# 如果同时部署 kubesphere
./kk create cluster -f config-sample.yaml --with-kubesphere v3.2.1
```

Console:   
 Account: admin  
 Password: P@88w0rd

### 4、配置文件说明

```bash
apiVersion: kubekey.kubesphere.io/v1alpha1
kind: Cluster
metadata:
  name: sample
spec:
  hosts:  # 指定集群的节点信息，包括登录集群的账号密码
  - {name: master1, address: 10.4.7.60, internalAddress: 10.4.7.60, user: root, password: '123456'}
  - {name: master2, address: 10.4.7.61, internalAddress: 10.4.7.61, user: root, password: '123456'}
  - {name: master3, address: 10.4.7.62, internalAddress: 10.4.7.62, user: root, password: '123456'}
  - {name: node1, address: 10.4.7.70, internalAddress: 10.4.7.70, user: root, password: '123456'}
  - {name: node2, address: 10.4.7.71, internalAddress: 10.4.7.71, user: root, password: '123456'}
  roleGroups:
    etcd:   # etcd安装的节点信息
    - master1
    - master2
    - master3
    master:  # master安装的节点信息
    - master1 
    - master2
    - master3
    worker:  # worker安装的节点信息
    - node1
    - node2
  controlPlaneEndpoint:
##Internal loadbalancer for apiservers
    internalLoadbalancer: haproxy  # 开启内部的Lb

    domain: lb.kubesphere.local
    address: ""  #虚拟vip，如果是开启的内部的 lb，留空
    port: 6443
  kubernetes:  # 安装k8s版本的信息
    version: v1.21.5
    clusterName: cluster.local
  network:   # 选⽤k8s⽹络的信息
    plugin: calico
    kubePodsCIDR: 10.233.64.0/18
    kubeServiceCIDR: 10.233.0.0/18
  registry:  # 远程仓库的配置信息
    registryMirrors: []
    insecureRegistries: []
  addons: []  # 初始化安装的时候，开启了哪些组件。可以不配置，后续在后台操作
```

### 5、k8s证书

查看集群证书是否到期：

```sql
./kk certs check-expiration
```

更新证书：

```crystal
# 集群证书位置
/etc/kubernetes/pki/

# 执⾏命令更新证书
./kk certs renew -f config.yaml
```

## 三、kubekey节点管理

### 1、添加节点

1. 修改 config.yaml文件
2. 执行命令：./kk add nodes -f config.yaml

### 2、删除节点


以 admin 身份登录控制台，访问集群管理页面。若要将节点标记为不可调度，从左侧菜单中选择节点下的集群节点，找到想要从集群中删除的节点，点击停止调度。

或直接执行命令 kubectl cordon $NODENAME 。


### 3、启用可插拔组件

请参考：

### 4、节点管理

请参考：

### 5、卸载k8s集群

```typescript
./kk delete cluster -f config-sample.yaml
```

## 四、kubekey安装kubeSphere

### 

请参考：


### 2、本地自己安装的k8s集群

请参考：


## 五、KubeSphere多租户

### 1、多租户图示

![](assets/c5c5dc37ebdd4706bd84a87bf89ea1cc-20221101141635-tgqrbe4.png)​


![](assets/77c7e8e716a14aaf82194459283e2d4d-20221101141635-c9tasfn.png)​


KubeSphere 的多租户系统分三个层级，即集群、企业空间和项目。KubeSphere 中的项目等同于 Kubernetes的 

### 2、多租户实践


![](assets/6bf8430f60ae483ab82b01475af99a9e-20221101141635-7wkyvvo.png)​

测试密码全部设置为： Test123

admin初始的账号，已经修改为：Test123456


点击左上⻆的平台管理，然后选择访问控制。在左侧导航栏中，选择平台⻆色。这里是查看⻆色

点击左上⻆的平台管理，然后选择访问控制。在左侧导航栏中，选择用户。创建用户，根据上面的图示，创建对应的用户来测试。


1. 以 ws-manager 身份登录 KubeSphere，它具有管理平台上所有企业空间的权限。点击左上⻆的平台管理，选择访问控制。在企业空间中，可以看到仅列出了一个默认企业空间 system-workspace ，即系统企业空间，其中运行着与系统相关的组件和服务，您无法删除该企业空间。
2. 点击右侧的创建，将新企业空间命名为 demo-workspace ，并将用户 ws-admin 设置为企业空间管理员。完成后，点击创建。
3. 登出控制台，然后以 ws-admin 身份重新登录。在企业空间设置中，选择企业空间成员，然后点击邀请。
4. 邀请 project-admin 和 project-regular 进入企业空间，分别授予 workspace-self-provisioner 和workspace-viewer 角色，点击确定。
5. 将 project-admin 和 project-regular 都添加到企业空间后，点击确定。在企业空间中，您可以看到列出的三名成员。

![](assets/0620a37ed5ad40a19a018bb6a07fe3ea-20221101141635-x9vnp78.png)​


1. 以 project-admin 身份登录 KubeSphere Web 控制台，在项目中，点击创建。
2. 输入项目名称（例如 demo-project ），然后点击确定完成，您还可以为项目添加别名和描述。
3. 在项目中，点击刚创建的项目查看其详情页面。
4. 在项目的概览页目，默认情况下未设置项目配额。您可以点击编辑配额并根据需要指定资源请求和限制（例如：CPU 和内存的限制分别设为 1 Core 和 1000 Gi）。
5. 在项目设置 > 项目成员中，邀请 project-regular 至该项目，并授予该用户 operator 角色。信息具有 operator 角色的用户是项目维护者，可以管理项目中除用户和角色以外的资源。
6. 在创建应用路由（即 Kubernetes 中的 Ingress）之前，需要启用该项目的网关。网关是在项目中运行的NGINX Ingress 控制器。若要设置网关，请转到项目设置中的网关设置，然后点击设置网关。此步骤中仍使用帐户 project-admin 。
7. 选择访问方式 NodePort，然后点击确定。
8. 在网关设置下，可以在页母上看到网关地址以及 http/https 的端口。


若要创建 DevOps 项目，需要预先启用 KubeSphere DevOps 系统，该系统是个可插拔的组件

1. 以 project-admin 身份登录控制台，在 DevOps 项目中，点击创建。
2. 输入 DevOps 项目名称（例如 demo-devops ），然后点击确定，也可以为该项目添加别名和描述。
3. 点击刚创建的项目查看其详细页母。
4. 转到 DevOps 项目设置，然后选择 DevOps 项目成员。点击邀请授予 project-regular 用户 operator的角色，允许其创建流水线和凭证。

## 六、KubeSphere中间件

### 1、部署中间件要素

应用部署需要关注的信息【应用部署三要素】：

1. 应用的部署方式
2. 应用的数据挂载（数据，配置文件）
3. 应用的可访问性

![](assets/414ac2933f16425f9c3fa5ecad6ea485-20221101141635-inmsvx3.png)​

### 2、KubeShpere-k8s-mysql



![](assets/9cf0dcf124104f1994cb21edc33247a3-20221101141634-8xau4je.png)​

* 需要指定环境变量 MYSQL_ROOT_PASSWORD；
* 需要有mysql的配置内容 my.cnf；
* 需要指定mysql的存储 pvc；



```groovy
docker run -p 3306:3306 --name mysql-01 \
-v /mydata/mysql/log:/var/log/mysql \
-v /mydata/mysql/data:/var/lib/mysql \
-v /mydata/mysql/conf:/etc/mysql/conf.d \
-e MYSQL_ROOT_PASSWORD=root \
--restart=always \
-d mysql:5.7
```


```sql
[client]
default-character-set=utf8mb4

[mysql]
default-character-set=utf8mb4

[mysqld]
init_connect='SET collation_connection = utf8mb4_unicode_ci'
init_connect='SET NAMES utf8mb4'
character-set-server=utf8mb4
collation-server=utf8mb4_unicode_ci
skip-character-set-client-handshake
skip-name-resolve
```


配置的就是ConfigMap的信息，我们会把mysql的配置内容，定义在ConfigMap中。

* 进入配置页母；平台管理->集群管理->配置->配置字典；
* 配置；

![](assets/fd6aab07fbb94046a6af159115cd9d5f-20221101141635-poc034k.png)​

* 下一步，添加数据


键：

* my.cnf 就是会在容器里的名称；

值：

* 这里就是配置mysql的内容；

![](assets/5a80e10b67d24b4aab83dff926e3235b-20221101141634-bwje2kb.png)​


pvc，用来存储数据的，比如这里会把单独申请一个存储空间来保存mysql的内容。

注意：这里如果是提前申请的 pvc，也就是在 存储->存储卷中申请。后续mysql扩容的话，会都使用这一个存储卷。

一般是在应用负载配置的时候，一同申请。这样如果mysql扩容，也会一同申请新的pvc。


平台管理->集群管理->存储->存储卷


![](assets/7ab9c16ddde0439dbaa6aaad4297fa9f-20221101141634-e65ofgy.png)​



进入配置页面；平台管理->集群管理->应用负载->工作负载



![](assets/dc1ec30d9c574d2b862815112219b0ba-20221101141635-0tfkv1r.png)​


![](assets/0e54c9130edb477f9891d617b1e2240f-20221101141634-l8m291v.png)​

![](assets/8331052222684231a5b6c9c688b3384c-20221101141634-ow513z2.png)​


![](assets/e2197781954941c386fddc06566a662a-20221101141635-yl05ctm.png)​

![](assets/43470ca22150474f81b898cf65680d2e-20221101141635-k9njh5i.png)​


![](assets/864f427187674e60afe5af52fe941acc-20221101141635-fu3hnph.png)​


![](assets/039e7fd1f2394eac8ce316cdbb0fb3f3-20221101141635-nok1cax.png)​


![](assets/4bc60571bc4f4e449ea39e027fa037e5-20221101141634-e5q4jmx.png)​

/var/lib/mysql：

![](assets/308ef2af74b94fb296469761c400577a-20221101141634-ousqmjf.png)​


![](assets/55427111af4f4e6bba89a2f2fa18c33f-20221101141634-ss4fy30.png)​

![](assets/3c24021e4e50440a97ee79984b06d0a2-20221101141634-zbkl93v.png)​


进入终端，查看：

![](assets/bc7d41ce550d443a89dd616955b2e939-20221101141635-lwua9h2.png)​


应用负载->服务

在容器内登录mysql查看：

![](assets/740e3f1f9a024ecea3e2798a8e41392f-20221101141634-nkr3ej0.png)​

![](assets/24742164ac274f05966b8291e5071f29-20221101141635-jfzrauv.png)​

对外发布服务：

应用负载->服务->创建

![](assets/c39ffabd619a4a3aaa0a048a60473fa1-20221101141634-d9vl9dp.png)​

![](assets/12a7c2de71754cb19788fc714a074025-20221101141634-q1lpthr.png)​

![](assets/519e2a1887e94abe8f0a7a1069549f96-20221101141634-069kcv4.png)​


![](assets/e130f86500814435a39deda425aa7c19-20221101141634-0jrlnil.png)​

### 3、KubeShpere-k8s-mysql



![](assets/c48f9cf452144a6ebb8e2a9aeb457d09-20221101141634-wbwj082.png)​

* 需要redis的配置内容， redins.conf；
* 需要指定redis的存储 , pvc；
* redis有启动命令 redis-server /etc/redis/redis.conf；




```bash
#创建配置⽂件
## 1、准备redis配置⽂件内容
mkdir -p /mydata/redis/conf && vim /mydata/redis/conf/redis.conf

##配置示例
appendonly yes
port 6379
bind 0.0.0.0

#docker启动redis
docker run -d -p 6379:6379 --restart=always \
-v /mydata/redis/conf/redis.conf:/etc/redis/redis.conf \
-v /mydata/redis-01/data:/data \
--name redis-01 redis:6.2.5 \
redis-server /etc/redis/redis.conf
```




![](assets/28998fc10056495a86c112517d86085d-20221101141634-ldrgysc.png)​

![](assets/16a83072af644456a03f30c89a3e8fea-20221101141634-oy8336x.png)​



进入配置页面；平台管理->集群管理->应用负载->工作负载



![](assets/28421e823f8d438e92ccefde569af844-20221101141634-6fignd7.png)​


![](assets/273d4832db1a47e6802534cd1be8ae35-20221101141634-z0jzeu7.png)​

![](assets/f4f5b47ad382465c9fd09ac7e10a1948-20221101141635-x1qz7y4.png)​

![](assets/3cf080b91ed849fcb5b377d7c5844937-20221101141634-zncpd6o.png)​


这里，没有提前准备pvc，所以直接操作：

![](assets/8b58a91f9e594818894fdd75201915ca-20221101141634-it4uql4.png)​

![](assets/69c88b825d66477c828a24f713783316-20221101141634-1i143r8.png)​


![](assets/3082fe81903c47f39f9ba50b875cd482-20221101141635-y5evj2v.png)​




应用负载->服务->创建

![](assets/8d753870139a476db2a64bfef309dc2d-20221101141634-uyadbk6.png)​

![](assets/0a32ab0b77fa4e65bffd9139e8e28ecf-20221101141635-f1zwo8o.png)​

![](assets/709cdc305aa5437bb606bf3f71185ce4-20221101141634-bdn9gh7.png)​

### 4、KubeShpere-k8s-es



![](assets/30a8361884e74a4aa781c18c5935d8a6-20221101141635-eqne3fh.png)​

* 需要指定es的配置， elasticsearch.yml, jvm.options；
* 需要指定es的存储，pvc；
* 需要指定环境变量, ES_JAVA_OPTS；
* 这里会把配置内容挂载到容器中， 其实 /usr/share/elasticsearch/config里有多个配置，我们这里要挂载进去的只有 elasticsearch.yml, jvm.options；




```bash
# 创建数据目录
mkdir -p /mydata/es-01/data && chmod 777 -R /mydata/es-01/data

# 容器启动
docker run --restart=always -d -p 9200:9200 -p 9300:9300 \
-e "discovery.type=single-node" \
-e ES_JAVA_OPTS="-Xms512m -Xmx512m" \
-v es-config:/usr/share/elasticsearch/config \
-v /mydata/es-01/data:/usr/share/elasticsearch/data \
--name es-01 \
elasticsearch:7.13.4
```

elasticsearch.yml：

```scss
cluster.name: "docker-cluster"
network.host: 0.0.0.0
```

jvm.options：

```ruby
################################################################
##
## JVM configuration
##
################################################################
##
## WARNING: DO NOT EDIT THIS FILE. If you want to override the
## JVM options in this file, or set any additional options, you
## should create one or more files in the jvm.options.d
## directory containing your adjustments.
##
## See https://www.elastic.co/guide/en/elasticsearch/reference/current/jvm-options.html
## for more information.
##
################################################################
################################################################
## IMPORTANT: JVM heap size
################################################################
##
## The heap size is automatically configured by Elasticsearch
## based on the available memory in your system and the roles
## each node is configured to fulfill. If specifying heap is
## required, it should be done through a file in jvm.options.d,
## and the min and max should be set to the same value. For
## example, to set the heap to 4 GB, create a new file in the
## jvm.options.d directory containing these lines:
##
## -Xms4g
## -Xmx4g
##
## See https://www.elastic.co/guide/en/elasticsearch/reference/current/heap-size.html
## for more information
##
################################################################
################################################################
## Expert settings
################################################################
##
## All settings below here are considered expert settings. Do
## not adjust them unless you understand what you are doing. Do
## not edit them in this file; instead, create a new file in the
## jvm.options.d directory containing your adjustments.
##
################################################################
## GC configuration
8-13:-XX:+UseConcMarkSweepGC
8-13:-XX:CMSInitiatingOccupancyFraction=75
8-13:-XX:+UseCMSInitiatingOccupancyOnly
## G1GC Configuration
# NOTE: G1 GC is only supported on JDK version 10 or later
# to use G1GC, uncomment the next two lines and update the version on the
# following three lines to your version of the JDK
# 10-13:-XX:-UseConcMarkSweepGC
# 10-13:-XX:-UseCMSInitiatingOccupancyOnly
14-:-XX:+UseG1GC
## JVM temporary directory
-Djava.io.tmpdir=${ES_TMPDIR}
## heap dumps
# generate a heap dump when an allocation from the Java heap fails; heap dumps
# are created in the working directory of the JVM unless an alternative path is
# specified
-XX:+HeapDumpOnOutOfMemoryError
# specify an alternative path for heap dumps; ensure the directory exists and
# has sufficient space
-XX:HeapDumpPath=data
# specify an alternative path for JVM fatal error logs
-XX:ErrorFile=logs/hs_err_pid%p.log
## JDK 8 GC logging
8:-XX:+PrintGCDetails
8:-XX:+PrintGCDateStamps
8:-XX:+PrintTenuringDistribution
8:-XX:+PrintGCApplicationStoppedTime
8:-Xloggc:logs/gc.log
8:-XX:+UseGCLogFileRotation
8:-XX:NumberOfGCLogFiles=32
8:-XX:GCLogFileSize=64m
# JDK 9+ GC logging
9-:-
Xlog:gc*,gc+age=trace,safepoint:file=logs/gc.log:utctime,pid,tags:filecount=32,filesize
=64m
```



平台管理->集群管理->配置->配置字典


![](assets/2c5430ffdd3b483c94ab43740a892be0-20221101141634-wulvikk.png)​

![](assets/319ffc9a74b24530985ea6e9568b8ce8-20221101141634-71aen2a.png)​



进入配置页面：

平台管理->集群管理->应用负载->工作负载



![](assets/9e18a79df8b04a2ab17c2909eff62c25-20221101141635-g4cuc4s.png)​


![](assets/50ffe6ab202d4de3a602d0801e976f93-20221101141634-2j7e7o5.png)​

![](assets/a843a971e71647a09c11d112c8caff73-20221101141635-5h501pf.png)​

![](assets/ca267bf798b046e89b3494b849b0165b-20221101141635-qc2j3lf.png)​


![](assets/476f1ee3d75b4798b0eb2f655e48eae2-20221101141635-7sazxyp.png)

注意：这里用的是子路径的配置方式。

a. 配置elasticsearch.yml

配置内的内容是： /usr/share/elasticsearch/config/elasticsearch.yml

![](assets/12808f848ec9472ea5442c67132258ed-20221101141634-ry7d26k.png)​

![](assets/a3ff490a754940b8a7023be749a8075b-20221101141635-kg73din.png)​

b. 配置 jvm.options

配置里的内容是： /usr/share/elasticsearch/config/jvm.options

![](assets/0eb5952b87c54ac6b3e759ebab2daadb-20221101141634-wiehz51.png)​




应用负载->服务->创建

### 5、KubeShpere-应用商店-rabbitmq




应用商店-消息队列-rabbitmq：

![](assets/d4dd25ba26c94d1f868751086b8ca8d6-20221101141634-xdq90gu.png)​

![](assets/2bf53e107b67492d8aa4176d18f0cf36-20221101141634-xwsvgne.png)​

### 6、KubeShpere-应用仓库-zk


helm：k8s的管理。



![](assets/e20b4f4602b44a1a9291e41401e612df-20221101141634-11cfzpp.png)​


应用管理->应用仓库

注意：要用空间管理员登录，我们这里是用ws-admin来登录。

![](assets/73769777caf14c0d956cb5520ecdc194-20221101141634-v46qcji.png)​

![](assets/3694f6bdc7144d84ae78aee6da302258-20221101141634-9mw7e7i.png)​


![](assets/94c4cbbbf3a04d0eb47f0677959bc3bd-20221101141635-y7jh8tf.png)​

![](assets/353793d7178e421c9134373bc307a24e-20221101141634-oifdfqw.png)​

![](assets/017c77a188094d2782a84acc30b920a5-20221101141634-emaeiw6.png)​

### 7、go 微服务中间件


bitnami中安装。



![](assets/9fe96fc2e5d64921ad250bbda3ee75b7-20221101141634-3o65iqt.png)​



![](assets/4b65f76b7f524260af047a1955504586-20221101141634-zwa897u.png)​


bitnami中安装。

### 8、DevOps-golang


1. 以 admin 身份登录控制台，点击左上⻆的平台管理，选择集群管理。
2. 点击 CRD，在搜索栏中输入 clusterconfiguration ，点击搜索结果查看其详细页面
3. 在自定义资源中，点击 ks-installer 右侧的，选择编辑 YAML。
4. 在该 YAML 文件中，搜寻到 devops ，将 enabled 的 false 改为 true 。完成后，点击右下⻆的确定，保存配置。

```vbnet
devops:
  enabled: true # 将“false”更改为“true”。
```

您可以使用 Web Kubectl 工具执行以下命令来检查安装过程：

```sql
kubectl logs -n kubesphere-system $(kubectl get pod -n kubesphere-system -l app=ks-
install -o jsonpath='{.items[0].metadata.name}') -f
```

查看是否安装成功：

```sql
kubectl get pod -n kubesphere-devops-system
```

安装以后，登录后台查看：

![](assets/dae107e2d7574c488adb64145d935bd1-20221101141635-p5uli0r.png)​


若要创建 DevOps 项目，需要预先启用KubeSphere DevOps系统，该系统是个可插拔的组件：

1. 以 project-admin 身份登录控制台，在 DevOps 项目中，点击创建。
2. 输入DevOps 项目名称（例如 demo-devops ），然后点击确定，也可以为该项目添加别名和描述。
3. 点击刚创建的项目查看其详细页面。
4. 转到 DevOps 项目设置，然后选择 DevOps 项目成员。点击邀请授予 project-regular用户 operator的角色，允许其创建流水线和凭证。

![](assets/cb78806dcc954f43bf019fa05fd59a9d-20221101141635-jrvmkwi.png)​


DevOps 项目->选中devops项目->流水线->创建

进人流水线，编辑测试：

![](assets/2bbe24e62017454d93293c848032dc2f-20221101141634-9vlr917.png)​

![](assets/f681373fd7fa4b2685d7f753171ffa06-20221101141635-bi6tx9h.png)​

详情参考：


### 9、go-micro-frame 微服务发布

项目架构

![](assets/f57c73d5fa7248d58e79116ebf919a5c-20221101141635-dtrms2q.png)​

目录代码：

```typescript
mall-code
|---mall-common //通⽤模块
|---mall-srv //微服务层-数据层
|------common-srv //公共微服务 [50050]
|------goods-srv //商品微服务 [50052]
|---mall-web //微服务层-业务层
|------api-backend-general-system-web //总后台 [8021]
|------api-mini-program-user-web //⼩程序 [8020]
```

详情参考：
