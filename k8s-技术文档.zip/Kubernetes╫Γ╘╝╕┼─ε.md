# Kubernetes租约概念

---

* [https://yinwu.blog.csdn.net/article/details/118637571](https://yinwu.blog.csdn.net/article/details/118637571?spm=1001.2014.3001.5502)

---

### 1.k8s租约概念

```ruby
k8s节点租约的概念：
[root@VM-2-6-tlinux ~]# kubectl  get leases -n kube-node-lease
NAME        HOLDER      AGE
10.0.1.11   10.0.1.11   21d
10.0.1.16   10.0.1.16   21d
10.0.1.4    10.0.1.4    21d
10.0.2.6    10.0.2.6    21d
[root@VM-2-6-tlinux ~]# kubectl get leases/10.0.2.6 -oyaml -n kube-node-lease
apiVersion: coordination.k8s.io/v1
kind: Lease
metadata:
  creationTimestamp: "2021-06-08T11:40:54Z"
  name: 10.0.2.6
  namespace: kube-node-lease
  ownerReferences:
  - apiVersion: v1
    kind: Node
    name: 10.0.2.6
    uid: ff1e998a-3bbf-459c-9db6-1cc637a85db7
  resourceVersion: "27832583"
  selfLink: /apis/coordination.k8s.io/v1/namespaces/kube-node-lease/leases/10.0.2.6
  uid: c369fee6-a0fa-47bc-881e-a5db8b96ff3e
spec:
  holderIdentity: 10.0.2.6
  leaseDurationSeconds: 40
  renewTime: "2021-06-30T08:34:52.509366Z"
```

### 2.k8s资源已raw格式输出

```ruby
kubectl get --raw /api/v1/namespaces/cpaas-system/pods/cpaas-elasticsearch-c6d48c6c6-bnv9v|jq
```

### 3.k8s-[yaml](https://so.csdn.net/so/search?q=yaml&spm=1001.2101.3001.7020)基础结构

```ruby
apiVersion: v1
kind: Node
metadata:
  name:
spec:
  name:
```

### 4.[CentOS7](https://so.csdn.net/so/search?q=CentOS7&spm=1001.2101.3001.7020).x升级内核

```ruby
[root@k8s7-200.host.com ~]# cat /etc/redhat-release 
CentOS Linux release 7.6.1810 (Core) 
[root@k8s7-200.host.com ~]# uname -r
3.10.0-957.el7.x86_64

 ~]# wget -O /etc/yum.repos.d/epel.repo https://mirrors.tencent.com/repo/epel-7.repo
 ~]# wget -O /etc/yum.repos.d/CentOS-Base.repo https://mirrors.tencent.com/repo/centos7_base.repo

~]# yum -y install yum-plugin-fastestmirror
~]# yum update -y

~]# rpm -Uvh https://www.elrepo.org/elrepo-release-7.0-3.el7.elrepo.noarch.rpm
~]# rpm -import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org

查看可用内核版本
~]# yum --disablerepo="*" --enablerepo="elrepo-kernel" list available

安装最新版本内核 5.13.0-1.el7.elrepo
~]# yum -y --enablerepo=elrepo-kernel install kernel-ml.x86_64 kernel-ml-devel.x86_64

查看启动器
~]# awk -F\' '$1=="menuentry " {print i++ " : " $2}' /etc/grub2.cfg
0 : CentOS Linux (5.13.0-1.el7.elrepo.x86_64) 7 (Core)
1 : CentOS Linux (3.10.0-1160.31.1.el7.x86_64) 7 (Core)
2 : CentOS Linux (3.10.0-957.el7.x86_64) 7 (Core)
3 : CentOS Linux (0-rescue-7d3920cb5d75497a8862dd8e8e5e1c85) 7 (Core)

设置默认启动内核---0后边内核为我们设置的内核
~]# grub2-set-default 0


查看内核版本默认启动顺序---确保第一个是我们设置的内核
~]# awk -F\' '$1=="menuentry " {print $2}' /etc/grub2.cfg
CentOS Linux (5.13.0-1.el7.elrepo.x86_64) 7 (Core)
CentOS Linux (3.10.0-1160.31.1.el7.x86_64) 7 (Core)
CentOS Linux (3.10.0-957.el7.x86_64) 7 (Core)
CentOS Linux (0-rescue-7d3920cb5d75497a8862dd8e8e5e1c85) 7 (Core)

在各节点执行---重启系统
 ~]# reboot

重启后查看内核：uname -r  是否为我们设置的内核
~]# uname -r
5.13.0-1.el7.elrepo.x86_64	#升级成功！！！
```
