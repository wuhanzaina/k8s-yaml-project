# 使用K8s Ingress暴露PetClinic微服务

---

* [https://yinwu.blog.csdn.net/article/details/110008037](https://yinwu.blog.csdn.net/article/details/110008037?spm=1001.2014.3001.5502)

---

### 文章目录

* [1.Ingress Controller](#1Ingress_Controller_3)
* [2.安装Nginx Ingress Controller](#2Nginx_Ingress_Controller_5)
* [3.本地发布Nginx IngressController](#3Nginx_IngressController_8)
* [4.校验部署](#4_27)
* [5.架构设计](#5_29)
* [6.发布PetClinic微服务](#6PetClinic_31)
* [7.通过NodePort校验PetClinic微服务](#7NodePortPetClinic_33)
* [8.Ingress发布文件](#8Ingress_36)
* [9.发布Ingress暴露PetClinic微服务](#9IngressPetClinic_38)
* [10.查看Ingress详情](#10Ingress_40)
* [11.校验通过Ingress访问vet微服务](#11Ingressvet_42)
* [12.校验通过Ingress访问customer微服务](#12Ingresscustomer_44)
* [13.总结](#13_46)

 K8S安装Ingress参考文档1：  
[https://blog.csdn.net/chengyinwu/article/details/107828778](https://blog.csdn.net/chengyinwu/article/details/107828778)

 K8S安装Ingress参考文档2：  
[https://blog.csdn.net/chengyinwu/article/details/103533061](https://blog.csdn.net/chengyinwu/article/details/103533061)

### 1.Ingress Controller

官方文档：[https://kubernetes.io/docs/concepts/services-networking/ingress-controllers/](https://kubernetes.io/docs/concepts/services-networking/ingress-controllers/)

### 2.安装[Nginx](https://so.csdn.net/so/search?q=Nginx&spm=1001.2101.3001.7020) Ingress Controller

官方文档：[https://kubernetes.github.io/ingress-nginx/deploy/](https://kubernetes.github.io/ingress-nginx/deploy/)  
 Github地址：[https://github.com/kubernetes/ingress-nginx/](https://github.com/kubernetes/ingress-nginx/)

### 3.本地发布Nginx IngressController

```sql
注意注意~
参考此文档：https://github.com/kubernetes/ingress-nginx/blob/nginx-0.30.0/docs/deploy/index.md

[root@k8s7-22.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch06/01/ingress-nginx/mandatory.yaml
namespace/ingress-nginx created
configmap/nginx-configuration created
configmap/tcp-services created
configmap/udp-services created
serviceaccount/nginx-ingress-serviceaccount created
clusterrole.rbac.authorization.k8s.io/nginx-ingress-clusterrole created
role.rbac.authorization.k8s.io/nginx-ingress-role created
rolebinding.rbac.authorization.k8s.io/nginx-ingress-role-nisa-binding created
clusterrolebinding.rbac.authorization.k8s.io/nginx-ingress-clusterrole-nisa-binding created
deployment.apps/nginx-ingress-controller created
limitrange/ingress-nginx created
```

![在这里插入图片描述](assets/20201124161500595-20221008134753-3385uhv.png)​

### 4.校验部署

![在这里插入图片描述](assets/20201124161757203-20221008134753-umudqw8.png)​

### 5.[架构](https://so.csdn.net/so/search?q=%E6%9E%B6%E6%9E%84&spm=1001.2101.3001.7020)设计

![在这里插入图片描述](assets/20201123212730721-20221008134753-5u028jb.png)​

### 6.发布PetClinic[微服务](https://so.csdn.net/so/search?q=%E5%BE%AE%E6%9C%8D%E5%8A%A1&spm=1001.2101.3001.7020)

![在这里插入图片描述](assets/20201124161846710-20221008134753-gqne7zb.png)​

### 7.通过NodePort校验PetClinic微服务

![在这里插入图片描述](assets/20201124162134276-20221008134753-prq8civ.png)​

### 8.Ingress发布文件

![在这里插入图片描述](assets/20201123212846195-20221008134753-h102o73.png)​

### 9.发布Ingress暴露PetClinic微服务

`[root@k8s7-22.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch06/01/ingress.yaml`

### 10.查看Ingress详情

![在这里插入图片描述](assets/20201124164258177-20221008134753-a01is4j.png)​

### 11.校验通过Ingress访问vet微服务

![在这里插入图片描述](assets/20201124181450116-20221008134753-q4icw87.png)​

### 12.校验通过Ingress访问customer微服务

![在这里插入图片描述](assets/20201124181509726-20221008134753-kr7inor.png)​

### 13.总结

![在这里插入图片描述](assets/20201124181550962-20221008134753-u1lmi35.png)​
