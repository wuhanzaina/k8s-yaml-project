# harbor配置nginx代理

---

* [https://blog.csdn.net/lcl_xiaowugui/article/details/105422794](https://blog.csdn.net/lcl_xiaowugui/article/details/105422794)

---

从前面的文章harbor搭建[docker](https://so.csdn.net/so/search?q=docker&spm=1001.2101.3001.7020)私有镜像仓库可以看出harbor默认只能使用`harbor.yml`中hostname指定的ip或[主机名](https://so.csdn.net/so/search?q=%E4%B8%BB%E6%9C%BA%E5%90%8D&spm=1001.2101.3001.7020)作为web访问地址，但在实际使用过程中，一般不允许ip地址或者主机名直接暴露在外访问，故需要配置nginx代理，通过代理后指定的地址进行访问。

---

### 一、设置原理

* 通过nginx为harbor后端暴露的地址及端口设置proxy地址，来源于harbor配置文件中的hostname及port
* 修改harbor配置文件再次使用nginx设置的proxy地址

---

### 二、[Nginx](https://so.csdn.net/so/search?q=Nginx&spm=1001.2101.3001.7020)代理

​ 通过修改nginx的配置文件中server模块设置代理地址以及端口等信息，若harbor与nginx不在同一个服务器上或harbor不止一个服务器，还需要通过nginx的upstream模块来实现请求后端realserver及负载均衡，nginx配置文件修改处示例如下：

```bash
## 设置upstream
upstream harbor{ 
    server x.x.x.x:xx;			# 后端harbor地址
}
## 设置代理后地址及监听端口等
server { 
    listen 80;		# 代理后端口
    server_name xx.xx.com;		# 代理后访问地址

    location /harbor { 
        proxy_pass http://harbor;			# 这里对应的是上面upstream后指定的名称
     }
}
```

---

### 三、Harbor设置

​ 通过nginx配置了代理之后，还需要修改harbor的配置文件设置proxy地址：

```yaml
[root@xxxx harbor]# vim harbor.yml
# Uncomment external_url if you want to enable external proxy
# And when it enabled the hostname will no longer used
## 打开该项配置，这里对应着nginx所设置的代理后访问地址
external_url: http://xx.xx.com
```

---

### 四、Web验证

​ 通过浏览器访问`http://xx.xx.com:port`访问代理后地址，这里因为nginx代理后使用了80端口，所以不需要写明端口。  
 ​![在这里插入图片描述](assets/20200409230211159-20220926104045-vcdxbpe.png)​ ​

​ 至此，harbor配置nginx代理设置成功！
