# 滚动发布抽象～Deployment原理剖析

---

* [https://yinwu.blog.csdn.net/article/details/109695058](https://yinwu.blog.csdn.net/article/details/109695058?spm=1001.2014.3001.5502)

---

### 文章目录

* [1.何谓滚动发布Rolling Update](#1Rolling_Update_1)

  * [2.蓝绿 vs 滚动发布](#2_vs__4)
  * [3.K8s发布抽象Deployment](#3K8sDeployment_6)
  * [4.Deployment滚动发布](#4Deployment_9)
  * [5.Deployment发布规范样例](#5Deployment_12)
  * [6.PetClinic的Deployment发布规范](#6PetClinicDeployment_15)
  * [7.PetClinic的Service发布规范](#7PetClinicService_18)
  * [8.发布PetClinic Deployment和Service](#8PetClinic_DeploymentService_21)
  * [9.校验PetClinic应用V1.0.0](#9PetClinicV100_29)
  * [10.更新PetClinic的Deployment发布规范](#10PetClinicDeployment_31)
  * [11.滚动发布PetClinic V1.0.1](#11PetClinic_V101_33)
  * [12.滚动发布结束](#12_38)
  * [13.查看发布历史](#13_40)
  * [14.校验PetClinic应用V1.0.1](#14PetClinicV101_42)
  * [15.回滚发布](#15_44)
  * [16.校验PetClinic应用回退到V1.0.0](#16PetClinicV100_46)
  * [17.指定回退版本](#17_48)
  * [18.总结](#18_52)

### 1.何谓滚动发布Rolling Update

一种高级发布策略，按批次依次替换老版本，逐步升级到新版本。发布过程中，应用不中断，用户体验平滑。  
 ![在这里插入图片描述](assets/2020111419214141-20221008134825-1voayyp.png)​

### 2.蓝绿 vs 滚动发布

![在这里插入图片描述](assets/20201114192258265-20221008134825-cwb86f0.png)​

### 3.K8s发布抽象Deployment

Deployment可以理解为是一种滚动发布方式，它是在ReplicaSet基础上进行了一次包装  
 ![在这里插入图片描述](assets/20201114194032148-20221008134825-dnctnn7.png)​

### 4.Deployment滚动发布

假设ReplicaSet v1.0.0对应的3个pod已经发布，然后通过Deployment进行滚动发布，升级至v1.0.1，这个过程中等到蓝色部分的pod逐步上线之后，对应的绿色pod会慢慢消失，当然Deployment始终会保证有Pod在运行，服务不中断，另外前置的Service抽象会屏蔽掉内部Pod具体的变化，让Client端对整个发布无感知，如果蓝色Pod有问题，健康检查不通过，这时Deployment会终止本次更新，Deployment抽象的引入，把滚动发布机制给封装与自动化了  
 ![在这里插入图片描述](assets/20201114194244980-20221008134825-e6hqcjc.png)​

### 5.Deployment发布规范样例

官方地址：[https://kubernetes.io/docs/concepts/workloads/controllers/deployment/](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/)  
 ![在这里插入图片描述](assets/20201114195131578-20221008134825-xdddobu.png)​

### 6.PetClinic的Deployment发布规范

![在这里插入图片描述](assets/20201114200444159-20221008134825-ynalwju.png)​

### 7.PetClinic的Service发布规范

![在这里插入图片描述](assets/20201114200046933-20221008134825-ckftpgj.png)​

### 8.发布PetClinic Deployment和Service

```sql
[root@k8s7-22.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch05/07/petclinic-dp.yaml
deployment.apps/petclinic created
[root@k8s7-22.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch05/07/petclinic-svc.yaml
service/petclinic created
```

![在这里插入图片描述](assets/20201114200625867-20221008134825-ohyhb4g.png)​

### 9.校验PetClinic应用V1.0.0

![在这里插入图片描述](assets/20201114200722586-20221008134825-7oooj18.png)​

### 10.更新PetClinic的Deployment发布规范

![在这里插入图片描述](assets/20201114200831747-20221008134825-82u7nfn.png)​

### 11.滚动发布PetClinic V1.0.1

```sql
[root@k8s7-22.host.com ~]# kubectl apply -f http://k8s-yaml.od.com/k8s-msa-in-action/ch05/07/petclinic-dp.yaml
deployment.apps/petclinic configured
```

### 12.滚动发布结束

![在这里插入图片描述](assets/20201114201043258-20221008134825-2hv00qi.png)​

### 13.查看发布历史

![在这里插入图片描述](assets/20201114201205922-20221008134825-mnibt1l.png)​

### 14.校验PetClinic应用V1.0.1

![在这里插入图片描述](assets/20201114201232518-20221008134825-f7awrtc.png)​

### 15.回滚发布

![在这里插入图片描述](assets/20201114201448905-20221008134825-jz9qjli.png)​

### 16.校验PetClinic应用回退到V1.0.0

![在这里插入图片描述](assets/20201114201518240-20221008134825-0et8yeu.png)​

### 17.指定回退版本

![在这里插入图片描述](assets/20201114201733715-20221008134825-6w7yu9j.png)  
 浏览器访问验证是否已更新至v1.0.1

### 18.总结

![在这里插入图片描述](assets/20201114201928477-20221008134825-lg2ur8l.png)​
