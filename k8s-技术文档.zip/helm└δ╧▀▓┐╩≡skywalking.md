# helm离线部署skywalking

---

* [https://www.jianshu.com/p/f029fdd2acab](https://www.jianshu.com/p/f029fdd2acab)

---

## 1.  chart

## 1.1 下载

下载地址：

[https://github.com/apache/skywalking-kubernetes/releases/tag/v3.0.0](https://links.jianshu.com/go?to=https%3A%2F%2Fgithub.com%2Fapache%2Fskywalking-kubernetes%2Freleases%2Ftag%2Fv3.0.0)

## 1.2 修改配置

> values.yaml文件中可以看到，一共是三个服务：
>
> * oap：skywalking的server
> * ui：提供web界面
> * elasticsearch
>

根据情况修改values.yaml文件，示例如下：

### 1.2.1 oap

* 修改内网镜像

```yml
oap:
  name: oap
  image:
    repository: harbocto.boe.com.cn/public/skywalking-oap-server
    #repository: apache/skywalking-oap-server
    tag: 8.0.1-es7
    pullPolicy: IfNotPresent
```

* 资源限制

```yml
  resources:
     limits:
       cpu: 8
       memory: 8Gi
     requests:
       cpu: 4
       memory: 4Gi
```

### 1.2.2 ui

* 修改镜像

```yml
  image:
    repository: harbocto.boe.com.cn/public/skywalking-ui
    #repository: apache/skywalking-ui
```

* 修改service

> 修改type为NodePort，添加nodePort
>

```yml
  service:
    #type: ClusterIP
    type: NodePort
    # clusterIP: None
    externalPort: 80
    internalPort: 8080
    nodePort: 30036
```

### 1.2.3 ES

* 修改账号密码

```yml
  config:
   ......
    user: "liubei"         # [optional]
    password: "liubei@2021"     # [optional]
```

* 修改内网镜像

```yml
image: "harxxx.xxx.com.cn/public/elasticsearch"
```

## 2. 镜像：

* 提前下载如下四个镜像：

> apache/skywalking-oap-server:8.0.1-es7
>
> apache/skywalking-ui:8.0.1
>
> docker.elastic.co/elasticsearch/elasticsearch
>
> busybox:1.30
>

* 前三个镜像

  修改成我们前边在 values.yml 中对应的镜像名，并上传到私有镜像仓库。
* busybox镜像

  没有在chart文件中找到这个配置，只好修改镜像名推到私有harbor，然后在每个node节点下载该镜像，最后把镜像名改回busybox:1.30

## 3.部署

* 部署如下：

```shell
[root@DoM01 skywalking]# helm install skywalking ./ -n skywalking
NAME: skywalking
LAST DEPLOYED: Tue Mar 23 15:28:25 2021
NAMESPACE: skywalking
STATUS: deployed
REVISION: 3
NOTES:
************************************************************************
*                                                                      *
*                 SkyWalking Helm Chart by SkyWalking Team             *
*                                                                      *
************************************************************************

Thank you for installing skywalking.

Your release is named skywalking.

Learn more, please visit https://skywalking.apache.org/

Get the UI URL by running these commands:
  export NODE_PORT=$(kubectl get --namespace skywalking -o jsonpath="{.spec.ports[0].nodePort}" services skywalking-ui)
  export NODE_IP=$(kubectl get nodes --namespace skywalking -o jsonpath="{.items[0].status.addresses[0].address}")
  echo http://$NODE_IP:$NODE_PORT
#################################################################################
######   WARNING: Persistence is disabled!!! You will lose your data when   #####
######            the SkyWalking's storage ES pod is terminated.            #####
#################################################################################

```

* 查看结果：

```shell
[root@DoM01 skywalking]# kubectl get pod -n skywalking
NAME                              READY   STATUS      RESTARTS   AGE
elasticsearch-master-0            1/1     Running     0          99s
elasticsearch-master-1            1/1     Running     0          99s
elasticsearch-master-2            1/1     Running     0          99s
skywalking-es-init-8cqmt          0/1     Completed   0          99s
skywalking-oap-6549899c78-7cn42   1/1     Running     0          99s
skywalking-oap-6549899c78-x8lwb   1/1     Running     0          99s
skywalking-ui-764b7c6444-kpknc    1/1     Running     0          99s

```
