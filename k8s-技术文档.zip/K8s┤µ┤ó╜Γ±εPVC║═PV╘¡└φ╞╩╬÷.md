# K8s存储解耦PVC和PV原理剖析

---

* [https://yinwu.blog.csdn.net/article/details/109811300](https://yinwu.blog.csdn.net/article/details/109811300?spm=1001.2014.3001.5502)

---

### 文章目录

* [1.PV和PVC](#1PVPVC_1)
* [2.准备资源配置清单](#2_10)
* [3.应用资源配置清单](#3_129)
* [4.检查PV与PVC](#4PVPVC_131)
* [5.浏览器校验](#5_133)
* [6.tmp/data02目录下生成mysql和petclinic数据文件](#6tmpdata02mysqlpetclinic_135)
* [7.删除并重启mysql pod](#7mysql_pod_137)
* [8.浏览器校验仍然成功](#8_139)
* [9.总结](#9_143)

### 1.PV和PVC

官方文档：[https://kubernetes.io/docs/concepts/storage/persistent-volumes/](https://kubernetes.io/docs/concepts/storage/persistent-volumes/)  
 为了解决Pod与存储卷的耦合问题，K8S引入了PVC与PV的抽象概念来进行解耦。  
 PersistentVolumeClaim持久卷申请，简称PVC；  
 PersistentVolume持久卷，简称PV；  
 ![在这里插入图片描述](assets/20201119143135126-20221008134805-mu7iap7.png)  
 （1）通过引入PVC，开发人员在发布文件Volume中可以直接引用持久卷申请PVC，可以理解为是一种存储规范，例如存储容量大小，存储模式等等，但是它不规范存储过程中的细节；另一方面，K8S集群管理员可以预先为不同环境的集群定制不同的PV，底层可对接各种不同的存储，运行时PV与PVC将通过存储类别/Label进行绑定，让PVC能够具体的和后端某种存储进行关联对接，PVC还可与存储类进行绑定，Storage Class它是一种高级的存储定制分类机制，一般由管理员与供应商提供，PVC与PV的绑定称之为“静态绑定”，PVC与SC的绑定称之为“动态绑定”。  
 （2）引入PVC的好处是它让Volume和具体的持久化存储实现进行了解耦操作，提供了灵活性和可移植性，使应用发布可以在不同环境中进行灵活迁移，另一方面它的引入还实现了职责分离，Volume和PVC一般由Pod开发人员定义，只需要提出存储需求，不关心具体实现，而PV和SC一般由K8S集群管理员定制提供，它无需关注应用的发布形式

### 2.准备资源配置清单

```sql
[root@k8s7-200.host.com /data/k8s-yaml/k8s-msa-in-action/ch07/02]# cat local-pv.yaml 
apiVersion: v1
kind: PersistentVolume
metadata:
  name: local-pv
spec:
  storageClassName: standard
  capacity:
    storage: 300Mi
  accessModes:
    - ReadWriteOnce
  hostPath:
    path: "/tmp/data02"
    type: DirectoryOrCreate
[root@k8s7-200.host.com /data/k8s-yaml/k8s-msa-in-action/ch07/02]# cat mysql-pvc.yaml 
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: mysql-pvc
spec:
  storageClassName: standard
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 300Mi

[root@k8s7-200.host.com /data/k8s-yaml/k8s-msa-in-action/ch07/02]# cat mysql-dp.yaml 
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mysql
spec:
  selector:
    matchLabels:
      app: mysql
  replicas: 1
  template:
    metadata:
      labels:
        app: mysql
    spec:
      containers:
        - name: mysql
          image: harbor.od.com/bobo/mysql:5.7.30
          env:
            - name: MYSQL_ROOT_PASSWORD
              value: petclinic
            - name: MYSQL_DATABASE
              value: petclinic
          volumeMounts:
            - name: mysql-persistent-volume
              mountPath: /var/lib/mysql
      volumes:
        - name: mysql-persistent-volume
          persistentVolumeClaim:
            claimName: mysql-pvc

[root@k8s7-200.host.com /data/k8s-yaml/k8s-msa-in-action/ch07/02]# cat mysql-svc.yaml 
apiVersion: v1
kind: Service
metadata:
  name: mysql
spec:
  selector:
    app: mysql
  ports:
    - name: tcp
      port: 3306
      targetPort: 3306
  type: ClusterIP

[root@k8s7-200.host.com /data/k8s-yaml/k8s-msa-in-action/ch07/02]# cat petclinic-dp.yaml 
apiVersion: apps/v1
kind: Deployment
metadata:
  name: petclinic
spec:
  selector:
    matchLabels:
      app: petclinic
  replicas: 1
  template:
    metadata:
      labels:
        app: petclinic
    spec:
      containers:
        - name: petclinic
          image: harbor.od.com/bobo/spring-petclinic:1.0.1.RELEASE
          env:
            - name: SPRING_PROFILES_ACTIVE
              value: mysql
            - name: DATASOURCE_URL
              value: jdbc:mysql://mysql/petclinic
            - name: DATASOURCE_USERNAME
              value: root
            - name: DATASOURCE_PASSWORD
              value: petclinic
            - name: DATASOURCE_INIT_MODE
              value: always
[root@k8s7-200.host.com /data/k8s-yaml/k8s-msa-in-action/ch07/02]# cat petclinic-svc.yaml 
apiVersion: v1
kind: Service
metadata:
  name: petclinic
spec:
  ports:
    - name: http
      port: 8080
      targetPort: 8080
      nodePort: 3665
  selector:
    app: petclinic
  type: NodePort

```

### 3.应用资源配置清单

![在这里插入图片描述](assets/2020111915065710-20221008134805-nk6od7l.png)​

### 4.检查PV与PVC

![在这里插入图片描述](assets/20201119150809157-20221008134805-vihskfn.png)​

### 5.浏览器校验

![在这里插入图片描述](assets/20201119150922982-20221008134805-xieum8f.png)​

### 6.tmp/data02目录下生成mysql和petclinic数据文件

![在这里插入图片描述](assets/20201119151008966-20221008134805-4f7v0xj.png)​

### 7.删除并重启mysql pod

![在这里插入图片描述](assets/20201119151125343-20221008134805-zkr54ng.png)​

### 8.浏览器校验仍然成功

![在这里插入图片描述](assets/20201119151231423-20221008134805-ic9n8k7.png)​

> var/lib/mysql表和数据都存在
>

### 9.总结

（1）PersistentVolumeClaim(PVC)是K8s支持的一种存储解耦机制，PVC在Volume和PV之间引入了一层间接。  
（2）PersistentVolume(PV)是K8s支持的持久化存储抽象，底层可以对接各种物理存储机制。  
（3）Pod -> Volume -> PVC -> PV -> 物理存储  
 Pod可以关联Volume，Pod容器可以挂载Volume，Volume可以对接引用PVC，接着PVC可以绑定到PV，PV可以对接具体的物理存储，最最核心的是PVC，它的引入使Volume和具体的持久化存储之间实现了解耦与职责分离
