# kubectl命令自动补全

---

* [https://yinwu.blog.csdn.net/article/details/119983349](https://yinwu.blog.csdn.net/article/details/119983349?spm=1001.2014.3001.5502)

---

### 

### 1.安装bash-completion工具

```ruby
[root@k8s-master01 ~]# yum install bash-completion -y
否则报错：
-bash: _get_comp_words_by_ref: command not found
```

### 2.执行bash_completion

```sql
[root@k8s-master01 ~]# source /usr/share/bash-completion/bash_completion
```

### 3.加载kubectl completion

```sql
[root@k8s-master01 ~]# source <(kubectl completion bash)

# 在 bash 中设置当前 shell 的自动补全，要先安装 bash-completion 包。
[root@k8s-master01 ~]# echo "source <(kubectl completion bash)" >> ~/.bashrc

# 在您的 bash shell 中永久的添加自动补全

测试：
[root@k8s-master01 ~]# kubectl ex
exec     explain  expose
[root@k8s-master01 ~]# kubectl explain pod.spec
```

### 4.node打标签

```bash
添加
kubectl label nodes kube-node label_name=label_value	#node节点名称
kubectl label nodes 1.1.1.1 label_name=label_value		#node节点IP
 

查询
kubectl get node -a -l "node=kube-node"
 
删除一个Label，只需在命令行最后指定Label的key名并与一个减号相连即可：
$ kubectl label nodes 1.1.1.1 role- 

修改一个Label的值，需要加上--overwrite参数：
$ kubectl label nodes 1.1.1.1 role=apache --overwrite

或者你可以直接kubectl edit 就可以编辑这个node 的配置，保存退出就可以了！
```
