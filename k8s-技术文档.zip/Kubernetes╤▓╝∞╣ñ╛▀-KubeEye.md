# Kubernetes巡检工具-KubeEye

---

* [https://www.modb.pro/db/78835](https://www.modb.pro/db/78835)

---

![](assets/modb_20210705_fc579132-dd68-11eb-820b-00163e068ecd-20220917195931-7u0s6qp.png)​

## 1 你还在为这些问题烦恼吗？

* 集群组件不健康
* 节点 NotReady
* ETCD 健康状况
* 磁盘损坏问题
* 应用容器配置 request、limit
* Pod 各种问题起不来
* 证书即将过期
* Docker 服务异常
* 存储空间不足
* yaml文件语法

## 2 只需三步解除你的烦恼

#### 2.1 确保 ~/.kube/config 有效

#### 2.2 下载KubeEye

`curl -s https://experimental.sh1a.qingstor.com/v1.1.0/KubeEye-v0.1.0-linux-amd64.tar.gz | tar -xzv`

#### 2.3 开始体检你的 Kubernetes 集群

```
./ke diagroot@node1:# ./ke diag
NODENAME        SEVERITY   HEARTBEATTIME               REASON               MESSAGE
node18          Fatal      2020-11-19T10:32:03+08:00   NodeStatusUnknown    Kubelet stopped posting node status.
node3           Fatal      2020-11-27T17:36:53+08:00   KubeletNotReady      Container runtime not ready: RuntimeReady=false reason:DockerDaemonNotReady message:docker: failed to get docker version: Cannot connect to the Docker daemon at unix:///var/run/docker.sock. Is the docker daemon running?NAME            SEVERITY   TIME                        MESSAGE
scheduler       Fatal      2020-11-27T17:09:59+08:00   Get http://127.0.0.1:10251/healthz: dial tcp 127.0.0.1:10251: connect: connection refused
etcd-0          Fatal      2020-11-27T17:56:37+08:00   Get https://192.168.13.8:2379/health: dial tcp 192.168.13.8:2379: connect: connection refusedNAMESPACE       SEVERITY   PODNAME                                          EVENTTIME                   REASON                MESSAGE
default         Warning    node3.164b53d23ea79fc7                           2020-11-27T17:37:34+08:00   ContainerGCFailed     rpc error: code = Unknown desc = Cannot connect to the Docker daemon at unix:///var/run/docker.sock. Is the docker daemon running?
default         Warning    node3.164b553ca5740aae                           2020-11-27T18:03:31+08:00   FreeDiskSpaceFailed   failed to garbage collect required amount of images. Wanted to free 5399374233 bytes, but freed 416077545 bytes
default         Warning    nginx-b8ffcf679-q4n9v.16491643e6b68cd7           2020-11-27T17:09:24+08:00   Failed                Error: ImagePullBackOff
default         Warning    node3.164b5861e041a60e                           2020-11-27T19:01:09+08:00   SystemOOM             System OOM encountered, victim process: stress, pid: 16713
default         Warning    node3.164b58660f8d4590                           2020-11-27T19:01:27+08:00   OOMKilling            Out of memory: Kill process 16711 (stress) score 205 or sacrifice child Killed process 16711 (stress), UID 0, total-vm:826516kB, anon-rss:819296kB, file-rss:0kB, shmem-rss:0kB
kube-system     Warning    calico-node-zvl9t.164b3dc50580845d               2020-11-27T17:09:35+08:00   DNSConfigForming      Nameserver limits were exceeded, some nameservers have been omitted, the applied nameserver line is: 100.64.11.3 114.114.114.114 119.29.29.29NAMESPACE       SEVERITY   NAME                        KIND                 TIME                        MESSAGE
kube-system     Warning    calico-node                 DaemonSet            2020-11-27T17:09:59+08:00   [runAsPrivileged cpuLimitsMissing]
kube-system     Warning    nodelocaldns                DaemonSet            2020-11-27T17:09:59+08:00   [cpuLimitsMissing runAsPrivileged]
default         Warning    nginx                       Deployment           2020-11-27T17:09:59+08:00   [cpuLimitsMissing livenessProbeMissing tagNotSpecified]
kube-system     Warning    calico-kube-controllers     Deployment           2020-11-27T17:09:59+08:00   [cpuLimitsMissing livenessProbeMissing]
kube-system     Warning    coredns                     Deployment           2020-11-27T17:09:59+08:00   [cpuLimitsMissing]登录后复制
```

更多功能指令方式，可以执行 ./ke -h 查看。

## 3 附件

* KubeEye Github链接

`https://github.com/kubesphere/kubeeye`

* KubeEye架构图

![](assets/modb_20210705_fca7e81c-dd68-11eb-820b-00163e068ecd-20220917195931-a6k9hjr.png)​
