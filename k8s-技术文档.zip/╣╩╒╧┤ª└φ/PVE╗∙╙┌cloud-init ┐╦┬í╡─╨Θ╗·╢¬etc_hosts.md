# PVE基于cloud-init 克隆的虚机丢etc_hosts

2022-10-28  因为断电重启， 发现测试环境没有自动恢复 ， 发现如下问题：

1. 开发测试环境中部分虚拟机通过dhcp获取ip的有ip丢失的情况，改为手动分配ip
2. PVE基于cloud-init 克隆的虚机丢etc_hosts

    ```bash
    cat /etc/cloud/cloud.cfg
    users:
     - default

    disable_root: 1
    ssh_pwauth:   0

    mount_default_fields: [~, ~, 'auto', 'defaults,nofail,x-systemd.requires=cloud-init.service', '0', '2']
    resize_rootfs_tmp: /dev
    ssh_deletekeys:   1
    ssh_genkeytypes:  ~
    syslog_fix_perms: ~
    disable_vmware_customization: false

    cloud_init_modules:
     - disk_setup
     - migrator
     - bootcmd
     - write-files
     - growpart
     - resizefs
     - set_hostname
     - update_hostname
    # - update_etc_hosts
     - rsyslog
     - users-groups
     - ssh

    cloud_config_modules:
     - mounts
     - locale
     - set-passwords
     - rh_subscription
     - yum-add-repo
     - package-update-upgrade-install
     - timezone
     - puppet
     - chef
     - salt-minion
     - mcollective
     - disable-ec2-metadata
     - runcmd

    cloud_final_modules:
     - rightscale_userdata
     - scripts-per-once
     - scripts-per-boot
     - scripts-per-instance
     - scripts-user
     - ssh-authkey-fingerprints
     - keys-to-console
     - phone-home
     - final-message
     - power-state-change

    system_info:
      default_user:
        name: centos
        lock_passwd: true
        gecos: Cloud User
        groups: [adm, systemd-journal]
        sudo: ["ALL=(ALL) NOPASSWD:ALL"]
        shell: /bin/bash
      distro: rhel
      paths:
        cloud_dir: /var/lib/cloud
        templates_dir: /etc/cloud/templates
      ssh_svcname: sshd

    # vim:syntax=yaml
    ```
3. ks集群没法正常访问,原因就是受PVE的cloud-init影响, 两个办法

    * 将下面的hosts配置保存到`/etc/cloud/template/hosts.redhat.tmp`

    ```bash
    192.168.52.241 lb.kubesphere.local
    192.168.52.241 k8s-master1
    192.168.52.242 k8s-node1
    192.168.52.243 k8s-node2
    ```

    将 `/etc/cloud/cloud.cfg`中`update_etc_host`注释掉
4.
