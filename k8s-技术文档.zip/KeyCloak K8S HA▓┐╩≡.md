# KeyCloak K8S HA部署

---

* [https://blog.csdn.net/canghaiguzhou/article/details/108587511](https://blog.csdn.net/canghaiguzhou/article/details/108587511)

---

## 0、win10 PowerShell安装K8S管理工具

在本机PowerShell安装k8s管理工具，用它来远程管理k8s集群

> choco install [kubernetes](https://so.csdn.net/so/search?q=kubernetes&spm=1001.2101.3001.7020)-cli
>

## 1、安装HELM3（win10）

安装helm,其他平台请参见helm官网：[https://helm.sh/docs/intro/install/](https://helm.sh/docs/intro/install/)

> choco install kubernetes-helm
>

## 2、设置repo

添加keycloak的helm repo，有时候偶尔网络不好可能不会添加成功，多添加几次就好了。

> helm repo add codecentric https://codecentric.github.io/helm-charts
>

## 3、安装keycloak

参考：keycloak repo github地址：[https://github.com/codecentric/helm-charts/tree/master/charts/keycloak](https://github.com/codecentric/helm-charts/tree/master/charts/keycloak)  
keycloak chart提供了许多配置项：通过提供values.yml配置实现高可用，参考keycloak repo github与keycloak官网说明，使用dns_ping, 提供keyCloakConfig.yaml作为values.yml, 内容如下:

```
postgresql:
  # Disable PostgreSQL dependency
  enabled: false

replicas: 3  

startupScripts:
  # cli script that reconfigures WildFly
  contextPath.cli: |
    embed-server --server-config=standalone-ha.xml --std-out=echo
    batch
    /subsystem=infinispan/cache-container=keycloak/distributed-cache=sessions:write-attribute(name=owners, value=${env.CACHE_OWNERS:2})
    /subsystem=infinispan/cache-container=keycloak/distributed-cache=authenticationSessions:write-attribute(name=owners, value=${env.CACHE_OWNERS:2})
    /subsystem=infinispan/cache-container=keycloak/distributed-cache=offlineSessions:write-attribute(name=owners, value=${env.CACHE_OWNERS:2})
    /subsystem=infinispan/cache-container=keycloak/distributed-cache=loginFailures:write-attribute(name=owners, value=${env.CACHE_OWNERS:2})
  
    echo Configuring node identifier

    ## Sets the node identifier to the node name (= pod name). Node identifiers have to be unique. They can have a
    ## maximum length of 23 characters. Thus, the chart's fullname template truncates its length accordingly.
    /subsystem=transactions:write-attribute(name=node-identifier, value=${jboss.node.name})
  
    echo Finished configuring node identifier
    run-batch

    stop-embedded-server

service:
  type: NodePort

ingress:
  enabled: true



extraEnv: |
  - name: JGROUPS_DISCOVERY_PROTOCOL
    value: dns.DNS_PING
  - name: JGROUPS_DISCOVERY_PROPERTIES
    value: 'dns_query={ { include "keycloak.serviceDnsName" . }}'
  - name: CACHE_OWNERS
    value: "3"
  - name: CACHE_OWNERS_AUTH_SESSIONS
    value: "3"
  - name: KEYCLOAK_USER
    value: admin
  - name: KEYCLOAK_PASSWORD
    value: admin
  - name: DB_VENDOR
    value: postgres
  - name: DB_ADDR
    value: xxx.xxx.xxx.xxx
  - name: DB_PORT
    value: "5432"
  - name: DB_DATABASE
    value: keycloak
  - name: DB_USER
    value: username
  - name: DB_PASSWORD
    value: password  
```

注意：replicas要与CACHE_OWNERS、CACHE_OWNERS_AUTH_SESSIONS 保持一致，然后helm安装keycloak chart:

> helm install keycloak codecentric/keycloak -n keycloak --version=9.0.4 --values keyCloakConfig.yaml
>

安装成功：  
 ![在这里插入图片描述](assets/20200916101512619-20220907201006-qpm1s4z.png)​

关键日志：  
 ![在这里插入图片描述](assets/20200916101840462-20220907201006-59y59np.png)​

![在这里插入图片描述](assets/20200916102010309-20220907201006-ig9g4qb.png)​

## 4、测试KeyCloak-HA

登录keycloak管理页面，按照下面次序分别测试：  
 杀掉keycloak-0,1 保留keycloak-2  
 杀掉keycloak1,2 保留keycloak-0  
 杀掉keycloak0,2 保留keycloak-1  
 以上三种情况应该都不影响已登录账号  
 说明keycloak-ha已成功安装！

## 5、不使用helm，直接使用K8S部署yaml

按照你自己的需要来修改

```yaml
apiVersion: v1
data:
  keycloak.cli: |
    embed-server --server-config=standalone-ha.xml --std-out=echo
    batch
    /subsystem=datasources/xa-data-source=ExampleXADS/:add(jndi-name=java:jboss/datasources/ExampleXADS,enabled=true,driver-name=postgresql)
    /subsystem=datasources/xa-data-source=ExampleXADS/xa-datasource-properties=URL/:add(value=jdbc:postgresql://pg-sit.demo-sit:5432/demo_oauth?characterEncoding\=utf8)
    /subsystem=infinispan/cache-container=keycloak/distributed-cache=sessions:write-attribute(name=owners, value=${env.CACHE_OWNERS:2})
    /subsystem=infinispan/cache-container=keycloak/distributed-cache=authenticationSessions:write-attribute(name=owners, value=${env.CACHE_OWNERS:2})
    /subsystem=infinispan/cache-container=keycloak/distributed-cache=offlineSessions:write-attribute(name=owners, value=${env.CACHE_OWNERS:2})
    /subsystem=infinispan/cache-container=keycloak/distributed-cache=loginFailures:write-attribute(name=owners, value=${env.CACHE_OWNERS:2})
  
    echo Configuring node identifier

    ## Sets the node identifier to the node name (= pod name). Node identifiers have to be unique. They can have a
    ## maximum length of 23 characters. Thus, the chart's fullname template truncates its length accordingly.
    /subsystem=transactions:write-attribute(name=node-identifier, value=${ jboss.node.name})
  
    echo Finished configuring node identifier
    run-batch

    stop-embedded-server

kind: ConfigMap
metadata:
  labels:
    app.kubernetes.io/instance: keycloak
    app.kubernetes.io/name: keycloak
    app.kubernetes.io/version: 15.0.0
  name: keycloak-startup
  namespace: demo-sit
---
apiVersion: v1
items:
- apiVersion: v1
  kind: Service
  metadata:
    labels:
      app.kubernetes.io/component: headless
      app.kubernetes.io/instance: keycloak
      app.kubernetes.io/name: keycloak
      app.kubernetes.io/version: 15.0.0
    name: keycloak-headless
    namespace: demo-sit
  spec:
    clusterIP: None
    ports:
    - name: http
      port: 80
      protocol: TCP
      targetPort: http
    selector:
      app.kubernetes.io/instance: keycloak
      app.kubernetes.io/name: keycloak
    sessionAffinity: None
    type: ClusterIP
  status:
    loadBalancer: { }
- apiVersion: v1
  kind: Service
  metadata:
    labels:
      app.kubernetes.io/component: http
      app.kubernetes.io/instance: keycloak
      app.kubernetes.io/name: keycloak
      app.kubernetes.io/version: 15.0.0
    name: keycloak-http
    namespace: demo-sit
  spec:
    externalTrafficPolicy: Cluster
    ports:
    - name: http
      port: 80
      protocol: TCP
      targetPort: http
      nodePort: 30180 
    - name: https
      port: 8443
      protocol: TCP
      targetPort: https
      nodePort: 30543
    - name: http-management
      port: 9990
      protocol: TCP
      targetPort: http-management
      nodePort: 31090
    selector:
      app.kubernetes.io/instance: keycloak
      app.kubernetes.io/name: keycloak
    sessionAffinity: None
    type: NodePort
  status:
    loadBalancer: { }
kind: List

---

apiVersion: v1
items:
- apiVersion: apps/v1
  kind: StatefulSet
  metadata:
    labels:
      app.kubernetes.io/instance: keycloak
      app.kubernetes.io/name: keycloak
      app.kubernetes.io/version: 15.0.0
    name: keycloak
    namespace: demo-sit
  spec:
    podManagementPolicy: Parallel
    replicas: 3
    revisionHistoryLimit: 10
    selector:
      matchLabels:
        app.kubernetes.io/instance: keycloak
        app.kubernetes.io/name: keycloak
    serviceName: keycloak-headless
    template:
      metadata:
        labels:
          app.kubernetes.io/instance: keycloak
          app.kubernetes.io/name: keycloak
      spec:
        affinity:
          podAntiAffinity:
            preferredDuringSchedulingIgnoredDuringExecution:
            - podAffinityTerm:
                labelSelector:
                  matchExpressions:
                  - key: app.kubernetes.io/component
                    operator: NotIn
                    values:
                    - test
                  matchLabels:
                    app.kubernetes.io/instance: keycloak
                    app.kubernetes.io/name: keycloak
                topologyKey: failure-domain.beta.kubernetes.io/zone
              weight: 100
            requiredDuringSchedulingIgnoredDuringExecution:
            - labelSelector:
                matchExpressions:
                - key: app.kubernetes.io/component
                  operator: NotIn
                  values:
                  - test
                matchLabels:
                  app.kubernetes.io/instance: keycloak
                  app.kubernetes.io/name: keycloak
              topologyKey: kubernetes.io/hostname
        containers:
        - env:
          - name: JGROUPS_DISCOVERY_PROTOCOL
            value: dns.DNS_PING
          - name: JGROUPS_DISCOVERY_PROPERTIES
            value: 'dns_query=keycloak-headless.demo-sit.svc.cluster.local'
          - name: CACHE_OWNERS
            value: "3"
          - name: CACHE_OWNERS_AUTH_SESSIONS
            value: "3"
          - name: KEYCLOAK_USER
            value: admin
          - name: KEYCLOAK_PASSWORD
            value: admin
          - name: DB_VENDOR
            value: postgres
          - name: DB_ADDR
            value: pg-sit.demo-sit
          - name: DB_PORT
            value: "5432"
          - name: DB_DATABASE
            value: keycloak
          - name: DB_USER
            value: demo_ddl_user
          - name: DB_PASSWORD
            value: xxxxxxx
          - name: PROXY_ADDRESS_FORWARDING
            value: "true"
          - name: TZ         
            value: Asia/Shanghai
          image: xx.xx.xx.xx/baseimages/keycloak:15.0.0
          imagePullPolicy: IfNotPresent
          livenessProbe:
            failureThreshold: 3
            httpGet:
              path: /auth/
              port: http
              scheme: HTTP
            initialDelaySeconds: 300
            periodSeconds: 10
            successThreshold: 1
            timeoutSeconds: 5
          name: keycloak
          resources: 
            limits:
              cpu: 2
              memory: 2Gi
            requests: 
              cpu: 2
              memory: 2Gi
          ports:
          - containerPort: 8080
            name: http
            protocol: TCP
          - containerPort: 8443
            name: https
            protocol: TCP
          - containerPort: 9990
            name: http-management
            protocol: TCP
          readinessProbe:
            failureThreshold: 3
            httpGet:
              path: /auth/realms/master
              port: http
              scheme: HTTP
            initialDelaySeconds: 30
            periodSeconds: 10
            successThreshold: 1
            timeoutSeconds: 1
          terminationMessagePath: /dev/termination-log
          terminationMessagePolicy: File
          volumeMounts:
          - mountPath: /opt/jboss/startup-scripts
            name: startup
            readOnly: true
          - mountPath: /opt/jboss/keycloak/modules/system/layers/keycloak/cn/hutool/main
            name: hutool
            readOnly: true
          - mountPath: /opt/jboss/keycloak/standalone/deployments
            name: deployment
            readOnly: false
          #- mountPath: /etc/localtime
          #  name: tz-config
          #  readOnly: false
        dnsPolicy: ClusterFirst
        enableServiceLinks: true
        restartPolicy: Always
        serviceAccountName: default
        serviceAccount: default
        imagePullSecrets:
        - name: user-29732-registrysecret
        schedulerName: default-scheduler
        terminationGracePeriodSeconds: 60
        volumes:
        - configMap:
            defaultMode: 365
            name: keycloak-startup
          name: startup
        - persistentVolumeClaim:
            claimName: keycloak-pvc
          name: hutool
        - persistentVolumeClaim:
            claimName: keycloak-deployment-pvc
          name: deployment
        #- name: tz-config
        #  hostPath:
        #    path: /etc/localtime
    updateStrategy:
      type: RollingUpdate
kind: List

```
