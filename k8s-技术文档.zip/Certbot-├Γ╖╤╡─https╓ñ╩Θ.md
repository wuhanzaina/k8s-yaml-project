# Certbot-免费的https证书

---

* [https://blog.csdn.net/weixin_44520133/article/details/104215066](https://blog.csdn.net/weixin_44520133/article/details/104215066)

---

### 什么是HTTPS？

HTTP：是互联网上应用最为广泛的一种[网络协议](https://so.csdn.net/so/search?q=%E7%BD%91%E7%BB%9C%E5%8D%8F%E8%AE%AE&spm=1001.2101.3001.7020)，是一个客户端和服务器端请求和应答的标准（TCP），用于从WWW服务器传输超文本到本地浏览器的传输协议，它可以使浏览器更加高效，使网络传输减少。

HTTPS：全称：Hyper Text Transfer Protocol over Secure [Socket](https://so.csdn.net/so/search?q=Socket&spm=1001.2101.3001.7020) Layer，则是以安全为目标的HTTP通道，简单讲是HTTP的安全版，即HTTP下加入SSL层，HTTPS的安全基础是SSL，因此加密的详细内容就需要SSL。

HTTPS协议的主要作用可以分为两种：一种是建立一个信息安全[通道](https://so.csdn.net/so/search?q=%E9%80%9A%E9%81%93&spm=1001.2101.3001.7020)，来保证数据传输的安全；另一种就是确认网站的真实性。

### 如何使用HTTPS？

一般情况下，要使用HTTPS协议，需要有一张被信任的 CA （ Certificate Authority ）也就是证书授权中心颁发的 SSL 安全证书，并且将它部署到你的网站服务器上。一旦部署成功后，当用户访问你的网站时，浏览器会在显示的网址前加一把小锁，表明这个网站是安全的，当然同时你也会看到网址前的前缀变成了 https ，不再是 http 了

### https请求

获取SSL证书  
 理论上，我们自己也可以手动制作一个 SSL 安全证书，但是我们自己签发的安全证书浏览器信任，所以我们需要被信任的证书授权中心（ CA ）签发的安全证书。而一般的 SSL 安全证书签发服务都需要付费，且价格昂贵，不过为了加快推广 https 的普及， EEF 电子前哨基金会、 Mozilla 基金会和美国密歇根大学成立了一个公益组织叫 ISRG （ Internet Security Research Group ），这个组织从 2015 年开始推出了 Let’s Encrypt 免费证书。这个免费证书不仅免费，而且还相当好用，所以我们就可以利用 Let’s Encrypt 提供的免费证书部署 https 了。

### Let’s Encrypt

Let’s Encrypt提供了免费的证书申请服务，同时也提供了官方客户端 Certbot，打开首页，就可以得到官方的安装教程。官方教程给出了四种常用服务器和不同的Linux、Unix的安装使用方案，可以说是十分的贴心了。

#### Certbot首页

下面我将会介绍一个通用的安装方案：

1. 获取`certbot-auto`

```bash
wget https://dl.eff.org/certbot-auto
chmod a+x certbot-auto
```

2. 生成证书  
    生成证书前需要关闭服务器

```bash
service nginx stop
./certbot-auto certonly
```

根据提示，输入相关资料后，如打印类似以下内容，即可在/etc/letsencrypt/archive目录下得到证书文件。

成功申请证书  
如果不想一步一步走，也可以直接使用以下命令直接生成。注意xxx需要替换为自己的东西。

```bash
./certbot-auto certonly --standalone --email xxx@xxx.com --agree-tos -d xxx.com -d www.xxx.com
```

```bash
How would you like to authenticate with the ACME CA?
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
1: Nginx Web Server plugin (nginx)
2: Spin up a temporary webserver (standalone)【使用临时Web服务器（独立目录）】
3: Place files in webroot directory (webroot)【将文件放在webroot目录】

【选择3回车】
Plugins selected: Authenticator webroot, Installer None
Enter email address (used for urgent renewal and security notices)964453362@qq.com【输入您的邮箱地址，用于紧急更新和安全通知】

Please read the Terms of Service at
https://letsencrypt.org/documents/LE-SA-v1.2-November-15-2017.pdf. You must
agree in order to register with the ACME server at
https://acme-v02.api.letsencrypt.org/directory
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
(A)gree/(C)ancel: A【选择A回车同意服务条款，C为拒绝】

Would you be willing to share your email address with the Electronic Frontier
Foundation, a founding partner of the Let's Encrypt project and the non-profit
organization that develops Certbot? We'd like to send you email about our work
encrypting the web, EFF news, campaigns, and ways to support digital freedom.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
(Y)es/(N)o: Y 您是否愿意分享您的电子邮件地址，建议选择Y回车】
Please enter in your domain name(s) (comma and/or space separated)  (Enter 'c'
to cancel): mp.wukuy.cn 【输入域名回车】
Obtaining a new certificate
Performing the following challenges:
http-01 challenge for mp.wukuy.cn 
Input the webroot for mp.wukuy.cn: (Enter 'c' to cancel): /usr/local/www/wechat/mp 【输入网站所在绝对路径回车】

```

3.配置证书  
 Nginx中配置SSL证书的配置文件参考如下：

```bash
server { 
    listen  443 ssl;
    server_name xxx.com;
    location / { 
        # ....
    }
    ssl_certificate /etc/letsencrypt/live/xxx.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/xxx.com/privkey.pem;
}
server { 
    listen  80;
    server_name xxx.com;
     location / { 
                # ...
        }
      #如果需要把http强制转换为https，需要配置以下内容
      if ($host = xxx.com) { 
          return 301 https://$host$request_uri;
      } 
}
```

配置完成后，启动Nginx，浏览器中查看效果。

```bash
service nginx start
```

### 自动续订

Certbot可以配置为在证书过期之前自动更新证书。由于Let’s Encrypt SSL证书有效期时间为90天，所以建议您利用此功能。您可以通过运行以下命令来测试证书的自动续订：

```bash
$ ./certbot-auto --nginx certonly
```

如果以上正常工作，你可以通过添加运行以下操作的cron或systemd定时任务安排自动更新：

```bash
./certbot-auto renew
```

我们写一个自动执行脚本，建议每小时执行一次：

```bash
$ sudo crontab -e
```

添加以下内容：

```bash

0 */6 * * * /usr/bin/certbot renew --quiet && /bin/systemctl restart nginx
保存并退出！
```

通过命令查看是否添加成功：

```bash
$ crontab -l
0 */6 * * * /usr/bin/certbot renew --quiet && /bin/systemctl restart nginx
重启crontab
```

```bash
$ systemctl status crond.service
$ systemctl restart crond.service
```

通过命令观察 crontab 是否执行：

```bash
$ tail -f /var/log/cron
```

证书是否续订成功，可以通过以下命令管理查看证书信息：

```bash
$ certbot certificates
```


## Docker CertBot 获取 SSL 证书

参考:  
 https://blog.csdn.net/weixin_34313182/article/details/87948575  
 https://blog.csdn.net/wc810267705/article/details/79917688

```shell
docker run -it --rm --name certbot \
            -v "/etc/letsencrypt:/etc/letsencrypt" \
            -v "/var/lib/letsencrypt:/var/lib/letsencrypt" \
            -v "/data/letsencrypt:/.secrets" \
            certbot/dns-cloudflare certonly \
            --preferred-challenges dns --manual \
            --server https://acme-v02.api.letsencrypt.org/directory \
            -d "*.xxx.cn"
```

签发证书时提示添加TXT记录

```bash
Please deploy a DNS TXT record under the name
_acme-challenge.example.com with the following value:
 
kxxxxxxxxxxxxx_xxxxxxxxxxx_Q
 
Before continuing, verify the record is deployed.
```

在阿里云解析一下TXT记录即可
