# 深入理解Kubelet

---

* [https://blog.csdn.net/chengyinwu/article/details/122998677](https://blog.csdn.net/chengyinwu/article/details/122998677)

---

### 

### kubelet[架构](https://so.csdn.net/so/search?q=%E6%9E%B6%E6%9E%84&spm=1001.2101.3001.7020)

![在这里插入图片描述](assets/fee373da5df74adebab04ad0ede8a418-20220927104406-asmbaqo.png)​

> 架构剖析：  
> 最上边为[API](https://so.csdn.net/so/search?q=API&spm=1001.2101.3001.7020)层，有自己的healthz健康检测机制，只读API暴露metrics。  
> 子系统有ProbeManager（主要做探活，kubelet作为代理，运行在每个节点，功能有2点：a.上报节点信息，b.接收apiserver指令，控制Pod[生命周期](https://so.csdn.net/so/search?q=%E7%94%9F%E5%91%BD%E5%91%A8%E6%9C%9F&spm=1001.2101.3001.7020)），syncLoop组件：watch apiserver，有事件发生时，需要PodWorker确认本地容器进程是否启动。  
> OOMWatcher主要看容器有没有oom状态，结合节点资源状态评估会Kill某些进程。  
> GPUManager主要为GPU计算节点提供服务管理。  
> cAdvisor可以理解为通过cgroup收集容器进程的资源使用量，并且上报；容器资源监控统一主要依赖cadvisor组件实现。  
> DiskSpaceManager：磁盘上空间够不够？  
> StatusManager：监控节点上的状态信息  
> EvictionManager：例如磁盘不足了，mem不足，不可压缩资源不足时，应该要做驱逐操作，用什么行为，主要是这个组件来实现。  
> VolumeManager：跟volume卷相关，管理pod存储等  
> Image/Container GC：看节点上有哪些image和container，那这些还会一直占用磁盘空间，通过GC来进行回收，减少资源利用。  
> Container Runtime Interface：CRI，启动Pod是通过CRI来操作的。  
> CRI有两套运行时，一套docker shim，一套remote Container Runtime。
>

### kubelet管理pod的核心流程

![在这里插入图片描述](assets/d30522d37b6249c5bb4037c5faa485fe-20220927104406-ejjh4ya.png)​

> kubelet它本身也是一个控制器模式，主要关注一些对象的变化，pod update事件，接受3个不同源，file：扫描/etc/kubernetes/manifests目录，静态加载pod，apiserver：配置apiserver地址，拉取资源清单，httpserver：自己启一个http服务，发送pod资源配置清单即可，清单只需Kubelet从endpoints中读取。  
> 加载到Pod清单以后，syncLoop作为消费者，它来检索update事件，通过podworker来操作，其中computePodAction会计算pod做什么action，如果是新pod，会调用CRI的create接口来进行创建，如果是删除pod事件，本地进程又有这个pod，就会触发一个kill动作。  
> pleg：收集当前节点所有信息，会在CRI里边查pod的清单，及Pod运行状态，它会通过pod lifecycle events——》上报至Master节点，有这种events之后，master节点就会很清楚的知道pod的状况。
>

### Kubelet

![在这里插入图片描述](assets/0a7025f9061e4b09b77f32d0b0c31115-20220927104406-tm8rhip.png)​

### 节点管理

![在这里插入图片描述](assets/0d0131e1391647618d551ccd4c4b1847-20220927104406-kebu93f.png)​

### Pod管理

![在这里插入图片描述](assets/e8dd07c0fbde4f8393501db8915726f3-20220927104406-085pf4i.png)​

### Pod启动流程

![在这里插入图片描述](assets/7790d59e364c473ca65f950e524cb839-20220927104406-dldm6t3.png)​

> 作为一个用户，例如：控制器或者命令行kubectl操作创建一个pod，会被apiserver接收，apiserver经过认证鉴权之后会把Pod清单信息存入etcd，用户会得到一个create事件，这时就可以看Pod的创建状态了，Scheduler组件会watch pod变化，做一个bind pod操作，把pod和Node做关联关系绑定，同样bind操作也会存入etcd，这时kubelet组件watch apiserver（已经bound好的Pod），computeaction，如果它发现是新建Pod，就会调用containerd或者CRI接口里的RunPodSandbox api，container就会调用网络插件SetupPod，会返回结果告诉kubelet节点的Ip是多少？kubelet就会告知apiserver节点的ip已配置好，kubelet接着会去Pull image，create container，start container，把真正的状态返回给apiserver，这个信息回写到etcd，这个就是整个启动过程
>

> 其他：  
> k8s里的容器是一组pod组成，默认共享namespace，存储等，k8s在此之上引出一个sandbox概念，比如：启动一个nginx pod，它不会先启动nginx，它会先启动一个sandbox container（pause镜像），pause永远是一个sleep状态，它不会有任何资源开销，非常稳定的一个进程，k8s把sandbox作为一个底座加入，利用它的稳定性，把namespace挂给它，网络配置等，回归nginx pod，它本身是有资源开销，例如出现oom，如果把网络配置在nginx，挂掉就会影响；在主容器启动过程中，需要有一个网络就绪的条件，有了sandbox之后，所有网络都是配置在它本身。
>


### kubelet启动pod的流程（细）

![在这里插入图片描述](assets/f4df4f08c820429193e161c4c7bd1131-20220927104406-y1htlqw.png)​
