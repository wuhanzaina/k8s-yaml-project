# 清理Docker容器、镜像、数据卷和网络

---

* [https://blog.csdn.net/u012516914/article/details/108892039](https://blog.csdn.net/u012516914/article/details/108892039)

---

## 总纲:

```
# 清理缓存
docker image prune -a  -f
docker container prune -f
docker volume prune
docker network prune
docker system prune
```

```
# 清理已经停止的容器
docker rm -v $(docker ps --all --quiet --filter 'status=exited')
这会找到所有处于已退出（exited）状态的容器，一行一个地输出它们的 ID，以便我们可以将它提供给其它 shell 指令。
我们使用 docker rm -v 来删除任何匿名卷（没有显式名称的卷）。

# 清理磁盘卷
上面的命令应该删除与该容器关联的卷。如果你手动创建卷，并要删除任何未被使用的卷：
docker volume rm $(docker volume ls --quiet --filter 'dangling=true')

# 清理镜像
通常删除所有 Docker 镜像是安全的。我们可以在需要的时候按需获取。通常在一个镜像被清理后，构建时间会更长，因为 docker 守护进程需要花时间再次下载镜像
docker rm --force $(docker images --quiet)
这里，我们使用了 --force 来强制删除镜像，即使一个容器正在使用那个镜像。我们可以以后再获取这个镜像。

# 清理网络
这很简单。我们可以删除任何网络，它会在之后按需重建。
docker network rm $(docker network ls --quiet)

```


### 无法删除网络error

```

[root@harbor harbor]# docker network ls
NETWORK ID          NAME                DRIVER              SCOPE
93f0ec306ab5        bridge              bridge              local
821031255cda        harbor_harbor       bridge              local
[root@harbor harbor]# docker network rm 821031255cda
Error response from daemon: error while removing network: network harbor_harbor id 821031255cdaf4909913c8a1c9451db461e898a877661564f59cd13f4d0d68b5 has active endpoints

# 关联网络删除再重新创建
docker network disconnect-f bridge 容器名字
```


### 统一设置容器日志

```
# docker统一设置日志
{
  "log-driver":"json-file",
  "log-opts": {"max-size":"5g", "max-file":"3"}
}

```


 [Docker](https://so.csdn.net/so/search?q=Docker&spm=1001.2101.3001.7020)是一个开放源代码的容器化平台，可让您快速构建，测试和部署应用程序，而且是可以在任何地方运行的便携式容器。

 使用Docker时，您会快速累积大量未使用的对象，这些对象会占用大量磁盘空间，并使Docker命令产生的输出混乱。除非明确指令，否则Docker不会删除未使用的对象，例如容器、镜像、数据卷和网络。

 本指南是一个备忘单，可通过删除未使用的Docker容器、镜像、数据卷和网络来帮助Docker用户保持系统有序、并释放磁盘空间。

## 删除所有未使用的Docker对象

 该`docker system prune`命令会删除所有停止的容器，dangling的镜像和未使用的网络：

```go
docker system prune
```

 该命令将提示您确认操作：

```go
WARNING! This will remove:
        - all stopped containers
        - all networks not used by at least one container
        - all dangling images
        - all build cache
Are you sure you want to continue? [y/N]
```

 使用-f或--force选项绕过提示。默认情况下，该命令不会删除未使用的卷以防止丢失重要数据。要删除所有未使用的卷，请传递--volumes选项：

```go
docker system prune --volumes
```

```go
WARNING! This will remove:
        - all stopped containers
        - all networks not used by at least one container
        - all volumes not used by at least one container
        - all dangling images
        - all build cache
Are you sure you want to continue? [y/N] y
```

## 删除Docker容器

 停止使用Docker容器时，不会自动删除它们，除非使用--rm标志启动容器。

## 删除一个或多个容器

 要删除一个或多个Docker容器，请使用`docker container rm`命令，后跟要删除的容器的ID。

 通过使用以下选项调用命令，可以获得所有容器的列表：`docker container ls -a`

```go
docker container ls -a
```

 输出应如下所示：

```go
CONTAINER ID        IMAGE                   COMMAND                  CREATED             STATUS                      PORTS               NAMES
cc3f2ff51cab        centos                  "/bin/bash"              2 months ago        Created                                         competent_nightingale
cd20b396a061        solita/ubuntu-systemd   "/bin/bash -c 'exec …"   2 months ago        Exited (137) 2 months ago                       systemd
fb62432cf3c1        ubuntu                  "/bin/bash"              3 months ago        Exited (130) 3 months ago                       jolly_mirzakhani
```

 知道CONTAINER ID要删除的容器后，将其传递给`docker container rm`命令。例如，要删除上面输出中列出的前两个容器，可以运行：

```go
docker container rm cc3f2ff51cab cd20b396a061
```

 如果收到类似于以下所示的错误消息，则表明该容器正在运行。您需要先停止容器，然后再移除它。

```go
Error response from daemon: You cannot remove a running container fc983ebf4771d42a8bd0029df061cb74dc12cb174530b2036987575b83442b47. Stop the container before attempting removal or force remove.
```

## 删除所有停止的容器

 要删除所有停止的容器，请使用以下`docker container prune`命令：

```go
docker container prune
```

```go
WARNING! This will remove all stopped containers.
Are you sure you want to continue? [y/N] y
```

 为避免出现提示，请使用-f或--force选项。

 如果要获取将通过删除的所有非运行（停止）容器的列表`docker container prune`，请使用以下命令：

```go
docker container ls -a --filter status=exited --filter status=created 
```

## 使用过滤器取出容器

 该`docker container prune`命令允许您使用该--filter选项根据特定条件删除容器。在撰写本文时，当前支持的过滤器为until和label。您可以使用多个--filter选项来指定多个过滤器。例如，要删除所有在12小时前创建的图像，请运行：

```go
docker container prune --filter "until=12h"
```

## 停止并取出所有容器

 要停止所有正在运行的容器，请使用`docker container stop`命令，后跟容器ID：

```go
docker container stop $(docker container ls -aq)
```

 该命令`docker container ls -aq`生成所有容器的列表。一旦停止所有容器，请使用`docker container rm`命令，然后是容器ID列表，将其删除。

```go
docker container rm $(docker container ls -aq)
```

## 删除Docker镜像

 当您下载Docker镜像时，它将一直保存在服务器上，直到您手动将其删除为止。

## 删除一个或多个镜像

 要删除一个或多个Docker镜像，首先需要找到镜像的ID：

```go
docker image ls
```

 输出应如下所示：

```go
REPOSITORY              TAG                 IMAGE ID            CREATED             SIZE
centos                  latest              75835a67d134        7 days ago          200MB
ubuntu                  latest              2a4cca5ac898        2 months ago        111MB
linuxize/fedora         latest              a45d6dca3361        3 months ago        311MB
java                    8-jre               e44d62cf8862        3 months ago        311MB
```

 找到要删除的镜像后，将其IMAGE ID传递给`docker image rm`命令。例如，要删除上面输出中列出的前两个镜像，可以运行：

```go
docker image rm 75835a67d134 2a4cca5ac898
```

 如果收到以下错误消息，则表明现有容器正在使用该镜像。要删除镜像，您必须先删除容器。

```go
Error response from daemon: conflict: unable to remove repository reference "centos" (must force) - container cd20b396a061 is using its referenced image 75835a67d134
```

## 删除dangling的镜像

 Docker提供了一个docker image prune命令，可用于删除dangling的和未使用的镜像。

 dangling镜像是未标记且未被任何容器使用的镜像。要删除dangling的镜像，请输入：

```go
docker image prune
```

```go
WARNING! This will remove all dangling images.
Are you sure you want to continue? [y/N] y
```

 使用-f或--force选项绕过提示。

> “  
> 运行此命令时要小心。如果构建的镜像没有标签，则将其删除
>
> ”
>

## 删除所有未使用的镜像

 要删除所有现有容器未引用的所有镜像，而不仅仅是dangling的容器，请使用prune带有以下-a选项的命令：

```go
docker image prune -a
```

```go
WARNING! This will remove all images without at least one container associated to them.
Are you sure you want to continue? [y/N] y
```

## 使用过滤器删除镜像

 使用该`docker image prune`命令，您还可以使用该--filter选项根据特定条件删除镜像。

 在撰写本文时，当前支持的过滤器为until和label。您可以使用多个过滤器。

 例如，要删除所有在超过七天（168小时）之前创建的镜像，请运行：

```go
docker image prune -a --filter "until=12h"
```

## 删除Docker数据卷

## 删除一个或多个卷

 要删除一个或多个Docker卷，请运行`docker volume ls`命令以查找要删除的卷的ID。

```go
docker volume ls
```

 输出应如下所示：

```go
DRIVER              VOLUME NAME
local               4e12af8913af888ba67243dec78419bf18adddc3c7a4b2345754b6db64293163
local               terano
```

 找到VOLUME NAME要删除的卷后，将它们传递给`docker volume rm`命令。例如，要除去上面输出中列出的第一个卷，请运行：

```go
docker volume rm 4e12af8913af888ba67243dec78419bf18adddc3c7a4b2345754b6db64293163
```

 如果您收到与以下所示类似的错误，则表明现有容器正在使用该卷。要删除该卷，您必须先删除该容器。

```go
Error response from daemon: remove 4e12af8913af888ba67243dec78419bf18adddc3c7a4b2345754b6db64293163: volume is in use - [c7188935a38a6c3f9f11297f8c98ce9996ef5ddad6e6187be62bad3001a66c8e]
```

## 删除所有未使用的卷

 要删除所有未使用的卷，请使用以下docker image prune命令：

```go
docker volume prune
```

```go
WARNING! This will remove all local volumes not used by at least one container.
Are you sure you want to continue? [y/N]
```

 使用-f或--force选项绕过提示。

## 删除Docker网络

## 删除一个或多个网络

 要删除一个或多个Docker网络，请使用`docker network ls`命令查找要删除的网络的ID。

```go
docker network ls
```

 输出应如下所示：

```go
NETWORK ID          NAME                DRIVER              SCOPE
107b8ac977e3        bridge              bridge              local
ab998267377d        host                host                local
c520032c3d31        my-bridge-network   bridge              local
9bc81b63f740        none                null                local
```

 找到要删除的网络后，将其NETWORK ID传递给docker network rm命令。例如，删除名称为my-bridge-networkrun的网络：

```go
docker network rm c520032c3d31
```

 如果收到与以下所示类似的错误，则表明现有容器正在使用该网络。要删除网络，必须先删除容器。

```go
Error response from daemon: network my-bridge-network id 6f5293268bb91ad2498b38b0bca970083af87237784017be24ea208d2233c5aa has active endpoints
```

## 删除所有未使用的网络

 使用docker network prune命令删除所有未使用的网络。

```go
docker network prune
```

 系统将提示您继续：

```go
WARNING! This will remove all networks not used by at least one container.
Are you sure you want to continue? [y/N] 
```

 使用-f或--force选项绕过提示。

## 使用过滤器删除网络

 使用该`docker network prune`命令，可以使用--filter选项根据条件删除网络。

 在撰写本文时，当前支持的过滤器为until和label。您可以使用多个--filter选项来使用多个过滤器。例如，要删除在12个小时前创建的所有网络，请运行：

```go
docker network prune -a --filter "until=12h"
```


## 使用 docker-compose 清理

如果你使用 docker-compose 启动容器，我们有一种简单的方法来清理与特定 compose 文件关联的资源。

```
docker-compose down --volumes --rmi all --remove-orphans
```

不幸的是，这个命令不会删除匿名卷，因此你必须处理这些匿名卷。

## 一条命令解决所有问题

docker 是短暂的，我们总是可以重新获取镜像，为了开发重新创建我们的数据库，或者这只是一个持续集成系统，我们可以删除一切。

```
docker system prune --all --force --volumes
```


## 结论

 在本指南中，向您展示了一些用于删除Docker容器、镜像、数据卷和网络的常用命令。如有任何疑问，请在下面发表评论。
