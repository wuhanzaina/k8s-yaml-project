# 使用Harbor作为Chart仓库

---

* [https://www.cnblogs.com/LiuChang-blog/p/15468505.html](https://www.cnblogs.com/LiuChang-blog/p/15468505.html)

---

前提条件: 先部署 harbor 仓库，这里省略步骤，我当前的 harbor 仓库版本为 1.9.1。  
Harbor 是一个主流的镜像仓库系统，在 v1.6 版本以后的 harbor 中新增加了 helm charts 的管理功能，可以存储Chart文件。

**1 启用Harbor的Chart仓库服务**

```
这里在 harbor 服务器上操作
# cd /usr/local/harbor/
# ./install.sh --with-chartmuseum
​
启用后，默认项目就带有helm charts功能了。我这里创建一个名为lc_chart的私有仓库。
如果harbor安装之后需要启用helm则执行
# docker-compose down
# ./install.sh --with-chartmuseum

```

**2 安装push插件**

```
(1) 我这里使用的helm 版本为 helm-v3.7.1，helm 中已经集成了push 插件，但是由于helm 版本过高导致 helm 集成的 push 插件
不能连接 harbor 仓库，我这里使用二进制版本的push 插件。
参考: https://github.com/chartmuseum/helm-push/issues/109
​
(2) heml push 插件二进制安装
# helm push插件的 github 项目地址
https://github.com/chartmuseum/helm-push
1) 在线安装
# helm plugin install https://github.com/chartmuseum/helm-push
​
2) 离线安装
# wget https://github.com/chartmuseum/helm-push/releases/download/v0.10.1/helm-push_0.10.1_linux_amd64.tar.gz
# mkdir -p helm-push/
# tar -xzf helm-push_0.10.1_linux_amd64.tar.gz -C helm-push/
​
# 查看 helm 插件的存放路径
# helm env
......
HELM_PLUGINS="/root/.local/share/helm/plugins"
​
# 创建插件目录
# mkdir -p /root/.local/share/helm/plugins
​
# 复制插件到插件目录
# cp -a helm-push/ /root/.local/share/helm/plugins/
```

**3 添加repo**

```
# helm repo add harbor_lc_chart --username admin --password Harbor12345 http://172.16.1.61/chartrepo/lc_chart
# helm repo update
# helm repo list
NAME           URL                                  
harbor_lc_charthttp://172.16.1.61/chartrepo/lc_chart
```

**4 推送与安装Chart**

```
(1) 推送
1) 带用户名、密码、仓库url推送
# helm cm-push demo-0.1.0.tgz --username admin --password Harbor12345 http://172.16.1.61/chartrepo/lc_chart
Pushing demo-0.1.0.tgz to http://172.16.1.61/chartrepo/lc_chart...
Done.
​
2) 根据本地添加认证的仓库推送
# helm cm-push demo-0.1.0.tgz harbor_lc_chart
Pushing demo-0.1.0.tgz to harbor_lc_chart...
Done.
​
(2) 查看推送到harbor上的chart

(3) 部署Chart
1) 下载后部署
# helm pull --version 0.1.0 harbor_lc_chart/demo
# helm install web demo-0.1.0.tgz -n default

2) 在线部署
# helm install web --version 0.1.0 harbor_lc_chart/demo -n default

```
