# 深入理解Kube-Proxy

---

* [https://yinwu.blog.csdn.net/article/details/114521680](https://yinwu.blog.csdn.net/article/details/114521680?spm=1001.2014.3001.5502)

---

### 1.理解Netfilter和[Iptables](https://so.csdn.net/so/search?q=Iptables&spm=1001.2101.3001.7020)

![在这里插入图片描述](assets/20210308095210315-20221008134111-jnjyok1.png)  
 Kube-proxy主要功能：服务发现与[负载均衡](https://so.csdn.net/so/search?q=%E8%B4%9F%E8%BD%BD%E5%9D%87%E8%A1%A1&spm=1001.2101.3001.7020)  
 Kube-proxy是如何将clusterip转换为Podip？并且将流量路由到Pod的？其实是间接通过Linux内核（Netfliter和iptables）来实现地址转换和流量路由，Netfilter是Linux支持的一种钩子方法，它允许内核的其他模块注册各种回调方法，这些方法可以截获网络包并且可以改变目标路由；  
 iptables是一组用户空间程序，通过它可以设置Netfilter路由规则，这些Iptables规则可以检查、转发、修改、重定向或者丢弃IP网络包，简单讲，iptables是Netfilter的用户空间态接口。  
 ![在这里插入图片描述](assets/20210308095331513-20221008134111-y50cskz.png)​

### 2.Kube-Proxy的三种工作模式

#### 2.1 用户空间代理模式（Userspace Proxy Mode）

![在这里插入图片描述](assets/20210308100338710-20221008134111-gxq00mm.png)  
 =原理剖析：=

> 1.kube-proxy首先会监听Master节点服务的创建、删除等相关事件，同时也监听服务背后端点pod的地址；  
> 2.当有一个类型为clusterip服务被创建时，kube-proxy会在节点上边开启一个随机端口（10.100.0.2:10400），通过这个端口可以将对应的请求转发到目标的Pod  
> 3.kube-proxy会通过iptables设置转发规则，让Netfilter接收到目标为Clusterip+port（10.104.14.67:80）就转发到上一步开启的随机端口，如果后端Pod发送变化的话，kube-proxy也会同步这种变化  
> 4.当节点上边有运行客户端调用Cluster ip时  
> 5.这个请求会被Netfilter截获，并且转发到上一步创建的ip+port上  
> 6.kube-proxy接收到请求时，就会采用负载均衡方式将请求转发到后端pod
>

以上流程1~3步可以理解为服务发现阶段，4~6可以理解为运行调用阶段，这种模式属于穿透模式，它涉及到众多的上下文切换，当有请求转发到代理的端口时，kube-proxy必须要切换到内核模式去接收包，然后切换到用户空间进行负载均衡调用，因为负载均衡策略并没有设置在Netfilter当中，它是由用户空间的kube-proxy直接来完成的，由于频繁的上下文切换，这种模式的性能并不是很理想。

#### 2.2 Iptables模式

![在这里插入图片描述](assets/20210308103148929-20221008134111-wknufj1.png)  
 =原理剖析：=

> 1.kube-proxy监听Master服务的创建、删除等事件，也会监听后端Pod的IP地址  
> 2.当有一个类型为clusterip服务被创建时，kube-proxy通过iptables直接去设置转发规则，让Netfilter接收到目标为服务为Clusterip+端口的请求时（10.104.14.67:80）直接进行负载均衡调用，并且转发到后端的Pod,如果后端Pod发送变化的话，kube-proxy会跟iptables同步这种变化  
> 3.当节点上边有客户端对Cluster+ip发起调用的话  
> 4.这个请求会被Netfilter模块截获进行负载均衡，并且转发到后端目标Pod
>

iptables具有性能高的优点，因为它是不穿透kube-proxy的，它是通过Netfilter iptables直接转发的，相反，它也有一些不足点：  
 1.支持的负载均衡策略比较简单，一般不支持高级负载均衡；  
 2.不具备失效自动重试机制，所以一般会使用就绪探针来进行配合；  
 3.iptables模式适用于中小规模k8s集群，对于大规模k8s集群不太适用，假设有5000个节点的集群，有2000个服务，每个服务启10个Pod，那么大约需要在每个节点同步大约2万条iptables规则，同时在云环境中后端Pod可能会随时变化，也就是iptables规则经常要同步，在大规模下，这个同步会对Linux内核带来巨大的开销，为了支持更大规模集群的支持，k8s从v1.11版本开始引入了一种新的工作模式（IPVS）

#### 2.3 IPVS模式

ipvs是一种Linux内核支持的服务虚拟化技术，它是构建于Netfilter基础之上的，作为内核传输层高性能负载均衡的技术，也是LVS主要的组成技术，它不仅支持robbing负载均衡算法还支持最小连接、目标源hash、最短延迟 等高级路由算法，同时ipvs使用高效的hash算法来存储网络路由规则，相比iptables可以显著减少这些规则的同步开销，可以大大提升集群的扩展规模。  
 ![在这里插入图片描述](assets/20210308105219498-20221008134111-anqem4e.png)  
 原理与Iptables模式类型，此处不赘述了，以上3种模式中，ipvs模式是效率、性能最高，也是最好的，但是它的配置稍有复杂；

### 3.总结和建议

![在这里插入图片描述](assets/2021030810594264-20221008134111-30jtvkd.png)​
