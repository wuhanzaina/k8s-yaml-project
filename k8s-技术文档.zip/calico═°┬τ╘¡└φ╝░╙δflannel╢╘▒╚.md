# calico网络原理及与flannel对比

---

* [https://blog.csdn.net/ganpuzhong42/article/details/77853131](https://blog.csdn.net/ganpuzhong42/article/details/77853131)

        最近在搞paas的内容，也刚接触了[kubernetes](https://so.csdn.net/so/search?q=kubernetes&spm=1001.2101.3001.7020)，都涉及到了网络覆盖的内容，也就是跨主机容器之间的通信，本身docker有原生的跨主机通信方案，但是效率很差。所以出现了一系列的开源组件，如flannel，calico，weave等。这里主要介绍一下calico和fannel

## 一 calico[架构](https://so.csdn.net/so/search?q=%E6%9E%B6%E6%9E%84&spm=1001.2101.3001.7020)

首先请看calico的架构图，如下图。

![](assets/20170413171704693-20220916094328-qr9vkxx)​

calico包括如下重要组件：Felix，etcd，BGP Client，BGP Route Reflector。下面分别说明一下这些组件。

Felix：主要负责路由配置以及ACLS规则的配置以及下发，它存在在每个node节点上。

etcd：分布式键值存储，主要负责网络元数据一致性，确保Calico网络状态的准确性，可以与kubernetes共用；

 BGPClient(BIRD), 主要负责把 Felix写入 kernel的路由信息分发到当前 Calico网络，确保 workload间的通信的有效性；

 BGPRoute Reflector(BIRD), 大规模部署时使用，摒弃所有节点互联的mesh模式，通过一个或者多个 BGPRoute Reflector 来完成集中式的路由分发；

## 二 calico原理

如下图所示，描述了从源容器经过源宿主机，经过数据中心的路由，然后到达目的宿主机最后分配到目的容器的过程。

![](assets/20170413171714990-20220916094328-onyambw)​

整个过程中始终都是根据iptables规则进行路由转发，并没有进行封包，解包的过程，这和flannel比起来效率就会快多了。

## 三 flannel原理

​

## 四 对比

从上述的原理可以看出，flannel在进行路由转发的基础上进行了封包解包的操作，这样浪费了CPU的计算资源。下图是从网上找到的各个开源网络组件的性能对比。可以看出无论是带宽还是网络延迟，calico和主机的性能是差不多的。

![](https://www.youruncloud.com/uploadFiles/images/14%283%29.png)​

原理已经搞得差不多了，那么就应该搭建calico的网络环境了，我基于kubernetes，整合了calico网络，具体的部署方法请见下一篇：kubernetes整合calico网络部署方法。
