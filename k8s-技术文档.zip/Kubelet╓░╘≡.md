# Kubelet职责

---

* [https://copyfuture.com/blogs-details/202207231431449292](https://copyfuture.com/blogs-details/202207231431449292)

---

## kubelet

---

每个节点上都运行一个kubelet服务进程，默认监听10250端口。

* 接收并执行master发来的指令(其实是用watch的机制去监听的，如果这些pod发生了变化，他就会去执行某些操作，具体执行什么样的操作就是管理pod当中的容器)
* 管理Pod及Pod中的容器
* 每个kubelet进程会在APIServer上注册节点自身信息，定期向 master 节点汇报节点的资源使用情况，并通过 cAdvisor 监控节点和容器的资源。（pod健康状态通过pleg去做上报，节点的资源使用情况通过cadvisor上报）

## 节点管理

---

kubelet本身有节点管理的功能，它可以注册节点，更新节点状态，所以在启动kubelet的时候，如果加了register-node，那么就会自动的将当前节点注册到apiserver。

节点管理主要是节点自注册和节点状态更新∶

* kubelet 可以通过设置启动参数--register-node 来确定是否向API Server注册自己
* 如果 kubelet 没有选择自注册模式，则需要用户自己配置Node 资源信息，同时需要告知 kubelet集群上的APIServer的位置
* kubelet在启动时通过APIServer注册节点信息，并定时向APIServer发送节点新消息，APIServer在接收到新消息后，将信息写入etcd。

## Pod管理

---

和节点管理相关更加重要的是pod的管理，因为节点的注册管理是一次性的，然后有kublet不断的上报状态，更重要的是应用的管理，也即是pod。

kubelet如何管理pod？它首先要知道节点上要启动哪些pod，这就涉及到如何获取pod清单，kubelet有几种方式去获取pod清单，第一种就是文件的方式，也就是static pod，扫描到目录下有pod清单文件，就将这些pod启动起来。

![](assets/202207231431449292_0-20220927103752-04q4ymg.png)​

其次可以通过http endpoint来加载pod，你可以给它一个启动参数叫做manifest-url，这个url是http-endpoint，你把所有pod清单放在那，他也会去读取那个url来加载pod清单。

最后就是apiservre了，当apiserver启动之后，它自己会去启动api网关，kubelet连接到apiserver，会去监听apiserver上面所有的pod，当然是和这个节点相关的，经过调度之后的。（kubelet会去watch apiservre，apiserver那边有pod创建出来了，并且和这个节点相关，这个节点上的kubelet就会去工作）

获取Pod清单∶

* 文件∶启动参数--config指定的配置目录下的文件（默认/etc/Kubernetes/manifests/）。该文件每20秒重新检查一次（可配置）。
* HTTP endpoint（URL）∶启动参数--manifest-url设置。每20秒检查一次这个端点（可配置）。
* APIServer∶通过APIServer监听etcd目录，同步Pod清单。
* HTTP Server∶ kubelet 侦听 HTTP 请求，并响应简单的 API 以提交新的 Pod 清单。
