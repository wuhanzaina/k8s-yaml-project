# 深入理解Kube-Scheduler

---

* [https://yinwu.blog.csdn.net/article/details/122938083](https://yinwu.blog.csdn.net/article/details/122938083?spm=1001.2014.3001.5502)

---

### 调度

kube-[scheduler](https://so.csdn.net/so/search?q=scheduler&spm=1001.2101.3001.7020)负责分配调度Pod到集群内的节点上，它监听kube-apiserver，查询还未分配Node的Pod，然后根据调度策略为这些Pod分配节点（更新Pod的NodeName字段）。  
 调度器需要充分考虑诸多的因素：

* 公平调度
* 资源高效利用
* QoS
* affinity和anti-affinity（亲和性和反亲和性）
* 数据本地化（data locality），适用于大数据领域
* 内部负载干扰（inter-workload interference）
* deadlines

#### 调度器

kube-scheduler调度分为两个阶段，predicate和priority：

* predicate：过滤不符合条件的节点；
* priority：优先级排序，选择优先级最高的节点。

#### Predicates策略

![在这里插入图片描述](assets/7ce7f374119648e2b506fdeb6f202588-20221008133539-rcwm7ul.png)  
 ![在这里插入图片描述](assets/95fe7df171e340e5b45ad470e0abed6f-20221008133539-jaar0l8.png)​

#### Predicates plugin工作原理

![在这里插入图片描述](assets/633824e06e674f3790c59e74f08bea9b-20221008133539-cghmhed.png)​

```yaml
Addresses:
  InternalIP:  192.168.65.4
  Hostname:    docker-desktop
Capacity:	#集群总资源
  cpu:                4
  ephemeral-storage:  61255492Ki
  hugepages-1Gi:      0
  hugepages-2Mi:      0
  hugepages-32Mi:     0
  hugepages-64Ki:     0
  memory:             4027704Ki
  pods:               110
Allocatable:	#可剩余的资源
  cpu:                4
  ephemeral-storage:  56453061334
  hugepages-1Gi:      0
  hugepages-2Mi:      0
  hugepages-32Mi:     0
  hugepages-64Ki:     0
  memory:             3925304Ki
  pods:               110
```

#### Priorities策略

![在这里插入图片描述](assets/2894644b6e344607883a4135ce53705d-20221008133539-mi5zl8m.png)  
 ![在这里插入图片描述](assets/99667bfc1677496ab8bf6c5c65b5165a-20221008133539-mxq5ns6.png)​
